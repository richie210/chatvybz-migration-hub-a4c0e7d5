import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { DollarSign, TrendingUp, Users, Calendar, Download } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { stripePaymentService } from '../../services/stripePaymentService';
import Icon from '../../components/AppIcon';

export default function ChannelMonetizationDashboard() {
  const { user, loading: authLoading, isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const [selectedChannelId, setSelectedChannelId] = useState(null);
  const [channels, setChannels] = useState([]);
  const [revenue, setRevenue] = useState(null);
  const [payouts, setPayouts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    if (authLoading) return;

    if (!isAuthenticated) {
      navigate('/login');
      return;
    }

    loadData();
  }, [authLoading, isAuthenticated, navigate]);

  useEffect(() => {
    if (selectedChannelId) {
      loadChannelRevenue(selectedChannelId);
      loadPayouts(selectedChannelId);
    }
  }, [selectedChannelId]);

  const loadData = async () => {
    try {
      setLoading(true);
      setError(null);

      // Import channelService dynamically to avoid circular dependencies
      const { channelService } = await import('../../services/channelService');
      const result = await channelService?.getMyAdminChannels();
      if (result?.error) throw result?.error;

      setChannels(result?.data || []);
      if (result?.data?.length > 0) {
        setSelectedChannelId(result?.data?.[0]?.id);
      }
    } catch (err) {
      console.error('Error loading channels:', err);
      setError(err?.message);
    } finally {
      setLoading(false);
    }
  };

  const loadChannelRevenue = async (channelId) => {
    try {
      const result = await stripePaymentService?.getChannelRevenue(channelId);
      if (result?.error) throw result?.error;

      setRevenue(result?.data);
    } catch (err) {
      console.error('Error loading revenue:', err);
    }
  };

  const loadPayouts = async (channelId) => {
    try {
      const result = await stripePaymentService?.getCreatorPayouts(channelId);
      if (result?.error) throw result?.error;

      setPayouts(result?.data || []);
    } catch (err) {
      console.error('Error loading payouts:', err);
    }
  };

  const handleSetupStripeConnect = async () => {
    try {
      const result = await stripePaymentService?.setupStripeConnect();
      if (result?.error) throw result?.error;

      // Redirect to Stripe Connect onboarding
      if (result?.data?.url) {
        window.location.href = result?.data?.url;
      }
    } catch (err) {
      console.error('Error setting up Stripe Connect:', err);
      setError(err?.message);
    }
  };

  const handleRequestPayout = async () => {
    if (!selectedChannelId || !revenue?.totals?.totalEarnings) return;

    try {
      const result = await stripePaymentService?.requestPayout(
        selectedChannelId,
        revenue?.totals?.totalEarnings
      );
      if (result?.error) throw result?.error;

      alert('Payout requested successfully!');
      loadPayouts(selectedChannelId);
    } catch (err) {
      console.error('Error requesting payout:', err);
      setError(err?.message);
    }
  };

  if (authLoading || loading) {
    return (
      <div className="flex items-center justify-center h-screen bg-gray-50">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading monetization data...</p>
        </div>
      </div>
    );
  }

  const selectedChannel = channels?.find(c => c?.id === selectedChannelId);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-green-600 to-green-700 text-white p-6 shadow-lg">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center gap-3 mb-4">
            <Icon name="DollarSign" size={32} />
            <div>
              <h1 className="text-2xl font-bold">Channel Monetization</h1>
              <p className="text-green-100">Track revenue, subscriptions, and payouts</p>
            </div>
          </div>

          {/* Channel Selector */}
          {channels?.length > 0 && (
            <select
              value={selectedChannelId || ''}
              onChange={(e) => setSelectedChannelId(e?.target?.value)}
              className="w-full md:w-auto px-4 py-2 rounded-lg text-gray-900 focus:outline-none focus:ring-2 focus:ring-green-300"
            >
              {channels?.map((channel) => (
                <option key={channel?.id} value={channel?.id}>
                  {channel?.name}
                </option>
              ))}
            </select>
          )}
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-6">
        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-6">
            {error}
          </div>
        )}

        {/* Revenue Overview Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-gray-600 text-sm">Total Earnings</span>
              <Icon name="DollarSign" size={20} className="text-green-500" />
            </div>
            <p className="text-3xl font-bold text-gray-900">
              {stripePaymentService?.formatAmount(revenue?.totals?.totalEarnings || 0)}
            </p>
            <p className="text-sm text-gray-500 mt-1">Last 30 days</p>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-gray-600 text-sm">Subscription Revenue</span>
              <Icon name="TrendingUp" size={20} className="text-blue-500" />
            </div>
            <p className="text-3xl font-bold text-gray-900">
              {stripePaymentService?.formatAmount(revenue?.totals?.subscriptionRevenue || 0)}
            </p>
            <p className="text-sm text-gray-500 mt-1">
              {revenue?.subscriptions?.length || 0} active subscribers
            </p>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-gray-600 text-sm">Ad Revenue</span>
              <Icon name="TrendingUp" size={20} className="text-purple-500" />
            </div>
            <p className="text-3xl font-bold text-gray-900">
              {stripePaymentService?.formatAmount(revenue?.totals?.adRevenue || 0)}
            </p>
            <p className="text-sm text-gray-500 mt-1">From platform ads</p>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-gray-600 text-sm">MRR</span>
              <Icon name="Calendar" size={20} className="text-orange-500" />
            </div>
            <p className="text-3xl font-bold text-gray-900">
              {stripePaymentService?.formatAmount(revenue?.totals?.monthlyRecurringRevenue || 0)}
            </p>
            <p className="text-sm text-gray-500 mt-1">Monthly recurring</p>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-4 mb-6 border-b border-gray-200">
          <button
            onClick={() => setActiveTab('overview')}
            className={`pb-3 px-4 font-medium transition-colors ${
              activeTab === 'overview' ?'text-green-600 border-b-2 border-green-600' :'text-gray-600 hover:text-green-600'
            }`}
          >
            Overview
          </button>
          <button
            onClick={() => setActiveTab('payouts')}
            className={`pb-3 px-4 font-medium transition-colors ${
              activeTab === 'payouts' ?'text-green-600 border-b-2 border-green-600' :'text-gray-600 hover:text-green-600'
            }`}
          >
            Payouts
          </button>
        </div>

        {/* Overview Tab */}
        {activeTab === 'overview' && (
          <div className="space-y-6">
            {/* Revenue Breakdown */}
            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="text-lg font-bold text-gray-900 mb-4">Revenue Breakdown</h3>
              <div className="space-y-4">
                {revenue?.revenueSplits?.map((split) => (
                  <div key={split?.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div>
                      <p className="font-medium text-gray-900 capitalize">{split?.revenue_type}</p>
                      <p className="text-sm text-gray-600">
                        {new Date(split?.period_start)?.toLocaleDateString()} - {new Date(split?.period_end)?.toLocaleDateString()}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-lg font-bold text-gray-900">
                        {stripePaymentService?.formatAmount(split?.creator_earnings, split?.currency)}
                      </p>
                      <p className="text-sm text-gray-600">
                        {split?.transaction_count} transactions
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Active Subscriptions */}
            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="text-lg font-bold text-gray-900 mb-4">Active Subscriptions</h3>
              <div className="space-y-3">
                {revenue?.subscriptions?.map((sub) => (
                  <div key={sub?.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <Icon name="Users" size={20} className="text-blue-500" />
                      <span className="text-gray-900">{sub?.tier_id?.name}</span>
                    </div>
                    <span className="font-medium text-gray-900">
                      {stripePaymentService?.formatAmount(sub?.tier_id?.price, sub?.tier_id?.currency)}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Payouts Tab */}
        {activeTab === 'payouts' && (
          <div className="space-y-6">
            <div className="bg-white rounded-lg shadow p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-bold text-gray-900">Payout History</h3>
                <button
                  onClick={handleRequestPayout}
                  disabled={!revenue?.totals?.totalEarnings || revenue?.totals?.totalEarnings < 50}
                  className="bg-green-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
                >
                  <Icon name="Download" size={20} />
                  <span>Request Payout</span>
                </button>
              </div>

              {payouts?.length === 0 ? (
                <div className="text-center py-12">
                  <Icon name="DollarSign" size={64} className="mx-auto text-gray-300 mb-4" />
                  <p className="text-gray-500">No payouts yet</p>
                  <p className="text-sm text-gray-400 mt-2">Minimum payout amount: $50</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {payouts?.map((payout) => (
                    <div key={payout?.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div>
                        <p className="font-medium text-gray-900">
                          {stripePaymentService?.formatAmount(payout?.amount, payout?.currency)}
                        </p>
                        <p className="text-sm text-gray-600">
                          {new Date(payout?.created_at)?.toLocaleDateString()}
                        </p>
                      </div>
                      <span
                        className={`px-3 py-1 rounded-full text-sm font-medium ${
                          payout?.status === 'paid' ?'bg-green-100 text-green-700'
                            : payout?.status === 'processing' ?'bg-blue-100 text-blue-700'
                            : payout?.status === 'failed' ?'bg-red-100 text-red-700' :'bg-gray-100 text-gray-700'
                        }`}
                      >
                        {payout?.status}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {channels?.length === 0 && (
          <div className="text-center py-12">
            <Icon name="DollarSign" size={64} className="mx-auto text-gray-300 mb-4" />
            <p className="text-gray-500 text-lg">No channels found</p>
            <p className="text-gray-400 text-sm mt-2">Create a channel to start monetizing</p>
          </div>
        )}
      </div>
    </div>
  );
}