import React, { useState } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Clock, Calendar } from 'lucide-react';

function UsageTrendsChart({ hourlyData, weeklyData, peakHour, peakDay }) {
  const [activeView, setActiveView] = useState('hourly');

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-2">
          <Clock className="w-5 h-5 text-indigo-600" />
          <h3 className="text-lg font-semibold text-gray-900">Usage Patterns</h3>
        </div>
        <div className="flex items-center space-x-2">
          <button
            onClick={() => setActiveView('hourly')}
            className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
              activeView === 'hourly' ?'bg-blue-600 text-white' :'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Hourly
          </button>
          <button
            onClick={() => setActiveView('weekly')}
            className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
              activeView === 'weekly' ?'bg-blue-600 text-white' :'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Weekly
          </button>
        </div>
      </div>

      {/* Peak Usage Info */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="p-4 bg-gradient-to-br from-blue-50 to-indigo-50 rounded-lg">
          <div className="flex items-center space-x-2 mb-2">
            <Clock className="w-4 h-4 text-blue-600" />
            <span className="text-xs font-medium text-blue-600">Peak Hour</span>
          </div>
          <p className="text-2xl font-bold text-gray-900">{peakHour}</p>
        </div>
        <div className="p-4 bg-gradient-to-br from-purple-50 to-pink-50 rounded-lg">
          <div className="flex items-center space-x-2 mb-2">
            <Calendar className="w-4 h-4 text-purple-600" />
            <span className="text-xs font-medium text-purple-600">Peak Day</span>
          </div>
          <p className="text-2xl font-bold text-gray-900">{peakDay}</p>
        </div>
      </div>

      {/* Chart */}
      <ResponsiveContainer width="100%" height={300}>
        <BarChart data={activeView === 'hourly' ? hourlyData : weeklyData}>
          <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
          <XAxis 
            dataKey={activeView === 'hourly' ? 'hour' : 'day'}
            stroke="#6b7280"
            fontSize={12}
            angle={activeView === 'hourly' ? -45 : 0}
            textAnchor={activeView === 'hourly' ? 'end' : 'middle'}
            height={activeView === 'hourly' ? 80 : 60}
          />
          <YAxis stroke="#6b7280" fontSize={12} />
          <Tooltip 
            contentStyle={{ backgroundColor: '#fff', border: '1px solid #e5e7eb', borderRadius: '8px' }}
            labelStyle={{ fontWeight: 'bold', marginBottom: '4px' }}
          />
          <Bar 
            dataKey="count" 
            fill="#6366f1" 
            radius={[8, 8, 0, 0]}
            maxBarSize={60}
          />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}

export default UsageTrendsChart;