import React from 'react';
import { Users, Award } from 'lucide-react';

function EngagementTable({ participants }) {
  const formatDuration = (seconds) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    if (hours > 0) return `${hours}h ${minutes}m`;
    return `${minutes}m`;
  };

  const getScoreColor = (score) => {
    if (score >= 80) return 'text-green-600 bg-green-50';
    if (score >= 60) return 'text-blue-600 bg-blue-50';
    if (score >= 40) return 'text-yellow-600 bg-yellow-50';
    return 'text-gray-600 bg-gray-50';
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
      <div className="flex items-center space-x-2 mb-6">
        <Users className="w-5 h-5 text-purple-600" />
        <h3 className="text-lg font-semibold text-gray-900">Top Participants</h3>
      </div>

      {participants && participants?.length > 0 ? (
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-3 px-2 text-xs font-medium text-gray-600 uppercase">Rank</th>
                <th className="text-left py-3 px-2 text-xs font-medium text-gray-600 uppercase">Participant</th>
                <th className="text-center py-3 px-2 text-xs font-medium text-gray-600 uppercase">Calls</th>
                <th className="text-center py-3 px-2 text-xs font-medium text-gray-600 uppercase">Avg Duration</th>
                <th className="text-center py-3 px-2 text-xs font-medium text-gray-600 uppercase">Score</th>
              </tr>
            </thead>
            <tbody>
              {participants?.slice(0, 10)?.map((participant, index) => (
                <tr key={participant?.userId} className="border-b border-gray-100 hover:bg-gray-50">
                  <td className="py-3 px-2">
                    {index === 0 && <Award className="w-5 h-5 text-yellow-500" />}
                    {index === 1 && <Award className="w-5 h-5 text-gray-400" />}
                    {index === 2 && <Award className="w-5 h-5 text-orange-600" />}
                    {index > 2 && <span className="text-sm text-gray-600">{index + 1}</span>}
                  </td>
                  <td className="py-3 px-2">
                    <span className="text-sm font-medium text-gray-900">{participant?.userName}</span>
                  </td>
                  <td className="py-3 px-2 text-center">
                    <span className="text-sm text-gray-700">{participant?.totalCalls}</span>
                  </td>
                  <td className="py-3 px-2 text-center">
                    <span className="text-sm text-gray-700">{formatDuration(participant?.avgDuration)}</span>
                  </td>
                  <td className="py-3 px-2 text-center">
                    <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                      getScoreColor(participant?.engagementScore)
                    }`}>
                      {participant?.engagementScore}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <p className="text-center text-gray-500 py-8">No participant data available</p>
      )}
    </div>
  );
}

export default EngagementTable;