import React from 'react';
import { Calendar } from 'lucide-react';

function DateRangeSelector({ dateRange, onChange }) {
  const presets = [
    { label: 'Last 7 Days', days: 7 },
    { label: 'Last 30 Days', days: 30 },
    { label: 'Last 90 Days', days: 90 }
  ];

  const handlePresetClick = (days) => {
    const end = new Date();
    const start = new Date(Date.now() - days * 24 * 60 * 60 * 1000);
    onChange({
      start: start?.toISOString(),
      end: end?.toISOString()
    });
  };

  return (
    <div className="flex items-center space-x-2">
      <Calendar className="w-4 h-4 text-gray-500" />
      <div className="flex items-center space-x-1">
        {presets?.map((preset) => (
          <button
            key={preset?.days}
            onClick={() => handlePresetClick(preset?.days)}
            className="px-3 py-1.5 text-xs font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 transition-colors"
          >
            {preset?.label}
          </button>
        ))}
      </div>
    </div>
  );
}

export default DateRangeSelector;