import React, { useState } from 'react';
import { Brain, TrendingUp, Users, Target, AlertCircle, CheckCircle, Loader2, Sparkles } from 'lucide-react';

function AIInsightsPanel({ insights, loading, error, onRegenerate }) {
  const [expandedSection, setExpandedSection] = useState('summary');

  if (loading) {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8">
        <div className="flex flex-col items-center justify-center">
          <Loader2 className="w-12 h-12 animate-spin text-blue-600 mb-4" />
          <p className="text-gray-600">Analyzing conversation with Gemini AI...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="flex items-center gap-3 text-red-600 mb-4">
          <AlertCircle className="w-5 h-5" />
          <h3 className="font-semibold">AI Analysis Error</h3>
        </div>
        <p className="text-sm text-red-700 mb-4">{error}</p>
        {onRegenerate && (
          <button
            onClick={onRegenerate}
            className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 transition-colors"
          >
            Retry Analysis
          </button>
        )}
      </div>
    );
  }

  if (!insights) {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8 text-center">
        <Brain className="w-16 h-16 text-gray-400 mx-auto mb-4" />
        <p className="text-gray-600">No AI insights available. Analyze a call to see insights.</p>
      </div>
    );
  }

  const effectivenessScore = insights?.effectiveness_details?.effectiveness_score || 0;
  const sentimentScore = insights?.participant_sentiment?.sentiment_balance || 0;

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-br from-blue-50 to-purple-50 rounded-xl shadow-sm border border-blue-200 p-6">
        <div className="flex items-center gap-3 mb-4">
          <div className="p-2 bg-blue-600 rounded-lg">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <h2 className="text-xl font-bold text-gray-900">AI-Powered Insights</h2>
        </div>
        <p className="text-sm text-gray-700">{insights?.automated_insights?.summary}</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2 bg-green-100 rounded-lg">
              <Target className="w-5 h-5 text-green-600" />
            </div>
            <h3 className="font-semibold text-gray-900">Effectiveness</h3>
          </div>
          <div className="flex items-end gap-2 mb-2">
            <span className="text-4xl font-bold text-gray-900">{effectivenessScore}</span>
            <span className="text-lg text-gray-600 mb-1">/100</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2 mb-3">
            <div
              className="bg-green-600 h-2 rounded-full transition-all duration-500"
              style={{ width: `${effectivenessScore}%` }}
            />
          </div>
          <p className="text-sm text-gray-600">
            {insights?.effectiveness_details?.communication_clarity?.notes}
          </p>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2 bg-blue-100 rounded-lg">
              <Users className="w-5 h-5 text-blue-600" />
            </div>
            <h3 className="font-semibold text-gray-900">Sentiment</h3>
          </div>
          <div className="flex items-end gap-2 mb-2">
            <span className="text-4xl font-bold text-gray-900">
              {Math.round(sentimentScore * 100)}
            </span>
            <span className="text-lg text-gray-600 mb-1">%</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2 mb-3">
            <div
              className="bg-blue-600 h-2 rounded-full transition-all duration-500"
              style={{ width: `${sentimentScore * 100}%` }}
            />
          </div>
          <p className="text-sm text-gray-600">
            Overall: {insights?.participant_sentiment?.overall_call_sentiment}
          </p>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2 bg-purple-100 rounded-lg">
              <TrendingUp className="w-5 h-5 text-purple-600" />
            </div>
            <h3 className="font-semibold text-gray-900">Engagement</h3>
          </div>
          <div className="space-y-2">
            {insights?.conversation_patterns?.speaking_distribution?.slice(0, 2)?.map((participant, idx) => (
              <div key={idx}>
                <div className="flex items-center justify-between text-sm mb-1">
                  <span className="text-gray-700">{participant?.participant}</span>
                  <span className="font-medium text-gray-900">{participant?.percentage}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-1.5">
                  <div
                    className="bg-purple-600 h-1.5 rounded-full"
                    style={{ width: `${participant?.percentage}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-bold text-gray-900 mb-4">Key Takeaways</h3>
        <div className="space-y-2">
          {insights?.automated_insights?.key_takeaways?.map((takeaway, idx) => (
            <div key={idx} className="flex items-start gap-3">
              <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
              <p className="text-sm text-gray-700">{takeaway}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-bold text-gray-900 mb-4">Action Items</h3>
        <div className="space-y-3">
          {insights?.automated_insights?.action_items?.map((item, idx) => (
            <div key={idx} className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
              <div className="flex-shrink-0 w-6 h-6 bg-blue-600 text-white rounded-full flex items-center justify-center text-xs font-bold">
                {idx + 1}
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium text-gray-900 mb-1">{item?.task}</p>
                <div className="flex items-center gap-4 text-xs text-gray-600">
                  {item?.owner && <span>Owner: {item?.owner}</span>}
                  {item?.deadline && <span>Due: {item?.deadline}</span>}
                  <span className={`px-2 py-0.5 rounded-full ${
                    item?.priority === 'high' ? 'bg-red-100 text-red-700' :
                    item?.priority === 'medium'? 'bg-yellow-100 text-yellow-700' : 'bg-green-100 text-green-700'
                  }`}>
                    {item?.priority}
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {insights?.automated_insights?.risks?.length > 0 && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-bold text-gray-900 mb-4">Risks & Concerns</h3>
          <div className="space-y-2">
            {insights?.automated_insights?.risks?.map((risk, idx) => (
              <div key={idx} className="flex items-start gap-3 p-3 bg-red-50 rounded-lg">
                <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                <div className="flex-1">
                  <p className="text-sm text-gray-900">{risk?.risk}</p>
                  <span className={`inline-block mt-1 px-2 py-0.5 text-xs rounded-full ${
                    risk?.severity === 'high' ? 'bg-red-100 text-red-700' :
                    risk?.severity === 'medium'? 'bg-yellow-100 text-yellow-700' : 'bg-blue-100 text-blue-700'
                  }`}>
                    {risk?.severity} severity
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {insights?.automated_insights?.opportunities?.length > 0 && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-bold text-gray-900 mb-4">Opportunities</h3>
          <div className="space-y-2">
            {insights?.automated_insights?.opportunities?.map((opportunity, idx) => (
              <div key={idx} className="flex items-start gap-3">
                <TrendingUp className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
                <p className="text-sm text-gray-700">{opportunity}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

export default AIInsightsPanel;
