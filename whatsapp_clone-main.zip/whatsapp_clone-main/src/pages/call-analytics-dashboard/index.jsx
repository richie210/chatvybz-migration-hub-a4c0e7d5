import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { BarChart3, Phone, Users, Video, TrendingUp, Clock, Loader2, Sparkles } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { callAnalyticsService } from '../../services/callAnalyticsService';
import { processCallWithAI } from '../../services/geminiAnalyticsService';
import MetricsCard from './components/MetricsCard';
import CallVolumeChart from './components/CallVolumeChart';
import EngagementTable from './components/EngagementTable';
import UsageTrendsChart from './components/UsageTrendsChart';
import DateRangeSelector from './components/DateRangeSelector';
import AIInsightsPanel from './components/AIInsightsPanel';

function CallAnalyticsDashboard() {
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [dashboardData, setDashboardData] = useState(null);
  const [dateRange, setDateRange] = useState({
    start: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)?.toISOString(),
    end: new Date()?.toISOString()
  });
  const [aiInsights, setAiInsights] = useState(null);
  const [aiLoading, setAiLoading] = useState(false);
  const [aiError, setAiError] = useState('');
  const [showAIPanel, setShowAIPanel] = useState(false);

  useEffect(() => {
    if (!authLoading && !user) {
      navigate('/login');
    }
  }, [user, authLoading, navigate]);

  useEffect(() => {
    if (!authLoading && user) {
      loadDashboardData();
    }
  }, [dateRange, authLoading, user]);

  const loadDashboardData = async () => {
    try {
      setLoading(true);
      setError('');
      const data = await callAnalyticsService?.getDashboardData(dateRange);
      setDashboardData(data);
    } catch (err) {
      setError(err?.message || 'Failed to load analytics data');
    } finally {
      setLoading(false);
    }
  };

  const analyzeCallWithAI = async (callId, transcript) => {
    try {
      setAiLoading(true);
      setAiError('');
      const insights = await processCallWithAI(callId, transcript);
      setAiInsights(insights);
      setShowAIPanel(true);
    } catch (err) {
      setAiError(err?.message || 'Failed to analyze call with AI');
    } finally {
      setAiLoading(false);
    }
  };

  const handleAnalyzeSampleCall = async () => {
    const sampleTranscript = `[00:00:05] John: Hi Sarah, thanks for joining the call today. I wanted to discuss the Q4 project timeline.
[00:00:12] Sarah: Of course! I've been reviewing the requirements and I think we can deliver by November 15th.
[00:00:20] John: That's great to hear. What about the testing phase? Do we have enough buffer time?
[00:00:28] Sarah: Yes, I've allocated two weeks for testing and bug fixes. We should be in good shape.
[00:00:35] John: Perfect. Let's schedule a follow-up next week to review the progress.
[00:00:40] Sarah: Sounds good. I'll send out a calendar invite.
[00:00:45] John: Thanks Sarah. Have a great day!
[00:00:48] Sarah: You too, John. Bye!`;
    
    await analyzeCallWithAI('sample-call-id', sampleTranscript);
  };

  const formatDuration = (seconds) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    if (hours > 0) return `${hours}h ${minutes}m`;
    return `${minutes}m`;
  };

  if (authLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-50">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Call Analytics Dashboard - Performance Insights</title>
        <meta name="description" content="Comprehensive call metrics, participant engagement, and usage trends" />
      </Helmet>

      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <div className="bg-white border-b border-gray-200 shadow-sm">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-lg">
                  <BarChart3 className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-gray-900">Call Analytics</h1>
                  <p className="text-sm text-gray-600">Performance insights and usage trends</p>
                </div>
              </div>
              <div className="flex items-center space-x-4">
                <button
                  onClick={handleAnalyzeSampleCall}
                  disabled={aiLoading}
                  className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg hover:from-blue-700 hover:to-purple-700 transition-colors disabled:opacity-50"
                >
                  {aiLoading ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Sparkles className="w-4 h-4" />
                  )}
                  Analyze with AI
                </button>
                <DateRangeSelector dateRange={dateRange} onChange={setDateRange} />
                <button
                  onClick={() => navigate('/calls')}
                  className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Back to Calls
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {error && (
            <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg">
              <p className="text-sm text-red-800">{error}</p>
            </div>
          )}

          {loading ? (
            <div className="flex flex-col items-center justify-center py-20">
              <Loader2 className="w-12 h-12 animate-spin text-blue-600 mb-4" />
              <p className="text-gray-600">Loading analytics data...</p>
            </div>
          ) : dashboardData ? (
            <>
              {showAIPanel && (
                <div className="mb-8">
                  <AIInsightsPanel
                    insights={aiInsights}
                    loading={aiLoading}
                    error={aiError}
                    onRegenerate={handleAnalyzeSampleCall}
                  />
                </div>
              )}

              {/* Key Metrics */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <MetricsCard
                  title="Total Calls"
                  value={dashboardData?.volumeMetrics?.totalCalls}
                  icon={Phone}
                  color="blue"
                  subtitle={`${dashboardData?.volumeMetrics?.completedCalls} completed`}
                />
                <MetricsCard
                  title="Answer Rate"
                  value={`${dashboardData?.volumeMetrics?.answerRate}%`}
                  icon={TrendingUp}
                  color="green"
                  subtitle="Call success rate"
                />
                <MetricsCard
                  title="Avg Duration"
                  value={formatDuration(dashboardData?.volumeMetrics?.avgDuration)}
                  icon={Clock}
                  color="purple"
                  subtitle="Per completed call"
                />
                <MetricsCard
                  title="Participants"
                  value={dashboardData?.engagement?.totalParticipants}
                  icon={Users}
                  color="orange"
                  subtitle={`Avg score: ${dashboardData?.engagement?.avgEngagementScore}`}
                />
              </div>

              {/* Call Volume Chart */}
              <div className="mb-8">
                <CallVolumeChart
                  data={dashboardData?.volumeMetrics?.trendData}
                  callsByType={dashboardData?.volumeMetrics?.callsByType}
                />
              </div>

              {/* Two Column Layout */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
                {/* Participant Engagement */}
                <EngagementTable
                  participants={dashboardData?.engagement?.topParticipants}
                />

                {/* Recording Metrics */}
                <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                  <div className="flex items-center space-x-2 mb-6">
                    <Video className="w-5 h-5 text-red-600" />
                    <h3 className="text-lg font-semibold text-gray-900">Recording Performance</h3>
                  </div>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <span className="text-sm text-gray-600">Total Recordings</span>
                      <span className="text-lg font-semibold text-gray-900">
                        {dashboardData?.recordings?.totalRecordings}
                      </span>
                    </div>
                    <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <span className="text-sm text-gray-600">Storage Used</span>
                      <span className="text-lg font-semibold text-gray-900">
                        {dashboardData?.recordings?.totalStorageGB} GB
                      </span>
                    </div>
                    <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <span className="text-sm text-gray-600">Completion Rate</span>
                      <span className="text-lg font-semibold text-green-600">
                        {dashboardData?.recordings?.completionRate}%
                      </span>
                    </div>
                    <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <span className="text-sm text-gray-600">Avg File Size</span>
                      <span className="text-lg font-semibold text-gray-900">
                        {dashboardData?.recordings?.avgFileSize} MB
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Usage Trends */}
              <UsageTrendsChart
                hourlyData={dashboardData?.trends?.hourlyDistribution}
                weeklyData={dashboardData?.trends?.weeklyDistribution}
                peakHour={dashboardData?.trends?.peakUsageHour}
                peakDay={dashboardData?.trends?.peakUsageDay}
              />
            </>
          ) : (
            <div className="text-center py-20">
              <BarChart3 className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600">No analytics data available for the selected period.</p>
            </div>
          )}
        </div>
      </div>
    </>
  );
}

export default CallAnalyticsDashboard;