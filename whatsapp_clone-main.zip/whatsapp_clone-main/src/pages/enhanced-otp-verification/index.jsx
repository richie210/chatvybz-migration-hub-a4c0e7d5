import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Shield, Clock, RefreshCw, Copy, Check, AlertCircle } from 'lucide-react';
import phoneAuthService from '../../services/phoneAuthService';

export default function EnhancedOTPVerification() {
  const navigate = useNavigate();
  const [otp, setOtp] = useState(['', '', '', '', '', '']);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [timeLeft, setTimeLeft] = useState(300); // 5 minutes
  const [canResend, setCanResend] = useState(false);
  const [clipboardDetected, setClipboardDetected] = useState(false);
  const inputRefs = useRef([]);

  // Auto-paste from clipboard
  useEffect(() => {
    const handlePaste = async (e) => {
      const pastedData = e?.clipboardData?.getData('text');
      if (pastedData && /^\d{6}$/?.test(pastedData)) {
        e?.preventDefault();
        const digits = pastedData?.split('');
        setOtp(digits);
        setClipboardDetected(true);
        setTimeout(() => setClipboardDetected(false), 2000);
        
        // Auto-verify after paste
        await handleVerify(digits?.join(''));
      }
    };

    window.addEventListener('paste', handlePaste);
    return () => window.removeEventListener('paste', handlePaste);
  }, []);

  // Countdown timer
  useEffect(() => {
    if (timeLeft === 0) {
      setCanResend(true);
      setError('Verification code expired. Please request a new one.');
      return;
    }

    const timer = setInterval(() => {
      setTimeLeft(prev => prev - 1);
    }, 1000);

    return () => clearInterval(timer);
  }, [timeLeft]);

  const handleChange = (index, value) => {
    if (!/^\d*$/?.test(value)) return;

    const newOtp = [...otp];
    newOtp[index] = value?.slice(-1);
    setOtp(newOtp);
    setError('');

    // Auto-focus next field
    if (value && index < 5) {
      inputRefs?.current?.[index + 1]?.focus();
    }

    // Auto-verify when all digits entered
    if (newOtp?.every(digit => digit) && !loading) {
      handleVerify(newOtp?.join(''));
    }
  };

  const handleKeyDown = (index, e) => {
    // Backspace navigation
    if (e?.key === 'Backspace' && !otp?.[index] && index > 0) {
      inputRefs?.current?.[index - 1]?.focus();
    }
  };

  const handleVerify = async (code = null) => {
    const otpCode = code || otp?.join('');
    if (otpCode?.length !== 6) {
      setError('Please enter all 6 digits');
      return;
    }

    setLoading(true);
    setError('');

    try {
      const result = await phoneAuthService?.verifyOTP(otpCode);
      
      if (result?.success) {
        setSuccess('Phone number verified successfully!');
        setTimeout(() => {
          navigate('/profile-setup');
        }, 1500);
      } else {
        setError(result?.error || 'Invalid verification code');
        setOtp(['', '', '', '', '', '']);
        inputRefs?.current?.[0]?.focus();
      }
    } catch (err) {
      setError(err?.message || 'Verification failed. Please try again.');
      setOtp(['', '', '', '', '', '']);
      inputRefs?.current?.[0]?.focus();
    } finally {
      setLoading(false);
    }
  };

  const handleResend = async () => {
    if (!canResend) return;

    setLoading(true);
    setError('');
    setSuccess('');

    try {
      // Get phone from storage or previous step
      const phoneData = JSON.parse(localStorage.getItem('pendingPhoneVerification') || '{}');
      
      if (!phoneData?.phoneNumber) {
        setError('Phone number not found. Please restart verification.');
        return;
      }

      await phoneAuthService?.sendOTP(phoneData?.countryCode, phoneData?.phoneNumber);
      
      setSuccess('New verification code sent!');
      setTimeLeft(300);
      setCanResend(false);
      setOtp(['', '', '', '', '', '']);
      inputRefs?.current?.[0]?.focus();
    } catch (err) {
      setError(err?.message || 'Failed to resend code');
    } finally {
      setLoading(false);
    }
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs?.toString()?.padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-xl max-w-md w-full p-8">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-green-100 rounded-full mb-4">
            <Shield className="w-8 h-8 text-green-600" />
          </div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">
            Verify Your Number
          </h1>
          <p className="text-gray-600">
            Enter the 6-digit code sent to your phone
          </p>
        </div>

        {/* Timer Display */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
          <div className="flex items-center justify-center space-x-2 text-blue-700">
            <Clock className="w-5 h-5" />
            <span className="font-semibold">
              Code expires in: {formatTime(timeLeft)}
            </span>
          </div>
        </div>

        {/* Clipboard Detection */}
        {clipboardDetected && (
          <div className="bg-green-50 border border-green-200 rounded-lg p-3 mb-4 flex items-center space-x-2">
            <Check className="w-5 h-5 text-green-600" />
            <span className="text-sm text-green-700">Code auto-pasted from clipboard</span>
          </div>
        )}

        {/* OTP Input Fields */}
        <div className="flex justify-center space-x-2 mb-6">
          {otp?.map((digit, index) => (
            <input
              key={index}
              ref={el => inputRefs.current[index] = el}
              type="text"
              inputMode="numeric"
              maxLength={1}
              value={digit}
              onChange={(e) => handleChange(index, e?.target?.value)}
              onKeyDown={(e) => handleKeyDown(index, e)}
              className={`w-12 h-14 text-center text-2xl font-semibold border-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 transition-all ${
                error ? 'border-red-300 shake' : 'border-gray-300'
              } ${digit ? 'border-green-500 bg-green-50' : ''}`}
              disabled={loading || timeLeft === 0}
              autoFocus={index === 0}
            />
          ))}
        </div>

        {/* Error Message */}
        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-3 mb-4 flex items-start space-x-2">
            <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
            <span className="text-sm text-red-700">{error}</span>
          </div>
        )}

        {/* Success Message */}
        {success && (
          <div className="bg-green-50 border border-green-200 rounded-lg p-3 mb-4 flex items-start space-x-2">
            <Check className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
            <span className="text-sm text-green-700">{success}</span>
          </div>
        )}

        {/* Verify Button */}
        <button
          onClick={() => handleVerify()}
          disabled={loading || otp?.some(d => !d) || timeLeft === 0}
          className="w-full bg-green-600 text-white py-3 rounded-lg font-semibold hover:bg-green-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors mb-4"
        >
          {loading ? (
            <span className="flex items-center justify-center">
              <RefreshCw className="w-5 h-5 animate-spin mr-2" />
              Verifying...
            </span>
          ) : (
            'Verify Code'
          )}
        </button>

        {/* Resend Section */}
        <div className="text-center">
          <button
            onClick={handleResend}
            disabled={!canResend || loading}
            className={`text-sm font-medium ${
              canResend
                ? 'text-green-600 hover:text-green-700' :'text-gray-400 cursor-not-allowed'
            } transition-colors`}
          >
            {canResend ? (
              <span className="flex items-center justify-center">
                <RefreshCw className="w-4 h-4 mr-1" />
                Resend Code
              </span>
            ) : (
              `Resend available in ${formatTime(timeLeft)}`
            )}
          </button>
        </div>

        {/* Tips */}
        <div className="mt-6 pt-6 border-t border-gray-200">
          <p className="text-xs text-gray-500 text-center mb-2">
            💡 <strong>Tips:</strong>
          </p>
          <ul className="text-xs text-gray-500 space-y-1">
            <li>• Copy the code from SMS and it will auto-paste</li>
            <li>• Use backspace to navigate between digits</li>
            <li>• Code will auto-verify when complete</li>
          </ul>
        </div>
      </div>
      <style jsx>{`
        @keyframes shake {
          0%, 100% { transform: translateX(0); }
          25% { transform: translateX(-10px); }
          75% { transform: translateX(10px); }
        }
        .shake {
          animation: shake 0.3s ease-in-out;
        }
      `}</style>
    </div>
  );
}