import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Users, RefreshCw, CheckCircle, UserPlus, AlertCircle, Search } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { contactDiscoveryService } from '../../services/contactDiscoveryService';


export default function ContactDiscoveryMatching() {
  const navigate = useNavigate();
  const { user } = useAuth();

  const [loading, setLoading] = useState(true);
  const [syncing, setSyncing] = useState(false);
  const [error, setError] = useState('');
  
  const [contacts, setContacts] = useState([]);
  const [discoveredUsers, setDiscoveredUsers] = useState([]);
  const [syncStatus, setSyncStatus] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('discovered'); // discovered, all

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }
    loadData();
  }, [user, navigate]);

  const loadData = async () => {
    try {
      setLoading(true);
      const [discovered, allContacts, status] = await Promise.all([
        contactDiscoveryService?.getDiscoveredUsers(user?.id),
        contactDiscoveryService?.getAllContacts(user?.id),
        contactDiscoveryService?.getSyncStatus(user?.id)
      ]);
      
      setDiscoveredUsers(discovered);
      setContacts(allContacts);
      setSyncStatus(status);
    } catch (err) {
      setError(err?.message || 'Failed to load contacts');
    } finally {
      setLoading(false);
    }
  };

  const handleContactSync = async () => {
    try {
      setSyncing(true);
      setError('');

      // Request contact access
      if (!('contacts' in navigator)) {
        setError('Contact access is not supported in this browser');
        return;
      }

      // This is a mock implementation - actual contact API would be used in production
      const mockContacts = [
        { name: 'John Doe', phoneNumber: '+1234567890', countryCode: '+1' },
        { name: 'Jane Smith', phoneNumber: '+9876543210', countryCode: '+1' }
      ];

      await contactDiscoveryService?.syncContacts(user?.id, mockContacts);
      await loadData();
    } catch (err) {
      setError(err?.message || 'Failed to sync contacts');
    } finally {
      setSyncing(false);
    }
  };

  const handleStartChat = (userId) => {
    navigate(`/main-chat-interface?userId=${userId}`);
  };

  const handleInvite = (contact) => {
    // Mock invite functionality
    const message = `Join ChatVybz! Download the app: https://chatvybz.com`;
    window.open(`sms:${contact?.countryCode}${contact?.contactPhone}?body=${encodeURIComponent(message)}`);
  };

  const getFilteredContacts = () => {
    const list = selectedCategory === 'discovered' ? discoveredUsers : contacts;
    
    if (!searchQuery) return list;

    return list?.filter(contact => {
      const searchLower = searchQuery?.toLowerCase();
      const name = contact?.contactName?.toLowerCase() || '';
      const displayName = contact?.profile?.displayName?.toLowerCase() || '';
      return name?.includes(searchLower) || displayName?.includes(searchLower);
    });
  };

  const filteredContacts = getFilteredContacts();

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading contacts...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <Users className="w-8 h-8 text-blue-600" />
              <div>
                <h1 className="text-2xl font-bold text-gray-900">
                  Contact Discovery
                </h1>
                <p className="text-sm text-gray-600">
                  Find friends who are already on ChatVybz
                </p>
              </div>
            </div>

            <button
              onClick={handleContactSync}
              disabled={syncing}
              className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
            >
              <RefreshCw className={`w-4 h-4 ${syncing ? 'animate-spin' : ''}`} />
              {syncing ? 'Syncing...' : 'Sync Contacts'}
            </button>
          </div>

          {/* Sync Status */}
          {syncStatus && (
            <div className="flex items-center gap-6 text-sm">
              <div className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-green-600" />
                <span className="text-gray-700">
                  <strong>{syncStatus?.totalContacts}</strong> contacts synced
                </span>
              </div>
              <div className="flex items-center gap-2">
                <Users className="w-4 h-4 text-blue-600" />
                <span className="text-gray-700">
                  <strong>{syncStatus?.platformUsersFound}</strong> on ChatVybz
                </span>
              </div>
              {syncStatus?.lastSyncAt && (
                <span className="text-gray-500">
                  Last synced: {new Date(syncStatus.lastSyncAt)?.toLocaleDateString()}
                </span>
              )}
            </div>
          )}
        </div>
      </div>
      <div className="max-w-7xl mx-auto px-4 py-6">
        {/* Error Message */}
        {error && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
            <p className="text-red-800 text-sm">{error}</p>
          </div>
        )}

        {/* Category Tabs */}
        <div className="flex gap-4 mb-6">
          <button
            onClick={() => setSelectedCategory('discovered')}
            className={`px-6 py-2 rounded-lg font-medium transition-colors ${
              selectedCategory === 'discovered' ?'bg-blue-600 text-white' :'bg-white text-gray-700 hover:bg-gray-50'
            }`}
          >
            On ChatVybz ({discoveredUsers?.length})
          </button>
          <button
            onClick={() => setSelectedCategory('all')}
            className={`px-6 py-2 rounded-lg font-medium transition-colors ${
              selectedCategory === 'all' ?'bg-blue-600 text-white' :'bg-white text-gray-700 hover:bg-gray-50'
            }`}
          >
            All Contacts ({contacts?.length})
          </button>
        </div>

        {/* Search Bar */}
        <div className="mb-6 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e?.target?.value)}
            placeholder="Search contacts..."
            className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>

        {/* Contacts List */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          {filteredContacts?.length === 0 ? (
            <div className="p-8 text-center">
              <Users className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-600 mb-2">
                {selectedCategory === 'discovered' ?'No platform users found yet' :'No contacts synced yet'
                }
              </p>
              <p className="text-sm text-gray-500">
                Sync your contacts to find friends on ChatVybz
              </p>
            </div>
          ) : (
            <div className="divide-y divide-gray-200">
              {filteredContacts?.map((contact) => (
                <div key={contact?.id} className="p-4 hover:bg-gray-50 transition-colors">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      {/* Avatar */}
                      <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-100 to-indigo-100 flex items-center justify-center text-blue-600 font-semibold">
                        {contact?.profile?.displayName?.[0]?.toUpperCase() || 
                         contact?.contactName?.[0]?.toUpperCase() || '?'}
                      </div>

                      {/* Contact Info */}
                      <div>
                        <h3 className="font-semibold text-gray-900">
                          {contact?.profile?.displayName || contact?.contactName}
                        </h3>
                        <p className="text-sm text-gray-600">
                          {contact?.countryCode} {contact?.contactPhone}
                        </p>
                        {contact?.profile?.bio && (
                          <p className="text-sm text-gray-500 mt-1">
                            {contact?.profile?.bio}
                          </p>
                        )}
                      </div>
                    </div>

                    {/* Action Button */}
                    {contact?.isPlatformUser ? (
                      <button
                        onClick={() => handleStartChat(contact?.platformUserId)}
                        className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center gap-2"
                      >
                        <Users className="w-4 h-4" />
                        Chat
                      </button>
                    ) : (
                      <button
                        onClick={() => handleInvite(contact)}
                        className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors flex items-center gap-2"
                      >
                        <UserPlus className="w-4 h-4" />
                        Invite
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Continue Button */}
        <div className="mt-6 flex justify-center">
          <button
            onClick={() => navigate('/main-chat-interface')}
            className="px-8 py-3 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 transition-colors"
          >
            Continue to Chat
          </button>
        </div>

        {/* Privacy Notice */}
        <div className="mt-6 p-4 bg-blue-50 rounded-lg">
          <p className="text-sm text-blue-800">
            <strong>Privacy:</strong> Your contacts are encrypted and only used to find platform users. 
            You can disable contact sync anytime in settings.
          </p>
        </div>
      </div>
    </div>
  );
}