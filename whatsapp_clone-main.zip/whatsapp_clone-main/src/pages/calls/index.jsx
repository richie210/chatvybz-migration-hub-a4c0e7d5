import React, { useState, useEffect } from 'react';
import { Phone, Video, PhoneOff, PhoneMissed, PhoneIncoming, PhoneOutgoing } from 'lucide-react';
import { callService } from '../../services/callService';
import { useAuth } from '../../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import { format } from 'date-fns';
import CallModal from './components/CallModal';
import ActiveCallUI from './components/ActiveCallUI';
import { supabase } from '../../lib/supabase';

function CallsScreen() {
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [callHistory, setCallHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [activeCall, setActiveCall] = useState(null);
  const [incomingCall, setIncomingCall] = useState(null);
  const [showCallModal, setShowCallModal] = useState(false);

  useEffect(() => {
    // Wait for auth to complete before making any calls
    if (authLoading) return;

    // Redirect to login if not authenticated
    if (!user) {
      navigate('/login');
      return;
    }

    // Only fetch data when authenticated
    fetchCallHistory();
    checkActiveCall();
    setupIncomingCallListener();
  }, [user, authLoading, navigate]);

  const fetchCallHistory = async () => {
    try {
      setLoading(true);
      const data = await callService?.getCallHistory();
      setCallHistory(data);
    } catch (err) {
      setError(err?.message);
    } finally {
      setLoading(false);
    }
  };

  const checkActiveCall = async () => {
    try {
      const call = await callService?.getActiveCall();
      if (call) {
        setActiveCall(call);
      }
    } catch (err) {
      console.error('Error checking active call:', err);
    }
  };

  const setupIncomingCallListener = () => {
    if (!user?.id) return;

    const subscription = callService?.subscribeToIncomingCalls(user?.id, async (payload) => {
      if (payload?.eventType === 'INSERT') {
        // Fetch full call details
        const { data } = await supabase?.from('calls')?.select(`
            *,
            initiator:profiles!calls_initiator_id_fkey(id, full_name, avatar_url)
          `)?.eq('id', payload?.new?.id)?.single();

        setIncomingCall(data);
      }
    });

    return () => {
      subscription?.unsubscribe();
    };
  };

  const handleCallClick = (call) => {
    const contact = call?.initiator_id === user?.id ? call?.recipient : call?.initiator;
    setShowCallModal({ contact, type: call?.call_type });
  };

  const handleAnswerCall = async () => {
    if (!incomingCall) return;
    
    try {
      await callService?.answerCall(incomingCall?.id);
      setActiveCall(incomingCall);
      setIncomingCall(null);
    } catch (err) {
      console.error('Error answering call:', err);
    }
  };

  const handleDeclineCall = async () => {
    if (!incomingCall) return;
    
    try {
      await callService?.declineCall(incomingCall?.id);
      setIncomingCall(null);
    } catch (err) {
      console.error('Error declining call:', err);
    }
  };

  const getCallIcon = (call) => {
    const isIncoming = call?.recipient_id === user?.id;
    const isMissed = call?.call_status === 'missed';
    const isVideo = call?.call_type === 'video' || call?.call_type === 'conference';

    if (isMissed) {
      return <PhoneMissed className="w-5 h-5 text-red-500" />;
    }
    if (isIncoming) {
      return <PhoneIncoming className="w-5 h-5 text-green-500" />;
    }
    return <PhoneOutgoing className="w-5 h-5 text-blue-500" />;
  };

  const formatCallDuration = (seconds) => {
    if (!seconds) return 'Not connected';
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs?.toString()?.padStart(2, '0')}`;
  };

  // Show loading screen while authentication is being determined
  if (authLoading || (loading && !error)) {
    return (
      <div className="flex justify-center items-center min-h-screen bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-sky-500 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading calls...</p>
        </div>
      </div>
    );
  }

  if (activeCall) {
    return (
      <ActiveCallUI
        call={activeCall}
        onEndCall={() => {
          setActiveCall(null);
          fetchCallHistory();
        }}
      />
    );
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen bg-gray-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-sky-500"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex justify-center items-center min-h-screen bg-gray-50">
        <div className="bg-red-50 border border-red-200 rounded-lg p-6 max-w-md">
          <h3 className="text-red-800 font-semibold mb-2">Error</h3>
          <p className="text-red-600">{error}</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-sky-500 text-white p-4">
        <h1 className="text-xl font-semibold">Calls</h1>
      </div>
      {/* Incoming Call Alert */}
      {incomingCall && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl p-6 max-w-sm w-full text-center">
            <img
              src={incomingCall?.initiator?.avatar_url || '/assets/images/no_image.png'}
              alt={incomingCall?.initiator?.full_name || 'Caller'}
              className="w-24 h-24 rounded-full mx-auto mb-4 object-cover"
            />
            <h2 className="text-xl font-bold mb-2">
              {incomingCall?.initiator?.full_name || 'Unknown'}
            </h2>
            <p className="text-gray-600 mb-6">
              Incoming {incomingCall?.call_type} call...
            </p>
            <div className="flex gap-4 justify-center">
              <button
                onClick={handleDeclineCall}
                className="bg-red-500 text-white rounded-full p-4 hover:bg-red-600 transition-colors"
              >
                <PhoneOff className="w-6 h-6" />
              </button>
              <button
                onClick={handleAnswerCall}
                className="bg-green-500 text-white rounded-full p-4 hover:bg-green-600 transition-colors"
              >
                <Phone className="w-6 h-6" />
              </button>
            </div>
          </div>
        </div>
      )}
      {/* Call History */}
      <div className="p-4">
        {callHistory?.length === 0 ? (
          <div className="text-center py-12">
            <Phone className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500">No call history yet</p>
          </div>
        ) : (
          <div className="space-y-2">
            {callHistory?.map((call) => {
              const contact = call?.initiator_id === user?.id ? call?.recipient : call?.initiator;
              
              return (
                <div
                  key={call?.id}
                  onClick={() => handleCallClick(call)}
                  className="bg-white rounded-lg p-4 flex items-center gap-4 hover:bg-gray-50 cursor-pointer transition-colors"
                >
                  <img
                    src={contact?.avatar_url || '/assets/images/no_image.png'}
                    alt={contact?.full_name || 'Contact'}
                    className="w-12 h-12 rounded-full object-cover"
                  />
                  <div className="flex-1">
                    <h3 className="font-semibold text-gray-900">
                      {contact?.full_name || 'Unknown'}
                    </h3>
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      {getCallIcon(call)}
                      <span>
                        {format(new Date(call.created_at), 'MMM d, h:mm a')}
                      </span>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-gray-600">
                      {formatCallDuration(call?.duration)}
                    </p>
                    {call?.call_type === 'video' && (
                      <Video className="w-4 h-4 text-sky-500 ml-auto mt-1" />
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
      {/* Call Modal */}
      {showCallModal && (
        <CallModal
          contact={showCallModal?.contact}
          callType={showCallModal?.type}
          onClose={() => setShowCallModal(false)}
          onCallStarted={(call) => {
            setActiveCall(call);
            setShowCallModal(false);
          }}
        />
      )}
    </div>
  );
}

export default CallsScreen;