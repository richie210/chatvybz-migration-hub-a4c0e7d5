import React, { useState } from 'react';
import { Phone, Video, X } from 'lucide-react';
import { callService } from '../../../services/callService';

function CallModal({ contact, callType = 'voice', onClose, onCallStarted }) {
  const [initiating, setInitiating] = useState(false);
  const [error, setError] = useState(null);

  const handleInitiateCall = async (type) => {
    try {
      setInitiating(true);
      setError(null);
      
      const call = await callService?.initiateCall(contact?.id, type);
      onCallStarted(call);
    } catch (err) {
      console.error('Error initiating call:', err);
      setError(err?.message);
    } finally {
      setInitiating(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl p-6 max-w-sm w-full">
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-600"
        >
          <X className="w-6 h-6" />
        </button>

        {/* Contact info */}
        <div className="text-center mb-6">
          <img
            src={contact?.avatar_url || '/assets/images/no_image.png'}
            alt={contact?.full_name || 'Contact'}
            className="w-24 h-24 rounded-full mx-auto mb-4 object-cover"
          />
          <h2 className="text-xl font-bold text-gray-900">
            {contact?.full_name || 'Unknown'}
          </h2>
          <p className="text-gray-600">{contact?.phone_number}</p>
        </div>

        {/* Error message */}
        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-3 mb-4">
            <p className="text-red-600 text-sm">{error}</p>
          </div>
        )}

        {/* Call options */}
        <div className="space-y-3">
          <button
            onClick={() => handleInitiateCall('voice')}
            disabled={initiating}
            className="w-full bg-sky-500 text-white py-3 rounded-lg flex items-center justify-center gap-2 hover:bg-sky-600 transition-colors disabled:opacity-50"
          >
            <Phone className="w-5 h-5" />
            <span>Voice Call</span>
          </button>

          <button
            onClick={() => handleInitiateCall('video')}
            disabled={initiating}
            className="w-full bg-green-500 text-white py-3 rounded-lg flex items-center justify-center gap-2 hover:bg-green-600 transition-colors disabled:opacity-50"
          >
            <Video className="w-5 h-5" />
            <span>Video Call</span>
          </button>

          <button
            onClick={onClose}
            className="w-full bg-gray-200 text-gray-700 py-3 rounded-lg hover:bg-gray-300 transition-colors"
          >
            Cancel
          </button>
        </div>

        {initiating && (
          <div className="text-center mt-4">
            <div className="inline-block animate-spin rounded-full h-6 w-6 border-b-2 border-sky-500"></div>
            <p className="text-sm text-gray-600 mt-2">Connecting...</p>
          </div>
        )}
      </div>
    </div>
  );
}

export default CallModal;