import React, { useState, useEffect, useRef } from 'react';
import { Mic, MicOff, Video, VideoOff, PhoneOff, Volume2, VolumeX, Camera, Circle } from 'lucide-react';
import { callService } from '../../../services/callService';
import { webrtcService } from '../../../services/webrtcService';
import { useAuth } from '../../../contexts/AuthContext';

export function ActiveCallUI({ call, onEndCall }) {
  const { user } = useAuth();
  const [isMuted, setIsMuted] = useState(false);
  const [isSpeakerOn, setIsSpeakerOn] = useState(false);
  const [isVideoOn, setIsVideoOn] = useState(call?.call_type === 'video');
  const [isRecording, setIsRecording] = useState(false);
  const [callDuration, setCallDuration] = useState(0);
  const [error, setError] = useState(null);
  const [isEncrypted, setIsEncrypted] = useState(call?.isEncrypted || false);
  
  const localVideoRef = useRef(null);
  const remoteVideoRef = useRef(null);
  const timerRef = useRef(null);

  const isVideo = call?.call_type === 'video' || call?.call_type === 'conference';
  const contact = call?.initiator_id === user?.id ? call?.recipient : call?.initiator;
  const isInitiator = call?.initiator_id === user?.id;

  useEffect(() => {
    initializeCall();
    startCallTimer();

    return () => {
      if (timerRef?.current) {
        clearInterval(timerRef?.current);
      }
      webrtcService?.endCall();
    };
  }, []);

  const initializeCall = async () => {
    try {
      if (!webrtcService?.constructor?.isSupported()) {
        throw new Error('WebRTC is not supported in this browser');
      }

      let remoteStream;

      if (isInitiator) {
        // Create connection as initiator
        remoteStream = await webrtcService?.createPeerConnection(call?.id, isVideo);
      } else {
        // Wait for offer and accept connection
        // This would typically come from a signaling server
        // For now, we'll simulate it
        remoteStream = await webrtcService?.acceptPeerConnection(call?.id, null, isVideo);
      }

      // Attach streams to video elements
      if (localVideoRef?.current && webrtcService?.localStream) {
        localVideoRef.current.srcObject = webrtcService?.localStream;
      }

      if (remoteVideoRef?.current && remoteStream) {
        remoteVideoRef.current.srcObject = remoteStream;
      }
    } catch (err) {
      console.error('Error initializing call:', err);
      setError(err?.message);
    }
  };

  const startCallTimer = () => {
    if (call?.started_at) {
      timerRef.current = setInterval(() => {
        setCallDuration((prev) => prev + 1);
      }, 1000);
    }
  };

  const formatDuration = (seconds) => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    
    if (hrs > 0) {
      return `${hrs}:${mins?.toString()?.padStart(2, '0')}:${secs?.toString()?.padStart(2, '0')}`;
    }
    return `${mins}:${secs?.toString()?.padStart(2, '0')}`;
  };

  const handleToggleMute = async () => {
    try {
      const muted = webrtcService?.toggleMute();
      setIsMuted(muted);
      await callService?.updateCallSettings(call?.id, { is_muted: muted });
    } catch (err) {
      console.error('Error toggling mute:', err);
    }
  };

  const handleToggleVideo = async () => {
    try {
      const videoOn = webrtcService?.toggleVideo();
      setIsVideoOn(videoOn);
    } catch (err) {
      console.error('Error toggling video:', err);
    }
  };

  const handleToggleSpeaker = async () => {
    setIsSpeakerOn(!isSpeakerOn);
    await callService?.updateCallSettings(call?.id, { is_speaker_on: !isSpeakerOn });
  };

  const handleSwitchCamera = async () => {
    try {
      const newStream = await webrtcService?.switchCamera();
      if (localVideoRef?.current) {
        localVideoRef.current.srcObject = newStream;
      }
    } catch (err) {
      console.error('Error switching camera:', err);
    }
  };

  const handleToggleRecording = async () => {
    try {
      if (isRecording) {
        const recordingBlob = await webrtcService?.stopRecording();
        await webrtcService?.saveRecording(call?.id, recordingBlob);
        setIsRecording(false);
      } else {
        webrtcService?.startRecording();
        setIsRecording(true);
      }
    } catch (err) {
      console.error('Error toggling recording:', err);
    }
  };

  const handleEndCall = async () => {
    try {
      // Stop recording if active
      if (isRecording) {
        await handleToggleRecording();
      }

      await callService?.endCall(call?.id);
      webrtcService?.endCall();
      onEndCall();
    } catch (err) {
      console.error('Error ending call:', err);
      // End call anyway
      webrtcService?.endCall();
      onEndCall();
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-gray-900 flex flex-col">
      {/* Call header */}
      <div className="p-4 bg-gray-800 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <img
            src={call?.participant?.avatar || '/default-avatar.png'}
            alt={call?.participant?.name}
            className="w-12 h-12 rounded-full"
          />
          <div>
            <h3 className="text-white font-medium">{call?.participant?.name}</h3>
            <p className="text-sm text-gray-400">{call?.status}</p>
          </div>
        </div>

        {/* Encryption indicator */}
        {isEncrypted && (
          <div className="flex items-center gap-2 px-3 py-1 bg-green-500/20 rounded-full">
            <svg className="w-4 h-4 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
            </svg>
            <span className="text-sm text-green-400 font-medium">End-to-end encrypted</span>
          </div>
        )}

        {/* Call timer */}
        {call?.started_at && (
          <div className="text-sm text-gray-400">
            {formatDuration(callDuration)}
          </div>
        )}
      </div>

      {/* Video container */}
      <div className="relative flex-1">
        {isVideo ? (
          <>
            {/* Remote video (full screen) */}
            <video
              ref={remoteVideoRef}
              autoPlay
              playsInline
              className="w-full h-full object-cover"
            />

            {/* Local video (picture-in-picture) */}
            <div className="absolute top-4 right-4 w-32 h-48 bg-gray-900 rounded-lg overflow-hidden shadow-lg">
              <video
                ref={localVideoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-cover"
              />
            </div>
          </>
        ) : (
          /* Voice call UI */
          (<div className="flex flex-col items-center justify-center h-full text-white">
            <img
              src={contact?.avatar_url || '/assets/images/no_image.png'}
              alt={contact?.full_name || 'Contact'}
              className="w-32 h-32 rounded-full mb-6 object-cover"
            />
            <h2 className="text-2xl font-bold mb-2">
              {contact?.full_name || 'Unknown'}
            </h2>
            <p className="text-sky-200">
              {call?.call_status === 'ringing' ? 'Calling...' : formatDuration(callDuration)}
            </p>
          </div>)
        )}
      </div>

      {/* Call info overlay */}
      <div className="absolute top-0 left-0 right-0 p-4 bg-gradient-to-b from-black/50 to-transparent">
        <div className="flex items-center justify-between text-white">
          <div>
            <p className="font-semibold">{contact?.full_name || 'Unknown'}</p>
            <p className="text-sm text-sky-200">
              {call?.call_status === 'ringing' ? 'Connecting...' : formatDuration(callDuration)}
            </p>
          </div>
          {isRecording && (
            <div className="flex items-center gap-2 bg-red-500 px-3 py-1 rounded-full">
              <Circle className="w-3 h-3 fill-current animate-pulse" />
              <span className="text-sm">Recording</span>
            </div>
          )}
        </div>
      </div>

      {/* Controls */}
      <div className="absolute bottom-0 left-0 right-0 p-6 bg-gradient-to-t from-black/50 to-transparent">
        <div className="flex justify-center items-center gap-4">
          {/* Mute button */}
          <button
            onClick={handleToggleMute}
            className={`rounded-full p-4 transition-colors ${
              isMuted ? 'bg-red-500' : 'bg-white/20 hover:bg-white/30'
            }`}
          >
            {isMuted ? (
              <MicOff className="w-6 h-6 text-white" />
            ) : (
              <Mic className="w-6 h-6 text-white" />
            )}
          </button>

          {/* Video toggle (only for video calls) */}
          {isVideo && (
            <button
              onClick={handleToggleVideo}
              className={`rounded-full p-4 transition-colors ${
                !isVideoOn ? 'bg-red-500' : 'bg-white/20 hover:bg-white/30'
              }`}
            >
              {isVideoOn ? (
                <Video className="w-6 h-6 text-white" />
              ) : (
                <VideoOff className="w-6 h-6 text-white" />
              )}
            </button>
          )}

          {/* End call button */}
          <button
            onClick={handleEndCall}
            className="bg-red-500 rounded-full p-6 hover:bg-red-600 transition-colors"
          >
            <PhoneOff className="w-6 h-6 text-white" />
          </button>

          {/* Speaker button */}
          <button
            onClick={handleToggleSpeaker}
            className={`rounded-full p-4 transition-colors ${
              isSpeakerOn ? 'bg-sky-500' : 'bg-white/20 hover:bg-white/30'
            }`}
          >
            {isSpeakerOn ? (
              <Volume2 className="w-6 h-6 text-white" />
            ) : (
              <VolumeX className="w-6 h-6 text-white" />
            )}
          </button>

          {/* Camera switch (only for video calls) */}
          {isVideo && (
            <button
              onClick={handleSwitchCamera}
              className="rounded-full p-4 bg-white/20 hover:bg-white/30 transition-colors"
            >
              <Camera className="w-6 h-6 text-white" />
            </button>
          )}
        </div>

        {/* Recording button (secondary row) */}
        <div className="flex justify-center mt-4">
          <button
            onClick={handleToggleRecording}
            className={`px-4 py-2 rounded-full text-white text-sm transition-colors ${
              isRecording
                ? 'bg-red-500 hover:bg-red-600' :'bg-white/20 hover:bg-white/30'
            }`}
          >
            {isRecording ? 'Stop Recording' : 'Start Recording'}
          </button>
        </div>
      </div>
    </div>
  );
}

export default ActiveCallUI;