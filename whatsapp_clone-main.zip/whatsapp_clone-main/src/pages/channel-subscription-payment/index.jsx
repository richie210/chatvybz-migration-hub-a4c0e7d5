import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { DollarSign, Check, Loader2, CreditCard } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { stripePaymentService } from '../../services/stripePaymentService';
import { loadStripe } from '@stripe/stripe-js';
import { Elements, PaymentElement, useStripe, useElements } from '@stripe/react-stripe-js';
import Icon from '../../components/AppIcon';

const stripePromise = loadStripe(import.meta.env?.VITE_STRIPE_PUBLISHABLE_KEY);

function CheckoutForm({ subscription, onSuccess, onCancel }) {
  const stripe = useStripe();
  const elements = useElements();
  const [processing, setProcessing] = useState(false);
  const [error, setError] = useState(null);

  const handleSubmit = async (e) => {
    e?.preventDefault();

    if (!stripe || !elements) return;

    setProcessing(true);
    setError(null);

    try {
      const { error: submitError } = await stripe?.confirmPayment({
        elements,
        confirmParams: {
          return_url: `${window.location?.origin}/channel-subscription-success`,
        },
      });

      if (submitError) {
        setError(submitError?.message);
      } else {
        onSuccess?.();
      }
    } catch (err) {
      setError(err?.message);
    } finally {
      setProcessing(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <PaymentElement />

      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg">
          {error}
        </div>
      )}

      <div className="flex gap-3">
        <button
          type="submit"
          disabled={!stripe || processing}
          className="flex-1 bg-blue-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
        >
          {processing ? (
            <>
              <Icon name="Loader2" size={20} className="animate-spin" />
              <span>Processing...</span>
            </>
          ) : (
            <>
              <Icon name="CreditCard" size={20} />
              <span>Subscribe Now</span>
            </>
          )}
        </button>
        <button
          type="button"
          onClick={onCancel}
          disabled={processing}
          className="px-6 py-3 border border-gray-300 rounded-lg font-medium hover:bg-gray-50 disabled:opacity-50"
        >
          Cancel
        </button>
      </div>
    </form>
  );
}

export default function ChannelSubscriptionPayment() {
  const { user, loading: authLoading, isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const channelId = searchParams?.get('channelId');
  const tierId = searchParams?.get('tierId');

  const [tiers, setTiers] = useState([]);
  const [selectedTier, setSelectedTier] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showCheckout, setShowCheckout] = useState(false);
  const [clientSecret, setClientSecret] = useState(null);
  const [subscriptionData, setSubscriptionData] = useState(null);

  useEffect(() => {
    if (authLoading) return;

    if (!isAuthenticated) {
      navigate('/login');
      return;
    }

    if (!channelId) {
      navigate('/channel-discovery-subscription-hub');
      return;
    }

    loadSubscriptionTiers();
  }, [authLoading, isAuthenticated, channelId, navigate]);

  const loadSubscriptionTiers = async () => {
    try {
      setLoading(true);
      setError(null);

      const result = await stripePaymentService?.getChannelSubscriptionTiers(channelId);
      if (result?.error) throw result?.error;

      setTiers(result?.data || []);

      // Auto-select tier if provided in URL
      if (tierId) {
        const tier = result?.data?.find(t => t?.id === tierId);
        if (tier) setSelectedTier(tier);
      }
    } catch (err) {
      console.error('Error loading subscription tiers:', err);
      setError(err?.message);
    } finally {
      setLoading(false);
    }
  };

  const handleSubscribe = async (tier) => {
    try {
      setLoading(true);
      setError(null);

      const result = await stripePaymentService?.subscribeToChannel(channelId, tier?.id);
      if (result?.error) throw result?.error;

      setClientSecret(result?.data?.clientSecret);
      setSubscriptionData(result?.data);
      setSelectedTier(tier);
      setShowCheckout(true);
    } catch (err) {
      console.error('Error subscribing to channel:', err);
      setError(err?.message);
    } finally {
      setLoading(false);
    }
  };

  const handlePaymentSuccess = () => {
    navigate(`/channel-subscription-success?subscriptionId=${subscriptionData?.subscriptionId}`);
  };

  const handleCancelCheckout = () => {
    setShowCheckout(false);
    setClientSecret(null);
    setSubscriptionData(null);
    setSelectedTier(null);
  };

  if (authLoading || loading) {
    return (
      <div className="flex items-center justify-center h-screen bg-gray-50">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading subscription options...</p>
        </div>
      </div>
    );
  }

  if (showCheckout && clientSecret) {
    return (
      <div className="min-h-screen bg-gray-50 py-12">
        <div className="max-w-2xl mx-auto px-6">
          <div className="bg-white rounded-lg shadow-lg p-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Complete Your Subscription</h2>
            
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium text-gray-900">{selectedTier?.name}</p>
                  <p className="text-sm text-gray-600">{selectedTier?.description}</p>
                </div>
                <div className="text-right">
                  <p className="text-2xl font-bold text-blue-600">
                    {stripePaymentService?.formatAmount(selectedTier?.price, selectedTier?.currency)}
                  </p>
                  <p className="text-sm text-gray-600">per {selectedTier?.billing_interval}</p>
                </div>
              </div>
            </div>

            <Elements stripe={stripePromise} options={{ clientSecret }}>
              <CheckoutForm
                subscription={subscriptionData}
                onSuccess={handlePaymentSuccess}
                onCancel={handleCancelCheckout}
              />
            </Elements>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-6xl mx-auto px-6">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Choose Your Subscription</h1>
          <p className="text-xl text-gray-600">Unlock premium features and support the channel</p>
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-6">
            {error}
          </div>
        )}

        {/* Subscription Tiers */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {tiers?.map((tier) => (
            <div
              key={tier?.id}
              className={`bg-white rounded-lg shadow-lg overflow-hidden transition-transform hover:scale-105 ${
                tier?.tier === 'pro' ? 'ring-2 ring-blue-500' : ''
              }`}
            >
              {tier?.tier === 'pro' && (
                <div className="bg-blue-500 text-white text-center py-2 font-medium">
                  Most Popular
                </div>
              )}

              <div className="p-8">
                <h3 className="text-2xl font-bold text-gray-900 mb-2">{tier?.name}</h3>
                <p className="text-gray-600 mb-6">{tier?.description}</p>

                <div className="mb-6">
                  <span className="text-4xl font-bold text-gray-900">
                    {stripePaymentService?.formatAmount(tier?.price, tier?.currency)}
                  </span>
                  <span className="text-gray-600 ml-2">/ {tier?.billing_interval}</span>
                </div>

                <ul className="space-y-3 mb-8">
                  {tier?.features?.map((feature, index) => (
                    <li key={index} className="flex items-start gap-2">
                      <Icon name="Check" size={20} className="text-green-500 flex-shrink-0 mt-0.5" />
                      <span className="text-gray-700">{feature}</span>
                    </li>
                  ))}
                </ul>

                <button
                  onClick={() => handleSubscribe(tier)}
                  disabled={tier?.tier === 'free' || loading}
                  className={`w-full py-3 rounded-lg font-medium transition-colors ${
                    tier?.tier === 'free' ?'bg-gray-100 text-gray-400 cursor-not-allowed'
                      : tier?.tier === 'pro' ?'bg-blue-600 text-white hover:bg-blue-700' :'bg-gray-900 text-white hover:bg-gray-800'
                  }`}
                >
                  {tier?.tier === 'free' ? 'Current Plan' : 'Subscribe Now'}
                </button>
              </div>
            </div>
          ))}
        </div>

        {tiers?.length === 0 && (
          <div className="text-center py-12">
            <Icon name="DollarSign" size={64} className="mx-auto text-gray-300 mb-4" />
            <p className="text-gray-500 text-lg">No subscription tiers available for this channel</p>
          </div>
        )}
      </div>
    </div>
  );
}