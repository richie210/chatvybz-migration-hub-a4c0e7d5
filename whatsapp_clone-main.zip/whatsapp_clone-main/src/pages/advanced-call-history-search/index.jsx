import React, { useState, useEffect } from 'react';
import { Search, Filter, Save, Download, Calendar, Clock, Users, FileText, X, ChevronDown, ChevronUp } from 'lucide-react';
import { callSearchService } from '../../services/callSearchService';

export default function AdvancedCallHistorySearch() {
  // Search state
  const [searchText, setSearchText] = useState('');
  const [suggestions, setSuggestions] = useState([]);
  const [showSuggestions, setShowSuggestions] = useState(false);

  // Filter state
  const [showFilters, setShowFilters] = useState(false);
  const [selectedParticipants, setSelectedParticipants] = useState([]);
  const [availableParticipants, setAvailableParticipants] = useState([]);
  const [minDuration, setMinDuration] = useState(5); // minutes
  const [maxDuration, setMaxDuration] = useState(480); // 8 hours in minutes
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [datePreset, setDatePreset] = useState('');
  const [selectedCallTypes, setSelectedCallTypes] = useState([]);

  // Results state
  const [searchResults, setSearchResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // Saved searches state
  const [savedSearches, setSavedSearches] = useState([]);
  const [showSavedSearches, setShowSavedSearches] = useState(false);
  const [showSaveModal, setShowSaveModal] = useState(false);
  const [saveQueryName, setSaveQueryName] = useState('');
  const [enableNotifications, setEnableNotifications] = useState(false);

  // Export state
  const [showExportMenu, setShowExportMenu] = useState(false);

  // Load initial data
  useEffect(() => {
    loadParticipants();
    loadSavedSearches();
  }, []);

  const loadParticipants = async () => {
    try {
      const participants = await callSearchService?.getCallParticipants();
      setAvailableParticipants(participants);
    } catch (err) {
      console.error('Error loading participants:', err);
    }
  };

  const loadSavedSearches = async () => {
    try {
      const searches = await callSearchService?.getSavedSearches();
      setSavedSearches(searches);
    } catch (err) {
      console.error('Error loading saved searches:', err);
    }
  };

  // Handle search text input with suggestions
  const handleSearchTextChange = async (value) => {
    setSearchText(value);
    if (value?.length > 2) {
      try {
        const suggestions = await callSearchService?.getSearchSuggestions(value);
        setSuggestions(suggestions);
        setShowSuggestions(true);
      } catch (err) {
        console.error('Error getting suggestions:', err);
      }
    } else {
      setShowSuggestions(false);
    }
  };

  // Handle date preset selection
  const handleDatePreset = (preset) => {
    setDatePreset(preset);
    const today = new Date();
    let start = new Date();

    switch (preset) {
      case 'today':
        start = new Date(today.setHours(0, 0, 0, 0));
        break;
      case 'week':
        start?.setDate(today?.getDate() - 7);
        break;
      case 'month':
        start?.setMonth(today?.getMonth() - 1);
        break;
      default:
        return;
    }

    setStartDate(start?.toISOString()?.split('T')?.[0]);
    setEndDate(new Date()?.toISOString()?.split('T')?.[0]);
  };

  // Handle search execution
  const handleSearch = async () => {
    setLoading(true);
    setError('');
    
    try {
      const filters = {
        searchText: searchText || null,
        participantIds: selectedParticipants?.length > 0 ? selectedParticipants : null,
        minDuration: minDuration * 60, // convert to seconds
        maxDuration: maxDuration * 60, // convert to seconds
        startDate: startDate ? new Date(startDate) : null,
        endDate: endDate ? new Date(endDate) : null,
        callTypes: selectedCallTypes?.length > 0 ? selectedCallTypes : null,
        limit: 50,
        offset: 0
      };

      const results = await callSearchService?.searchCalls(filters);
      setSearchResults(results);
    } catch (err) {
      setError(err?.message || 'Failed to search calls');
      console.error('Search error:', err);
    } finally {
      setLoading(false);
    }
  };

  // Handle save search
  const handleSaveSearch = async () => {
    if (!saveQueryName?.trim()) {
      setError('Please enter a name for this search');
      return;
    }

    try {
      const filters = {
        participantIds: selectedParticipants,
        minDuration,
        maxDuration,
        startDate,
        endDate,
        selectedCallTypes
      };

      await callSearchService?.saveSearchQuery(
        saveQueryName,
        searchText,
        filters,
        enableNotifications
      );

      await loadSavedSearches();
      setShowSaveModal(false);
      setSaveQueryName('');
      setEnableNotifications(false);
    } catch (err) {
      setError(err?.message || 'Failed to save search');
    }
  };

  // Handle load saved search
  const handleLoadSavedSearch = async (savedSearch) => {
    setSearchText(savedSearch?.searchText || '');
    setSelectedParticipants(savedSearch?.filters?.participantIds || []);
    setMinDuration(savedSearch?.filters?.minDuration || 5);
    setMaxDuration(savedSearch?.filters?.maxDuration || 480);
    setStartDate(savedSearch?.filters?.startDate || '');
    setEndDate(savedSearch?.filters?.endDate || '');
    setSelectedCallTypes(savedSearch?.filters?.selectedCallTypes || []);
    
    await callSearchService?.updateSearchUsage(savedSearch?.id);
    setShowSavedSearches(false);
    handleSearch();
  };

  // Handle export results
  const handleExport = (format) => {
    try {
      const exportData = callSearchService?.exportResults(searchResults, format);
      const blob = new Blob([exportData], { 
        type: format === 'json' ? 'application/json' : 'text/csv' 
      });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `call-history-${new Date()?.getTime()}.${format}`;
      link?.click();
      URL.revokeObjectURL(url);
      setShowExportMenu(false);
    } catch (err) {
      setError(err?.message || 'Failed to export results');
    }
  };

  // Format duration for display
  const formatDuration = (seconds) => {
    if (!seconds) return '0m';
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    return hours > 0 ? `${hours}h ${minutes}m` : `${minutes}m`;
  };

  // Format date for display
  const formatDate = (dateString) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date?.toLocaleString('en-US', { 
      month: 'short', 
      day: 'numeric', 
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Advanced Call History Search</h1>
          <p className="text-gray-600">Search across all video conferences with comprehensive filtering</p>
        </div>

        {/* Main Search Bar */}
        <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
          <div className="relative">
            <div className="flex items-center space-x-4">
              <div className="flex-1 relative">
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type="text"
                  value={searchText}
                  onChange={(e) => handleSearchTextChange(e?.target?.value)}
                  placeholder="Search by keywords, participant names, or transcription content..."
                  className="w-full pl-12 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
                {showSuggestions && suggestions?.length > 0 && (
                  <div className="absolute top-full left-0 right-0 mt-2 bg-white border border-gray-200 rounded-lg shadow-lg z-10 max-h-60 overflow-y-auto">
                    {suggestions?.map((suggestion, index) => (
                      <button
                        key={index}
                        onClick={() => {
                          setSearchText(suggestion?.suggestion);
                          setShowSuggestions(false);
                        }}
                        className="w-full px-4 py-3 text-left hover:bg-gray-50 flex items-center justify-between"
                      >
                        <span className="text-gray-900">{suggestion?.suggestion}</span>
                        <span className="text-xs text-gray-500">{suggestion?.searchCount} searches</span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
              <button
                onClick={() => setShowFilters(!showFilters)}
                className="flex items-center space-x-2 px-6 py-3 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
              >
                <Filter className="w-5 h-5" />
                <span>Filters</span>
                {showFilters ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </button>
              <button
                onClick={handleSearch}
                disabled={loading}
                className="px-8 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-400 transition-colors font-medium"
              >
                {loading ? 'Searching...' : 'Search'}
              </button>
            </div>
          </div>

          {/* Advanced Filters Panel */}
          {showFilters && (
            <div className="mt-6 pt-6 border-t border-gray-200 space-y-6">
              {/* Participants Filter */}
              <div>
                <label className="flex items-center space-x-2 text-sm font-medium text-gray-700 mb-3">
                  <Users className="w-4 h-4" />
                  <span>Participants</span>
                </label>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                  {availableParticipants?.map((participant) => (
                    <label key={participant?.userId} className="flex items-center space-x-2 p-3 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={selectedParticipants?.includes(participant?.userId)}
                        onChange={(e) => {
                          if (e?.target?.checked) {
                            setSelectedParticipants([...selectedParticipants, participant?.userId]);
                          } else {
                            setSelectedParticipants(selectedParticipants?.filter(id => id !== participant?.userId));
                          }
                        }}
                        className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                      />
                      <div className="flex items-center space-x-2 min-w-0">
                        {participant?.avatarUrl ? (
                          <img src={participant?.avatarUrl} alt={participant?.displayName} className="w-6 h-6 rounded-full" />
                        ) : (
                          <div className="w-6 h-6 rounded-full bg-gray-300 flex items-center justify-center text-xs text-gray-600">
                            {participant?.displayName?.[0] || '?'}
                          </div>
                        )}
                        <span className="text-sm text-gray-700 truncate">{participant?.displayName}</span>
                      </div>
                    </label>
                  ))}
                </div>
              </div>

              {/* Duration Filter */}
              <div>
                <label className="flex items-center space-x-2 text-sm font-medium text-gray-700 mb-3">
                  <Clock className="w-4 h-4" />
                  <span>Duration Range</span>
                </label>
                <div className="flex items-center space-x-4">
                  <div className="flex-1">
                    <label className="text-xs text-gray-500 mb-1 block">Min (minutes)</label>
                    <input
                      type="number"
                      value={minDuration}
                      onChange={(e) => setMinDuration(parseInt(e?.target?.value) || 0)}
                      min="0"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <span className="text-gray-400 pt-6">to</span>
                  <div className="flex-1">
                    <label className="text-xs text-gray-500 mb-1 block">Max (minutes)</label>
                    <input
                      type="number"
                      value={maxDuration}
                      onChange={(e) => setMaxDuration(parseInt(e?.target?.value) || 0)}
                      min="0"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>
                <input
                  type="range"
                  min="5"
                  max="480"
                  value={maxDuration}
                  onChange={(e) => setMaxDuration(parseInt(e?.target?.value))}
                  className="w-full mt-3"
                />
              </div>

              {/* Date Range Filter */}
              <div>
                <label className="flex items-center space-x-2 text-sm font-medium text-gray-700 mb-3">
                  <Calendar className="w-4 h-4" />
                  <span>Date Range</span>
                </label>
                <div className="flex flex-wrap gap-3 mb-3">
                  {['today', 'week', 'month']?.map((preset) => (
                    <button
                      key={preset}
                      onClick={() => handleDatePreset(preset)}
                      className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                        datePreset === preset
                          ? 'bg-blue-600 text-white' :'bg-gray-100 text-gray-700 hover:bg-gray-200'
                      }`}
                    >
                      {preset?.charAt(0)?.toUpperCase() + preset?.slice(1)}
                    </button>
                  ))}
                </div>
                <div className="flex items-center space-x-4">
                  <div className="flex-1">
                    <label className="text-xs text-gray-500 mb-1 block">Start Date</label>
                    <input
                      type="date"
                      value={startDate}
                      onChange={(e) => setStartDate(e?.target?.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <span className="text-gray-400 pt-6">to</span>
                  <div className="flex-1">
                    <label className="text-xs text-gray-500 mb-1 block">End Date</label>
                    <input
                      type="date"
                      value={endDate}
                      onChange={(e) => setEndDate(e?.target?.value)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>
              </div>

              {/* Call Type Filter */}
              <div>
                <label className="flex items-center space-x-2 text-sm font-medium text-gray-700 mb-3">
                  <FileText className="w-4 h-4" />
                  <span>Call Type</span>
                </label>
                <div className="flex flex-wrap gap-3">
                  {['voice', 'video', 'conference']?.map((type) => (
                    <label key={type} className="flex items-center space-x-2 p-3 border border-gray-200 rounded-lg hover:bg-gray-50 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={selectedCallTypes?.includes(type)}
                        onChange={(e) => {
                          if (e?.target?.checked) {
                            setSelectedCallTypes([...selectedCallTypes, type]);
                          } else {
                            setSelectedCallTypes(selectedCallTypes?.filter(t => t !== type));
                          }
                        }}
                        className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                      />
                      <span className="text-sm text-gray-700 capitalize">{type}</span>
                    </label>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Actions Bar */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-3">
            <button
              onClick={() => setShowSavedSearches(!showSavedSearches)}
              className="flex items-center space-x-2 px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
            >
              <Save className="w-4 h-4" />
              <span>Saved Searches ({savedSearches?.length})</span>
            </button>
            {searchResults?.length > 0 && (
              <>
                <button
                  onClick={() => setShowSaveModal(true)}
                  className="flex items-center space-x-2 px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  <Save className="w-4 h-4" />
                  <span>Save This Search</span>
                </button>
                <div className="relative">
                  <button
                    onClick={() => setShowExportMenu(!showExportMenu)}
                    className="flex items-center space-x-2 px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    <Download className="w-4 h-4" />
                    <span>Export</span>
                  </button>
                  {showExportMenu && (
                    <div className="absolute top-full left-0 mt-2 bg-white border border-gray-200 rounded-lg shadow-lg z-10 min-w-[150px]">
                      <button
                        onClick={() => handleExport('json')}
                        className="w-full px-4 py-2 text-left hover:bg-gray-50 rounded-t-lg"
                      >
                        Export as JSON
                      </button>
                      <button
                        onClick={() => handleExport('csv')}
                        className="w-full px-4 py-2 text-left hover:bg-gray-50 rounded-b-lg"
                      >
                        Export as CSV
                      </button>
                    </div>
                  )}
                </div>
              </>
            )}
          </div>
          {searchResults?.length > 0 && (
            <span className="text-sm text-gray-600">
              {searchResults?.length} result{searchResults?.length !== 1 ? 's' : ''} found
            </span>
          )}
        </div>

        {/* Saved Searches Panel */}
        {showSavedSearches && savedSearches?.length > 0 && (
          <div className="bg-white rounded-lg shadow-sm p-6 mb-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Saved Searches</h2>
            <div className="space-y-3">
              {savedSearches?.map((search) => (
                <div key={search?.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50">
                  <div className="flex-1">
                    <h3 className="font-medium text-gray-900">{search?.queryName}</h3>
                    <p className="text-sm text-gray-600 mt-1">{search?.searchText || 'No search text'}</p>
                    <p className="text-xs text-gray-500 mt-1">Last used: {formatDate(search?.lastUsedAt)}</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => handleLoadSavedSearch(search)}
                      className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm"
                    >
                      Load
                    </button>
                    <button
                      onClick={async () => {
                        await callSearchService?.deleteSavedSearch(search?.id);
                        await loadSavedSearches();
                      }}
                      className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Error Message */}
        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-6">
            {error}
          </div>
        )}

        {/* Search Results */}
        {loading ? (
          <div className="bg-white rounded-lg shadow-sm p-12 text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
            <p className="text-gray-600">Searching call history...</p>
          </div>
        ) : searchResults?.length > 0 ? (
          <div className="space-y-4">
            {searchResults?.map((result) => (
              <div key={result?.callId} className="bg-white rounded-lg shadow-sm p-6 hover:shadow-md transition-shadow">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    {result?.initiatorAvatar ? (
                      <img src={result?.initiatorAvatar} alt={result?.initiatorName} className="w-12 h-12 rounded-full" />
                    ) : (
                      <div className="w-12 h-12 rounded-full bg-gray-300 flex items-center justify-center text-lg text-gray-600">
                        {result?.initiatorName?.[0] || '?'}
                      </div>
                    )}
                    <div>
                      <h3 className="font-semibold text-gray-900">{result?.initiatorName}</h3>
                      <div className="flex items-center space-x-2 mt-1">
                        <span className={`px-2 py-1 text-xs rounded-full ${
                          result?.callType === 'video' ? 'bg-blue-100 text-blue-700' :
                          result?.callType === 'voice'? 'bg-green-100 text-green-700' : 'bg-purple-100 text-purple-700'
                        }`}>
                          {result?.callType}
                        </span>
                        <span className="text-sm text-gray-600">{formatDuration(result?.duration)}</span>
                        <span className="text-sm text-gray-400">•</span>
                        <span className="text-sm text-gray-600">{result?.participantCount} participant{result?.participantCount !== 1 ? 's' : ''}</span>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-gray-600">{formatDate(result?.startedAt)}</p>
                    {result?.relevanceScore > 0 && (
                      <p className="text-xs text-blue-600 mt-1">Relevance: {(result?.relevanceScore * 100)?.toFixed(0)}%</p>
                    )}
                  </div>
                </div>

                {result?.transcriptSnippet && (
                  <div className="bg-gray-50 rounded-lg p-4 mb-4">
                    <p className="text-sm text-gray-700">{result?.transcriptSnippet}</p>
                  </div>
                )}

                {result?.participants && result?.participants?.length > 0 && (
                  <div className="flex items-center space-x-2">
                    <span className="text-sm text-gray-600">Participants:</span>
                    <div className="flex -space-x-2">
                      {result?.participants?.slice(0, 5)?.map((participant, idx) => (
                        participant?.avatarUrl ? (
                          <img
                            key={idx}
                            src={participant?.avatarUrl}
                            alt={participant?.displayName}
                            className="w-8 h-8 rounded-full border-2 border-white"
                            title={participant?.displayName}
                          />
                        ) : (
                          <div
                            key={idx}
                            className="w-8 h-8 rounded-full border-2 border-white bg-gray-300 flex items-center justify-center text-xs text-gray-600"
                            title={participant?.displayName}
                          >
                            {participant?.displayName?.[0] || '?'}
                          </div>
                        )
                      ))}
                      {result?.participants?.length > 5 && (
                        <div className="w-8 h-8 rounded-full border-2 border-white bg-gray-400 flex items-center justify-center text-xs text-white">
                          +{result?.participants?.length - 5}
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        ) : !loading && (
          <div className="bg-white rounded-lg shadow-sm p-12 text-center">
            <Search className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No results found</h3>
            <p className="text-gray-600">Try adjusting your search criteria or filters</p>
          </div>
        )}

        {/* Save Search Modal */}
        {showSaveModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-lg shadow-xl max-w-md w-full p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-semibold text-gray-900">Save Search</h2>
                <button
                  onClick={() => setShowSaveModal(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Search Name
                  </label>
                  <input
                    type="text"
                    value={saveQueryName}
                    onChange={(e) => setSaveQueryName(e?.target?.value)}
                    placeholder="e.g., Weekly Team Meetings"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  />
                </div>
                <label className="flex items-center space-x-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={enableNotifications}
                    onChange={(e) => setEnableNotifications(e?.target?.checked)}
                    className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                  />
                  <span className="text-sm text-gray-700">Enable notifications for new matching content</span>
                </label>
              </div>
              <div className="flex items-center space-x-3 mt-6">
                <button
                  onClick={handleSaveSearch}
                  className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Save Search
                </button>
                <button
                  onClick={() => setShowSaveModal(false)}
                  className="flex-1 px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}