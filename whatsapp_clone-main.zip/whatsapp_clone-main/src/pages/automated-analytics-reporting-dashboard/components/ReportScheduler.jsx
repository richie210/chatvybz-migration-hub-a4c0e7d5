import React, { useState, useEffect } from 'react';
import { analyticsReportService } from '../../../services/analyticsReportService';
import { supabase } from '../../../lib/supabase';

const ReportScheduler = ({ onScheduleCreated }) => {
  const [formData, setFormData] = useState({
    reportType: 'creator_revenue',
    recipientEmail: '',
    frequency: 'weekly',
    scheduleTime: '09:00',
    timezone: Intl.DateTimeFormat()?.resolvedOptions()?.timeZone,
    channelId: ''
  });
  const [channels, setChannels] = useState([]);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState(null);

  useEffect(() => {
    loadUserData();
  }, []);

  const loadUserData = async () => {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (user?.email) {
        setFormData(prev => ({ ...prev, recipientEmail: user?.email }));
      }

      // Load user's channels for subscriber insights
      const { data: channelsData } = await supabase
        ?.from('channels')
        ?.select('id, name')
        ?.eq('created_by', user?.id);

      if (channelsData) {
        setChannels(channelsData);
      }
    } catch (err) {
      console.error('Error loading user data:', err);
    }
  };

  const handleSubmit = async (e) => {
    e?.preventDefault();
    
    try {
      setLoading(true);
      setMessage(null);

      // Validate channel selection for subscriber insights
      if (formData?.reportType === 'subscriber_insights' && !formData?.channelId) {
        setMessage({ type: 'error', text: 'Please select a channel for subscriber insights report' });
        return;
      }

      const scheduleData = {
        reportType: formData?.reportType,
        recipientEmail: formData?.recipientEmail,
        frequency: formData?.frequency,
        scheduleTime: formData?.scheduleTime,
        timezone: formData?.timezone,
        channelId: formData?.reportType === 'subscriber_insights' ? formData?.channelId : null
      };

      const result = await analyticsReportService?.scheduleReport(scheduleData);

      if (result?.success) {
        setMessage({ type: 'success', text: 'Report schedule created successfully!' });
        setTimeout(() => {
          onScheduleCreated?.();
        }, 1500);
      } else {
        setMessage({ type: 'error', text: result?.error || 'Failed to create schedule' });
      }
    } catch (err) {
      setMessage({ type: 'error', text: err?.message || 'An error occurred' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 max-w-2xl mx-auto">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2 bg-teal-100 rounded-lg">
          <svg className="w-6 h-6 text-teal-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
          </svg>
        </div>
        <h2 className="text-xl font-semibold text-gray-900">Schedule New Report</h2>
      </div>
      <form onSubmit={handleSubmit} className="space-y-5">
        {/* Report Type */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Report Type</label>
          <select
            value={formData?.reportType}
            onChange={(e) => setFormData(prev => ({ ...prev, reportType: e?.target?.value }))}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent"
            required
          >
            <option value="creator_revenue">Creator Revenue Analytics</option>
            <option value="call_metrics">Call Metrics Report</option>
            <option value="subscriber_insights">Subscriber Insights</option>
          </select>
        </div>

        {/* Channel Selection (for subscriber insights) */}
        {formData?.reportType === 'subscriber_insights' && (
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Select Channel</label>
            <select
              value={formData?.channelId}
              onChange={(e) => setFormData(prev => ({ ...prev, channelId: e?.target?.value }))}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent"
              required
            >
              <option value="">Choose a channel...</option>
              {channels?.map(channel => (
                <option key={channel?.id} value={channel?.id}>{channel?.name}</option>
              ))}
            </select>
          </div>
        )}

        {/* Recipient Email */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Recipient Email</label>
          <input
            type="email"
            value={formData?.recipientEmail}
            onChange={(e) => setFormData(prev => ({ ...prev, recipientEmail: e?.target?.value }))}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent"
            placeholder="email@example.com"
            required
          />
        </div>

        {/* Frequency */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Frequency</label>
          <div className="grid grid-cols-3 gap-3">
            <button
              type="button"
              onClick={() => setFormData(prev => ({ ...prev, frequency: 'daily' }))}
              className={`px-4 py-2 rounded-lg border-2 transition-colors ${
                formData?.frequency === 'daily' ?'border-teal-600 bg-teal-50 text-teal-700' :'border-gray-200 bg-white text-gray-700 hover:border-gray-300'
              }`}
            >
              Daily
            </button>
            <button
              type="button"
              onClick={() => setFormData(prev => ({ ...prev, frequency: 'weekly' }))}
              className={`px-4 py-2 rounded-lg border-2 transition-colors ${
                formData?.frequency === 'weekly' ?'border-teal-600 bg-teal-50 text-teal-700' :'border-gray-200 bg-white text-gray-700 hover:border-gray-300'
              }`}
            >
              Weekly
            </button>
            <button
              type="button"
              onClick={() => setFormData(prev => ({ ...prev, frequency: 'monthly' }))}
              className={`px-4 py-2 rounded-lg border-2 transition-colors ${
                formData?.frequency === 'monthly' ?'border-teal-600 bg-teal-50 text-teal-700' :'border-gray-200 bg-white text-gray-700 hover:border-gray-300'
              }`}
            >
              Monthly
            </button>
          </div>
        </div>

        {/* Schedule Time */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Schedule Time</label>
          <input
            type="time"
            value={formData?.scheduleTime}
            onChange={(e) => setFormData(prev => ({ ...prev, scheduleTime: e?.target?.value }))}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent"
            required
          />
        </div>

        {/* Timezone */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Timezone</label>
          <input
            type="text"
            value={formData?.timezone}
            onChange={(e) => setFormData(prev => ({ ...prev, timezone: e?.target?.value }))}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg bg-gray-50"
            readOnly
          />
          <p className="mt-1 text-xs text-gray-500">Detected from your browser settings</p>
        </div>

        {/* Message Display */}
        {message && (
          <div className={`p-4 rounded-lg ${
            message?.type === 'success' ? 'bg-green-50 text-green-800' : 'bg-red-50 text-red-800'
          }`}>
            {message?.text}
          </div>
        )}

        {/* Submit Button */}
        <button
          type="submit"
          disabled={loading}
          className="w-full px-4 py-3 bg-teal-600 text-white rounded-lg hover:bg-teal-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed font-medium"
        >
          {loading ? 'Creating Schedule...' : 'Create Schedule'}
        </button>
      </form>
    </div>
  );
};

export default ReportScheduler;