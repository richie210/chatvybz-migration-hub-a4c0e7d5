import React, { useState, useEffect } from 'react';
import { supabase } from '../../../lib/supabase';

const DeliveryTracker = ({ refreshKey }) => {
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    loadDeliveryLogs();
  }, [refreshKey]);

  const loadDeliveryLogs = async () => {
    try {
      setLoading(true);

      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) return;

      const { data, error } = await supabase
        ?.from('report_delivery_logs')
        ?.select('*')
        ?.eq('user_id', user?.id)
        ?.order('created_at', { ascending: false })
        ?.limit(50);

      if (error) throw error;
      setLogs(data || []);
    } catch (err) {
      console.error('Error loading delivery logs:', err);
    } finally {
      setLoading(false);
    }
  };

  const filteredLogs = filter === 'all' 
    ? logs 
    : logs?.filter(log => log?.report_type === filter);

  const getTypeColor = (type) => {
    const colors = {
      creator_revenue: 'bg-green-100 text-green-800',
      call_metrics: 'bg-blue-100 text-blue-800',
      subscriber_insights: 'bg-purple-100 text-purple-800'
    };
    return colors?.[type] || 'bg-gray-100 text-gray-800';
  };

  const getTypeLabel = (type) => {
    const labels = {
      creator_revenue: 'Revenue',
      call_metrics: 'Calls',
      subscriber_insights: 'Subscribers'
    };
    return labels?.[type] || type;
  };

  const getStatusColor = (status) => {
    return status === 'sent' ? 'text-green-600' : 'text-red-600';
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-orange-100 rounded-lg">
            <svg className="w-6 h-6 text-orange-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" />
            </svg>
          </div>
          <h3 className="text-lg font-semibold text-gray-900">Report Delivery Tracking</h3>
        </div>

        {/* Filter Buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setFilter('all')}
            className={`px-3 py-1 rounded-lg text-sm font-medium transition-colors ${
              filter === 'all' ? 'bg-teal-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            All
          </button>
          <button
            onClick={() => setFilter('creator_revenue')}
            className={`px-3 py-1 rounded-lg text-sm font-medium transition-colors ${
              filter === 'creator_revenue' ? 'bg-teal-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Revenue
          </button>
          <button
            onClick={() => setFilter('call_metrics')}
            className={`px-3 py-1 rounded-lg text-sm font-medium transition-colors ${
              filter === 'call_metrics' ? 'bg-teal-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Calls
          </button>
          <button
            onClick={() => setFilter('subscriber_insights')}
            className={`px-3 py-1 rounded-lg text-sm font-medium transition-colors ${
              filter === 'subscriber_insights' ? 'bg-teal-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Subscribers
          </button>
        </div>
      </div>
      {loading ? (
        <div className="flex items-center justify-center h-40">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-teal-600"></div>
        </div>
      ) : filteredLogs?.length === 0 ? (
        <div className="text-center py-12">
          <svg className="w-16 h-16 text-gray-300 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
          </svg>
          <p className="text-gray-500">No delivery logs found</p>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Report Type</th>
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Recipient</th>
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Status</th>
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Delivered At</th>
              </tr>
            </thead>
            <tbody>
              {filteredLogs?.map((log, index) => (
                <tr key={index} className="border-b border-gray-100 hover:bg-gray-50 transition-colors">
                  <td className="py-3 px-4">
                    <span className={`inline-block px-3 py-1 rounded-full text-xs font-medium ${getTypeColor(log?.report_type)}`}>
                      {getTypeLabel(log?.report_type)}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-sm text-gray-700">
                    {log?.recipient_email || 'N/A'}
                  </td>
                  <td className="py-3 px-4">
                    <span className={`font-medium text-sm ${getStatusColor(log?.delivery_status)}`}>
                      {log?.delivery_status === 'sent' ? '✓ Delivered' : '✗ Failed'}
                    </span>
                    {log?.error_message && (
                      <p className="text-xs text-red-600 mt-1">{log?.error_message}</p>
                    )}
                  </td>
                  <td className="py-3 px-4 text-sm text-gray-600">
                    {new Date(log?.created_at)?.toLocaleString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default DeliveryTracker;