import React, { useState, useEffect } from 'react';
import { analyticsReportService } from '../../../services/analyticsReportService';
import { supabase } from '../../../lib/supabase';

const ReportPreview = () => {
  const [reportType, setReportType] = useState('creator_revenue');
  const [email, setEmail] = useState('');
  const [channelId, setChannelId] = useState('');
  const [channels, setChannels] = useState([]);
  const [loading, setLoading] = useState(false);
  const [sending, setSending] = useState(false);
  const [message, setMessage] = useState(null);

  React.useEffect(() => {
    loadUserData();
  }, []);

  const loadUserData = async () => {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (user?.email) {
        setEmail(user?.email);
      }

      // Load user's channels
      const { data: channelsData } = await supabase
        ?.from('channels')
        ?.select('id, name')
        ?.eq('created_by', user?.id);

      if (channelsData) {
        setChannels(channelsData);
        if (channelsData?.length > 0) {
          setChannelId(channelsData?.[0]?.id);
        }
      }
    } catch (err) {
      console.error('Error loading user data:', err);
    }
  };

  const handleSendPreview = async () => {
    try {
      setSending(true);
      setMessage(null);

      let result;
      const dateRange = { days: 30 };

      if (reportType === 'creator_revenue') {
        result = await analyticsReportService?.sendCreatorRevenueReport(email, dateRange);
      } else if (reportType === 'call_metrics') {
        result = await analyticsReportService?.sendCallMetricsReport(email, dateRange);
      } else if (reportType === 'subscriber_insights') {
        if (!channelId) {
          setMessage({ type: 'error', text: 'Please select a channel' });
          return;
        }
        result = await analyticsReportService?.sendSubscriberInsightsReport(email, channelId, dateRange);
      }

      if (result?.success) {
        setMessage({ type: 'success', text: `Preview report sent successfully to ${email}` });
      } else {
        setMessage({ type: 'error', text: result?.error || 'Failed to send preview' });
      }
    } catch (err) {
      setMessage({ type: 'error', text: err?.message || 'An error occurred' });
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 max-w-2xl mx-auto">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2 bg-blue-100 rounded-lg">
          <svg className="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
          </svg>
        </div>
        <h2 className="text-xl font-semibold text-gray-900">Report Preview & Test</h2>
      </div>
      <div className="space-y-5">
        {/* Report Type Selection */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Select Report Type</label>
          <select
            value={reportType}
            onChange={(e) => setReportType(e?.target?.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent"
          >
            <option value="creator_revenue">Creator Revenue Analytics</option>
            <option value="call_metrics">Call Metrics Report</option>
            <option value="subscriber_insights">Subscriber Insights</option>
          </select>
        </div>

        {/* Channel Selection (for subscriber insights) */}
        {reportType === 'subscriber_insights' && (
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Select Channel</label>
            <select
              value={channelId}
              onChange={(e) => setChannelId(e?.target?.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent"
            >
              <option value="">Choose a channel...</option>
              {channels?.map(channel => (
                <option key={channel?.id} value={channel?.id}>{channel?.name}</option>
              ))}
            </select>
          </div>
        )}

        {/* Email Input */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Send Preview To</label>
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e?.target?.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent"
            placeholder="email@example.com"
          />
        </div>

        {/* Report Description */}
        <div className="bg-gray-50 rounded-lg p-4">
          <h3 className="font-medium text-gray-900 mb-2">Report Contents:</h3>
          {reportType === 'creator_revenue' && (
            <ul className="text-sm text-gray-600 space-y-1 list-disc list-inside">
              <li>Total revenue breakdown (subscriptions + ads)</li>
              <li>Revenue by channel</li>
              <li>Top performing channels</li>
              <li>Payout summaries</li>
            </ul>
          )}
          {reportType === 'call_metrics' && (
            <ul className="text-sm text-gray-600 space-y-1 list-disc list-inside">
              <li>Total calls and completion rate</li>
              <li>Average call duration</li>
              <li>Call types breakdown (voice/video/conference)</li>
              <li>Peak usage times</li>
            </ul>
          )}
          {reportType === 'subscriber_insights' && (
            <ul className="text-sm text-gray-600 space-y-1 list-disc list-inside">
              <li>Total subscribers and growth trends</li>
              <li>Engagement metrics</li>
              <li>Demographics breakdown</li>
              <li>Churn rate analysis</li>
            </ul>
          )}
        </div>

        {/* Message Display */}
        {message && (
          <div className={`p-4 rounded-lg ${
            message?.type === 'success' ? 'bg-green-50 text-green-800' : 'bg-red-50 text-red-800'
          }`}>
            <div className="flex items-start gap-2">
              {message?.type === 'success' ? (
                <svg className="w-5 h-5 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
              ) : (
                <svg className="w-5 h-5 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                </svg>
              )}
              <p className="text-sm">{message?.text}</p>
            </div>
          </div>
        )}

        {/* Send Button */}
        <button
          onClick={handleSendPreview}
          disabled={sending || !email}
          className="w-full px-4 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed font-medium flex items-center justify-center gap-2"
        >
          {sending ? (
            <>
              <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
              Sending Preview...
            </>
          ) : (
            <>
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
              </svg>
              Send Preview Report
            </>
          )}
        </button>

        <p className="text-xs text-gray-500 text-center">
          Preview reports use the last 30 days of data
        </p>
      </div>
    </div>
  );
};

export default ReportPreview;