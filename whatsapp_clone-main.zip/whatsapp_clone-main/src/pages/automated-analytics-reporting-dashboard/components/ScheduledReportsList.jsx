import React, { useState } from 'react';
import { analyticsReportService } from '../../../services/analyticsReportService';

const ScheduledReportsList = ({ schedules, onUpdate }) => {
  const [deletingId, setDeletingId] = useState(null);
  const [togglingId, setTogglingId] = useState(null);

  const handleDelete = async (scheduleId) => {
    if (!window.confirm('Are you sure you want to delete this scheduled report?')) {
      return;
    }

    try {
      setDeletingId(scheduleId);
      const result = await analyticsReportService?.deleteScheduledReport(scheduleId);
      
      if (result?.success) {
        onUpdate?.();
      } else {
        alert(result?.error || 'Failed to delete schedule');
      }
    } catch (err) {
      alert(err?.message || 'An error occurred');
    } finally {
      setDeletingId(null);
    }
  };

  const handleToggleActive = async (schedule) => {
    try {
      setTogglingId(schedule?.id);
      const result = await analyticsReportService?.updateScheduledReport(
        schedule?.id,
        { isActive: !schedule?.isActive }
      );
      
      if (result?.success) {
        onUpdate?.();
      } else {
        alert(result?.error || 'Failed to update schedule');
      }
    } catch (err) {
      alert(err?.message || 'An error occurred');
    } finally {
      setTogglingId(null);
    }
  };

  const getReportTypeLabel = (type) => {
    const labels = {
      creator_revenue: 'Creator Revenue',
      call_metrics: 'Call Metrics',
      subscriber_insights: 'Subscriber Insights'
    };
    return labels?.[type] || type;
  };

  const getFrequencyBadge = (frequency) => {
    const colors = {
      daily: 'bg-blue-100 text-blue-800',
      weekly: 'bg-green-100 text-green-800',
      monthly: 'bg-purple-100 text-purple-800'
    };
    return colors?.[frequency] || 'bg-gray-100 text-gray-800';
  };

  if (schedules?.length === 0) {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-12 text-center">
        <svg className="w-20 h-20 text-gray-300 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
        </svg>
        <h3 className="text-lg font-semibold text-gray-900 mb-2">No Scheduled Reports</h3>
        <p className="text-gray-600">Create your first scheduled report to get started</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {schedules?.map((schedule) => (
        <div
          key={schedule?.id}
          className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow"
        >
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-3">
                <h3 className="text-lg font-semibold text-gray-900">
                  {getReportTypeLabel(schedule?.reportType)}
                </h3>
                <span className={`px-3 py-1 rounded-full text-xs font-medium ${getFrequencyBadge(schedule?.frequency)}`}>
                  {schedule?.frequency}
                </span>
                <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                  schedule?.isActive ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                }`}>
                  {schedule?.isActive ? 'Active' : 'Inactive'}
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                <div className="flex items-center gap-2 text-gray-600">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                  </svg>
                  <span>{schedule?.recipientEmail}</span>
                </div>
                <div className="flex items-center gap-2 text-gray-600">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  <span>{schedule?.scheduleTime} ({schedule?.timezone})</span>
                </div>
                {schedule?.lastSent && (
                  <div className="flex items-center gap-2 text-gray-600">
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    <span>Last sent: {new Date(schedule?.lastSent)?.toLocaleString()}</span>
                  </div>
                )}
                <div className="flex items-center gap-2 text-gray-600">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                  </svg>
                  <span>Created: {new Date(schedule?.createdAt)?.toLocaleDateString()}</span>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center gap-2 ml-4">
              <button
                onClick={() => handleToggleActive(schedule)}
                disabled={togglingId === schedule?.id}
                className={`p-2 rounded-lg transition-colors ${
                  schedule?.isActive
                    ? 'bg-yellow-100 text-yellow-700 hover:bg-yellow-200' :'bg-green-100 text-green-700 hover:bg-green-200'
                } disabled:opacity-50`}
                title={schedule?.isActive ? 'Pause' : 'Activate'}
              >
                {togglingId === schedule?.id ? (
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-current"></div>
                ) : schedule?.isActive ? (
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 9v6m4-6v6m7-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                ) : (
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                )}
              </button>
              <button
                onClick={() => handleDelete(schedule?.id)}
                disabled={deletingId === schedule?.id}
                className="p-2 bg-red-100 text-red-700 rounded-lg hover:bg-red-200 transition-colors disabled:opacity-50"
                title="Delete"
              >
                {deletingId === schedule?.id ? (
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-red-700"></div>
                ) : (
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                  </svg>
                )}
              </button>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default ScheduledReportsList;