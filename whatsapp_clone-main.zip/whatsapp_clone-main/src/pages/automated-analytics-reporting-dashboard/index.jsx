import React, { useState, useEffect } from 'react';
import { analyticsReportService } from '../../services/analyticsReportService';
import ReportScheduler from './components/ReportScheduler';
import ScheduledReportsList from './components/ScheduledReportsList';
import ReportPreview from './components/ReportPreview';
import DeliveryTracker from './components/DeliveryTracker';

const AutomatedAnalyticsReportingDashboard = () => {
  const [schedules, setSchedules] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [activeTab, setActiveTab] = useState('schedules');
  const [refreshKey, setRefreshKey] = useState(0);

  useEffect(() => {
    loadScheduledReports();
  }, [refreshKey]);

  const loadScheduledReports = async () => {
    try {
      setLoading(true);
      setError(null);

      const result = await analyticsReportService?.getScheduledReports();

      if (result?.success) {
        setSchedules(result?.schedules || []);
      } else {
        setError(result?.error || 'Failed to load scheduled reports');
      }
    } catch (err) {
      setError(err?.message || 'An error occurred');
    } finally {
      setLoading(false);
    }
  };

  const handleRefresh = () => {
    setRefreshKey(prev => prev + 1);
  };

  const handleScheduleCreated = () => {
    handleRefresh();
    setActiveTab('schedules');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Automated Analytics Reporting Dashboard</h1>
              <p className="mt-2 text-sm text-gray-600">
                Schedule and manage email delivery of analytics reports for revenue, calls, and subscribers
              </p>
            </div>
            <button
              onClick={handleRefresh}
              className="px-4 py-2 bg-teal-600 text-white rounded-lg hover:bg-teal-700 transition-colors flex items-center gap-2"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
              </svg>
              Refresh
            </button>
          </div>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-6">
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-1 inline-flex gap-1">
          <button
            onClick={() => setActiveTab('schedules')}
            className={`px-6 py-2 rounded-md font-medium transition-colors ${
              activeTab === 'schedules' ?'bg-teal-600 text-white' :'text-gray-700 hover:bg-gray-100'
            }`}
          >
            Scheduled Reports
          </button>
          <button
            onClick={() => setActiveTab('create')}
            className={`px-6 py-2 rounded-md font-medium transition-colors ${
              activeTab === 'create' ?'bg-teal-600 text-white' :'text-gray-700 hover:bg-gray-100'
            }`}
          >
            Create Schedule
          </button>
          <button
            onClick={() => setActiveTab('preview')}
            className={`px-6 py-2 rounded-md font-medium transition-colors ${
              activeTab === 'preview' ?'bg-teal-600 text-white' :'text-gray-700 hover:bg-gray-100'
            }`}
          >
            Report Preview
          </button>
          <button
            onClick={() => setActiveTab('delivery')}
            className={`px-6 py-2 rounded-md font-medium transition-colors ${
              activeTab === 'delivery' ?'bg-teal-600 text-white' :'text-gray-700 hover:bg-gray-100'
            }`}
          >
            Delivery Tracking
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {loading && activeTab === 'schedules' ? (
          <div className="flex items-center justify-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-teal-600"></div>
          </div>
        ) : error && activeTab === 'schedules' ? (
          <div className="bg-red-50 border border-red-200 rounded-lg p-6 text-center">
            <svg className="w-12 h-12 text-red-500 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <p className="text-red-800 font-medium">{error}</p>
            <button
              onClick={handleRefresh}
              className="mt-4 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
            >
              Try Again
            </button>
          </div>
        ) : (
          <>
            {activeTab === 'schedules' && (
              <ScheduledReportsList
                schedules={schedules}
                onUpdate={handleRefresh}
              />
            )}
            {activeTab === 'create' && (
              <ReportScheduler onScheduleCreated={handleScheduleCreated} />
            )}
            {activeTab === 'preview' && (
              <ReportPreview />
            )}
            {activeTab === 'delivery' && (
              <DeliveryTracker refreshKey={refreshKey} />
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default AutomatedAnalyticsReportingDashboard;