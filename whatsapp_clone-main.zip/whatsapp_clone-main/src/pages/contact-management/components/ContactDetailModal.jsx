import React from 'react';
import Image from '../../../components/AppImage';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ContactDetailModal = ({ isOpen, onClose, contact, onStartChat, onShareContact, onBlockContact }) => {
  if (!isOpen || !contact) return null;

  const sharedGroups = [
    { id: 1, name: 'Tech Team', members: 12 },
    { id: 2, name: 'Project Alpha', members: 8 }
  ];

  return (
    <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-200 flex items-center justify-center p-4">
      <div className="bg-card border border-border rounded-xl shadow-xl w-full max-w-lg max-h-[90vh] overflow-y-auto custom-scrollbar">
        <div className="relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-lg bg-background/80 hover:bg-muted transition-colors focus-ring z-10"
            aria-label="Close modal"
          >
            <Icon name="X" size={20} color="var(--color-foreground)" />
          </button>

          <div className="flex flex-col items-center p-6 md:p-8 border-b border-border">
            <div className="relative mb-4">
              <div className="w-24 h-24 md:w-32 md:h-32 rounded-full overflow-hidden">
                <Image
                  src={contact?.avatar}
                  alt={contact?.avatarAlt}
                  className="w-full h-full object-cover"
                />
              </div>
              {contact?.isOnline && (
                <div className="absolute bottom-2 right-2 w-5 h-5 bg-success rounded-full border-4 border-card" />
              )}
            </div>

            <h2 className="text-xl md:text-2xl font-bold text-foreground mb-2">
              {contact?.name}
            </h2>
            <p className="text-sm md:text-base text-muted-foreground font-mono mb-1">
              {contact?.phone}
            </p>
            {contact?.status && (
              <p className="text-sm text-muted-foreground text-center max-w-xs">
                {contact?.status}
              </p>
            )}
          </div>
        </div>

        <div className="p-4 md:p-6 space-y-4">
          {contact?.isAppUser && (
            <>
              <div className="grid grid-cols-2 gap-3">
                <Button
                  variant="default"
                  fullWidth
                  iconName="MessageCircle"
                  iconPosition="left"
                  onClick={() => {
                    onStartChat(contact);
                    onClose();
                  }}
                >
                  Message
                </Button>
                <Button
                  variant="outline"
                  fullWidth
                  iconName="Share2"
                  iconPosition="left"
                  onClick={() => onShareContact(contact)}
                >
                  Share
                </Button>
              </div>

              <div className="space-y-3">
                <h3 className="text-sm font-semibold text-foreground">Contact Information</h3>
                
                <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                  <Icon name="Phone" size={20} color="var(--color-primary)" />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs text-muted-foreground">Phone</p>
                    <p className="text-sm font-medium text-foreground font-mono truncate">
                      {contact?.phone}
                    </p>
                  </div>
                </div>

                {contact?.email && (
                  <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                    <Icon name="Mail" size={20} color="var(--color-primary)" />
                    <div className="flex-1 min-w-0">
                      <p className="text-xs text-muted-foreground">Email</p>
                      <p className="text-sm font-medium text-foreground truncate">
                        {contact?.email}
                      </p>
                    </div>
                  </div>
                )}
              </div>

              {sharedGroups?.length > 0 && (
                <div className="space-y-3">
                  <h3 className="text-sm font-semibold text-foreground">
                    Shared Groups ({sharedGroups?.length})
                  </h3>
                  {sharedGroups?.map((group) => (
                    <div
                      key={group?.id}
                      className="flex items-center gap-3 p-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors cursor-pointer"
                    >
                      <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                        <Icon name="Users" size={20} color="var(--color-primary)" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-foreground truncate">
                          {group?.name}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {group?.members} members
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              <div className="pt-4 border-t border-border">
                <Button
                  variant="destructive"
                  fullWidth
                  iconName="Ban"
                  iconPosition="left"
                  onClick={() => {
                    onBlockContact(contact);
                    onClose();
                  }}
                >
                  Block Contact
                </Button>
              </div>
            </>
          )}

          {!contact?.isAppUser && (
            <div className="text-center py-6">
              <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-muted flex items-center justify-center">
                <Icon name="UserX" size={32} color="var(--color-muted-foreground)" />
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2">
                Not on ChatVybz
              </h3>
              <p className="text-sm text-muted-foreground mb-6">
                {contact?.name} is not using ChatVybz yet. Invite them to join!
              </p>
              <Button
                variant="default"
                fullWidth
                iconName="Send"
                iconPosition="left"
              >
                Send Invitation
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ContactDetailModal;