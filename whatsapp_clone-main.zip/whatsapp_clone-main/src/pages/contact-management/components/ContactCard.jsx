import React from 'react';
import Image from '../../../components/AppImage';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ContactCard = ({ contact, onContactClick, onInviteClick, onBlockClick }) => {
  return (
    <div
      className={`flex items-center gap-3 p-4 rounded-xl transition-all duration-200 ${
        contact?.isAppUser
          ? 'hover:bg-muted cursor-pointer' :'bg-muted/50'
      }`}
      onClick={() => contact?.isAppUser && onContactClick(contact)}
    >
      <div className="relative flex-shrink-0">
        <div className="w-12 h-12 md:w-14 md:h-14 lg:w-16 lg:h-16 rounded-full overflow-hidden">
          <Image
            src={contact?.avatar}
            alt={contact?.avatarAlt}
            className="w-full h-full object-cover"
          />
        </div>
        {contact?.isAppUser && contact?.isOnline && (
          <div className="absolute bottom-0 right-0 w-3 h-3 md:w-4 md:h-4 bg-success rounded-full border-2 border-card" />
        )}
      </div>
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <h3 className="font-semibold text-foreground truncate text-sm md:text-base">
            {contact?.name}
          </h3>
          {contact?.isAppUser && (
            <Icon
              name="CheckCircle2"
              size={16}
              color="var(--color-primary)"
            />
          )}
        </div>
        <p className="text-xs md:text-sm text-muted-foreground truncate font-mono">
          {contact?.phone}
        </p>
        {contact?.isAppUser && contact?.status && (
          <p className="text-xs text-muted-foreground truncate mt-1">
            {contact?.status}
          </p>
        )}
      </div>
      <div className="flex-shrink-0">
        {contact?.isAppUser ? (
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={(e) => {
                e?.stopPropagation();
                onBlockClick(contact);
              }}
              aria-label={`Block ${contact?.name}`}
            >
              <Icon name="Ban" size={18} color="var(--color-muted-foreground)" />
            </Button>
          </div>
        ) : (
          <Button
            variant="outline"
            size="sm"
            iconName="Send"
            iconPosition="left"
            onClick={(e) => {
              e?.stopPropagation();
              onInviteClick(contact);
            }}
          >
            Invite
          </Button>
        )}
      </div>
    </div>
  );
};

export default ContactCard;