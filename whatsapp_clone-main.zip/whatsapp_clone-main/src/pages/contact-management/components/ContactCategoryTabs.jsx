import React from 'react';
import Icon from '../../../components/AppIcon';

const ContactCategoryTabs = ({ activeTab, onTabChange, counts }) => {
  const tabs = [
    {
      id: 'all',
      label: 'All Contacts',
      icon: 'Users',
      count: counts?.all
    },
    {
      id: 'app-users',
      label: 'On ChatVybz',
      icon: 'CheckCircle2',
      count: counts?.appUsers
    },
    {
      id: 'pending',
      label: 'Pending',
      icon: 'Clock',
      count: counts?.pending
    },
    {
      id: 'blocked',
      label: 'Blocked',
      icon: 'Ban',
      count: counts?.blocked
    }
  ];

  return (
    <div className="border-b border-border overflow-x-auto">
      <div className="flex gap-1 md:gap-2 px-4 md:px-6 lg:px-8 min-w-max">
        {tabs?.map((tab) => (
          <button
            key={tab?.id}
            onClick={() => onTabChange(tab?.id)}
            className={`flex items-center gap-2 px-3 md:px-4 py-3 md:py-4 border-b-2 transition-all duration-200 whitespace-nowrap ${
              activeTab === tab?.id
                ? 'border-primary text-primary font-semibold' :'border-transparent text-muted-foreground hover:text-foreground hover:bg-muted/50'
            }`}
          >
            <Icon
              name={tab?.icon}
              size={18}
              color={
                activeTab === tab?.id
                  ? 'var(--color-primary)'
                  : 'var(--color-muted-foreground)'
              }
            />
            <span className="text-sm md:text-base">{tab?.label}</span>
            {tab?.count > 0 && (
              <span
                className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                  activeTab === tab?.id
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-muted text-muted-foreground'
                }`}
              >
                {tab?.count}
              </span>
            )}
          </button>
        ))}
      </div>
    </div>
  );
};

export default ContactCategoryTabs;