import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const QRCodeScanner = ({ isOpen, onClose, onScanSuccess }) => {
  const [isScanning, setIsScanning] = useState(false);

  if (!isOpen) return null;

  const handleStartScan = () => {
    setIsScanning(true);
    setTimeout(() => {
      onScanSuccess({
        name: 'Scanned User',
        phone: '+1 (555) 999-8888',
        avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_179ff6059-1763293430396.png",
        avatarAlt: 'Professional headshot of Asian man with black hair wearing gray sweater'
      });
      setIsScanning(false);
      onClose();
    }, 2000);
  };

  return (
    <div className="fixed inset-0 bg-background/80 backdrop-blur-sm z-200 flex items-center justify-center p-4">
      <div className="bg-card border border-border rounded-xl shadow-xl w-full max-w-md">
        <div className="flex items-center justify-between p-4 md:p-6 border-b border-border">
          <h2 className="text-lg md:text-xl font-bold text-foreground">Scan QR Code</h2>
          <button
            onClick={onClose}
            className="p-2 rounded-lg hover:bg-muted transition-colors focus-ring"
            aria-label="Close scanner">

            <Icon name="X" size={20} color="var(--color-foreground)" />
          </button>
        </div>

        <div className="p-6 md:p-8">
          <div className="aspect-square bg-muted rounded-xl flex items-center justify-center mb-6 relative overflow-hidden">
            {isScanning ?
            <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-full h-1 bg-primary animate-pulse" style={{ animation: 'scan 2s linear infinite' }} />
              </div> :

            <Icon name="QrCode" size={120} color="var(--color-muted-foreground)" />
            }
          </div>

          <div className="text-center mb-6">
            <h3 className="text-base font-semibold text-foreground mb-2">
              {isScanning ? 'Scanning...' : 'Position QR Code'}
            </h3>
            <p className="text-sm text-muted-foreground">
              {isScanning ?
              'Please wait while we scan the code' :
              'Align the QR code within the frame to scan'}
            </p>
          </div>

          <div className="flex gap-3">
            <Button
              variant="outline"
              fullWidth
              onClick={onClose}
              disabled={isScanning}>

              Cancel
            </Button>
            <Button
              variant="default"
              fullWidth
              iconName="Camera"
              iconPosition="left"
              onClick={handleStartScan}
              loading={isScanning}>

              {isScanning ? 'Scanning' : 'Start Scan'}
            </Button>
          </div>
        </div>
      </div>

      <style jsx>{`
        @keyframes scan {
          0% { transform: translateY(-100%); }
          100% { transform: translateY(100%); }
        }
      `}</style>
    </div>);

};

export default QRCodeScanner;