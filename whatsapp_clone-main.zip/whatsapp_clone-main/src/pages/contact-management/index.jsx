import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import ChatTabNavigation from '../../components/ui/ChatTabNavigation';
import ProfileSettingsTrigger from '../../components/ui/ProfileSettingsDropdown';
import Icon from '../../components/AppIcon';
import Input from '../../components/ui/Input';
import Button from '../../components/ui/Button';
import ContactCard from './components/ContactCard';
import ContactCategoryTabs from './components/ContactCategoryTabs';
import AddContactModal from './components/AddContactModal';
import ContactDetailModal from './components/ContactDetailModal';
import BulkActionsBar from './components/BulkActionsBar';
import QRCodeScanner from './components/QRCodeScanner';

const ContactManagement = () => {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState('all');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [isQRScannerOpen, setIsQRScannerOpen] = useState(false);
  const [selectedContact, setSelectedContact] = useState(null);
  const [selectedContacts, setSelectedContacts] = useState([]);
  const [isSelectionMode, setIsSelectionMode] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);

  const [contacts, setContacts] = useState([
  {
    id: 1,
    name: 'Sarah Johnson',
    phone: '+1 (555) 123-4567',
    email: 'sarah.johnson@email.com',
    isAppUser: true,
    isOnline: true,
    avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_18811c304-1763296452128.png",
    avatarAlt: 'Professional woman with blonde hair in business attire smiling at camera',
    status: 'Hey there! I am using ChatVybz',
    isBlocked: false,
    isPending: false
  },
  {
    id: 2,
    name: 'Michael Chen',
    phone: '+1 (555) 234-5678',
    email: 'michael.chen@email.com',
    isAppUser: true,
    isOnline: true,
    avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_144f5236b-1763295524542.png",
    avatarAlt: 'Asian man with short black hair wearing casual blue shirt outdoors',
    status: 'Available',
    isBlocked: false,
    isPending: false
  },
  {
    id: 3,
    name: 'Emma Wilson',
    phone: '+1 (555) 345-6789',
    email: 'emma.wilson@email.com',
    isAppUser: true,
    isOnline: false,
    avatar: "https://images.unsplash.com/photo-1600357524338-0aa536556606",
    avatarAlt: 'Young woman with brown hair in red top smiling warmly',
    status: 'Busy - Do not disturb',
    isBlocked: false,
    isPending: false
  },
  {
    id: 4,
    name: 'David Brown',
    phone: '+1 (555) 456-7890',
    email: 'david.brown@email.com',
    isAppUser: false,
    isOnline: false,
    avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_1256e6cce-1763294834422.png",
    avatarAlt: 'Middle-aged man with gray hair and beard in formal attire',
    status: null,
    isBlocked: false,
    isPending: true
  },
  {
    id: 5,
    name: 'Lisa Anderson',
    phone: '+1 (555) 567-8901',
    email: 'lisa.anderson@email.com',
    isAppUser: true,
    isOnline: true,
    avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_11974cf31-1763296445328.png",
    avatarAlt: 'Professional woman with dark hair in business suit with confident expression',
    status: 'At work - Available after 5 PM',
    isBlocked: false,
    isPending: false
  },
  {
    id: 6,
    name: 'James Taylor',
    phone: '+1 (555) 678-9012',
    email: 'james.taylor@email.com',
    isAppUser: false,
    isOnline: false,
    avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_149216793-1763296002470.png",
    avatarAlt: 'Young man with short brown hair wearing casual gray sweater',
    status: null,
    isBlocked: false,
    isPending: true
  },
  {
    id: 7,
    name: 'Rachel Green',
    phone: '+1 (555) 789-0123',
    email: 'rachel.green@email.com',
    isAppUser: true,
    isOnline: false,
    avatar: "https://images.unsplash.com/photo-1658857901791-a189a1ac3f3e",
    avatarAlt: 'Woman with long blonde hair in casual white top with friendly smile',
    status: 'Coffee lover ☕',
    isBlocked: true,
    isPending: false
  },
  {
    id: 8,
    name: 'Tom Harris',
    phone: '+1 (555) 890-1234',
    email: 'tom.harris@email.com',
    isAppUser: true,
    isOnline: true,
    avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_1d60b73e0-1763295361478.png",
    avatarAlt: 'Athletic man with short dark hair in sports attire outdoors',
    status: 'Living my best life 🌟',
    isBlocked: false,
    isPending: false
  }]
  );

  const filteredContacts = contacts?.filter((contact) => {
    const matchesSearch = contact?.name?.toLowerCase()?.includes(searchQuery?.toLowerCase()) ||
    contact?.phone?.includes(searchQuery);

    switch (activeTab) {
      case 'app-users':
        return matchesSearch && contact?.isAppUser && !contact?.isBlocked;
      case 'pending':
        return matchesSearch && contact?.isPending;
      case 'blocked':
        return matchesSearch && contact?.isBlocked;
      default:
        return matchesSearch && !contact?.isBlocked;
    }
  });

  const categoryCounts = {
    all: contacts?.filter((c) => !c?.isBlocked)?.length,
    appUsers: contacts?.filter((c) => c?.isAppUser && !c?.isBlocked)?.length,
    pending: contacts?.filter((c) => c?.isPending)?.length,
    blocked: contacts?.filter((c) => c?.isBlocked)?.length
  };

  const handleContactClick = (contact) => {
    if (isSelectionMode) {
      toggleContactSelection(contact?.id);
    } else {
      setSelectedContact(contact);
      setIsDetailModalOpen(true);
    }
  };

  const handleStartChat = (contact) => {
    navigate('/main-chat-interface', { state: { contactId: contact?.id } });
  };

  const handleInviteClick = (contact) => {
    console.log('Sending invitation to:', contact?.name);
  };

  const handleBlockContact = (contact) => {
    setContacts((prev) =>
    prev?.map((c) =>
    c?.id === contact?.id ? { ...c, isBlocked: true } : c
    )
    );
  };

  const handleShareContact = (contact) => {
    console.log('Sharing contact:', contact?.name);
  };

  const handleAddContact = (newContact) => {
    const contact = {
      id: Date.now(),
      ...newContact,
      isAppUser: Math.random() > 0.5,
      isOnline: false,
      avatar: `https://randomuser.me/api/portraits/${Math.random() > 0.5 ? 'men' : 'women'}/${Math.floor(Math.random() * 100)}.jpg`,
      avatarAlt: `Professional headshot of person in business attire`,
      status: 'Hey there! I am using ChatVybz',
      isBlocked: false,
      isPending: !newContact?.isAppUser
    };
    setContacts((prev) => [contact, ...prev]);
  };

  const handleQRScanSuccess = (scannedContact) => {
    handleAddContact(scannedContact);
  };

  const handleSyncContacts = () => {
    setIsSyncing(true);
    setTimeout(() => {
      setIsSyncing(false);
    }, 2000);
  };

  const toggleContactSelection = (contactId) => {
    setSelectedContacts((prev) =>
    prev?.includes(contactId) ?
    prev?.filter((id) => id !== contactId) :
    [...prev, contactId]
    );
  };

  const handleCreateGroup = () => {
    navigate('/group-chat-management', {
      state: { preselectedContacts: selectedContacts }
    });
  };

  const handleClearSelection = () => {
    setSelectedContacts([]);
    setIsSelectionMode(false);
  };

  useEffect(() => {
    if (selectedContacts?.length === 0) {
      setIsSelectionMode(false);
    }
  }, [selectedContacts]);

  return (
    <>
      <Helmet>
        <title>Contact Management - ChatVybz</title>
        <meta
          name="description"
          content="Manage your contacts, sync phonebook, and discover ChatVybz users" />

      </Helmet>
      <div className="flex h-screen bg-background">
        <ChatTabNavigation />

        <main className="flex-1 flex flex-col lg:ml-80">
          <header className="flex items-center justify-between px-4 md:px-6 lg:px-8 py-4 border-b border-border bg-card">
            <div className="flex items-center gap-3">
              <button
                onClick={() => navigate(-1)}
                className="lg:hidden p-2 rounded-lg hover:bg-muted transition-colors focus-ring"
                aria-label="Go back">

                <Icon name="ArrowLeft" size={20} color="var(--color-foreground)" />
              </button>
              <div>
                <h1 className="text-lg md:text-xl lg:text-2xl font-bold text-foreground">
                  Contacts
                </h1>
                <p className="text-xs md:text-sm text-muted-foreground">
                  {filteredContacts?.length} {filteredContacts?.length === 1 ? 'contact' : 'contacts'}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="icon"
                onClick={handleSyncContacts}
                loading={isSyncing}
                aria-label="Sync contacts">

                <Icon name="RefreshCw" size={20} color="var(--color-foreground)" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsQRScannerOpen(true)}
                aria-label="Scan QR code">

                <Icon name="QrCode" size={20} color="var(--color-foreground)" />
              </Button>
              <div className="hidden lg:block">
                <ProfileSettingsTrigger />
              </div>
            </div>
          </header>

          <div className="px-4 md:px-6 lg:px-8 py-4 border-b border-border bg-card">
            <div className="flex flex-col md:flex-row gap-3">
              <div className="flex-1">
                <Input
                  type="search"
                  placeholder="Search contacts by name or number..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e?.target?.value)}
                  className="w-full" />

              </div>
              <div className="flex gap-2">
                <Button
                  variant="default"
                  iconName="UserPlus"
                  iconPosition="left"
                  onClick={() => setIsAddModalOpen(true)}
                  className="flex-1 md:flex-none">

                  Add Contact
                </Button>
                <Button
                  variant="outline"
                  iconName={isSelectionMode ? 'X' : 'CheckSquare'}
                  iconPosition="left"
                  onClick={() => {
                    setIsSelectionMode(!isSelectionMode);
                    if (isSelectionMode) {
                      setSelectedContacts([]);
                    }
                  }}
                  className="flex-1 md:flex-none">

                  {isSelectionMode ? 'Cancel' : 'Select'}
                </Button>
              </div>
            </div>
          </div>

          <ContactCategoryTabs
            activeTab={activeTab}
            onTabChange={setActiveTab}
            counts={categoryCounts} />


          <div className="flex-1 overflow-y-auto custom-scrollbar pb-20 lg:pb-4">
            {filteredContacts?.length === 0 ?
            <div className="flex flex-col items-center justify-center h-full px-4 py-12">
                <div className="w-24 h-24 md:w-32 md:h-32 rounded-full bg-muted flex items-center justify-center mb-6">
                  <Icon
                  name={searchQuery ? 'Search' : 'Users'}
                  size={48}
                  color="var(--color-muted-foreground)" />

                </div>
                <h3 className="text-lg md:text-xl font-semibold text-foreground mb-2">
                  {searchQuery ? 'No contacts found' : 'No contacts yet'}
                </h3>
                <p className="text-sm md:text-base text-muted-foreground text-center max-w-md mb-6">
                  {searchQuery ?
                'Try adjusting your search or add a new contact' : 'Start by adding contacts or syncing your phonebook'}
                </p>
                {!searchQuery &&
              <div className="flex flex-col sm:flex-row gap-3">
                    <Button
                  variant="default"
                  iconName="UserPlus"
                  iconPosition="left"
                  onClick={() => setIsAddModalOpen(true)}>

                      Add Contact
                    </Button>
                    <Button
                  variant="outline"
                  iconName="RefreshCw"
                  iconPosition="left"
                  onClick={handleSyncContacts}
                  loading={isSyncing}>

                      Sync Contacts
                    </Button>
                  </div>
              }
              </div> :

            <div className="p-4 md:p-6 lg:p-8 space-y-2">
                {filteredContacts?.map((contact) =>
              <div key={contact?.id} className="relative">
                    {isSelectionMode &&
                <div className="absolute left-2 top-1/2 -translate-y-1/2 z-10">
                        <input
                    type="checkbox"
                    checked={selectedContacts?.includes(contact?.id)}
                    onChange={() => toggleContactSelection(contact?.id)}
                    className="w-5 h-5 rounded border-2 border-primary text-primary focus:ring-2 focus:ring-primary focus:ring-offset-2" />

                      </div>
                }
                    <div className={isSelectionMode ? 'ml-8' : ''}>
                      <ContactCard
                    contact={contact}
                    onContactClick={handleContactClick}
                    onInviteClick={handleInviteClick}
                    onBlockClick={handleBlockContact} />

                    </div>
                  </div>
              )}
              </div>
            }
          </div>
        </main>
      </div>
      <AddContactModal
        isOpen={isAddModalOpen}
        onClose={() => setIsAddModalOpen(false)}
        onAddContact={handleAddContact} />

      <ContactDetailModal
        isOpen={isDetailModalOpen}
        onClose={() => {
          setIsDetailModalOpen(false);
          setSelectedContact(null);
        }}
        contact={selectedContact}
        onStartChat={handleStartChat}
        onShareContact={handleShareContact}
        onBlockContact={handleBlockContact} />

      <QRCodeScanner
        isOpen={isQRScannerOpen}
        onClose={() => setIsQRScannerOpen(false)}
        onScanSuccess={handleQRScanSuccess} />

      <BulkActionsBar
        selectedCount={selectedContacts?.length}
        onCreateGroup={handleCreateGroup}
        onClearSelection={handleClearSelection} />

    </>);

};

export default ContactManagement;