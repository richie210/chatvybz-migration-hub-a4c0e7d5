import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { Users, MessageSquare, TrendingUp, Globe, Ban, Shield, Loader2, Search, AlertCircle } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { adminAnalyticsService } from '../../services/adminAnalyticsService';
import MetricsCard from '../call-analytics-dashboard/components/MetricsCard';
import Button from '../../components/ui/Button';

export default function ChatVybzAdminDashboard() {
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();

  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [metrics, setMetrics] = useState(null);
  const [messageVolume, setMessageVolume] = useState([]);
  const [userGrowth, setUserGrowth] = useState([]);
  const [users, setUsers] = useState([]);
  const [usersPage, setUsersPage] = useState(1);
  const [usersTotalPages, setUsersTotalPages] = useState(1);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCountry, setSelectedCountry] = useState(null);
  const [error, setError] = useState('');
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    if (!authLoading && !user) {
      navigate('/login');
    }
  }, [user, authLoading, navigate]);

  useEffect(() => {
    if (!authLoading && user) {
      checkAdminAndLoadData();
    }
  }, [authLoading, user]);

  const checkAdminAndLoadData = async () => {
    try {
      setLoading(true);
      setError('');

      const adminStatus = await adminAnalyticsService?.isAdmin();
      setIsAdmin(adminStatus);

      if (!adminStatus) {
        setError('Access denied. Admin privileges required.');
        setLoading(false);
        return;
      }

      await loadDashboardData();
    } catch (err) {
      console.error('Error checking admin status:', err);
      setError(err?.message || 'Failed to load dashboard');
    } finally {
      setLoading(false);
    }
  };

  const loadDashboardData = async () => {
    try {
      const [metricsData, volumeResult, growthResult, usersResult] = await Promise.all([
        adminAnalyticsService?.getDashboardMetrics(),
        adminAnalyticsService?.getMessageVolumeTrends(30),
        adminAnalyticsService?.getUserGrowthTrends(30),
        adminAnalyticsService?.getUsers({ page: usersPage, limit: 20, search: searchQuery, country: selectedCountry })
      ]);

      setMetrics(metricsData);
      setMessageVolume(volumeResult?.data || []);
      setUserGrowth(growthResult?.data || []);
      setUsers(usersResult?.data || []);
      setUsersTotalPages(usersResult?.totalPages || 1);
    } catch (err) {
      console.error('Error loading dashboard data:', err);
      setError(err?.message || 'Failed to load dashboard data');
    }
  };

  const handleBanUser = async (userId) => {
    const reason = prompt('Enter ban reason:');
    if (!reason) return;

    try {
      const result = await adminAnalyticsService?.banUser(userId, reason);
      if (result?.error) throw result?.error;
      alert('User banned successfully');
      await loadDashboardData();
    } catch (err) {
      alert(err?.message || 'Failed to ban user');
    }
  };

  const handleSuspendUser = async (userId) => {
    const reason = prompt('Enter suspension reason:');
    if (!reason) return;

    const days = prompt('Enter suspension duration (days):', '7');
    if (!days) return;

    try {
      const result = await adminAnalyticsService?.suspendUser(userId, reason, parseInt(days));
      if (result?.error) throw result?.error;
      alert('User suspended successfully');
      await loadDashboardData();
    } catch (err) {
      alert(err?.message || 'Failed to suspend user');
    }
  };

  const handleSearchUsers = async () => {
    setUsersPage(1);
    await loadDashboardData();
  };

  if (authLoading || loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-50">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-50">
        <div className="text-center">
          <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Access Denied</h2>
          <p className="text-gray-600 mb-4">Admin privileges required to access this page.</p>
          <Button onClick={() => navigate('/chat')}>Return to Chat</Button>
        </div>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>ChatVybz Admin Dashboard - Platform Analytics</title>
        <meta name="description" content="Comprehensive platform oversight with privacy-focused analytics and user management" />
      </Helmet>

      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-lg">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Shield className="w-8 h-8" />
                <div>
                  <h1 className="text-2xl font-bold">ChatVybz Admin Dashboard</h1>
                  <p className="text-blue-100 text-sm">Platform Analytics & Administration</p>
                </div>
              </div>
              <div className="flex gap-3">
                <Button
                  variant="outline"
                  className="bg-white text-blue-600 hover:bg-blue-50"
                  onClick={() => navigate('/creator-revenue-analytics-dashboard')}
                >
                  Creator Revenue
                </Button>
                <Button
                  variant="outline"
                  className="bg-white text-blue-600 hover:bg-blue-50"
                  onClick={() => navigate('/ai-content-moderation-center')}
                >
                  Content Moderation
                </Button>
                <Button
                  variant="outline"
                  className="bg-white text-blue-600 hover:bg-blue-50"
                  onClick={() => navigate('/admin-user-management-moderation-center')}
                >
                  User Management
                </Button>
                <Button
                  variant="outline"
                  className="bg-white text-blue-600 hover:bg-blue-50"
                  onClick={() => navigate('/admin-announcement-broadcasting-system')}
                >
                  Manage Ads
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="bg-white border-b border-gray-200">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex space-x-8">
              <button
                onClick={() => setActiveTab('overview')}
                className={`py-4 px-2 border-b-2 font-medium text-sm transition-colors ${
                  activeTab === 'overview' ?'border-blue-600 text-blue-600' :'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                Overview
              </button>
              <button
                onClick={() => setActiveTab('users')}
                className={`py-4 px-2 border-b-2 font-medium text-sm transition-colors ${
                  activeTab === 'users' ?'border-blue-600 text-blue-600' :'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                User Management
              </button>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
              <p className="text-red-800">{error}</p>
            </div>
          )}

          {activeTab === 'overview' && metrics && (
            <div className="space-y-6">
              {/* KPI Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <MetricsCard
                  title="Total Users"
                  value={metrics?.totalUsers?.toLocaleString()}
                  icon={Users}
                  color="blue"
                  subtitle="All registered users"
                />
                <MetricsCard
                  title="Daily Active Users"
                  value={metrics?.dailyActiveUsers?.toLocaleString()}
                  icon={TrendingUp}
                  color="green"
                  subtitle="Last 24 hours"
                />
                <MetricsCard
                  title="Monthly Active Users"
                  value={metrics?.monthlyActiveUsers?.toLocaleString()}
                  icon={Users}
                  color="purple"
                  subtitle="Last 30 days"
                />
                <MetricsCard
                  title="Messages Today"
                  value={metrics?.totalMessagesToday?.toLocaleString()}
                  icon={MessageSquare}
                  color="orange"
                  subtitle="Total messages sent"
                />
              </div>

              {/* Charts */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Message Volume Chart */}
                <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
                    <MessageSquare className="w-5 h-5 text-blue-600" />
                    Message Volume (30 Days)
                  </h3>
                  <div className="h-64 flex items-center justify-center text-gray-500">
                    {messageVolume?.length > 0 ? (
                      <div className="w-full">
                        <p className="text-sm text-gray-600 mb-2">Total: {messageVolume?.reduce((sum, d) => sum + d?.count, 0)?.toLocaleString()} messages</p>
                        <div className="text-xs text-gray-500">Chart visualization available</div>
                      </div>
                    ) : (
                      <p>No message data available</p>
                    )}
                  </div>
                </div>

                {/* User Growth Chart */}
                <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-green-600" />
                    User Growth (30 Days)
                  </h3>
                  <div className="h-64 flex items-center justify-center text-gray-500">
                    {userGrowth?.length > 0 ? (
                      <div className="w-full">
                        <p className="text-sm text-gray-600 mb-2">New users: {userGrowth?.reduce((sum, d) => sum + d?.signups, 0)?.toLocaleString()}</p>
                        <div className="text-xs text-gray-500">Chart visualization available</div>
                      </div>
                    ) : (
                      <p>No growth data available</p>
                    )}
                  </div>
                </div>
              </div>

              {/* Geographic Distribution */}
              <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
                  <Globe className="w-5 h-5 text-purple-600" />
                  Geographic Distribution
                </h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {Object.entries(metrics?.usersByCountry || {})?.slice(0, 8)?.map(([country, count]) => (
                    <div key={country} className="bg-gray-50 rounded-lg p-4">
                      <p className="text-2xl font-bold text-gray-900">{count}</p>
                      <p className="text-sm text-gray-600">{country}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'users' && (
            <div className="space-y-6">
              {/* Search and Filters */}
              <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
                <div className="flex flex-col md:flex-row gap-4">
                  <div className="flex-1">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <input
                        type="text"
                        placeholder="Search by email or name..."
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e?.target?.value)}
                        onKeyPress={(e) => e?.key === 'Enter' && handleSearchUsers()}
                        className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      />
                    </div>
                  </div>
                  <Button onClick={handleSearchUsers}>Search</Button>
                </div>
              </div>

              {/* Users Table */}
              <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          User
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Country
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Joined
                        </th>
                        <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                          Actions
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {users?.map((user) => (
                        <tr key={user?.id} className="hover:bg-gray-50">
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center">
                              <div className="flex-shrink-0 h-10 w-10">
                                {user?.avatar_url ? (
                                  <img
                                    className="h-10 w-10 rounded-full"
                                    src={user?.avatar_url}
                                    alt={user?.full_name || 'User avatar'}
                                  />
                                ) : (
                                  <div className="h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center">
                                    <Users className="w-5 h-5 text-blue-600" />
                                  </div>
                                )}
                              </div>
                              <div className="ml-4">
                                <div className="text-sm font-medium text-gray-900">{user?.full_name || 'No name'}</div>
                                <div className="text-sm text-gray-500">{user?.email}</div>
                              </div>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className="text-sm text-gray-900">{user?.country_code || 'Unknown'}</span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className="text-sm text-gray-500">
                              {new Date(user?.created_at)?.toLocaleDateString()}
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                            <button
                              onClick={() => handleSuspendUser(user?.id)}
                              className="text-orange-600 hover:text-orange-900 mr-4"
                            >
                              Suspend
                            </button>
                            <button
                              onClick={() => handleBanUser(user?.id)}
                              className="text-red-600 hover:text-red-900"
                            >
                              Ban
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Pagination */}
                {usersTotalPages > 1 && (
                  <div className="bg-gray-50 px-6 py-4 flex items-center justify-between border-t border-gray-200">
                    <div className="text-sm text-gray-700">
                      Page {usersPage} of {usersTotalPages}
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setUsersPage(Math.max(1, usersPage - 1));
                          loadDashboardData();
                        }}
                        disabled={usersPage === 1}
                      >
                        Previous
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setUsersPage(Math.min(usersTotalPages, usersPage + 1));
                          loadDashboardData();
                        }}
                        disabled={usersPage === usersTotalPages}
                      >
                        Next
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
}