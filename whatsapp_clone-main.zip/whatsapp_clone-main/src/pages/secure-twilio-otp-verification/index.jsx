import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import twilioVerifyService from '../../services/twilioVerifyService';
import phoneAuthService from '../../services/phoneAuthService';
import { useAuth } from '../../contexts/AuthContext';

const SecureTwilioOTPVerification = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { signInWithPhone, signUpWithPhone } = useAuth();
  
  const phoneNumber = location?.state?.phoneNumber;
  const channel = location?.state?.channel || 'sms';
  const fallbackUsed = location?.state?.fallbackUsed || false;

  const [otp, setOtp] = useState(['', '', '', '', '', '']);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [resendTimer, setResendTimer] = useState(60);
  const [canResend, setCanResend] = useState(false);
  const [deliveryStatus, setDeliveryStatus] = useState(fallbackUsed ? 'delivered_via_fallback' : 'delivered');
  const inputRefs = useRef([]);

  // Redirect if no phone number
  useEffect(() => {
    if (!phoneNumber) {
      navigate('/whats-app-style-phone-authentication');
    }
  }, [phoneNumber, navigate]);

  // Countdown timer
  useEffect(() => {
    if (resendTimer > 0) {
      setCanResend(false);
      const timer = setTimeout(() => setResendTimer(resendTimer - 1), 1000);
      return () => clearTimeout(timer);
    } else {
      setCanResend(true);
    }
  }, [resendTimer]);

  // Auto-focus first input
  useEffect(() => {
    inputRefs?.current?.[0]?.focus();
  }, []);

  const handleChange = (index, value) => {
    if (!/^\d*$/?.test(value)) return;

    const newOtp = [...otp];
    newOtp[index] = value?.slice(-1);
    setOtp(newOtp);
    setError('');

    // Auto-focus next input
    if (value && index < 5) {
      inputRefs?.current?.[index + 1]?.focus();
    }

    // Auto-verify when all digits entered
    if (newOtp?.every(digit => digit !== '') && value) {
      handleVerify(newOtp?.join(''));
    }
  };

  const handleKeyDown = (index, e) => {
    if (e?.key === 'Backspace') {
      e?.preventDefault();
      if (otp?.[index]) {
        const newOtp = [...otp];
        newOtp[index] = '';
        setOtp(newOtp);
      } else if (index > 0) {
        const newOtp = [...otp];
        newOtp[index - 1] = '';
        setOtp(newOtp);
        inputRefs?.current?.[index - 1]?.focus();
      }
    } else if (e?.key === 'ArrowLeft' && index > 0) {
      inputRefs?.current?.[index - 1]?.focus();
    } else if (e?.key === 'ArrowRight' && index < 5) {
      inputRefs?.current?.[index + 1]?.focus();
    }
  };

  const handlePaste = (e) => {
    e?.preventDefault();
    const pastedData = e?.clipboardData?.getData('text')?.trim()?.slice(0, 6);
    if (!/^\d+$/?.test(pastedData)) return;

    const digits = pastedData?.split('');
    const newOtp = [...digits, ...Array(6 - digits?.length)?.fill('')]?.slice(0, 6);
    setOtp(newOtp);

    const nextFocusIndex = Math.min(digits?.length, 5);
    inputRefs?.current?.[nextFocusIndex]?.focus();

    if (digits?.length === 6) {
      handleVerify(newOtp?.join(''));
    }
  };

  const handleVerify = async (otpCode) => {
    if (isLoading) return;

    if (otpCode?.length !== 6) {
      setError('Please enter all 6 digits');
      return;
    }

    setIsLoading(true);
    setError('');

    try {
      // Verify OTP with Twilio
      const verifyResult = await twilioVerifyService?.verifyCode(phoneNumber, otpCode);

      if (!verifyResult?.success) {
        throw new Error('Invalid or expired verification code');
      }

      // Check if user exists
      const { data: profile } = await phoneAuthService?.checkUserExists(phoneNumber);

      if (profile) {
        // Existing user - sign in
        const { data, error } = await signInWithPhone(phoneNumber, '', otpCode);
        if (error) throw new Error(error?.message);
        
        // Navigate to main chat
        navigate('/main-chat-interface');
      } else {
        // New user - navigate to profile setup
        navigate('/profile-setup', {
          state: {
            phoneNumber,
            verified: true
          }
        });
      }
    } catch (err) {
      console.error('Verification error:', err);
      setError(err?.message || 'Invalid verification code. Please try again.');
      setOtp(['', '', '', '', '', '']);
      inputRefs?.current?.[0]?.focus();
    } finally {
      setIsLoading(false);
    }
  };

  const handleResend = async () => {
    if (!canResend || isLoading) return;

    setIsLoading(true);
    setError('');

    try {
      // Check rate limit
      const rateLimit = await twilioVerifyService?.checkRateLimit(phoneNumber);
      
      if (!rateLimit?.allowed) {
        throw new Error(rateLimit?.message || 'Rate limit exceeded. Please try again later.');
      }

      // Resend code with fallback
      const result = await twilioVerifyService?.sendWithFallback(phoneNumber);

      if (result?.success) {
        setResendTimer(60);
        setCanResend(false);
        setDeliveryStatus(result?.fallbackUsed ? 'delivered_via_fallback' : 'delivered');
        setOtp(['', '', '', '', '', '']);
        inputRefs?.current?.[0]?.focus();
      } else {
        throw new Error('Failed to resend code');
      }
    } catch (err) {
      console.error('Resend error:', err);
      setError(err?.message || 'Failed to resend code. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleBack = () => {
    navigate('/whats-app-style-phone-authentication');
  };

  const formatPhoneNumber = (phone) => {
    if (!phone) return '';
    const cleaned = phone?.replace(/\D/g, '');
    const match = phone?.match(/^(\+\d{1,3})(\d{3})(\d{3})(\d+)$/);
    if (match) {
      return `${match?.[1]} ${match?.[2]} ${match?.[3]} ${match?.[4]}`;
    }
    return phone;
  };

  return (
    <>
      <Helmet>
        <title>Verify OTP - ChatVybz</title>
        <meta
          name="description"
          content="Secure OTP verification powered by Twilio for ChatVybz phone authentication."
        />
      </Helmet>

      <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-teal-50 flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          <div className="bg-white rounded-2xl shadow-xl border border-gray-200 overflow-hidden">
            {/* Header */}
            <div className="bg-gradient-to-r from-green-500 to-teal-500 p-8 text-center">
              <div className="w-20 h-20 mx-auto bg-white rounded-full flex items-center justify-center mb-4 shadow-lg">
                <Icon name="ShieldCheck" size={40} color="#22B48A" />
              </div>
              <h1 className="text-3xl font-bold text-white mb-2">Verify Your Number</h1>
              <p className="text-white/90">Enter the 6-digit code we sent</p>
            </div>

            {/* Main Content */}
            <div className="p-8">
              {/* Back Button */}
              <button
                onClick={handleBack}
                className="flex items-center gap-2 text-sm text-gray-600 hover:text-gray-900 transition-colors mb-6"
              >
                <Icon name="ArrowLeft" size={16} />
                Change number
              </button>

              {/* Phone Number Display */}
              <div className="text-center mb-6">
                <p className="text-sm text-gray-600 mb-1">Code sent to</p>
                <p className="text-lg font-semibold text-gray-900">{formatPhoneNumber(phoneNumber)}</p>
                {deliveryStatus === 'delivered_via_fallback' && (
                  <p className="text-xs text-orange-600 mt-1 flex items-center justify-center gap-1">
                    <Icon name="Phone" size={12} />
                    Delivered via voice call
                  </p>
                )}
              </div>

              {/* Error Message */}
              {error && (
                <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-start gap-3">
                  <Icon name="AlertCircle" size={20} color="#EF4444" className="flex-shrink-0 mt-0.5" />
                  <div className="flex-1">
                    <p className="text-sm text-red-600">{error}</p>
                  </div>
                  <button onClick={() => setError('')} className="text-red-600 hover:text-red-700">
                    <Icon name="X" size={16} />
                  </button>
                </div>
              )}

              {/* OTP Input */}
              <div className="mb-6">
                <div className="flex justify-center gap-3 mb-4">
                  {otp?.map((digit, index) => (
                    <input
                      key={index}
                      ref={(el) => (inputRefs.current[index] = el)}
                      type="text"
                      inputMode="numeric"
                      pattern="[0-9]*"
                      maxLength={1}
                      value={digit}
                      onChange={(e) => handleChange(index, e?.target?.value)}
                      onKeyDown={(e) => handleKeyDown(index, e)}
                      onPaste={handlePaste}
                      disabled={isLoading}
                      className={`w-12 h-14 text-center text-xl font-semibold bg-white border-2 rounded-lg transition-all focus:outline-none focus:ring-2 focus:ring-green-500 ${
                        error
                          ? 'border-red-500'
                          : digit
                          ? 'border-green-500' :'border-gray-300'
                      } ${isLoading ? 'opacity-50 cursor-not-allowed' : ''}`}
                    />
                  ))}
                </div>
              </div>

              {/* Verify Button */}
              <Button
                type="button"
                onClick={() => handleVerify(otp?.join(''))}
                disabled={otp?.some(digit => digit === '') || isLoading}
                className="w-full bg-green-500 hover:bg-green-600 text-white py-3 rounded-lg font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 mb-4"
              >
                {isLoading ? (
                  <>
                    <Icon name="Loader2" className="w-5 h-5 animate-spin" />
                    Verifying...
                  </>
                ) : (
                  <>
                    <Icon name="CheckCircle" className="w-5 h-5" />
                    Verify Code
                  </>
                )}
              </Button>

              {/* Resend Section */}
              <div className="text-center">
                <p className="text-sm text-gray-600 mb-2">Didn't receive the code?</p>
                {canResend ? (
                  <button
                    type="button"
                    onClick={handleResend}
                    disabled={isLoading}
                    className={`text-sm font-medium transition-colors ${
                      isLoading ? 'text-gray-400 cursor-not-allowed' : 'text-green-600 hover:underline'
                    }`}
                  >
                    Resend Code
                  </button>
                ) : (
                  <p className="text-sm text-gray-500">
                    Resend available in <span className="font-medium text-gray-900">{resendTimer}s</span>
                  </p>
                )}
              </div>

              {/* Security Notice */}
              <div className="mt-8 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <div className="flex items-start gap-3">
                  <Icon name="Lock" size={20} color="#3B82F6" className="flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-blue-800">
                    <p className="font-medium mb-1">Secure Verification</p>
                    <p className="text-xs">
                      Your code is encrypted and expires in 10 minutes. Never share it with anyone.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="text-center mt-6">
            <p className="text-xs text-gray-500">
              Powered by Twilio Verify • Enterprise-grade security
            </p>
          </div>
        </div>
      </div>
    </>
  );
};

export default SecureTwilioOTPVerification;