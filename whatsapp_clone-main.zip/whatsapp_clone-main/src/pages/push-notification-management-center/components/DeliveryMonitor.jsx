import React, { useState, useEffect } from 'react';
import { resendNotificationService } from '../../../services/resendNotificationService';

const DeliveryMonitor = ({ dateRange, refreshKey }) => {
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    loadDeliveryLogs();
  }, [dateRange, refreshKey]);

  const loadDeliveryLogs = async () => {
    try {
      setLoading(true);

      const startDate = new Date();
      startDate?.setDate(startDate?.getDate() - (dateRange?.days || 7));

      const result = await resendNotificationService?.getNotificationStats({
        start: startDate?.toISOString(),
        end: new Date()?.toISOString()
      });

      if (result?.success && result?.logs) {
        setLogs(result?.logs);
      }
    } catch (err) {
      console.error('Error loading delivery logs:', err);
    } finally {
      setLoading(false);
    }
  };

  const filteredLogs = filter === 'all' 
    ? logs 
    : logs?.filter(log => log?.notification_type === filter);

  const getTypeColor = (type) => {
    const colors = {
      message: 'bg-green-100 text-green-800',
      mention: 'bg-purple-100 text-purple-800',
      call: 'bg-orange-100 text-orange-800'
    };
    return colors?.[type] || 'bg-gray-100 text-gray-800';
  };

  const getStatusColor = (status) => {
    return status === 'sent' ? 'text-green-600' : 'text-red-600';
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-blue-100 rounded-lg">
            <svg className="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
            </svg>
          </div>
          <h3 className="text-lg font-semibold text-gray-900">Real-Time Delivery Monitor</h3>
        </div>

        {/* Filter Buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setFilter('all')}
            className={`px-3 py-1 rounded-lg text-sm font-medium transition-colors ${
              filter === 'all' ? 'bg-teal-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            All
          </button>
          <button
            onClick={() => setFilter('message')}
            className={`px-3 py-1 rounded-lg text-sm font-medium transition-colors ${
              filter === 'message' ? 'bg-teal-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Messages
          </button>
          <button
            onClick={() => setFilter('mention')}
            className={`px-3 py-1 rounded-lg text-sm font-medium transition-colors ${
              filter === 'mention' ? 'bg-teal-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Mentions
          </button>
          <button
            onClick={() => setFilter('call')}
            className={`px-3 py-1 rounded-lg text-sm font-medium transition-colors ${
              filter === 'call' ? 'bg-teal-600 text-white' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Calls
          </button>
        </div>
      </div>
      {loading ? (
        <div className="flex items-center justify-center h-40">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-teal-600"></div>
        </div>
      ) : filteredLogs?.length === 0 ? (
        <div className="text-center py-12">
          <svg className="w-16 h-16 text-gray-300 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4" />
          </svg>
          <p className="text-gray-500">No delivery logs found</p>
        </div>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-200">
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Type</th>
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Recipient</th>
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Status</th>
                <th className="text-left py-3 px-4 text-sm font-semibold text-gray-700">Time</th>
              </tr>
            </thead>
            <tbody>
              {filteredLogs?.map((log, index) => (
                <tr key={index} className="border-b border-gray-100 hover:bg-gray-50 transition-colors">
                  <td className="py-3 px-4">
                    <span className={`inline-block px-3 py-1 rounded-full text-xs font-medium ${getTypeColor(log?.notification_type)}`}>
                      {log?.notification_type}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-sm text-gray-700">
                    {log?.recipient_email || 'N/A'}
                  </td>
                  <td className="py-3 px-4">
                    <span className={`font-medium text-sm ${getStatusColor(log?.delivery_status)}`}>
                      {log?.delivery_status === 'sent' ? '✓ Sent' : '✗ Failed'}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-sm text-gray-600">
                    {new Date(log?.created_at)?.toLocaleString()}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default DeliveryMonitor;