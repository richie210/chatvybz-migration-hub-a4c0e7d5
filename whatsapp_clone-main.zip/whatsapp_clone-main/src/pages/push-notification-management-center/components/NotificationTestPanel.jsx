import React, { useState } from 'react';
import { resendNotificationService } from '../../../services/resendNotificationService';
import { supabase } from '../../../lib/supabase';

const NotificationTestPanel = ({ onTest }) => {
  const [testType, setTestType] = useState('message');
  const [testEmail, setTestEmail] = useState('');
  const [testing, setTesting] = useState(false);
  const [result, setResult] = useState(null);

  const handleTest = async () => {
    try {
      setTesting(true);
      setResult(null);

      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) {
        setResult({ type: 'error', text: 'Not authenticated' });
        return;
      }

      const emailToTest = testEmail || user?.email;
      if (!emailToTest) {
        setResult({ type: 'error', text: 'Please enter an email address' });
        return;
      }

      const response = await resendNotificationService?.testNotification(emailToTest, testType);

      if (response?.success) {
        setResult({ type: 'success', text: `Test ${testType} notification sent successfully to ${emailToTest}` });
        onTest?.();
      } else {
        setResult({ type: 'error', text: response?.error || 'Failed to send test notification' });
      }
    } catch (err) {
      setResult({ type: 'error', text: err?.message || 'An error occurred' });
    } finally {
      setTesting(false);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2 bg-purple-100 rounded-lg">
          <svg className="w-6 h-6 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
        </div>
        <h3 className="text-lg font-semibold text-gray-900">Test Notifications</h3>
      </div>
      <div className="space-y-4">
        {/* Notification Type Selection */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Notification Type</label>
          <div className="grid grid-cols-3 gap-2">
            <button
              onClick={() => setTestType('message')}
              className={`px-4 py-2 rounded-lg border-2 transition-colors ${
                testType === 'message' ?'border-teal-600 bg-teal-50 text-teal-700' :'border-gray-200 bg-white text-gray-700 hover:border-gray-300'
              }`}
            >
              Message
            </button>
            <button
              onClick={() => setTestType('mention')}
              className={`px-4 py-2 rounded-lg border-2 transition-colors ${
                testType === 'mention' ?'border-teal-600 bg-teal-50 text-teal-700' :'border-gray-200 bg-white text-gray-700 hover:border-gray-300'
              }`}
            >
              Mention
            </button>
            <button
              onClick={() => setTestType('call')}
              className={`px-4 py-2 rounded-lg border-2 transition-colors ${
                testType === 'call' ?'border-teal-600 bg-teal-50 text-teal-700' :'border-gray-200 bg-white text-gray-700 hover:border-gray-300'
              }`}
            >
              Call
            </button>
          </div>
        </div>

        {/* Test Email Input */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Test Email (optional)</label>
          <input
            type="email"
            value={testEmail}
            onChange={(e) => setTestEmail(e?.target?.value)}
            placeholder="Leave empty to use your account email"
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent"
          />
          <p className="mt-1 text-xs text-gray-500">Test notification will be sent to this email</p>
        </div>

        {/* Result Message */}
        {result && (
          <div className={`p-4 rounded-lg ${
            result?.type === 'success' ? 'bg-green-50 text-green-800' : 'bg-red-50 text-red-800'
          }`}>
            <div className="flex items-start gap-2">
              {result?.type === 'success' ? (
                <svg className="w-5 h-5 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
              ) : (
                <svg className="w-5 h-5 flex-shrink-0 mt-0.5" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clipRule="evenodd" />
                </svg>
              )}
              <p className="text-sm">{result?.text}</p>
            </div>
          </div>
        )}

        {/* Test Button */}
        <button
          onClick={handleTest}
          disabled={testing}
          className="w-full px-4 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed font-medium flex items-center justify-center gap-2"
        >
          {testing ? (
            <>
              <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
              Sending Test...
            </>
          ) : (
            <>
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
              Send Test Notification
            </>
          )}
        </button>
      </div>
    </div>
  );
};

export default NotificationTestPanel;