import React, { useState, useEffect } from 'react';
import { resendNotificationService } from '../../services/resendNotificationService';
import NotificationStatsCard from './components/NotificationStatsCard';
import NotificationConfigPanel from './components/NotificationConfigPanel';
import NotificationTestPanel from './components/NotificationTestPanel';
import DeliveryMonitor from './components/DeliveryMonitor';

const PushNotificationManagementCenter = () => {
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [dateRange, setDateRange] = useState({ days: 7 });
  const [refreshKey, setRefreshKey] = useState(0);

  useEffect(() => {
    loadNotificationStats();
  }, [dateRange, refreshKey]);

  const loadNotificationStats = async () => {
    try {
      setLoading(true);
      setError(null);

      const startDate = new Date();
      startDate?.setDate(startDate?.getDate() - (dateRange?.days || 7));

      const result = await resendNotificationService?.getNotificationStats({
        start: startDate?.toISOString(),
        end: new Date()?.toISOString()
      });

      if (result?.success) {
        setStats(result?.stats);
      } else {
        setError(result?.error || 'Failed to load notification statistics');
      }
    } catch (err) {
      setError(err?.message || 'An error occurred');
    } finally {
      setLoading(false);
    }
  };

  const handleRefresh = () => {
    setRefreshKey(prev => prev + 1);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Push Notification Management Center</h1>
              <p className="mt-2 text-sm text-gray-600">
                Configure and monitor real-time notifications for messages, mentions, and calls
              </p>
            </div>
            <div className="flex items-center gap-3">
              <select
                value={dateRange?.days}
                onChange={(e) => setDateRange({ days: parseInt(e?.target?.value) })}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent"
              >
                <option value={1}>Last 24 hours</option>
                <option value={7}>Last 7 days</option>
                <option value={30}>Last 30 days</option>
                <option value={90}>Last 90 days</option>
              </select>
              <button
                onClick={handleRefresh}
                className="px-4 py-2 bg-teal-600 text-white rounded-lg hover:bg-teal-700 transition-colors flex items-center gap-2"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                </svg>
                Refresh
              </button>
            </div>
          </div>
        </div>
      </div>
      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {loading ? (
          <div className="flex items-center justify-center h-64">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-teal-600"></div>
          </div>
        ) : error ? (
          <div className="bg-red-50 border border-red-200 rounded-lg p-6 text-center">
            <svg className="w-12 h-12 text-red-500 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            <p className="text-red-800 font-medium">{error}</p>
            <button
              onClick={handleRefresh}
              className="mt-4 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
            >
              Try Again
            </button>
          </div>
        ) : (
          <div className="space-y-6">
            {/* Statistics Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <NotificationStatsCard
                title="Total Notifications"
                value={stats?.totalSent || 0}
                icon="bell"
                color="blue"
              />
              <NotificationStatsCard
                title="Message Alerts"
                value={stats?.messageNotifications || 0}
                icon="message"
                color="green"
              />
              <NotificationStatsCard
                title="Mention Alerts"
                value={stats?.mentionNotifications || 0}
                icon="at"
                color="purple"
              />
              <NotificationStatsCard
                title="Call Alerts"
                value={stats?.callNotifications || 0}
                icon="phone"
                color="orange"
              />
            </div>

            {/* Delivery Rate Card */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-900">Delivery Performance</h3>
                <span className="text-2xl font-bold text-teal-600">{stats?.deliveryRate || 0}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3">
                <div
                  className="bg-teal-600 h-3 rounded-full transition-all duration-500"
                  style={{ width: `${stats?.deliveryRate || 0}%` }}
                ></div>
              </div>
              <div className="mt-4 flex items-center justify-between text-sm">
                <span className="text-gray-600">Successful: {(stats?.totalSent || 0) - (stats?.failedDeliveries || 0)}</span>
                <span className="text-red-600">Failed: {stats?.failedDeliveries || 0}</span>
              </div>
            </div>

            {/* Configuration and Testing Panels */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <NotificationConfigPanel onUpdate={handleRefresh} />
              <NotificationTestPanel onTest={handleRefresh} />
            </div>

            {/* Delivery Monitor */}
            <DeliveryMonitor dateRange={dateRange} refreshKey={refreshKey} />
          </div>
        )}
      </div>
    </div>
  );
};

export default PushNotificationManagementCenter;