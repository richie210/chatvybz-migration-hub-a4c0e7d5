import React, { useState } from 'react';
import { TrendingUp } from 'lucide-react';
import { creatorRevenueSettlementService } from '../../../services/creatorRevenueSettlementService';

const EarningsChart = ({ daily, weekly, monthly }) => {
  const [period, setPeriod] = useState('daily');

  const data = period === 'daily' ? daily : period === 'weekly' ? weekly : monthly;

  const maxValue = Math.max(...(data?.map(d => d?.total) || [0]));

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-green-600" />
          Earnings Analytics
        </h2>
        <div className="flex gap-2">
          <button
            onClick={() => setPeriod('daily')}
            className={`px-3 py-1 rounded-lg text-sm font-medium transition-colors ${
              period === 'daily' ? 'bg-green-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            Daily
          </button>
          <button
            onClick={() => setPeriod('weekly')}
            className={`px-3 py-1 rounded-lg text-sm font-medium transition-colors ${
              period === 'weekly' ? 'bg-green-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            Weekly
          </button>
          <button
            onClick={() => setPeriod('monthly')}
            className={`px-3 py-1 rounded-lg text-sm font-medium transition-colors ${
              period === 'monthly' ? 'bg-green-600 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            Monthly
          </button>
        </div>
      </div>

      {data && data?.length > 0 ? (
        <div className="space-y-3">
          {data?.map((item, index) => (
            <div key={index} className="flex items-center gap-3">
              <div className="w-24 text-sm text-gray-600 flex-shrink-0">
                {item?.period}
              </div>
              <div className="flex-1">
                <div className="relative h-8 bg-gray-100 rounded-lg overflow-hidden">
                  <div
                    className="absolute inset-y-0 left-0 bg-gradient-to-r from-green-500 to-blue-500 rounded-lg transition-all"
                    style={{ width: `${(item?.total / maxValue) * 100}%` }}
                  ></div>
                  <div className="absolute inset-0 flex items-center px-3">
                    <span className="text-xs font-medium text-gray-900">
                      {creatorRevenueSettlementService?.formatAmount(item?.total)}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <p className="text-center text-gray-500 py-8">No earnings data available</p>
      )}

      {/* Legend */}
      <div className="mt-6 pt-4 border-t border-gray-200">
        <div className="flex items-center gap-4 text-xs">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-green-500 rounded"></div>
            <span className="text-gray-600">Subscriptions</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-blue-500 rounded"></div>
            <span className="text-gray-600">Ad Revenue</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-purple-500 rounded"></div>
            <span className="text-gray-600">Tips</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EarningsChart;