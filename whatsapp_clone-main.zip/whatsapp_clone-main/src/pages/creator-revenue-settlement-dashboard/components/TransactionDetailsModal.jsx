import React, { useState, useEffect } from 'react';
import { X, Loader2, DollarSign, TrendingUp, Heart, CreditCard, RotateCcw, Settings, AlertCircle } from 'lucide-react';
import { payoutTransactionService } from '../../../services/payoutTransactionService';
import Button from '../../../components/ui/Button';
import Icon from '../../../components/AppIcon';


const TransactionDetailsModal = ({ payout, onClose }) => {
  const [loading, setLoading] = useState(true);
  const [transactions, setTransactions] = useState([]);
  const [analytics, setAnalytics] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    if (payout?.id) {
      loadTransactionDetails();
    }
  }, [payout?.id]);

  const loadTransactionDetails = async () => {
    try {
      setLoading(true);
      setError('');

      const [txnResult, analyticsResult] = await Promise.all([
        payoutTransactionService?.getPayoutTransactions(payout?.id),
        payoutTransactionService?.getTransactionAnalytics(payout?.id)
      ]);

      if (txnResult?.error) throw txnResult?.error;
      if (analyticsResult?.error) throw analyticsResult?.error;

      setTransactions(txnResult?.data || []);
      setAnalytics(analyticsResult?.data);
    } catch (err) {
      console.error('Error loading transaction details:', err);
      setError(err?.message || 'Failed to load transaction details');
    } finally {
      setLoading(false);
    }
  };

  const getTypeIcon = (type) => {
    const iconName = payoutTransactionService?.getTransactionTypeIcon(type);
    const icons = {
      CreditCard,
      TrendingUp,
      Heart,
      RotateCcw,
      Settings,
      DollarSign
    };
    return icons?.[iconName] || DollarSign;
  };

  const getTypeColor = (type) => {
    const color = payoutTransactionService?.getTransactionTypeColor(type);
    const colors = {
      green: 'text-green-600 bg-green-50',
      blue: 'text-blue-600 bg-blue-50',
      purple: 'text-purple-600 bg-purple-50',
      red: 'text-red-600 bg-red-50',
      gray: 'text-gray-600 bg-gray-50'
    };
    return colors?.[color] || 'text-gray-600 bg-gray-50';
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-4xl w-full max-h-[90vh] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="bg-gradient-to-r from-green-600 to-blue-600 text-white p-6 flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold">Transaction Details</h2>
            <p className="text-green-100 mt-1">
              Payout: {payoutTransactionService?.formatAmount(payout?.amount, payout?.currency)}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-white/20 rounded-lg transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
            </div>
          ) : error ? (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-red-800 font-medium">Error Loading Transactions</p>
                <p className="text-red-600 text-sm mt-1">{error}</p>
              </div>
            </div>
          ) : transactions?.length === 0 ? (
            <div className="text-center py-12">
              <DollarSign className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-600">No transaction details available yet</p>
              <p className="text-gray-500 text-sm mt-2">
                Transaction details will appear once the payout is processed by Stripe
              </p>
            </div>
          ) : (
            <div className="space-y-6">
              {/* Analytics Summary */}
              {analytics && (
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div className="bg-blue-50 rounded-lg p-4">
                    <p className="text-sm text-blue-600 font-medium">Total Transactions</p>
                    <p className="text-2xl font-bold text-blue-900 mt-1">
                      {analytics?.totalTransactions}
                    </p>
                  </div>
                  <div className="bg-green-50 rounded-lg p-4">
                    <p className="text-sm text-green-600 font-medium">Gross Amount</p>
                    <p className="text-2xl font-bold text-green-900 mt-1">
                      {payoutTransactionService?.formatAmount(analytics?.totalAmount, payout?.currency)}
                    </p>
                  </div>
                  <div className="bg-red-50 rounded-lg p-4">
                    <p className="text-sm text-red-600 font-medium">Total Fees</p>
                    <p className="text-2xl font-bold text-red-900 mt-1">
                      {payoutTransactionService?.formatAmount(analytics?.totalFees, payout?.currency)}
                    </p>
                  </div>
                  <div className="bg-purple-50 rounded-lg p-4">
                    <p className="text-sm text-purple-600 font-medium">Net Amount</p>
                    <p className="text-2xl font-bold text-purple-900 mt-1">
                      {payoutTransactionService?.formatAmount(analytics?.netAmount, payout?.currency)}
                    </p>
                  </div>
                </div>
              )}

              {/* Transaction Breakdown by Type */}
              {analytics?.byType && Object.keys(analytics?.byType)?.length > 0 && (
                <div className="bg-gray-50 rounded-lg p-4">
                  <h3 className="text-lg font-semibold text-gray-900 mb-3">Breakdown by Type</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                    {Object.entries(analytics?.byType)?.map(([type, data]) => {
                      const Icon = getTypeIcon(type);
                      const colorClass = getTypeColor(type);
                      return (
                        <div key={type} className={`${colorClass} rounded-lg p-3`}>
                          <div className="flex items-center gap-2 mb-2">
                            <Icon className="w-4 h-4" />
                            <span className="text-sm font-medium">
                              {payoutTransactionService?.formatTransactionType(type)}
                            </span>
                          </div>
                          <p className="text-lg font-bold">
                            {payoutTransactionService?.formatAmount(data?.amount, payout?.currency)}
                          </p>
                          <p className="text-xs opacity-75 mt-1">
                            {data?.count} transaction{data?.count !== 1 ? 's' : ''}
                          </p>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Transaction List */}
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-3">All Transactions</h3>
                <div className="space-y-2">
                  {transactions?.map((txn) => {
                    const Icon = getTypeIcon(txn?.transaction_type);
                    const colorClass = getTypeColor(txn?.transaction_type);
                    return (
                      <div key={txn?.id} className="bg-white border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
                        <div className="flex items-start justify-between">
                          <div className="flex items-start gap-3 flex-1">
                            <div className={`p-2 rounded-lg ${colorClass}`}>
                              <Icon className="w-5 h-5" />
                            </div>
                            <div className="flex-1">
                              <p className="font-medium text-gray-900">
                                {payoutTransactionService?.formatTransactionType(txn?.transaction_type)}
                              </p>
                              <p className="text-sm text-gray-600 mt-1">{txn?.description}</p>
                              <p className="text-xs text-gray-500 mt-1">
                                {new Date(txn?.transaction_date)?.toLocaleString()}
                              </p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="text-lg font-bold text-gray-900">
                              {payoutTransactionService?.formatAmount(txn?.amount, txn?.currency)}
                            </p>
                            {txn?.fee_amount > 0 && (
                              <p className="text-xs text-red-600 mt-1">
                                Fee: {payoutTransactionService?.formatAmount(txn?.fee_amount, txn?.currency)}
                              </p>
                            )}
                            <p className="text-sm text-green-600 font-medium mt-1">
                              Net: {payoutTransactionService?.formatAmount(txn?.net_amount, txn?.currency)}
                            </p>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="border-t border-gray-200 p-4 flex justify-end">
          <Button onClick={onClose} variant="outline">
            Close
          </Button>
        </div>
      </div>
    </div>
  );
};

export default TransactionDetailsModal;