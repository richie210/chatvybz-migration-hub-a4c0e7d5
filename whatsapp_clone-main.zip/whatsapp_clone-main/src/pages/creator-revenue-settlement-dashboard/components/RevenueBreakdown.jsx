import React from 'react';
import { DollarSign, TrendingUp, Heart } from 'lucide-react';
import { creatorRevenueSettlementService } from '../../../services/creatorRevenueSettlementService';
import Icon from '../../../components/AppIcon';


const RevenueBreakdown = ({ revenueBySource }) => {
  if (!revenueBySource) return null;

  const total = revenueBySource?.subscriptions + revenueBySource?.adRevenue + revenueBySource?.tips;

  const sources = [
    {
      name: 'Subscriptions',
      amount: revenueBySource?.subscriptions,
      icon: DollarSign,
      color: 'bg-green-500',
      textColor: 'text-green-600',
      bgColor: 'bg-green-50'
    },
    {
      name: 'Ad Revenue',
      amount: revenueBySource?.adRevenue,
      icon: TrendingUp,
      color: 'bg-blue-500',
      textColor: 'text-blue-600',
      bgColor: 'bg-blue-50'
    },
    {
      name: 'Tips',
      amount: revenueBySource?.tips,
      icon: Heart,
      color: 'bg-purple-500',
      textColor: 'text-purple-600',
      bgColor: 'bg-purple-50'
    }
  ];

  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h2 className="text-lg font-semibold text-gray-900 mb-4">Revenue Breakdown by Source</h2>
      
      {/* Visual Bar */}
      <div className="h-8 bg-gray-100 rounded-lg overflow-hidden flex mb-6">
        {sources?.map((source, index) => {
          const percentage = total > 0 ? (source?.amount / total) * 100 : 0;
          return percentage > 0 ? (
            <div
              key={index}
              className={`${source?.color} flex items-center justify-center text-white text-xs font-medium`}
              style={{ width: `${percentage}%` }}
            >
              {percentage > 10 && `${percentage?.toFixed(0)}%`}
            </div>
          ) : null;
        })}
      </div>

      {/* Breakdown Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {sources?.map((source, index) => {
          const Icon = source?.icon;
          const percentage = total > 0 ? (source?.amount / total) * 100 : 0;
          
          return (
            <div key={index} className={`${source?.bgColor} rounded-lg p-4`}>
              <div className="flex items-center gap-2 mb-2">
                <Icon className={`w-5 h-5 ${source?.textColor}`} />
                <span className="text-sm font-medium text-gray-700">{source?.name}</span>
              </div>
              <p className={`text-2xl font-bold ${source?.textColor}`}>
                {creatorRevenueSettlementService?.formatAmount(source?.amount)}
              </p>
              <p className="text-xs text-gray-600 mt-1">
                {percentage?.toFixed(1)}% of total revenue
              </p>
            </div>
          );
        })}
      </div>

      {/* Total */}
      <div className="mt-6 pt-4 border-t border-gray-200">
        <div className="flex items-center justify-between">
          <span className="text-gray-700 font-medium">Total Revenue</span>
          <span className="text-2xl font-bold text-gray-900">
            {creatorRevenueSettlementService?.formatAmount(total)}
          </span>
        </div>
      </div>
    </div>
  );
};

export default RevenueBreakdown;