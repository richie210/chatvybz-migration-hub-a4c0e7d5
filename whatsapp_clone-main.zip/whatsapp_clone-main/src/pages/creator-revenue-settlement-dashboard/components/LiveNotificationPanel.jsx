import React, { useState, useEffect } from 'react';
import { Bell, CheckCircle, Clock, TrendingUp, XCircle, X } from 'lucide-react';
import { payoutNotificationService } from '../../../services/payoutNotificationService';
import { useAuth } from '../../../contexts/AuthContext';
import Icon from '../../../components/AppIcon';


const LiveNotificationPanel = () => {
  const { user } = useAuth();
  const [notifications, setNotifications] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [showPanel, setShowPanel] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleNewNotification = (notification) => {
    setNotifications(prev => [notification, ...prev]);
    setUnreadCount(prev => prev + 1);

    // Show browser notification if permission granted
    if (Notification?.permission === 'granted') {
      new Notification(notification?.title, {
        body: notification?.message,
        icon: '/favicon.ico'
      });
    }
  };

  useEffect(() => {
    if (user?.id) {
      loadNotifications();
      loadUnreadCount();

      // Subscribe to real-time updates
      const channel = payoutNotificationService?.subscribeToNotifications(
        user?.id,
        handleNewNotification
      );

      return () => {
        payoutNotificationService?.unsubscribeFromNotifications(channel);
      };
    }
  }, [user?.id]);

  const loadNotifications = async () => {
    setLoading(true);
    const result = await payoutNotificationService?.getNotifications(20);
    if (result?.data) {
      setNotifications(result?.data);
    }
    setLoading(false);
  };

  const loadUnreadCount = async () => {
    const result = await payoutNotificationService?.getUnreadCount();
    if (result?.data !== null) {
      setUnreadCount(result?.data);
    }
  };

  const handleMarkAsRead = async (notificationId) => {
    await payoutNotificationService?.markAsRead(notificationId);
    setNotifications(prev =>
      prev?.map(n => n?.id === notificationId ? { ...n, read: true } : n)
    );
    setUnreadCount(prev => Math.max(0, prev - 1));
  };

  const handleMarkAllAsRead = async () => {
    await payoutNotificationService?.markAllAsRead();
    setNotifications(prev => prev?.map(n => ({ ...n, read: true })));
    setUnreadCount(0);
  };

  const getNotificationIcon = (type) => {
    const icons = {
      payout_created: Clock,
      payout_processing: TrendingUp,
      payout_paid: CheckCircle,
      payout_failed: XCircle,
      payout_updated: Bell
    };
    return icons?.[type] || Bell;
  };

  const getNotificationColor = (type) => {
    const colors = {
      payout_created: 'text-blue-600 bg-blue-50',
      payout_processing: 'text-yellow-600 bg-yellow-50',
      payout_paid: 'text-green-600 bg-green-50',
      payout_failed: 'text-red-600 bg-red-50',
      payout_updated: 'text-gray-600 bg-gray-50'
    };
    return colors?.[type] || 'text-gray-600 bg-gray-50';
  };

  return (
    <div className="relative">
      {/* Notification Bell Button */}
      <button
        onClick={() => setShowPanel(!showPanel)}
        className="relative p-2 hover:bg-gray-100 rounded-lg transition-colors"
      >
        <Bell className="w-6 h-6 text-gray-700" />
        {unreadCount > 0 && (
          <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center animate-pulse">
            {unreadCount > 9 ? '9+' : unreadCount}
          </span>
        )}
      </button>

      {/* Notification Panel */}
      {showPanel && (
        <div className="absolute right-0 top-12 w-96 bg-white rounded-lg shadow-xl border border-gray-200 z-50 max-h-[600px] flex flex-col">
          {/* Header */}
          <div className="p-4 border-b border-gray-200 flex items-center justify-between">
            <div>
              <h3 className="text-lg font-semibold text-gray-900">Notifications</h3>
              {unreadCount > 0 && (
                <p className="text-sm text-gray-600">{unreadCount} unread</p>
              )}
            </div>
            <div className="flex items-center gap-2">
              {unreadCount > 0 && (
                <button
                  onClick={handleMarkAllAsRead}
                  className="text-xs text-blue-600 hover:text-blue-700 font-medium"
                >
                  Mark all read
                </button>
              )}
              <button
                onClick={() => setShowPanel(false)}
                className="p-1 hover:bg-gray-100 rounded"
              >
                <X className="w-5 h-5 text-gray-500" />
              </button>
            </div>
          </div>

          {/* Notification List */}
          <div className="flex-1 overflow-y-auto">
            {loading ? (
              <div className="p-8 text-center text-gray-500">
                Loading notifications...
              </div>
            ) : notifications?.length === 0 ? (
              <div className="p-8 text-center">
                <Bell className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <p className="text-gray-600">No notifications yet</p>
                <p className="text-sm text-gray-500 mt-1">
                  You'll be notified about payout updates here
                </p>
              </div>
            ) : (
              <div className="divide-y divide-gray-100">
                {notifications?.map((notification) => {
                  const Icon = getNotificationIcon(notification?.notification_type);
                  const colorClass = getNotificationColor(notification?.notification_type);
                  return (
                    <div
                      key={notification?.id}
                      className={`p-4 hover:bg-gray-50 transition-colors cursor-pointer ${
                        !notification?.read ? 'bg-blue-50' : ''
                      }`}
                      onClick={() => !notification?.read && handleMarkAsRead(notification?.id)}
                    >
                      <div className="flex items-start gap-3">
                        <div className={`p-2 rounded-lg ${colorClass} flex-shrink-0`}>
                          <Icon className="w-5 h-5" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-2">
                            <p className={`font-medium text-gray-900 ${
                              !notification?.read ? 'font-semibold' : ''
                            }`}>
                              {notification?.title}
                            </p>
                            {!notification?.read && (
                              <span className="w-2 h-2 bg-blue-600 rounded-full flex-shrink-0 mt-1.5"></span>
                            )}
                          </div>
                          <p className="text-sm text-gray-600 mt-1">
                            {notification?.message}
                          </p>
                          <p className="text-xs text-gray-500 mt-2">
                            {new Date(notification?.created_at)?.toLocaleString()}
                          </p>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default LiveNotificationPanel;