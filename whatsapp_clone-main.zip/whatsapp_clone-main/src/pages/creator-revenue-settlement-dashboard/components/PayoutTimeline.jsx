import React from 'react';
import { Clock, CheckCircle, TrendingUp, Receipt } from 'lucide-react';
import { creatorRevenueSettlementService } from '../../../services/creatorRevenueSettlementService';
import Button from '../../../components/ui/Button';

const PayoutTimeline = ({ payout, onViewTransactions }) => {
  const timeline = creatorRevenueSettlementService?.getPayoutTimeline(payout);

  return (
    <div className="border border-gray-200 rounded-lg p-4">
      <div className="flex items-center justify-between mb-3">
        <div>
          <p className="font-medium text-gray-900">{payout?.channel?.name}</p>
          <p className="text-sm text-gray-600">
            {creatorRevenueSettlementService?.formatAmount(payout?.amount, payout?.currency)}
          </p>
        </div>
        <div className="text-right">
          <span className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-medium ${
            payout?.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
            payout?.status === 'processing'? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-800'
          }`}>
            {payout?.status === 'pending' && <Clock className="w-3 h-3" />}
            {payout?.status === 'processing' && <TrendingUp className="w-3 h-3" />}
            {payout?.status?.charAt(0)?.toUpperCase() + payout?.status?.slice(1)}
          </span>
        </div>
      </div>

      {/* Timeline */}
      <div className="relative pl-6 space-y-3">
        <div className="absolute left-0 top-0 bottom-0 w-0.5 bg-gray-200"></div>
        
        {/* Created */}
        <div className="relative">
          <div className="absolute -left-[1.4rem] w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
            <CheckCircle className="w-4 h-4 text-white" />
          </div>
          <div>
            <p className="text-sm font-medium text-gray-900">Payout Created</p>
            <p className="text-xs text-gray-600">
              {new Date(timeline?.created)?.toLocaleString()}
            </p>
          </div>
        </div>

        {/* Processing */}
        {payout?.status === 'processing' && (
          <div className="relative">
            <div className="absolute -left-[1.4rem] w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center">
              <TrendingUp className="w-4 h-4 text-white" />
            </div>
            <div>
              <p className="text-sm font-medium text-gray-900">Processing Transfer</p>
              <p className="text-xs text-gray-600">In progress</p>
            </div>
          </div>
        )}

        {/* Estimated Arrival */}
        <div className="relative">
          <div className={`absolute -left-[1.4rem] w-6 h-6 rounded-full flex items-center justify-center ${
            payout?.status === 'paid' ? 'bg-green-500' : 'bg-gray-300'
          }`}>
            {payout?.status === 'paid' ? (
              <CheckCircle className="w-4 h-4 text-white" />
            ) : (
              <Clock className="w-4 h-4 text-white" />
            )}
          </div>
          <div>
            <p className="text-sm font-medium text-gray-900">
              {payout?.status === 'paid' ? 'Completed' : 'Estimated Arrival'}
            </p>
            <p className="text-xs text-gray-600">
              {payout?.status === 'paid' 
                ? new Date(timeline?.actualArrival)?.toLocaleString()
                : `${new Date(timeline?.estimatedArrival)?.toLocaleDateString()} (${timeline?.daysRemaining} days remaining)`
              }
            </p>
          </div>
        </div>
      </div>

      {/* Revenue Breakdown */}
      {payout?.revenue_breakdown && (
        <div className="mt-4 pt-4 border-t border-gray-200">
          <div className="flex items-center justify-between mb-2">
            <p className="text-xs font-medium text-gray-700">Revenue Breakdown:</p>
            {payout?.status === 'paid' && onViewTransactions && (
              <Button
                onClick={() => onViewTransactions(payout)}
                variant="outline"
                size="sm"
                className="text-xs flex items-center gap-1"
              >
                <Receipt className="w-3 h-3" />
                View Details
              </Button>
            )}
          </div>
          <div className="grid grid-cols-3 gap-2 text-xs">
            {payout?.revenue_breakdown?.subscription_revenue > 0 && (
              <div>
                <p className="text-gray-600">Subscriptions</p>
                <p className="font-medium text-gray-900">
                  {creatorRevenueSettlementService?.formatAmount(payout?.revenue_breakdown?.subscription_revenue)}
                </p>
              </div>
            )}
            {payout?.revenue_breakdown?.ad_revenue > 0 && (
              <div>
                <p className="text-gray-600">Ad Revenue</p>
                <p className="font-medium text-gray-900">
                  {creatorRevenueSettlementService?.formatAmount(payout?.revenue_breakdown?.ad_revenue)}
                </p>
              </div>
            )}
            {payout?.revenue_breakdown?.donation_revenue > 0 && (
              <div>
                <p className="text-gray-600">Tips</p>
                <p className="font-medium text-gray-900">
                  {creatorRevenueSettlementService?.formatAmount(payout?.revenue_breakdown?.donation_revenue)}
                </p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default PayoutTimeline;