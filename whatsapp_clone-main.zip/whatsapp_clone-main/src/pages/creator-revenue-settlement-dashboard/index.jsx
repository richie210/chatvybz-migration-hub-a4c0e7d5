import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { DollarSign, TrendingUp, Clock, CheckCircle, XCircle, FileText, Download, Loader2, AlertCircle, CreditCard, Receipt } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { creatorRevenueSettlementService } from '../../services/creatorRevenueSettlementService';
import Button from '../../components/ui/Button';
import SettlementMetricsCard from './components/SettlementMetricsCard';
import PayoutTimeline from './components/PayoutTimeline';
import EarningsChart from './components/EarningsChart';
import RevenueBreakdown from './components/RevenueBreakdown';
import TransactionDetailsModal from './components/TransactionDetailsModal';


export default function CreatorRevenueSettlementDashboard() {
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();

  const [loading, setLoading] = useState(true);
  const [settlementData, setSettlementData] = useState(null);
  const [taxYear, setTaxYear] = useState(new Date()?.getFullYear());
  const [activeTab, setActiveTab] = useState('overview');
  const [error, setError] = useState('');
  const [downloadingTax, setDownloadingTax] = useState(false);
  const [selectedPayout, setSelectedPayout] = useState(null);
  const [showTransactionModal, setShowTransactionModal] = useState(false);

  useEffect(() => {
    if (!authLoading && !user) {
      navigate('/login');
    }
  }, [user, authLoading, navigate]);

  useEffect(() => {
    if (!authLoading && user) {
      loadSettlementData();
    }
  }, [authLoading, user]);

  const loadSettlementData = async () => {
    try {
      setLoading(true);
      setError('');

      const result = await creatorRevenueSettlementService?.getSettlementData();

      if (result?.error) throw result?.error;

      setSettlementData(result?.data);
    } catch (err) {
      console.error('Error loading settlement data:', err);
      setError(err?.message || 'Failed to load settlement data');
    } finally {
      setLoading(false);
    }
  };

  const handleDownloadTaxDoc = async () => {
    try {
      setDownloadingTax(true);
      const result = await creatorRevenueSettlementService?.getTaxDocumentation(taxYear);
      
      if (result?.error) throw result?.error;

      // Create downloadable JSON file
      const dataStr = JSON.stringify(result?.data, null, 2);
      const dataBlob = new Blob([dataStr], { type: 'application/json' });
      const url = URL.createObjectURL(dataBlob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `tax-documentation-${taxYear}.json`;
      link?.click();
      URL.revokeObjectURL(url);

      alert('Tax documentation downloaded successfully');
    } catch (err) {
      console.error('Error downloading tax documentation:', err);
      alert(err?.message || 'Failed to download tax documentation');
    } finally {
      setDownloadingTax(false);
    }
  };

  const handleSetupStripeConnect = async () => {
    try {
      const result = await creatorRevenueSettlementService?.setupStripeConnect();
      if (result?.error) throw result?.error;

      if (result?.data?.url) {
        window.location.href = result?.data?.url;
      }
    } catch (err) {
      console.error('Error setting up Stripe Connect:', err);
      alert(err?.message || 'Failed to setup Stripe Connect');
    }
  };

  const handleViewTransactions = (payout) => {
    setSelectedPayout(payout);
    setShowTransactionModal(true);
  };

  const handleCloseTransactionModal = () => {
    setShowTransactionModal(false);
    setSelectedPayout(null);
  };

  if (authLoading || loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-lg shadow-lg p-6 max-w-md w-full">
          <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <p className="text-center text-gray-700 mb-4">{error}</p>
          <Button onClick={() => navigate('/channel-management-dashboard')} className="w-full">
            Go to Channel Management
          </Button>
        </div>
      </div>
    );
  }

  const metrics = settlementData?.metrics || {};
  const earningsAnalytics = settlementData?.earningsAnalytics || {};

  return (
    <>
      <Helmet>
        <title>Revenue Settlement Dashboard | ChatVybz</title>
      </Helmet>
      <div className="min-h-screen bg-gray-50 pb-20">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
                <DollarSign className="w-8 h-8 text-green-600" />
                Revenue Settlement
              </h1>
              <p className="mt-2 text-gray-600">
                Track your earnings, payouts, and settlement status
              </p>
            </div>
            <Button
              onClick={() => navigate('/withdrawal-request-management-dashboard')}
              variant="outline"
              iconName="ArrowRight"
              iconPosition="right"
            >
              Request Withdrawal
            </Button>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          {/* Key Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <SettlementMetricsCard
              title="Pending Settlements"
              value={creatorRevenueSettlementService?.formatAmount(metrics?.pendingAmount || 0)}
              icon={Clock}
              iconColor="text-yellow-600"
              bgColor="bg-yellow-50"
            />
            <SettlementMetricsCard
              title="Processing"
              value={creatorRevenueSettlementService?.formatAmount(metrics?.processingAmount || 0)}
              icon={TrendingUp}
              iconColor="text-blue-600"
              bgColor="bg-blue-50"
            />
            <SettlementMetricsCard
              title="Total Paid Out"
              value={creatorRevenueSettlementService?.formatAmount(metrics?.completedAmount || 0)}
              icon={CheckCircle}
              iconColor="text-green-600"
              bgColor="bg-green-50"
            />
            <SettlementMetricsCard
              title="Total Revenue"
              value={creatorRevenueSettlementService?.formatAmount(earningsAnalytics?.totalRevenue || 0)}
              icon={DollarSign}
              iconColor="text-purple-600"
              bgColor="bg-purple-50"
            />
          </div>

          {/* Tab Navigation */}
          <div className="bg-white rounded-lg shadow-sm mb-6">
            <div className="border-b border-gray-200">
              <nav className="flex -mb-px">
                {['overview', 'pending', 'completed', 'analytics', 'tax']?.map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setActiveTab(tab)}
                    className={`px-6 py-3 text-sm font-medium border-b-2 transition-colors ${
                      activeTab === tab
                        ? 'border-green-500 text-green-600' : 'border-transparent text-gray-600 hover:text-gray-900 hover:border-gray-300'
                    }`}
                  >
                    {tab?.charAt(0)?.toUpperCase() + tab?.slice(1)}
                  </button>
                ))}
              </nav>
            </div>
          </div>

          {/* Overview Tab */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* Revenue Breakdown */}
              <RevenueBreakdown revenueBySource={earningsAnalytics?.revenueBySource} />

              {/* Earnings Chart */}
              <EarningsChart 
                daily={earningsAnalytics?.daily}
                weekly={earningsAnalytics?.weekly}
                monthly={earningsAnalytics?.monthly}
              />

              {/* Recent Settlements */}
              <div className="bg-white rounded-lg shadow-sm p-6">
                <h2 className="text-lg font-semibold text-gray-900 mb-4">Recent Settlements</h2>
                <div className="space-y-3">
                  {settlementData?.payouts?.slice(0, 5)?.map((payout) => (
                    <div key={payout?.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                      <div className="flex items-center gap-3">
                        {payout?.status === 'paid' && <CheckCircle className="w-5 h-5 text-green-600" />}
                        {payout?.status === 'pending' && <Clock className="w-5 h-5 text-yellow-600" />}
                        {payout?.status === 'processing' && <TrendingUp className="w-5 h-5 text-blue-600" />}
                        {payout?.status === 'failed' && <XCircle className="w-5 h-5 text-red-600" />}
                        <div>
                          <p className="font-medium text-gray-900">{payout?.channel?.name}</p>
                          <p className="text-sm text-gray-600">
                            {new Date(payout?.created_at)?.toLocaleDateString()}
                          </p>
                        </div>
                      </div>
                      <div className="text-right flex items-center gap-3">
                        <div>
                          <p className="text-lg font-bold text-gray-900">
                            {creatorRevenueSettlementService?.formatAmount(payout?.amount, payout?.currency)}
                          </p>
                          <p className="text-sm text-gray-600 capitalize">{payout?.status}</p>
                        </div>
                        {payout?.status === 'paid' && (
                          <Button
                            onClick={() => handleViewTransactions(payout)}
                            variant="outline"
                            size="sm"
                            className="flex items-center gap-1"
                          >
                            <Receipt className="w-4 h-4" />
                            Details
                          </Button>
                        )}
                      </div>
                    </div>
                  ))}
                  {(!settlementData?.payouts || settlementData?.payouts?.length === 0) && (
                    <p className="text-center text-gray-500 py-8">No settlements yet</p>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Pending Tab */}
          {activeTab === 'pending' && (
            <div className="space-y-6">
              <div className="bg-white rounded-lg shadow-sm p-6">
                <h2 className="text-lg font-semibold text-gray-900 mb-4">Pending Settlements</h2>
                <div className="space-y-4">
                  {settlementData?.pendingSettlements?.map((payout) => (
                    <PayoutTimeline key={payout?.id} payout={payout} onViewTransactions={handleViewTransactions} />
                  ))}
                  {settlementData?.processingSettlements?.map((payout) => (
                    <PayoutTimeline key={payout?.id} payout={payout} onViewTransactions={handleViewTransactions} />
                  ))}
                  {(!settlementData?.pendingSettlements?.length && !settlementData?.processingSettlements?.length) && (
                    <p className="text-center text-gray-500 py-8">No pending settlements</p>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Completed Tab */}
          {activeTab === 'completed' && (
            <div className="space-y-6">
              <div className="bg-white rounded-lg shadow-sm p-6">
                <h2 className="text-lg font-semibold text-gray-900 mb-4">Completed Settlements</h2>
                <div className="space-y-3">
                  {settlementData?.completedSettlements?.map((payout) => (
                    <div key={payout?.id} className="flex items-center justify-between p-4 bg-green-50 rounded-lg hover:bg-green-100 transition-colors">
                      <div className="flex items-center gap-3">
                        <CheckCircle className="w-5 h-5 text-green-600" />
                        <div>
                          <p className="font-medium text-gray-900">{payout?.channel?.name}</p>
                          <p className="text-sm text-gray-600">
                            Paid on {new Date(payout?.paid_at)?.toLocaleDateString()}
                          </p>
                          <p className="text-xs text-gray-500 mt-1">
                            Stripe Transfer ID: {payout?.stripe_payout_id}
                          </p>
                        </div>
                      </div>
                      <div className="text-right flex items-center gap-3">
                        <div>
                          <p className="text-lg font-bold text-green-600">
                            {creatorRevenueSettlementService?.formatAmount(payout?.amount, payout?.currency)}
                          </p>
                          <p className="text-sm text-gray-600">
                            {payout?.revenue_breakdown?.subscription_revenue && `Subs: ${creatorRevenueSettlementService?.formatAmount(payout?.revenue_breakdown?.subscription_revenue)}`}
                          </p>
                        </div>
                        <Button
                          onClick={() => handleViewTransactions(payout)}
                          variant="outline"
                          size="sm"
                          className="flex items-center gap-1"
                        >
                          <Receipt className="w-4 h-4" />
                          View Details
                        </Button>
                      </div>
                    </div>
                  ))}
                  {(!settlementData?.completedSettlements || settlementData?.completedSettlements?.length === 0) && (
                    <p className="text-center text-gray-500 py-8">No completed settlements</p>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Analytics Tab */}
          {activeTab === 'analytics' && (
            <div className="space-y-6">
              <EarningsChart 
                daily={earningsAnalytics?.daily}
                weekly={earningsAnalytics?.weekly}
                monthly={earningsAnalytics?.monthly}
              />
              <RevenueBreakdown revenueBySource={earningsAnalytics?.revenueBySource} />
            </div>
          )}

          {/* Tax Tab */}
          {activeTab === 'tax' && (
            <div className="space-y-6">
              <div className="bg-white rounded-lg shadow-sm p-6">
                <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
                  <FileText className="w-5 h-5 text-blue-600" />
                  Tax Documentation
                </h2>
                <p className="text-gray-600 mb-6">
                  Download your tax documentation for the selected year. This includes 1099 forms for US creators and quarterly earnings summaries.
                </p>
                <div className="flex items-center gap-4">
                  <select
                    value={taxYear}
                    onChange={(e) => setTaxYear(parseInt(e?.target?.value))}
                    className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    {[2024, 2023, 2022, 2021]?.map((year) => (
                      <option key={year} value={year}>{year}</option>
                    ))}
                  </select>
                  <Button
                    onClick={handleDownloadTaxDoc}
                    disabled={downloadingTax}
                    className="flex items-center gap-2"
                  >
                    {downloadingTax ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <Download className="w-4 h-4" />
                    )}
                    Download Tax Documentation
                  </Button>
                </div>
              </div>

              {/* Stripe Connect Setup */}
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
                <div className="flex items-start gap-3">
                  <CreditCard className="w-6 h-6 text-blue-600 flex-shrink-0 mt-1" />
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">Stripe Connect Setup</h3>
                    <p className="text-gray-700 mb-4">
                      To receive payouts, you need to connect your Stripe account. This allows us to transfer your earnings directly to your bank account.
                    </p>
                    <Button onClick={handleSetupStripeConnect} className="bg-blue-600 hover:bg-blue-700">
                      Setup Stripe Connect
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Transaction Details Modal */}
        {showTransactionModal && selectedPayout && (
          <TransactionDetailsModal
            payout={selectedPayout}
            onClose={handleCloseTransactionModal}
          />
        )}
      </div>
    </>
  );
}