import React, { useState, useEffect } from 'react';
import { X, CheckCheck, Check, Clock, XCircle } from 'lucide-react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import { getBroadcastDeliveryStats } from '../../../services/broadcastService';

export default function DeliveryStatsModal({ list, messages, onClose }) {
  const [selectedMessage, setSelectedMessage] = useState(null);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (messages?.length > 0) {
      handleSelectMessage(messages?.[0]);
    }
  }, [messages]);

  const handleSelectMessage = async (message) => {
    setSelectedMessage(message);
    setLoading(true);

    try {
      const { data, error } = await getBroadcastDeliveryStats(message?.id);
      if (error) throw error;
      setStats(data);
    } catch (err) {
      console.error('Error loading stats:', err);
    } finally {
      setLoading(false);
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'read':
        return <Icon name="CheckCheck" size={16} color="var(--color-primary)" />;
      case 'delivered':
        return <Icon name="Check" size={16} color="var(--color-muted-foreground)" />;
      case 'sent':
        return <Icon name="Clock" size={16} color="var(--color-muted-foreground)" />;
      case 'failed':
        return <Icon name="XCircle" size={16} color="var(--color-destructive)" />;
      default:
        return <Icon name="Clock" size={16} color="var(--color-muted-foreground)" />;
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-card rounded-xl max-w-4xl w-full max-h-[90vh] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="p-6 border-b border-border flex items-center justify-between">
          <div>
            <h2 className="text-xl font-semibold text-foreground">Delivery Statistics</h2>
            <p className="text-sm text-muted-foreground mt-1">{list?.name}</p>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-muted rounded-lg transition-colors"
          >
            <Icon name="X" size={20} color="var(--color-foreground)" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto">
          {messages?.length === 0 ? (
            <div className="p-12 text-center">
              <Icon name="MessageSquare" size={48} color="var(--color-muted-foreground)" className="mx-auto mb-4" />
              <p className="text-muted-foreground">No messages sent yet</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-3 divide-x divide-border">
              {/* Message List */}
              <div className="col-span-1 overflow-y-auto max-h-[500px]">
                {messages?.map((msg) => (
                  <div
                    key={msg?.id}
                    onClick={() => handleSelectMessage(msg)}
                    className={`p-4 cursor-pointer transition-colors border-b border-border ${
                      selectedMessage?.id === msg?.id ? 'bg-muted' : 'hover:bg-muted/50'
                    }`}
                  >
                    <p className="text-sm text-foreground line-clamp-2 mb-2">
                      {msg?.decrypted_message || msg?.message}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {new Date(msg?.created_at)?.toLocaleString()}
                    </p>
                  </div>
                ))}
              </div>

              {/* Stats Display */}
              <div className="col-span-2 p-6">
                {loading ? (
                  <div className="flex items-center justify-center h-full">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
                  </div>
                ) : stats ? (
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-lg font-semibold text-foreground mb-4">Delivery Overview</h3>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="bg-background rounded-lg p-4">
                          <div className="flex items-center gap-2 mb-2">
                            <Icon name="Users" size={20} color="var(--color-muted-foreground)" />
                            <span className="text-sm text-muted-foreground">Total Recipients</span>
                          </div>
                          <p className="text-2xl font-bold text-foreground">{stats?.total}</p>
                        </div>

                        <div className="bg-background rounded-lg p-4">
                          <div className="flex items-center gap-2 mb-2">
                            <Icon name="Send" size={20} color="var(--color-muted-foreground)" />
                            <span className="text-sm text-muted-foreground">Sent</span>
                          </div>
                          <p className="text-2xl font-bold text-foreground">{stats?.sent}</p>
                        </div>

                        <div className="bg-background rounded-lg p-4">
                          <div className="flex items-center gap-2 mb-2">
                            <Icon name="Check" size={20} color="var(--color-muted-foreground)" />
                            <span className="text-sm text-muted-foreground">Delivered</span>
                          </div>
                          <p className="text-2xl font-bold text-foreground">{stats?.delivered}</p>
                        </div>

                        <div className="bg-background rounded-lg p-4">
                          <div className="flex items-center gap-2 mb-2">
                            <Icon name="CheckCheck" size={20} color="var(--color-primary)" />
                            <span className="text-sm text-muted-foreground">Read</span>
                          </div>
                          <p className="text-2xl font-bold text-primary">{stats?.read}</p>
                        </div>
                      </div>
                    </div>

                    {stats?.failed > 0 && (
                      <div className="bg-destructive/10 border border-destructive/20 rounded-lg p-4">
                        <div className="flex items-center gap-2">
                          <Icon name="XCircle" size={20} color="var(--color-destructive)" />
                          <span className="text-sm font-medium text-destructive">
                            {stats?.failed} failed deliveries
                          </span>
                        </div>
                      </div>
                    )}

                    {/* Individual Delivery Tracking */}
                    {selectedMessage?.delivery_tracking && (
                      <div>
                        <h4 className="text-sm font-semibold text-foreground mb-3">Individual Tracking</h4>
                        <div className="space-y-2 max-h-48 overflow-y-auto">
                          {selectedMessage?.delivery_tracking?.map((tracking) => (
                            <div
                              key={tracking?.id}
                              className="flex items-center justify-between p-3 bg-background rounded-lg"
                            >
                              <div className="flex items-center gap-2">
                                {getStatusIcon(tracking?.status)}
                                <span className="text-sm text-foreground capitalize">
                                  {tracking?.status}
                                </span>
                              </div>
                              <span className="text-xs text-muted-foreground">
                                {tracking?.read_at
                                  ? new Date(tracking?.read_at)?.toLocaleString()
                                  : tracking?.delivered_at
                                  ? new Date(tracking?.delivered_at)?.toLocaleString()
                                  : tracking?.sent_at
                                  ? new Date(tracking?.sent_at)?.toLocaleString()
                                  : 'Pending'}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="flex items-center justify-center h-full text-muted-foreground">
                    Select a message to view statistics
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-border">
          <Button variant="outline" onClick={onClose} className="w-full">
            Close
          </Button>
        </div>
      </div>
    </div>
  );
}