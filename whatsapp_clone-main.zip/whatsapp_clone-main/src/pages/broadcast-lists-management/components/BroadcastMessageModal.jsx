import React, { useState } from 'react';
import { X, Send } from 'lucide-react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import { sendBroadcastMessage } from '../../../services/broadcastService';

export default function BroadcastMessageModal({ list, onClose, onSuccess }) {
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleSubmit = async (e) => {
    e?.preventDefault();

    if (!message?.trim()) {
      setError('Please enter a message');
      return;
    }

    try {
      setLoading(true);
      setError(null);

      const { error: sendError } = await sendBroadcastMessage({
        broadcast_list_id: list?.id,
        message: message?.trim(),
        encrypt: true
      });

      if (sendError) throw sendError;
      onSuccess();
    } catch (err) {
      console.error('Error sending broadcast message:', err);
      setError(err?.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-card rounded-xl max-w-2xl w-full">
        {/* Header */}
        <div className="p-6 border-b border-border flex items-center justify-between">
          <div>
            <h2 className="text-xl font-semibold text-foreground">Send Broadcast Message</h2>
            <p className="text-sm text-muted-foreground mt-1">
              To: {list?.name} ({list?.recipient_ids?.length} recipients)
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-muted rounded-lg transition-colors"
          >
            <Icon name="X" size={20} color="var(--color-foreground)" />
          </button>
        </div>

        {/* Content */}
        <form onSubmit={handleSubmit}>
          <div className="p-6">
            <textarea
              value={message}
              onChange={(e) => setMessage(e?.target?.value)}
              placeholder="Type your message..."
              rows={8}
              className="w-full px-4 py-3 bg-background border border-border rounded-lg text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary resize-none"
              autoFocus
            />

            <div className="mt-4 flex items-center gap-2 text-sm text-muted-foreground">
              <Icon name="Lock" size={16} color="var(--color-muted-foreground)" />
              <span>Messages are end-to-end encrypted</span>
            </div>

            {error && (
              <div className="mt-4 bg-destructive/10 border border-destructive/20 rounded-lg p-3">
                <p className="text-destructive text-sm">{error}</p>
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="p-6 border-t border-border flex gap-3">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              className="flex-1"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              variant="default"
              disabled={loading || !message?.trim()}
              iconName="Send"
              iconPosition="left"
              className="flex-1"
            >
              {loading ? 'Sending...' : 'Send to All'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}