import React, { useState, useEffect } from 'react';
import { X, Users, Trash2, Send } from 'lucide-react';
import { getBroadcastList, removeMemberFromBroadcastList, getBroadcastMessages } from '../../../services/broadcastService';
import { format } from 'date-fns';

export default function BroadcastListDetailModal({ list, onClose, onUpdate }) {
  const [listDetails, setListDetails] = useState(list);
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [activeTab, setActiveTab] = useState('members'); // 'members' or 'messages'

  useEffect(() => {
    loadListDetails();
    loadMessages();
  }, [list?.id]);

  const loadListDetails = async () => {
    try {
      const result = await getBroadcastList(list?.id);
      if (result?.error) throw result?.error;
      setListDetails(result?.data);
    } catch (err) {
      console.error('Error loading list details:', err);
      setError(err?.message);
    }
  };

  const loadMessages = async () => {
    try {
      const result = await getBroadcastMessages(list?.id);
      if (result?.error) throw result?.error;
      setMessages(result?.data || []);
    } catch (err) {
      console.error('Error loading messages:', err);
    }
  };

  const handleRemoveMember = async (memberId) => {
    if (!window.confirm('Remove this contact from the list?')) return;

    try {
      setLoading(true);
      const result = await removeMemberFromBroadcastList(memberId);
      if (result?.error) throw result?.error;

      await loadListDetails();
      onUpdate();
    } catch (err) {
      console.error('Error removing member:', err);
      setError(err?.message);
    } finally {
      setLoading(false);
    }
  };

  const getDeliveryStats = (message) => {
    const tracking = message?.delivery_tracking || [];
    return {
      total: tracking?.length,
      delivered: tracking?.filter(t => t?.status === 'delivered' || t?.status === 'read')?.length,
      read: tracking?.filter(t => t?.status === 'read')?.length
    };
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-3xl w-full max-h-[90vh] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-start justify-between mb-4">
            <div className="flex-1">
              <h2 className="text-xl font-semibold text-gray-900 mb-1">{listDetails?.name}</h2>
              {listDetails?.description && (
                <p className="text-sm text-gray-600">{listDetails?.description}</p>
              )}
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Tabs */}
          <div className="flex gap-4 border-b border-gray-200">
            <button
              onClick={() => setActiveTab('members')}
              className={`pb-2 px-1 font-medium transition-colors ${
                activeTab === 'members' ?'text-blue-600 border-b-2 border-blue-600' :'text-gray-600 hover:text-gray-900'
              }`}
            >
              Members ({listDetails?.members?.length || 0})
            </button>
            <button
              onClick={() => setActiveTab('messages')}
              className={`pb-2 px-1 font-medium transition-colors ${
                activeTab === 'messages' ?'text-blue-600 border-b-2 border-blue-600' :'text-gray-600 hover:text-gray-900'
              }`}
            >
              Messages ({messages?.length || 0})
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-3 mb-4">
              <p className="text-red-600 text-sm">{error}</p>
            </div>
          )}

          {activeTab === 'members' ? (
            <div>
              {listDetails?.members?.length === 0 ? (
                <div className="text-center py-12 text-gray-500">
                  <Users className="w-16 h-16 mx-auto mb-4 opacity-20" />
                  <p>No members in this list</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {listDetails?.members?.map((member) => (
                    <div
                      key={member?.id}
                      className="flex items-center gap-3 p-3 rounded-lg border border-gray-200 hover:bg-gray-50 transition-colors"
                    >
                      <div className="w-10 h-10 rounded-full bg-gray-200 overflow-hidden flex-shrink-0">
                        {member?.contact?.avatar_url ? (
                          <img
                            src={member?.contact?.avatar_url}
                            alt={member?.contact?.full_name}
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-gray-600 font-medium">
                            {member?.contact?.full_name?.charAt(0)?.toUpperCase()}
                          </div>
                        )}
                      </div>
                      <div className="flex-1">
                        <p className="font-medium text-gray-900">{member?.contact?.full_name}</p>
                        <p className="text-sm text-gray-600">{member?.contact?.email}</p>
                      </div>
                      <button
                        onClick={() => handleRemoveMember(member?.id)}
                        disabled={loading}
                        className="p-2 rounded-lg border border-red-300 hover:bg-red-50 transition-colors disabled:opacity-50"
                        aria-label="Remove member"
                      >
                        <Trash2 className="w-4 h-4 text-red-600" />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          ) : (
            <div>
              {messages?.length === 0 ? (
                <div className="text-center py-12 text-gray-500">
                  <Send className="w-16 h-16 mx-auto mb-4 opacity-20" />
                  <p>No messages sent yet</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {messages?.map((message) => {
                    const stats = getDeliveryStats(message);
                    return (
                      <div
                        key={message?.id}
                        className="p-4 rounded-lg border border-gray-200 hover:bg-gray-50 transition-colors"
                      >
                        <p className="text-gray-900 mb-3">{message?.decrypted_content}</p>
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-gray-600">
                            {format(new Date(message?.sent_at), 'MMM d, yyyy h:mm a')}
                          </span>
                          <div className="flex items-center gap-4 text-gray-600">
                            <span>Delivered: {stats?.delivered}/{stats?.total}</span>
                            <span>Read: {stats?.read}/{stats?.total}</span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-gray-200 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-6 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}