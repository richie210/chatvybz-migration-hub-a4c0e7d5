import React, { useState } from 'react';
import { X, Send } from 'lucide-react';
import { sendBroadcastMessage } from '../../../services/broadcastService';

export default function SendBroadcastModal({ list, onClose, onSuccess }) {
  const [message, setMessage] = useState('');
  const [sending, setSending] = useState(false);
  const [error, setError] = useState(null);

  const handleSend = async () => {
    if (!message?.trim()) {
      setError('Please enter a message');
      return;
    }

    try {
      setSending(true);
      setError(null);

      const result = await sendBroadcastMessage(list?.id, message);
      if (result?.error) throw result?.error;

      onSuccess();
    } catch (err) {
      console.error('Error sending broadcast message:', err);
      setError(err?.message);
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-lg w-full">
        {/* Header */}
        <div className="p-6 border-b border-gray-200 flex items-center justify-between">
          <div>
            <h2 className="text-xl font-semibold text-gray-900">Send Broadcast Message</h2>
            <p className="text-sm text-gray-600 mt-1">
              To: {list?.name} ({list?.members?.length || 0} {list?.members?.length === 1 ? 'contact' : 'contacts'})
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6">
          <textarea
            value={message}
            onChange={(e) => setMessage(e?.target?.value)}
            placeholder="Type your message here..."
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 resize-none"
            rows={6}
            maxLength={1000}
            autoFocus
          />
          <div className="flex items-center justify-between mt-2">
            <p className="text-xs text-gray-500">
              {message?.length}/1000 characters
            </p>
            <p className="text-xs text-gray-600">
              Message will be sent individually to each contact
            </p>
          </div>

          {error && (
            <div className="mt-4 bg-red-50 border border-red-200 rounded-lg p-3">
              <p className="text-red-600 text-sm">{error}</p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-gray-200 flex items-center justify-end gap-3">
          <button
            onClick={onClose}
            className="px-6 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={handleSend}
            disabled={sending || !message?.trim()}
            className="flex items-center gap-2 px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {sending ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                <span>Sending...</span>
              </>
            ) : (
              <>
                <Send className="w-4 h-4" />
                <span>Send Broadcast</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}