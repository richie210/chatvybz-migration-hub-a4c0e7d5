import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Plus, Users, Send, Trash2, ChevronRight } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { getBroadcastLists, deleteBroadcastList } from '../../services/broadcastService';
import CreateBroadcastListModal from './components/CreateBroadcastListModal';
import BroadcastListDetailModal from './components/BroadcastListDetailModal';
import SendBroadcastModal from './components/SendBroadcastModal';

export default function BroadcastListsManagement() {
  const { user, loading: authLoading, isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const [broadcastLists, setBroadcastLists] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showDetailModal, setShowDetailModal] = useState(false);
  const [showSendModal, setShowSendModal] = useState(false);
  const [selectedList, setSelectedList] = useState(null);

  useEffect(() => {
    if (authLoading) return;

    if (!isAuthenticated) {
      navigate('/login');
      return;
    }

    loadBroadcastLists();
  }, [authLoading, isAuthenticated, navigate]);

  const loadBroadcastLists = async () => {
    try {
      setLoading(true);
      setError(null);

      const result = await getBroadcastLists();
      if (result?.error) throw result?.error;

      setBroadcastLists(result?.data || []);
    } catch (err) {
      console.error('Error loading broadcast lists:', err);
      setError(err?.message);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateList = () => {
    setShowCreateModal(true);
  };

  const handleViewList = (list) => {
    setSelectedList(list);
    setShowDetailModal(true);
  };

  const handleSendBroadcast = (list) => {
    setSelectedList(list);
    setShowSendModal(true);
  };

  const handleDeleteList = async (listId) => {
    if (!window.confirm('Are you sure you want to delete this broadcast list?')) return;

    try {
      const result = await deleteBroadcastList(listId);
      if (result?.error) throw result?.error;

      await loadBroadcastLists();
    } catch (err) {
      console.error('Error deleting broadcast list:', err);
      setError(err?.message);
    }
  };

  if (authLoading || loading) {
    return (
      <div className="flex items-center justify-center h-screen bg-gray-50">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading broadcast lists...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white p-6 shadow-lg">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-2xl font-bold mb-2">Broadcast Lists</h1>
          <p className="text-blue-100">Send messages to multiple contacts at once</p>
        </div>
      </div>

      <div className="max-w-6xl mx-auto p-6">
        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-6">
            <p className="font-medium">Error</p>
            <p className="text-sm">{error}</p>
          </div>
        )}

        {/* Create New List Button */}
        <div className="mb-6">
          <button
            onClick={handleCreateList}
            className="flex items-center gap-2 bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors shadow-md"
          >
            <Plus className="w-5 h-5" />
            <span className="font-medium">Create New Broadcast List</span>
          </button>
        </div>

        {/* Broadcast Lists */}
        {broadcastLists?.length === 0 ? (
          <div className="bg-white rounded-lg shadow-md p-12 text-center">
            <Users className="w-16 h-16 mx-auto mb-4 text-gray-300" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">No broadcast lists yet</h3>
            <p className="text-gray-600 mb-6">Create your first broadcast list to send messages to multiple contacts</p>
            <button
              onClick={handleCreateList}
              className="inline-flex items-center gap-2 bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors"
            >
              <Plus className="w-5 h-5" />
              <span>Create Broadcast List</span>
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {broadcastLists?.map((list) => (
              <div
                key={list?.id}
                className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow overflow-hidden"
              >
                <div className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold text-gray-900 mb-1">{list?.name}</h3>
                      {list?.description && (
                        <p className="text-sm text-gray-600 line-clamp-2">{list?.description}</p>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-2 text-sm text-gray-600 mb-4">
                    <Users className="w-4 h-4" />
                    <span>{list?.members?.length || 0} {list?.members?.length === 1 ? 'contact' : 'contacts'}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleSendBroadcast(list)}
                      className="flex-1 flex items-center justify-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
                    >
                      <Send className="w-4 h-4" />
                      <span className="text-sm font-medium">Send</span>
                    </button>
                    <button
                      onClick={() => handleViewList(list)}
                      className="p-2 rounded-lg border border-gray-300 hover:bg-gray-50 transition-colors"
                      aria-label="View details"
                    >
                      <ChevronRight className="w-5 h-5 text-gray-600" />
                    </button>
                    <button
                      onClick={() => handleDeleteList(list?.id)}
                      className="p-2 rounded-lg border border-red-300 hover:bg-red-50 transition-colors"
                      aria-label="Delete list"
                    >
                      <Trash2 className="w-5 h-5 text-red-600" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Modals */}
      {showCreateModal && (
        <CreateBroadcastListModal
          onClose={() => setShowCreateModal(false)}
          onSuccess={() => {
            setShowCreateModal(false);
            loadBroadcastLists();
          }}
        />
      )}

      {showDetailModal && selectedList && (
        <BroadcastListDetailModal
          list={selectedList}
          onClose={() => {
            setShowDetailModal(false);
            setSelectedList(null);
          }}
          onUpdate={() => {
            loadBroadcastLists();
          }}
        />
      )}

      {showSendModal && selectedList && (
        <SendBroadcastModal
          list={selectedList}
          onClose={() => {
            setShowSendModal(false);
            setSelectedList(null);
          }}
          onSuccess={() => {
            setShowSendModal(false);
            setSelectedList(null);
          }}
        />
      )}
    </div>
  );
}