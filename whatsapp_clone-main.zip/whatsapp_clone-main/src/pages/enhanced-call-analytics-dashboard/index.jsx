import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { Brain, MessageSquare, Target, Lightbulb, Activity, Loader2, AlertCircle, Sparkles } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { callAnalyticsService } from '../../services/callAnalyticsService';
import { geminiAnalyticsService } from '../../services/geminiAnalyticsService';
import MetricsCard from '../call-analytics-dashboard/components/MetricsCard';
import DateRangeSelector from '../call-analytics-dashboard/components/DateRangeSelector';
import ConversationFlowPanel from './components/ConversationFlowPanel';
import SentimentAnalysisPanel from './components/SentimentAnalysisPanel';
import EffectivenessScoreCard from './components/EffectivenessScoreCard';
import AutomatedInsightsPanel from './components/AutomatedInsightsPanel';

function EnhancedCallAnalyticsDashboard() {
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();

  const [loading, setLoading] = useState(true);
  const [aiLoading, setAiLoading] = useState(false);
  const [error, setError] = useState('');
  const [dashboardData, setDashboardData] = useState(null);
  const [aiAnalytics, setAiAnalytics] = useState(null);
  const [selectedCallId, setSelectedCallId] = useState(null);
  const [dateRange, setDateRange] = useState({
    start: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)?.toISOString(),
    end: new Date()?.toISOString()
  });

  useEffect(() => {
    if (!authLoading && !user) {
      navigate('/login');
    }
  }, [user, authLoading, navigate]);

  useEffect(() => {
    if (!authLoading && user) {
      loadDashboardData();
    }
  }, [dateRange, authLoading, user]);

  const loadDashboardData = async () => {
    try {
      setLoading(true);
      setError('');
      const data = await callAnalyticsService?.getDashboardData(dateRange);
      setDashboardData(data);
      
      // Auto-select most recent call for AI analysis
      if (data?.recentCalls?.length > 0) {
        const mostRecentCall = data?.recentCalls?.[0];
        setSelectedCallId(mostRecentCall?.id);
        loadAIAnalytics(mostRecentCall?.id);
      }
    } catch (err) {
      setError(err?.message || 'Failed to load analytics data');
    } finally {
      setLoading(false);
    }
  };

  const loadAIAnalytics = async (callId) => {
    try {
      setAiLoading(true);
      const aiData = await geminiAnalyticsService?.getEnhancedCallAnalytics(callId);
      setAiAnalytics(aiData);
    } catch (err) {
      setError(err?.message || 'Failed to load AI analytics');
    } finally {
      setAiLoading(false);
    }
  };

  const formatDuration = (seconds) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    if (hours > 0) return `${hours}h ${minutes}m`;
    return `${minutes}m`;
  };

  if (authLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-50">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Enhanced Call Analytics - AI-Powered Insights</title>
        <meta name="description" content="AI-powered conversation analysis, sentiment tracking, and meeting effectiveness scoring" />
      </Helmet>
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <div className="bg-white border-b border-gray-200 shadow-sm">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-gradient-to-br from-purple-500 to-indigo-600 rounded-lg">
                  <Brain className="w-6 h-6 text-white" />
                </div>
                <div>
                  <div className="flex items-center space-x-2">
                    <h1 className="text-2xl font-bold text-gray-900">Enhanced Call Analytics</h1>
                    <span className="px-2 py-1 text-xs font-semibold text-purple-700 bg-purple-100 rounded-full flex items-center space-x-1">
                      <Sparkles className="w-3 h-3" />
                      <span>AI-Powered</span>
                    </span>
                  </div>
                  <p className="text-sm text-gray-600">Gemini AI conversation analysis and insights</p>
                </div>
              </div>
              <div className="flex items-center space-x-4">
                <DateRangeSelector dateRange={dateRange} onChange={setDateRange} />
                <button
                  onClick={() => navigate('/call-analytics-dashboard')}
                  className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Standard View
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {error && (
            <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center space-x-3">
              <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0" />
              <p className="text-sm text-red-800">{error}</p>
            </div>
          )}

          {loading ? (
            <div className="flex flex-col items-center justify-center py-20">
              <Loader2 className="w-12 h-12 animate-spin text-purple-600 mb-4" />
              <p className="text-gray-600">Loading analytics data...</p>
            </div>
          ) : dashboardData ? (
            <>
              {/* Key Metrics */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                <MetricsCard
                  title="Total Calls Analyzed"
                  value={dashboardData?.volumeMetrics?.totalCalls}
                  icon={Activity}
                  color="blue"
                  subtitle="AI-enhanced insights"
                />
                <MetricsCard
                  title="Avg Effectiveness"
                  value={aiAnalytics?.effectiveness?.overallScore ? `${aiAnalytics?.effectiveness?.overallScore}%` : 'Analyzing...'}
                  icon={Target}
                  color="green"
                  subtitle="Meeting success rate"
                />
                <MetricsCard
                  title="Sentiment Score"
                  value={aiAnalytics?.sentiment?.overallSentiment || 'Loading...'}
                  icon={MessageSquare}
                  color="purple"
                  subtitle="Overall conversation tone"
                />
                <MetricsCard
                  title="AI Insights"
                  value={aiAnalytics?.insights?.actionItems?.length || 0}
                  icon={Lightbulb}
                  color="orange"
                  subtitle="Action items identified"
                />
              </div>

              {/* AI Analysis Loading State */}
              {aiLoading && (
                <div className="mb-8 p-6 bg-purple-50 border border-purple-200 rounded-xl">
                  <div className="flex items-center space-x-3">
                    <Loader2 className="w-5 h-5 animate-spin text-purple-600" />
                    <div>
                      <p className="text-sm font-medium text-purple-900">Gemini AI is analyzing conversation patterns...</p>
                      <p className="text-xs text-purple-700 mt-1">This may take a few moments</p>
                    </div>
                  </div>
                </div>
              )}

              {/* AI-Powered Panels */}
              {aiAnalytics && (
                <>
                  {/* Conversation Flow & Sentiment */}
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
                    <ConversationFlowPanel data={aiAnalytics?.conversationPatterns} />
                    <SentimentAnalysisPanel data={aiAnalytics?.sentiment} />
                  </div>

                  {/* Meeting Effectiveness */}
                  <div className="mb-8">
                    <EffectivenessScoreCard data={aiAnalytics?.effectiveness} />
                  </div>

                  {/* Automated Insights */}
                  <AutomatedInsightsPanel data={aiAnalytics?.insights} />
                </>
              )}

              {/* No AI Data State */}
              {!aiAnalytics && !aiLoading && (
                <div className="text-center py-20 bg-white rounded-xl shadow-sm border border-gray-200">
                  <Brain className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600 mb-2">No AI analytics available yet</p>
                  <p className="text-sm text-gray-500">Complete a call to see AI-powered insights</p>
                </div>
              )}
            </>
          ) : (
            <div className="text-center py-20">
              <Brain className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600">No analytics data available for the selected period.</p>
            </div>
          )}
        </div>
      </div>
    </>
  );
}

export default EnhancedCallAnalyticsDashboard;
