import React from 'react';
import { Target, Users, CheckCircle, Award } from 'lucide-react';

function EffectivenessScoreCard({ data }) {
  if (!data) return null;

  const getScoreColor = (score) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getScoreBgColor = (score) => {
    if (score >= 80) return 'bg-green-100';
    if (score >= 60) return 'bg-yellow-100';
    return 'bg-red-100';
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
      <div className="flex items-center space-x-2 mb-6">
        <Target className="w-5 h-5 text-green-600" />
        <h3 className="text-lg font-semibold text-gray-900">Meeting Effectiveness Score</h3>
      </div>
      {/* Overall Score */}
      <div className="mb-8 text-center">
        <div className={`inline-flex items-center justify-center w-32 h-32 rounded-full ${getScoreBgColor(data?.overallScore)} mb-4`}>
          <div className="text-center">
            <p className={`text-4xl font-bold ${getScoreColor(data?.overallScore)}`}>
              {data?.overallScore}
            </p>
            <p className="text-sm text-gray-600">out of 100</p>
          </div>
        </div>
        <div className="flex items-center justify-center space-x-2">
          <Award className={`w-5 h-5 ${getScoreColor(data?.overallScore)}`} />
          <p className="text-sm font-medium text-gray-700">
            {data?.overallScore >= 80 ? 'Highly Effective' : data?.overallScore >= 60 ? 'Moderately Effective' : 'Needs Improvement'}
          </p>
        </div>
      </div>
      {/* Detailed Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        {/* Participation Balance */}
        <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
          <div className="flex items-center space-x-2 mb-3">
            <Users className="w-5 h-5 text-blue-600" />
            <h4 className="text-sm font-semibold text-blue-900">Participation Balance</h4>
          </div>
          <p className={`text-3xl font-bold mb-2 ${getScoreColor(data?.participationBalance?.score)}`}>
            {data?.participationBalance?.score}
          </p>
          <p className="text-xs text-blue-800">{data?.participationBalance?.analysis}</p>
        </div>

        {/* Decision Making Progress */}
        <div className="p-4 bg-purple-50 rounded-lg border border-purple-200">
          <div className="flex items-center space-x-2 mb-3">
            <CheckCircle className="w-5 h-5 text-purple-600" />
            <h4 className="text-sm font-semibold text-purple-900">Decision Making</h4>
          </div>
          <p className={`text-3xl font-bold mb-2 ${getScoreColor(data?.decisionMakingProgress?.score)}`}>
            {data?.decisionMakingProgress?.score}
          </p>
          <p className="text-xs text-purple-800 mb-1">
            {data?.decisionMakingProgress?.decisionsReached} decisions reached
          </p>
          <p className="text-xs text-purple-700">{data?.decisionMakingProgress?.analysis}</p>
        </div>

        {/* Outcome Achievement */}
        <div className="p-4 bg-green-50 rounded-lg border border-green-200">
          <div className="flex items-center space-x-2 mb-3">
            <Target className="w-5 h-5 text-green-600" />
            <h4 className="text-sm font-semibold text-green-900">Outcome Achievement</h4>
          </div>
          <p className={`text-3xl font-bold mb-2 ${getScoreColor(data?.outcomeAchievement?.score)}`}>
            {data?.outcomeAchievement?.score}
          </p>
          <p className="text-xs text-green-800 mb-1">
            {data?.outcomeAchievement?.objectivesMet} objectives met
          </p>
          <p className="text-xs text-green-700">{data?.outcomeAchievement?.analysis}</p>
        </div>
      </div>
      {/* Recommendations */}
      {data?.recommendations?.length > 0 && (
        <div className="p-4 bg-yellow-50 rounded-lg border border-yellow-200">
          <h4 className="text-sm font-semibold text-yellow-900 mb-3">Recommendations for Improvement</h4>
          <ul className="space-y-2">
            {data?.recommendations?.map((rec, index) => (
              <li key={index} className="flex items-start space-x-2">
                <span className="text-yellow-600 mt-0.5">•</span>
                <span className="text-sm text-yellow-800">{rec}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}

export default EffectivenessScoreCard;
