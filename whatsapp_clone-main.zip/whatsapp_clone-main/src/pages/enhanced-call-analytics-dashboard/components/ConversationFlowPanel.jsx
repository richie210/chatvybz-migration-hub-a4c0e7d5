import React from 'react';
import { Users, MessageCircle, AlertTriangle } from 'lucide-react';

function ConversationFlowPanel({ data }) {
  if (!data) return null;

  const getEngagementColor = (level) => {
    switch (level?.toLowerCase()) {
      case 'high': return 'bg-green-500';
      case 'medium': return 'bg-yellow-500';
      case 'low': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
      <div className="flex items-center space-x-2 mb-6">
        <Users className="w-5 h-5 text-blue-600" />
        <h3 className="text-lg font-semibold text-gray-900">Conversation Flow Analysis</h3>
      </div>
      {/* Speaking Patterns */}
      <div className="mb-6">
        <h4 className="text-sm font-medium text-gray-700 mb-3">Speaking Time Distribution</h4>
        <div className="space-y-3">
          {data?.speakingPatterns?.map((pattern, index) => (
            <div key={index}>
              <div className="flex items-center justify-between text-sm mb-1">
                <span className="text-gray-700">{pattern?.participant}</span>
                <span className="text-gray-600">{pattern?.speakingTime}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${pattern?.speakingTime}%` }}
                />
              </div>
              <p className="text-xs text-gray-500 mt-1">{pattern?.turnCount} speaking turns</p>
            </div>
          ))}
        </div>
      </div>
      {/* Interruption Analysis */}
      {data?.interruptionAnalysis && (
        <div className="mb-6 p-4 bg-orange-50 rounded-lg border border-orange-200">
          <div className="flex items-center space-x-2 mb-3">
            <AlertTriangle className="w-4 h-4 text-orange-600" />
            <h4 className="text-sm font-medium text-orange-900">Interruption Analysis</h4>
          </div>
          <p className="text-sm text-orange-800 mb-2">
            Total Interruptions: <span className="font-semibold">{data?.interruptionAnalysis?.totalInterruptions}</span>
          </p>
          <div className="space-y-1">
            {data?.interruptionAnalysis?.byParticipant?.map((item, index) => (
              <div key={index} className="flex items-center justify-between text-xs text-orange-700">
                <span>{item?.participant}</span>
                <span className="font-medium">{item?.count} interruptions</span>
              </div>
            ))}
          </div>
        </div>
      )}
      {/* Engagement Heatmap */}
      <div>
        <h4 className="text-sm font-medium text-gray-700 mb-3">Engagement Heatmap</h4>
        <div className="grid grid-cols-4 gap-2">
          {data?.engagementHeatmap?.map((segment, index) => (
            <div key={index} className="text-center">
              <div className={`h-12 rounded-lg ${getEngagementColor(segment?.engagementLevel)} opacity-80`} />
              <p className="text-xs text-gray-600 mt-1">{segment?.timeSegment}</p>
              <p className="text-xs text-gray-500 capitalize">{segment?.engagementLevel}</p>
            </div>
          ))}
        </div>
      </div>
      {/* Conversation Flow Description */}
      {data?.conversationFlow && (
        <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
          <div className="flex items-center space-x-2 mb-2">
            <MessageCircle className="w-4 h-4 text-blue-600" />
            <h4 className="text-sm font-medium text-blue-900">Flow Summary</h4>
          </div>
          <p className="text-sm text-blue-800">{data?.conversationFlow}</p>
        </div>
      )}
    </div>
  );
}

export default ConversationFlowPanel;
