import React from 'react';
import { Lightbulb, CheckSquare, MessageSquare, TrendingUp, Repeat } from 'lucide-react';

function AutomatedInsightsPanel({ data }) {
  if (!data) return null;

  const getPriorityColor = (priority) => {
    switch (priority?.toLowerCase()) {
      case 'high': return { bg: 'bg-red-100', text: 'text-red-700', border: 'border-red-300' };
      case 'medium': return { bg: 'bg-yellow-100', text: 'text-yellow-700', border: 'border-yellow-300' };
      case 'low': return { bg: 'bg-green-100', text: 'text-green-700', border: 'border-green-300' };
      default: return { bg: 'bg-gray-100', text: 'text-gray-700', border: 'border-gray-300' };
    }
  };

  const getImportanceColor = (importance) => {
    switch (importance?.toLowerCase()) {
      case 'high': return 'text-red-600';
      case 'medium': return 'text-yellow-600';
      case 'low': return 'text-green-600';
      default: return 'text-gray-600';
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
      <div className="flex items-center space-x-2 mb-6">
        <Lightbulb className="w-5 h-5 text-yellow-600" />
        <h3 className="text-lg font-semibold text-gray-900">Automated Insights</h3>
      </div>
      {/* Summary */}
      <div className="mb-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
        <h4 className="text-sm font-semibold text-blue-900 mb-2">AI-Generated Summary</h4>
        <p className="text-sm text-blue-800">{data?.summary}</p>
      </div>
      {/* Key Discussion Points */}
      <div className="mb-6">
        <div className="flex items-center space-x-2 mb-4">
          <MessageSquare className="w-5 h-5 text-indigo-600" />
          <h4 className="text-sm font-semibold text-gray-900">Key Discussion Points</h4>
        </div>
        <div className="space-y-3">
          {data?.keyDiscussionPoints?.map((point, index) => (
            <div key={index} className="p-3 bg-gray-50 rounded-lg border border-gray-200">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-gray-900">{point?.topic}</span>
                <span className={`text-xs font-semibold capitalize ${getImportanceColor(point?.importance)}`}>
                  {point?.importance} priority
                </span>
              </div>
              <p className="text-xs text-gray-600">{point?.details}</p>
            </div>
          ))}
        </div>
      </div>
      {/* Action Items */}
      <div className="mb-6">
        <div className="flex items-center space-x-2 mb-4">
          <CheckSquare className="w-5 h-5 text-green-600" />
          <h4 className="text-sm font-semibold text-gray-900">Action Items</h4>
        </div>
        <div className="space-y-3">
          {data?.actionItems?.map((item, index) => {
            const colors = getPriorityColor(item?.priority);
            return (
              <div key={index} className={`p-3 rounded-lg border ${colors?.bg} ${colors?.border}`}>
                <div className="flex items-start justify-between mb-2">
                  <p className="text-sm font-medium text-gray-900 flex-1">{item?.task}</p>
                  <span className={`text-xs font-semibold px-2 py-1 rounded-full capitalize ${colors?.bg} ${colors?.text}`}>
                    {item?.priority}
                  </span>
                </div>
                <div className="flex items-center space-x-4 text-xs text-gray-600">
                  {item?.assignedTo && (
                    <span>Assigned to: <span className="font-medium">{item?.assignedTo}</span></span>
                  )}
                  {item?.dueDate && (
                    <span>Due: <span className="font-medium">{item?.dueDate}</span></span>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
      {/* Follow-up Recommendations */}
      <div className="mb-6">
        <div className="flex items-center space-x-2 mb-4">
          <TrendingUp className="w-5 h-5 text-purple-600" />
          <h4 className="text-sm font-semibold text-gray-900">Follow-up Recommendations</h4>
        </div>
        <div className="space-y-2">
          {data?.followUpRecommendations?.map((rec, index) => (
            <div key={index} className="p-3 bg-purple-50 rounded-lg border border-purple-200">
              <div className="flex items-center justify-between">
                <p className="text-sm text-purple-900 flex-1">{rec?.recommendation}</p>
                <div className="ml-3 flex items-center space-x-1">
                  <div className="w-16 bg-purple-200 rounded-full h-1.5">
                    <div
                      className="bg-purple-600 h-1.5 rounded-full"
                      style={{ width: `${rec?.confidenceScore}%` }}
                    />
                  </div>
                  <span className="text-xs text-purple-700">{rec?.confidenceScore}%</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
      {/* Recurring Topics */}
      {data?.recurringTopics?.length > 0 && (
        <div className="mb-6">
          <div className="flex items-center space-x-2 mb-3">
            <Repeat className="w-5 h-5 text-orange-600" />
            <h4 className="text-sm font-semibold text-gray-900">Recurring Topics</h4>
          </div>
          <div className="flex flex-wrap gap-2">
            {data?.recurringTopics?.map((topic, index) => (
              <span key={index} className="px-3 py-1 text-xs font-medium text-orange-700 bg-orange-100 rounded-full border border-orange-300">
                {topic}
              </span>
            ))}
          </div>
        </div>
      )}
      {/* Communication Style */}
      {data?.communicationStyle && (
        <div className="p-4 bg-indigo-50 rounded-lg border border-indigo-200">
          <h4 className="text-sm font-semibold text-indigo-900 mb-2">Communication Style Analysis</h4>
          <p className="text-sm text-indigo-800">{data?.communicationStyle}</p>
        </div>
      )}
    </div>
  );
}

export default AutomatedInsightsPanel;
