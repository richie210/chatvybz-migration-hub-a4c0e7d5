import React from 'react';
import { Heart, TrendingUp, Clock } from 'lucide-react';

function SentimentAnalysisPanel({ data }) {
  if (!data) return null;

  const getSentimentColor = (sentiment) => {
    switch (sentiment?.toLowerCase()) {
      case 'positive': return { bg: 'bg-green-100', text: 'text-green-700', border: 'border-green-300' };
      case 'neutral': return { bg: 'bg-gray-100', text: 'text-gray-700', border: 'border-gray-300' };
      case 'negative': return { bg: 'bg-red-100', text: 'text-red-700', border: 'border-red-300' };
      default: return { bg: 'bg-gray-100', text: 'text-gray-700', border: 'border-gray-300' };
    }
  };

  const overallColors = getSentimentColor(data?.overallSentiment);

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
      <div className="flex items-center space-x-2 mb-6">
        <Heart className="w-5 h-5 text-pink-600" />
        <h3 className="text-lg font-semibold text-gray-900">Sentiment Analysis</h3>
      </div>
      {/* Overall Sentiment */}
      <div className={`mb-6 p-4 rounded-lg border ${overallColors?.bg} ${overallColors?.border}`}>
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm text-gray-600 mb-1">Overall Sentiment</p>
            <p className={`text-2xl font-bold capitalize ${overallColors?.text}`}>
              {data?.overallSentiment}
            </p>
          </div>
          <Heart className={`w-8 h-8 ${overallColors?.text}`} />
        </div>
      </div>
      {/* Participant Sentiments */}
      <div className="mb-6">
        <h4 className="text-sm font-medium text-gray-700 mb-3">Participant Sentiments</h4>
        <div className="space-y-3">
          {data?.participantSentiments?.map((participant, index) => {
            const colors = getSentimentColor(participant?.sentiment);
            return (
              <div key={index} className={`p-3 rounded-lg border ${colors?.bg} ${colors?.border}`}>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-gray-900">{participant?.participant}</span>
                  <span className={`text-xs font-semibold px-2 py-1 rounded-full capitalize ${colors?.bg} ${colors?.text}`}>
                    {participant?.sentiment}
                  </span>
                </div>
                <p className="text-xs text-gray-600 mb-2">{participant?.emotionalTone}</p>
                <div className="flex items-center space-x-2">
                  <div className="flex-1 bg-gray-200 rounded-full h-1.5">
                    <div
                      className={`h-1.5 rounded-full ${participant?.sentiment === 'positive' ? 'bg-green-600' : participant?.sentiment === 'negative' ? 'bg-red-600' : 'bg-gray-600'}`}
                      style={{ width: `${participant?.confidenceScore}%` }}
                    />
                  </div>
                  <span className="text-xs text-gray-500">{participant?.confidenceScore}%</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
      {/* Sentiment Trend */}
      <div className="mb-6">
        <div className="flex items-center space-x-2 mb-3">
          <TrendingUp className="w-4 h-4 text-purple-600" />
          <h4 className="text-sm font-medium text-gray-700">Sentiment Trend</h4>
        </div>
        <div className="flex items-end space-x-2 h-24">
          {data?.sentimentTrend?.map((segment, index) => {
            const colors = getSentimentColor(segment?.sentiment);
            const height = segment?.sentiment === 'positive' ? '100%' : segment?.sentiment === 'neutral' ? '60%' : '30%';
            return (
              <div key={index} className="flex-1 flex flex-col items-center">
                <div
                  className={`w-full rounded-t-lg ${colors?.bg} ${colors?.border} border transition-all duration-300`}
                  style={{ height }}
                />
                <p className="text-xs text-gray-600 mt-1">{segment?.timeSegment}</p>
              </div>
            );
          })}
        </div>
      </div>
      {/* Key Emotional Moments */}
      {data?.keyEmotionalMoments?.length > 0 && (
        <div>
          <div className="flex items-center space-x-2 mb-3">
            <Clock className="w-4 h-4 text-indigo-600" />
            <h4 className="text-sm font-medium text-gray-700">Key Emotional Moments</h4>
          </div>
          <div className="space-y-2">
            {data?.keyEmotionalMoments?.map((moment, index) => {
              const colors = getSentimentColor(moment?.sentiment);
              return (
                <div key={index} className={`p-3 rounded-lg border ${colors?.bg} ${colors?.border}`}>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-medium text-gray-700">{moment?.timestamp}</span>
                    <span className={`text-xs font-semibold capitalize ${colors?.text}`}>{moment?.sentiment}</span>
                  </div>
                  <p className="text-xs text-gray-600">{moment?.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

export default SentimentAnalysisPanel;
