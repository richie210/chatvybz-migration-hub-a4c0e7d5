import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Calendar, Clock, Send, Edit2, Trash2, X, User, CheckCircle, AlertCircle } from 'lucide-react';
import { scheduledMessageService } from '../../services/scheduledMessageService';
import { useAuth } from '../../contexts/AuthContext';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';

export default function MessageScheduling() {
  const navigate = useNavigate();
  const { user, loading: authLoading, isAuthenticated } = useAuth();
  
  const [scheduledMessages, setScheduledMessages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [showComposer, setShowComposer] = useState(false);
  
  // Composer state
  const [message, setMessage] = useState('');
  const [scheduledDate, setScheduledDate] = useState('');
  const [scheduledTime, setScheduledTime] = useState('');
  const [recipientId, setRecipientId] = useState('');
  const [recurringPattern, setRecurringPattern] = useState('');
  const [composerError, setComposerError] = useState('');
  const [composerLoading, setComposerLoading] = useState(false);

  // Edit state
  const [editingMessage, setEditingMessage] = useState(null);
  const [editMessage, setEditMessage] = useState('');
  const [editDate, setEditDate] = useState('');
  const [editTime, setEditTime] = useState('');

  useEffect(() => {
    // Wait for auth to complete
    if (authLoading) {
      return;
    }

    // Redirect to login if not authenticated
    if (!isAuthenticated) {
      navigate('/login');
      return;
    }

    // Load messages only if authenticated
    loadScheduledMessages();
    
    // Subscribe to changes
    const unsubscribe = scheduledMessageService?.subscribeToChanges(() => {
      loadScheduledMessages();
    });

    return () => unsubscribe();
  }, [authLoading, isAuthenticated, navigate]);

  const loadScheduledMessages = async () => {
    try {
      setLoading(true);
      const messages = await scheduledMessageService?.getAll();
      setScheduledMessages(messages);
      setError('');
    } catch (err) {
      setError(err?.message || 'Failed to load scheduled messages');
    } finally {
      setLoading(false);
    }
  };

  const handleScheduleMessage = async (e) => {
    e?.preventDefault();
    
    if (!message?.trim() || !scheduledDate || !scheduledTime) {
      setComposerError('Please fill in all required fields');
      return;
    }

    try {
      setComposerLoading(true);
      setComposerError('');

      const scheduledDateTime = new Date(`${scheduledDate}T${scheduledTime}`);
      
      if (scheduledDateTime <= new Date()) {
        setComposerError('Scheduled time must be in the future');
        return;
      }

      await scheduledMessageService?.create({
        message: message?.trim(),
        scheduledTime: scheduledDateTime?.toISOString(),
        recipientId: recipientId || null,
        recurringPattern: recurringPattern || null,
        timezone: Intl.DateTimeFormat()?.resolvedOptions()?.timeZone
      });

      // Reset form
      setMessage('');
      setScheduledDate('');
      setScheduledTime('');
      setRecipientId('');
      setRecurringPattern('');
      setShowComposer(false);
      
      await loadScheduledMessages();
    } catch (err) {
      setComposerError(err?.message || 'Failed to schedule message');
    } finally {
      setComposerLoading(false);
    }
  };

  const handleEditMessage = async (messageId) => {
    if (!editMessage?.trim() || !editDate || !editTime) {
      return;
    }

    try {
      const editedDateTime = new Date(`${editDate}T${editTime}`);
      
      if (editedDateTime <= new Date()) {
        setError('Scheduled time must be in the future');
        return;
      }

      await scheduledMessageService?.edit(messageId, {
        message: editMessage?.trim(),
        scheduledTime: editedDateTime?.toISOString()
      });

      setEditingMessage(null);
      setEditMessage('');
      setEditDate('');
      setEditTime('');
      
      await loadScheduledMessages();
    } catch (err) {
      setError(err?.message || 'Failed to edit message');
    }
  };

  const handleCancelMessage = async (messageId) => {
    if (!window.confirm('Are you sure you want to cancel this scheduled message?')) {
      return;
    }

    try {
      await scheduledMessageService?.cancel(messageId);
      await loadScheduledMessages();
    } catch (err) {
      setError(err?.message || 'Failed to cancel message');
    }
  };

  const handleDeleteMessage = async (messageId) => {
    if (!window.confirm('Are you sure you want to delete this scheduled message?')) {
      return;
    }

    try {
      await scheduledMessageService?.delete(messageId);
      await loadScheduledMessages();
    } catch (err) {
      setError(err?.message || 'Failed to delete message');
    }
  };

  const startEdit = (msg) => {
    setEditingMessage(msg?.id);
    setEditMessage(msg?.message);
    const dateTime = new Date(msg.scheduledTime);
    setEditDate(dateTime?.toISOString()?.split('T')?.[0]);
    setEditTime(dateTime?.toTimeString()?.slice(0, 5));
  };

  const cancelEdit = () => {
    setEditingMessage(null);
    setEditMessage('');
    setEditDate('');
    setEditTime('');
  };

  const formatDateTime = (dateTimeString) => {
    const date = new Date(dateTimeString);
    return date?.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'pending': return 'text-yellow-600 bg-yellow-50';
      case 'delivered': return 'text-green-600 bg-green-50';
      case 'cancelled': return 'text-gray-600 bg-gray-50';
      case 'failed': return 'text-red-600 bg-red-50';
      default: return 'text-gray-600 bg-gray-50';
    }
  };

  // Show loading while checking authentication
  if (authLoading || loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="h-screen flex flex-col bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Message Scheduling</h1>
            <p className="text-sm text-gray-600 mt-1">Schedule messages for future delivery</p>
          </div>
          <Button 
            onClick={() => setShowComposer(true)}
            className="flex items-center gap-2"
          >
            <Send className="w-4 h-4" />
            Schedule Message
          </Button>
        </div>
      </div>
      {/* Error Display */}
      {error && (
        <div className="mx-6 mt-4 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center gap-3">
          <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0" />
          <p className="text-sm text-red-800">{error}</p>
          <button onClick={() => setError('')} className="ml-auto text-red-600 hover:text-red-800">
            <X className="w-5 h-5" />
          </button>
        </div>
      )}
      {/* Composer Modal */}
      {showComposer && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
              <h2 className="text-xl font-bold text-gray-900">Schedule New Message</h2>
              <button onClick={() => setShowComposer(false)} className="text-gray-500 hover:text-gray-700">
                <X className="w-6 h-6" />
              </button>
            </div>

            <form onSubmit={handleScheduleMessage} className="p-6 space-y-4">
              {composerError && (
                <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-sm text-red-800">
                  {composerError}
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Message *
                </label>
                <textarea
                  value={message}
                  onChange={(e) => setMessage(e?.target?.value)}
                  placeholder="Type your message..."
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                  rows="4"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    <Calendar className="w-4 h-4 inline mr-1" />
                    Date *
                  </label>
                  <Input
                    type="date"
                    value={scheduledDate}
                    onChange={(e) => setScheduledDate(e?.target?.value)}
                    min={new Date()?.toISOString()?.split('T')?.[0]}
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    <Clock className="w-4 h-4 inline mr-1" />
                    Time *
                  </label>
                  <Input
                    type="time"
                    value={scheduledTime}
                    onChange={(e) => setScheduledTime(e?.target?.value)}
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Recurring Pattern (Optional)
                </label>
                <select
                  value={recurringPattern}
                  onChange={(e) => setRecurringPattern(e?.target?.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="">None</option>
                  <option value="daily">Daily</option>
                  <option value="weekly">Weekly</option>
                  <option value="monthly">Monthly</option>
                </select>
              </div>

              <div className="flex justify-end gap-3 pt-4">
                <Button
                  type="button"
                  onClick={() => setShowComposer(false)}
                  className="bg-gray-200 text-gray-700 hover:bg-gray-300"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={composerLoading}
                  className="flex items-center gap-2"
                >
                  {composerLoading ? 'Scheduling...' : 'Schedule Message'}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}
      {/* Scheduled Messages List */}
      <div className="flex-1 overflow-y-auto px-6 py-4">
        {scheduledMessages?.length === 0 ? (
          <div className="text-center py-16">
            <Calendar className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No scheduled messages</h3>
            <p className="text-gray-600 mb-6">Schedule your first message to get started</p>
            <Button onClick={() => setShowComposer(true)}>
              <Send className="w-4 h-4 mr-2" />
              Schedule Message
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            {scheduledMessages?.map((msg) => (
              <div key={msg?.id} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                {editingMessage === msg?.id ? (
                  <div className="space-y-4">
                    <textarea
                      value={editMessage}
                      onChange={(e) => setEditMessage(e?.target?.value)}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                      rows="3"
                    />
                    <div className="grid grid-cols-2 gap-4">
                      <Input
                        type="date"
                        value={editDate}
                        onChange={(e) => setEditDate(e?.target?.value)}
                        min={new Date()?.toISOString()?.split('T')?.[0]}
                      />
                      <Input
                        type="time"
                        value={editTime}
                        onChange={(e) => setEditTime(e?.target?.value)}
                      />
                    </div>
                    <div className="flex justify-end gap-2">
                      <Button onClick={cancelEdit} className="bg-gray-200 text-gray-700 hover:bg-gray-300">
                        Cancel
                      </Button>
                      <Button onClick={() => handleEditMessage(msg?.id)}>
                        Save Changes
                      </Button>
                    </div>
                  </div>
                ) : (
                  <>
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <p className="text-gray-900 mb-2">{msg?.message}</p>
                        <div className="flex items-center gap-4 text-sm text-gray-600">
                          <span className="flex items-center gap-1">
                            <Clock className="w-4 h-4" />
                            {formatDateTime(msg?.scheduledTime)}
                          </span>
                          {msg?.recipient && (
                            <span className="flex items-center gap-1">
                              <User className="w-4 h-4" />
                              {msg?.recipient?.fullName}
                            </span>
                          )}
                          {msg?.recurringPattern && (
                            <span className="px-2 py-1 bg-blue-50 text-blue-700 rounded-full text-xs">
                              {msg?.recurringPattern}
                            </span>
                          )}
                        </div>
                      </div>
                      <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(msg?.deliveryStatus)}`}>
                        {msg?.deliveryStatus}
                      </span>
                    </div>

                    {msg?.deliveryConfirmation && msg?.deliveredAt && (
                      <div className="flex items-center gap-2 text-sm text-green-600 mb-4">
                        <CheckCircle className="w-4 h-4" />
                        <span>Delivered at {formatDateTime(msg?.deliveredAt)}</span>
                      </div>
                    )}

                    {msg?.deliveryStatus === 'pending' && !msg?.cancelledAt && (
                      <div className="flex justify-end gap-2 pt-4 border-t border-gray-100">
                        <button
                          onClick={() => startEdit(msg)}
                          className="flex items-center gap-1 px-3 py-2 text-sm text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                        >
                          <Edit2 className="w-4 h-4" />
                          Edit
                        </button>
                        <button
                          onClick={() => handleCancelMessage(msg?.id)}
                          className="flex items-center gap-1 px-3 py-2 text-sm text-orange-600 hover:bg-orange-50 rounded-lg transition-colors"
                        >
                          <X className="w-4 h-4" />
                          Cancel
                        </button>
                        <button
                          onClick={() => handleDeleteMessage(msg?.id)}
                          className="flex items-center gap-1 px-3 py-2 text-sm text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                          Delete
                        </button>
                      </div>
                    )}
                  </>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}