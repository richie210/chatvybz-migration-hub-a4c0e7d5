import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import PhoneInput from 'react-phone-number-input';
import { isValidPhoneNumber } from 'react-phone-number-input';
import 'react-phone-number-input/style.css';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import twilioVerifyService from '../../services/twilioVerifyService';

const WhatsAppStylePhoneAuthentication = () => {
  const navigate = useNavigate();
  const [phoneNumber, setPhoneNumber] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');

  const handlePhoneChange = (value) => {
    setPhoneNumber(value || '');
    if (error) setError('');
  };

  const handleSendCode = async (e) => {
    e?.preventDefault();
    setError('');

    // Validate phone number
    if (!phoneNumber) {
      setError('Phone number is required');
      return;
    }

    // Validate phone number format
    try {
      const isValid = isValidPhoneNumber(phoneNumber);
      if (!isValid) {
        setError('Please enter a valid phone number');
        return;
      }
    } catch (err) {
      console.error('Phone validation error:', err);
      setError('Invalid phone number format');
      return;
    }

    // Ensure phone number is in E.164 format
    if (!phoneNumber?.startsWith('+')) {
      setError('Phone number must include country code');
      return;
    }

    setIsLoading(true);

    try {
      console.log('Sending OTP to:', phoneNumber);
      
      // Send OTP via Twilio Verify with automatic fallback
      const result = await twilioVerifyService?.sendWithFallback(phoneNumber);

      if (result?.success) {
        // Navigate to OTP verification page with phone number
        navigate('/secure-twilio-otp-verification', {
          state: {
            phoneNumber,
            channel: result?.channel,
            fallbackUsed: result?.fallbackUsed
          }
        });
      } else {
        throw new Error('Failed to send verification code');
      }
    } catch (error) {
      console.error('Send OTP error:', error);
      
      // Display specific error message to user
      const errorMessage = error?.message || 'Failed to send verification code. Please try again.';
      
      alert(errorMessage);
      
      // If credentials are not configured, show helpful message
      if (errorMessage?.includes('not configured')) {
        console.error('CONFIGURATION ERROR: Twilio Verify credentials are missing in Supabase Edge Function environment variables.');
        console.error('Please add the following environment variables to your Supabase project:');
        console.error('- TWILIO_ACCOUNT_SID');
        console.error('- TWILIO_AUTH_TOKEN');
        console.error('- TWILIO_VERIFY_SERVICE_SID');
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <Helmet>
        <title>Phone Authentication - ChatVybz</title>
        <meta
          name="description"
          content="Secure WhatsApp-style phone authentication with OTP verification for ChatVybz messaging platform."
        />
      </Helmet>

      <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-teal-50 flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          <div className="bg-white rounded-2xl shadow-xl border border-gray-200 overflow-hidden">
            {/* Header */}
            <div className="bg-gradient-to-r from-green-500 to-teal-500 p-8 text-center">
              <div className="w-20 h-20 mx-auto bg-white rounded-full flex items-center justify-center mb-4 shadow-lg">
                <Icon name="MessageCircle" size={40} color="#22B48A" />
              </div>
              <h1 className="text-3xl font-bold text-white mb-2">ChatVybz</h1>
              <p className="text-white/90">Secure Phone Authentication</p>
            </div>

            {/* Main Content */}
            <div className="p-8">
              <div className="text-center mb-8">
                <h2 className="text-2xl font-bold text-gray-900 mb-2">
                  Enter Your Phone Number
                </h2>
                <p className="text-gray-600">
                  We'll send you a verification code via SMS
                </p>
              </div>

              {/* Error Message */}
              {error && (
                <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-start gap-3">
                  <Icon name="AlertCircle" size={20} color="#EF4444" className="flex-shrink-0 mt-0.5" />
                  <div className="flex-1">
                    <p className="text-sm text-red-600">{error}</p>
                  </div>
                  <button onClick={() => setError('')} className="text-red-600 hover:text-red-700">
                    <Icon name="X" size={16} />
                  </button>
                </div>
              )}

              {/* Phone Input Form */}
              <form onSubmit={handleSendCode} className="space-y-6">
                <div>
                  <label htmlFor="phoneNumber" className="block text-sm font-medium text-gray-700 mb-2">
                    Phone Number
                  </label>
                  <PhoneInput
                    international
                    defaultCountry="MQ"
                    value={phoneNumber}
                    onChange={handlePhoneChange}
                    placeholder="Enter phone number"
                    className="w-full"
                    disabled={isLoading}
                    countryCallingCodeEditable={false}
                    style={{
                      '--PhoneInputCountryFlag-height': '1.2em',
                      '--PhoneInput-color--focus': '#22B48A',
                    }}
                  />
                  <p className="mt-2 text-xs text-gray-500 flex items-center gap-1">
                    <Icon name="Shield" size={12} />
                    <span>Your number is encrypted and secure</span>
                  </p>
                </div>

                {/* Privacy Notice */}
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <div className="flex items-start gap-3">
                    <Icon name="Info" size={20} color="#3B82F6" className="flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-blue-800">
                      <p className="font-medium mb-1">How we use your phone number:</p>
                      <ul className="list-disc list-inside space-y-1 text-xs">
                        <li>Primary identifier for your account</li>
                        <li>Contact discovery with other users</li>
                        <li>Secure authentication via OTP</li>
                        <li>Never shared without your permission</li>
                      </ul>
                    </div>
                  </div>
                </div>

                {/* Submit Button */}
                <Button
                  type="submit"
                  disabled={isLoading || !phoneNumber}
                  className="w-full bg-green-500 hover:bg-green-600 text-white py-3 rounded-lg font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  {isLoading ? (
                    <>
                      <Icon name="Loader2" className="w-5 h-5 animate-spin" />
                      Sending Code...
                    </>
                  ) : (
                    <>
                      <Icon name="Send" className="w-5 h-5" />
                      Send Verification Code
                    </>
                  )}
                </Button>
              </form>

              {/* Security Features */}
              <div className="mt-8 pt-6 border-t border-gray-200">
                <div className="grid grid-cols-3 gap-4 text-center">
                  <div>
                    <div className="w-10 h-10 mx-auto bg-green-100 rounded-full flex items-center justify-center mb-2">
                      <Icon name="Lock" size={20} color="#22B48A" />
                    </div>
                    <p className="text-xs text-gray-600">End-to-End Encrypted</p>
                  </div>
                  <div>
                    <div className="w-10 h-10 mx-auto bg-green-100 rounded-full flex items-center justify-center mb-2">
                      <Icon name="ShieldCheck" size={20} color="#22B48A" />
                    </div>
                    <p className="text-xs text-gray-600">Secure Verification</p>
                  </div>
                  <div>
                    <div className="w-10 h-10 mx-auto bg-green-100 rounded-full flex items-center justify-center mb-2">
                      <Icon name="Globe" size={20} color="#22B48A" />
                    </div>
                    <p className="text-xs text-gray-600">Global Coverage</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Footer */}
          <div className="text-center mt-6 space-y-2">
            <p className="text-sm text-gray-600">
              By continuing, you agree to our Terms of Service and Privacy Policy
            </p>
            <p className="text-xs text-gray-500">
              © {new Date()?.getFullYear()} ChatVybz. All rights reserved.
            </p>
          </div>
        </div>
      </div>
    </>
  );
};

export default WhatsAppStylePhoneAuthentication;