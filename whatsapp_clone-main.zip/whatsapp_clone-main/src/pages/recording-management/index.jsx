import React, { useState, useEffect } from 'react';
import { Play, Pause, Download, Share2, Trash2, Eye, EyeOff, RefreshCw, CheckCircle, Clock, AlertCircle } from 'lucide-react';
import { getRecordings, deleteRecording, updateRecordingVisibility } from '../../services/recordingService';
import { regenerateAIInsights } from '../../services/aiSummaryService';

export default function RecordingManagement() {
  const [recordings, setRecordings] = useState([]);
  const [selectedRecording, setSelectedRecording] = useState(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [filterType, setFilterType] = useState('all');
  const [showShareModal, setShowShareModal] = useState(false);
  const [shareEmail, setShareEmail] = useState('');
  const [sharePermission, setSharePermission] = useState('view');
  const [processingRecordingId, setProcessingRecordingId] = useState(null);

  useEffect(() => {
    loadRecordings();
  }, [filterType]);

  const loadRecordings = async () => {
    try {
      setLoading(true);
      setError(null);
      const filters = filterType !== 'all' ? { type: filterType } : {};
      const data = await getRecordings(filters);
      setRecordings(data);
    } catch (err) {
      setError(err?.message);
    } finally {
      setLoading(false);
    }
  };

  const handlePlayPause = (recording) => {
    if (selectedRecording?.id === recording?.id) {
      setIsPlaying(!isPlaying);
    } else {
      setSelectedRecording(recording);
      setIsPlaying(true);
      setCurrentTime(0);
    }
  };

  const handleDelete = async (recordingId) => {
    if (!confirm('Are you sure you want to delete this recording? This action cannot be undone.')) {
      return;
    }

    try {
      await deleteRecording(recordingId);
      setRecordings(recordings?.filter(r => r?.id !== recordingId));
      if (selectedRecording?.id === recordingId) {
        setSelectedRecording(null);
        setIsPlaying(false);
      }
    } catch (err) {
      alert('Failed to delete recording: ' + err?.message);
    }
  };

  const handleToggleVisibility = async (recording) => {
    try {
      await updateRecordingVisibility(recording?.id, !recording?.is_public);
      setRecordings(recordings?.map(r => 
        r?.id === recording?.id ? { ...r, is_public: !r?.is_public } : r
      ));
    } catch (err) {
      alert('Failed to update visibility: ' + err?.message);
    }
  };

  const handleShare = async (recordingId) => {
    setShowShareModal(true);
    setSelectedRecording(recordings?.find(r => r?.id === recordingId));
  };

  const submitShare = async () => {
    if (!shareEmail?.trim()) {
      alert('Please enter an email address');
      return;
    }

    try {
      // In a real app, you would look up the user by email first
      // For now, we'll show a placeholder
      alert('Share functionality requires user lookup by email. This would be implemented in a production environment.');
      setShowShareModal(false);
      setShareEmail('');
    } catch (err) {
      alert('Failed to share recording: ' + err?.message);
    }
  };

  const handleRegenerateInsights = async (recordingId) => {
    try {
      setProcessingRecordingId(recordingId);
      const updated = await regenerateAIInsights(recordingId);
      setRecordings(recordings?.map(r => r?.id === recordingId ? updated : r));
      if (selectedRecording?.id === recordingId) {
        setSelectedRecording(updated);
      }
    } catch (err) {
      alert('Failed to regenerate insights: ' + err?.message);
    } finally {
      setProcessingRecordingId(null);
    }
  };

  const formatDuration = (seconds) => {
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hrs > 0 ? hrs + ':' : ''}${mins?.toString()?.padStart(2, '0')}:${secs?.toString()?.padStart(2, '0')}`;
  };

  const formatFileSize = (bytes) => {
    const mb = bytes / (1024 * 1024);
    return mb > 1024 ? `${(mb / 1024)?.toFixed(2)} GB` : `${mb?.toFixed(2)} MB`;
  };

  const formatDate = (dateString) => {
    return new Date(dateString)?.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading recordings...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Recording Management</h1>
          <p className="mt-2 text-gray-600">Manage your call and meeting recordings with AI-powered insights</p>
        </div>

        {error && (
          <div className="mb-6 bg-red-50 border border-red-200 rounded-lg p-4">
            <p className="text-red-800">{error}</p>
          </div>
        )}

        {/* Filter Tabs */}
        <div className="mb-6 flex space-x-2 border-b border-gray-200">
          {['all', 'call', 'meeting', 'conference']?.map((type) => (
            <button
              key={type}
              onClick={() => setFilterType(type)}
              className={`px-4 py-2 font-medium transition-colors ${
                filterType === type
                  ? 'text-blue-600 border-b-2 border-blue-600' :'text-gray-600 hover:text-gray-900'
              }`}
            >
              {type?.charAt(0)?.toUpperCase() + type?.slice(1)}
            </button>
          ))}
        </div>

        {/* Recordings Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Recordings List */}
          <div className="lg:col-span-2 space-y-4">
            {recordings?.length === 0 ? (
              <div className="bg-white rounded-lg shadow-sm p-12 text-center">
                <p className="text-gray-500">No recordings found</p>
              </div>
            ) : (
              recordings?.map((recording) => (
                <div
                  key={recording?.id}
                  className={`bg-white rounded-lg shadow-sm p-6 transition-all ${
                    selectedRecording?.id === recording?.id ? 'ring-2 ring-blue-500' : ''
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-2">
                        <h3 className="text-lg font-semibold text-gray-900">
                          {recording?.meetings?.title || recording?.calls?.call_type || 'Untitled Recording'}
                        </h3>
                        <span className="px-2 py-1 text-xs font-medium bg-blue-100 text-blue-800 rounded">
                          {recording?.recording_type}
                        </span>
                        {recording?.is_public && (
                          <span className="px-2 py-1 text-xs font-medium bg-green-100 text-green-800 rounded">
                            Public
                          </span>
                        )}
                      </div>

                      <div className="flex items-center space-x-4 text-sm text-gray-600 mb-3">
                        <span>{formatDate(recording?.created_at)}</span>
                        <span>•</span>
                        <span>{formatDuration(recording?.duration || 0)}</span>
                        <span>•</span>
                        <span>{formatFileSize(recording?.file_size || 0)}</span>
                      </div>

                      {recording?.is_processing && (
                        <div className="flex items-center space-x-2 text-amber-600 text-sm mb-2">
                          <Clock className="w-4 h-4 animate-spin" />
                          <span>Processing AI insights...</span>
                        </div>
                      )}

                      {recording?.processing_error && (
                        <div className="flex items-center space-x-2 text-red-600 text-sm mb-2">
                          <AlertCircle className="w-4 h-4" />
                          <span>{recording?.processing_error}</span>
                        </div>
                      )}

                      {recording?.ai_summary && (
                        <p className="text-gray-700 text-sm mb-3">{recording?.ai_summary}</p>
                      )}

                      <div className="flex items-center space-x-2">
                        <button
                          onClick={() => handlePlayPause(recording)}
                          className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                        >
                          {isPlaying && selectedRecording?.id === recording?.id ? (
                            <>
                              <Pause className="w-4 h-4" />
                              <span>Pause</span>
                            </>
                          ) : (
                            <>
                              <Play className="w-4 h-4" />
                              <span>Play</span>
                            </>
                          )}
                        </button>

                        <a
                          href={recording?.file_url}
                          download
                          className="p-2 text-gray-600 hover:text-blue-600 transition-colors"
                          title="Download"
                        >
                          <Download className="w-5 h-5" />
                        </a>

                        <button
                          onClick={() => handleShare(recording?.id)}
                          className="p-2 text-gray-600 hover:text-blue-600 transition-colors"
                          title="Share"
                        >
                          <Share2 className="w-5 h-5" />
                        </button>

                        <button
                          onClick={() => handleToggleVisibility(recording)}
                          className="p-2 text-gray-600 hover:text-blue-600 transition-colors"
                          title={recording?.is_public ? 'Make Private' : 'Make Public'}
                        >
                          {recording?.is_public ? (
                            <Eye className="w-5 h-5" />
                          ) : (
                            <EyeOff className="w-5 h-5" />
                          )}
                        </button>

                        {recording?.transcript && (
                          <button
                            onClick={() => handleRegenerateInsights(recording?.id)}
                            disabled={processingRecordingId === recording?.id}
                            className="p-2 text-gray-600 hover:text-blue-600 transition-colors disabled:opacity-50"
                            title="Regenerate AI Insights"
                          >
                            <RefreshCw className={`w-5 h-5 ${processingRecordingId === recording?.id ? 'animate-spin' : ''}`} />
                          </button>
                        )}

                        <button
                          onClick={() => handleDelete(recording?.id)}
                          className="p-2 text-gray-600 hover:text-red-600 transition-colors"
                          title="Delete"
                        >
                          <Trash2 className="w-5 h-5" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Details Panel */}
          {selectedRecording && (
            <div className="lg:col-span-1">
              <div className="bg-white rounded-lg shadow-sm p-6 sticky top-4">
                <h2 className="text-xl font-semibold text-gray-900 mb-4">Recording Details</h2>

                {/* Action Items */}
                {selectedRecording?.action_items && selectedRecording?.action_items?.length > 0 && (
                  <div className="mb-6">
                    <h3 className="text-sm font-semibold text-gray-900 mb-3 flex items-center">
                      <CheckCircle className="w-4 h-4 mr-2 text-green-600" />
                      Action Items
                    </h3>
                    <div className="space-y-2">
                      {selectedRecording?.action_items?.map((item, index) => (
                        <div key={index} className="p-3 bg-gray-50 rounded-lg">
                          <p className="text-sm text-gray-900">{item?.text}</p>
                          {item?.assigned_to && (
                            <p className="text-xs text-gray-600 mt-1">
                              Assigned to: {item?.assigned_to}
                            </p>
                          )}
                          {item?.due_date && (
                            <p className="text-xs text-gray-600">
                              Due: {new Date(item.due_date)?.toLocaleDateString()}
                            </p>
                          )}
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Key Points */}
                {selectedRecording?.key_points && selectedRecording?.key_points?.length > 0 && (
                  <div className="mb-6">
                    <h3 className="text-sm font-semibold text-gray-900 mb-3">Key Discussion Points</h3>
                    <div className="space-y-2">
                      {selectedRecording?.key_points?.map((point, index) => (
                        <div key={index} className="p-3 bg-gray-50 rounded-lg">
                          {point?.timestamp && (
                            <p className="text-xs text-blue-600 font-medium mb-1">{point?.timestamp}</p>
                          )}
                          <p className="text-sm text-gray-900">{point?.text}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Transcript */}
                {selectedRecording?.transcript && (
                  <div>
                    <h3 className="text-sm font-semibold text-gray-900 mb-3">Transcript</h3>
                    <div className="p-3 bg-gray-50 rounded-lg max-h-64 overflow-y-auto">
                      <p className="text-sm text-gray-700 whitespace-pre-wrap">
                        {selectedRecording?.transcript}
                      </p>
                    </div>
                  </div>
                )}

                {!selectedRecording?.transcript && !selectedRecording?.is_processing && (
                  <p className="text-sm text-gray-500 text-center py-8">
                    No transcript available for this recording
                  </p>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Share Modal */}
        {showShareModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-lg max-w-md w-full p-6">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Share Recording</h3>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Email Address
                  </label>
                  <input
                    type="email"
                    value={shareEmail}
                    onChange={(e) => setShareEmail(e?.target?.value)}
                    placeholder="user@example.com"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Permission Level
                  </label>
                  <select
                    value={sharePermission}
                    onChange={(e) => setSharePermission(e?.target?.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="view">View Only</option>
                    <option value="download">View & Download</option>
                    <option value="full_access">Full Access</option>
                  </select>
                </div>
              </div>

              <div className="mt-6 flex space-x-3">
                <button
                  onClick={submitShare}
                  className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Share
                </button>
                <button
                  onClick={() => {
                    setShowShareModal(false);
                    setShareEmail('');
                  }}
                  className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}