import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { DollarSign, CreditCard, Clock, AlertCircle, Plus, Loader2, TrendingUp } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { withdrawalRequestService } from '../../services/withdrawalRequestService';
import Button from '../../components/ui/Button';

import BankAccountSelector from './components/BankAccountSelector';
import WithdrawalForm from './components/WithdrawalForm';
import WithdrawalHistory from './components/WithdrawalHistory';
import WithdrawalLimits from './components/WithdrawalLimits';
import AddBankAccountModal from './components/AddBankAccountModal';

export default function WithdrawalRequestManagementDashboard() {
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();

  const [loading, setLoading] = useState(true);
  const [availableBalance, setAvailableBalance] = useState(0);
  const [bankAccounts, setBankAccounts] = useState([]);
  const [withdrawalHistory, setWithdrawalHistory] = useState([]);
  const [withdrawalLimits, setWithdrawalLimits] = useState(null);
  const [selectedBankAccount, setSelectedBankAccount] = useState(null);
  const [showAddBankModal, setShowAddBankModal] = useState(false);
  const [activeTab, setActiveTab] = useState('request');
  const [error, setError] = useState('');

  useEffect(() => {
    if (!authLoading && !user) {
      navigate('/login');
    }
  }, [user, authLoading, navigate]);

  useEffect(() => {
    if (!authLoading && user) {
      loadDashboardData();
    }
  }, [authLoading, user]);

  const loadDashboardData = async () => {
    try {
      setLoading(true);
      setError('');

      const [balanceResult, accountsResult, historyResult, limitsResult] = await Promise.all([
        withdrawalRequestService?.getAvailableBalance(),
        withdrawalRequestService?.getBankAccounts(),
        withdrawalRequestService?.getWithdrawalHistory(),
        withdrawalRequestService?.getWithdrawalLimits()
      ]);

      if (balanceResult?.error) throw balanceResult?.error;
      if (accountsResult?.error) throw accountsResult?.error;
      if (historyResult?.error) throw historyResult?.error;

      setAvailableBalance(balanceResult?.data || 0);
      setBankAccounts(accountsResult?.data || []);
      setWithdrawalHistory(historyResult?.data || []);
      setWithdrawalLimits(limitsResult?.data);

      // Auto-select primary bank account
      const primaryAccount = accountsResult?.data?.find(acc => acc?.is_primary);
      if (primaryAccount) {
        setSelectedBankAccount(primaryAccount?.id);
      }
    } catch (err) {
      console.error('Error loading dashboard data:', err);
      setError(err?.message || 'Failed to load dashboard data');
    } finally {
      setLoading(false);
    }
  };

  const handleWithdrawalSuccess = () => {
    loadDashboardData();
    setActiveTab('history');
  };

  const handleBankAccountAdded = () => {
    setShowAddBankModal(false);
    loadDashboardData();
  };

  if (authLoading || loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Withdrawal Request Management | ChatVybz</title>
      </Helmet>

      <div className="min-h-screen bg-gray-50 py-8 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
              <DollarSign className="w-8 h-8 text-green-600" />
              Withdrawal Management
            </h1>
            <p className="mt-2 text-gray-600">
              Request payouts, manage bank accounts, and track withdrawal history
            </p>
          </div>

          {/* Error Display */}
          {error && (
            <div className="mb-6 bg-red-50 border border-red-200 rounded-lg p-4 flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-red-800 font-medium">Error</p>
                <p className="text-red-700 text-sm">{error}</p>
              </div>
            </div>
          )}

          {/* Available Balance Card */}
          <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-xl shadow-lg p-6 mb-8 text-white">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-100 text-sm font-medium mb-1">Available Balance</p>
                <p className="text-4xl font-bold">
                  {withdrawalRequestService?.formatAmount(availableBalance)}
                </p>
                <p className="text-green-100 text-sm mt-2">
                  Ready for withdrawal
                </p>
              </div>
              <div className="bg-white/20 rounded-full p-4">
                <TrendingUp className="w-8 h-8" />
              </div>
            </div>
          </div>

          {/* Tabs */}
          <div className="bg-white rounded-lg shadow-sm mb-6">
            <div className="border-b border-gray-200">
              <nav className="flex -mb-px">
                <button
                  onClick={() => setActiveTab('request')}
                  className={`px-6 py-4 text-sm font-medium border-b-2 transition-colors ${
                    activeTab === 'request' ?'border-blue-600 text-blue-600' :'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <DollarSign className="w-4 h-4" />
                    Request Withdrawal
                  </div>
                </button>
                <button
                  onClick={() => setActiveTab('history')}
                  className={`px-6 py-4 text-sm font-medium border-b-2 transition-colors ${
                    activeTab === 'history' ?'border-blue-600 text-blue-600' :'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4" />
                    History
                  </div>
                </button>
                <button
                  onClick={() => setActiveTab('accounts')}
                  className={`px-6 py-4 text-sm font-medium border-b-2 transition-colors ${
                    activeTab === 'accounts' ?'border-blue-600 text-blue-600' :'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <CreditCard className="w-4 h-4" />
                    Bank Accounts
                  </div>
                </button>
                <button
                  onClick={() => setActiveTab('limits')}
                  className={`px-6 py-4 text-sm font-medium border-b-2 transition-colors ${
                    activeTab === 'limits' ?'border-blue-600 text-blue-600' :'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <AlertCircle className="w-4 h-4" />
                    Limits
                  </div>
                </button>
              </nav>
            </div>
          </div>

          {/* Tab Content */}
          <div className="bg-white rounded-lg shadow-sm p-6">
            {activeTab === 'request' && (
              <div>
                <h2 className="text-xl font-semibold text-gray-900 mb-6">Request Withdrawal</h2>
                
                {bankAccounts?.length === 0 ? (
                  <div className="text-center py-12">
                    <CreditCard className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">
                      No Bank Accounts
                    </h3>
                    <p className="text-gray-600 mb-6">
                      Add a bank account to start requesting withdrawals
                    </p>
                    <Button
                      onClick={() => setShowAddBankModal(true)}
                      iconName="Plus"
                    >
                      Add Bank Account
                    </Button>
                  </div>
                ) : (
                  <WithdrawalForm
                    availableBalance={availableBalance}
                    bankAccounts={bankAccounts}
                    selectedBankAccount={selectedBankAccount}
                    onBankAccountChange={setSelectedBankAccount}
                    onSuccess={handleWithdrawalSuccess}
                    withdrawalLimits={withdrawalLimits}
                  />
                )}
              </div>
            )}

            {activeTab === 'history' && (
              <div>
                <h2 className="text-xl font-semibold text-gray-900 mb-6">Withdrawal History</h2>
                <WithdrawalHistory
                  history={withdrawalHistory}
                  onRefresh={loadDashboardData}
                />
              </div>
            )}

            {activeTab === 'accounts' && (
              <div>
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-semibold text-gray-900">Bank Accounts</h2>
                  <Button
                    onClick={() => setShowAddBankModal(true)}
                    iconName="Plus"
                    size="sm"
                  >
                    Add Account
                  </Button>
                </div>
                <BankAccountSelector
                  accounts={bankAccounts}
                  selectedAccount={selectedBankAccount}
                  onSelect={setSelectedBankAccount}
                  onRefresh={loadDashboardData}
                />
              </div>
            )}

            {activeTab === 'limits' && (
              <div>
                <h2 className="text-xl font-semibold text-gray-900 mb-6">Withdrawal Limits</h2>
                <WithdrawalLimits limits={withdrawalLimits} />
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Add Bank Account Modal */}
      {showAddBankModal && (
        <AddBankAccountModal
          onClose={() => setShowAddBankModal(false)}
          onSuccess={handleBankAccountAdded}
        />
      )}
    </>
  );
}