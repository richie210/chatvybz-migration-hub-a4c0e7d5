import React from 'react';
import { TrendingUp, AlertCircle } from 'lucide-react';
import { withdrawalRequestService } from '../../../services/withdrawalRequestService';

export default function WithdrawalLimits({ limits }) {
  if (!limits) {
    return (
      <div className="text-center py-12">
        <AlertCircle className="w-16 h-16 text-gray-400 mx-auto mb-4" />
        <p className="text-gray-600">Loading limits...</p>
      </div>
    );
  }

  const calculatePercentage = (used, limit) => {
    return (used / limit) * 100;
  };

  const getProgressColor = (percentage) => {
    if (percentage >= 90) return 'bg-red-600';
    if (percentage >= 70) return 'bg-yellow-600';
    return 'bg-green-600';
  };

  const limitCards = [
    {
      title: 'Daily Limit',
      used: limits?.daily_used || 0,
      limit: limits?.daily_limit || 1000,
      resetInfo: 'Resets daily at midnight'
    },
    {
      title: 'Weekly Limit',
      used: limits?.weekly_used || 0,
      limit: limits?.weekly_limit || 5000,
      resetInfo: 'Resets every Monday'
    },
    {
      title: 'Monthly Limit',
      used: limits?.monthly_used || 0,
      limit: limits?.monthly_limit || 20000,
      resetInfo: 'Resets on the 1st of each month'
    }
  ];

  return (
    <div className="space-y-6">
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <div className="flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-blue-900 font-medium">About Withdrawal Limits</p>
            <p className="text-blue-800 text-sm mt-1">
              These limits help protect your account and ensure secure transactions. Limits reset automatically at the specified intervals.
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {limitCards?.map((card, index) => {
          const percentage = calculatePercentage(card?.used, card?.limit);
          const remaining = card?.limit - card?.used;

          return (
            <div key={index} className="bg-white border border-gray-200 rounded-lg p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-900">{card?.title}</h3>
                <TrendingUp className="w-5 h-5 text-gray-400" />
              </div>

              <div className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-gray-600">Used</span>
                    <span className="font-medium text-gray-900">
                      {withdrawalRequestService?.formatAmount(card?.used)}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm mb-2">
                    <span className="text-gray-600">Limit</span>
                    <span className="font-medium text-gray-900">
                      {withdrawalRequestService?.formatAmount(card?.limit)}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Remaining</span>
                    <span className="font-medium text-green-600">
                      {withdrawalRequestService?.formatAmount(remaining)}
                    </span>
                  </div>
                </div>

                {/* Progress Bar */}
                <div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className={`h-2 rounded-full transition-all ${getProgressColor(percentage)}`}
                      style={{ width: `${Math.min(percentage, 100)}%` }}
                    />
                  </div>
                  <p className="text-xs text-gray-500 mt-2">
                    {percentage?.toFixed(1)}% used
                  </p>
                </div>

                <p className="text-xs text-gray-500 pt-2 border-t border-gray-200">
                  {card?.resetInfo}
                </p>
              </div>
            </div>
          );
        })}
      </div>

      <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
        <h4 className="font-medium text-gray-900 mb-2">Need Higher Limits?</h4>
        <p className="text-sm text-gray-600 mb-3">
          If you need higher withdrawal limits, please contact our support team with your business requirements.
        </p>
        <button className="text-sm text-blue-600 hover:text-blue-700 font-medium">
          Request Limit Increase →
        </button>
      </div>
    </div>
  );
}