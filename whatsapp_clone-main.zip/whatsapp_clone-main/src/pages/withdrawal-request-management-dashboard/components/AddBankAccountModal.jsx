import React, { useState } from 'react';
import { X, CreditCard, AlertCircle } from 'lucide-react';
import { withdrawalRequestService } from '../../../services/withdrawalRequestService';
import Button from '../../../components/ui/Button';


export default function AddBankAccountModal({ onClose, onSuccess }) {
  const [formData, setFormData] = useState({
    nickname: '',
    bankName: '',
    accountType: 'checking',
    routingNumber: '',
    accountNumber: '',
    confirmAccountNumber: '',
    isPrimary: false
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    setError('');
  };

  const validateForm = () => {
    if (!formData?.nickname?.trim()) {
      return 'Please enter an account nickname';
    }
    if (!formData?.bankName?.trim()) {
      return 'Please enter bank name';
    }
    if (!formData?.routingNumber || formData?.routingNumber?.length !== 9) {
      return 'Routing number must be 9 digits';
    }
    if (!formData?.accountNumber || formData?.accountNumber?.length < 4) {
      return 'Please enter a valid account number';
    }
    if (formData?.accountNumber !== formData?.confirmAccountNumber) {
      return 'Account numbers do not match';
    }
    return null;
  };

  const handleSubmit = async (e) => {
    e?.preventDefault();
    
    const validationError = validateForm();
    if (validationError) {
      setError(validationError);
      return;
    }

    try {
      setLoading(true);
      setError('');

      const result = await withdrawalRequestService?.addBankAccount(formData);

      if (result?.error) throw result?.error;

      onSuccess?.();
    } catch (err) {
      console.error('Error adding bank account:', err);
      setError(err?.message || 'Failed to add bank account');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <div className="flex items-center gap-3">
            <div className="bg-blue-100 rounded-full p-2">
              <CreditCard className="w-6 h-6 text-blue-600" />
            </div>
            <h2 className="text-xl font-semibold text-gray-900">Add Bank Account</h2>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* Account Nickname */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Account Nickname *
            </label>
            <input
              type="text"
              value={formData?.nickname}
              onChange={(e) => handleChange('nickname', e?.target?.value)}
              placeholder="e.g., Primary Checking"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              required
            />
          </div>

          {/* Bank Name */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Bank Name *
            </label>
            <input
              type="text"
              value={formData?.bankName}
              onChange={(e) => handleChange('bankName', e?.target?.value)}
              placeholder="e.g., Chase Bank"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              required
            />
          </div>

          {/* Account Type */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Account Type *
            </label>
            <select
              value={formData?.accountType}
              onChange={(e) => handleChange('accountType', e?.target?.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="checking">Checking</option>
              <option value="savings">Savings</option>
            </select>
          </div>

          {/* Routing Number */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Routing Number *
            </label>
            <input
              type="text"
              value={formData?.routingNumber}
              onChange={(e) => handleChange('routingNumber', e?.target?.value?.replace(/\D/g, ''))}
              placeholder="9 digits"
              maxLength={9}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              required
            />
          </div>

          {/* Account Number */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Account Number *
            </label>
            <input
              type="password"
              value={formData?.accountNumber}
              onChange={(e) => handleChange('accountNumber', e?.target?.value?.replace(/\D/g, ''))}
              placeholder="Enter account number"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              required
            />
          </div>

          {/* Confirm Account Number */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Confirm Account Number *
            </label>
            <input
              type="password"
              value={formData?.confirmAccountNumber}
              onChange={(e) => handleChange('confirmAccountNumber', e?.target?.value?.replace(/\D/g, ''))}
              placeholder="Re-enter account number"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              required
            />
          </div>

          {/* Set as Primary */}
          <div className="flex items-center gap-2">
            <input
              type="checkbox"
              id="isPrimary"
              checked={formData?.isPrimary}
              onChange={(e) => handleChange('isPrimary', e?.target?.checked)}
              className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
            />
            <label htmlFor="isPrimary" className="text-sm text-gray-700">
              Set as primary account
            </label>
          </div>

          {/* Security Notice */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-blue-900 font-medium text-sm">Security Notice</p>
                <p className="text-blue-800 text-xs mt-1">
                  Your bank account information is encrypted and stored securely. We never share your financial data with third parties.
                </p>
              </div>
            </div>
          </div>

          {/* Error Display */}
          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
              <p className="text-red-800 text-sm">{error}</p>
            </div>
          )}

          {/* Actions */}
          <div className="flex gap-3 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              className="flex-1"
              disabled={loading}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              loading={loading}
              disabled={loading}
              className="flex-1"
            >
              {loading ? 'Adding...' : 'Add Bank Account'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}