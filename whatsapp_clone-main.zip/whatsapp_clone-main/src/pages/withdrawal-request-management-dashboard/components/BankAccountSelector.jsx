import React, { useState } from 'react';
import { CreditCard, CheckCircle, AlertCircle, Trash2 } from 'lucide-react';
import { withdrawalRequestService } from '../../../services/withdrawalRequestService';
import Button from '../../../components/ui/Button';

export default function BankAccountSelector({ accounts, selectedAccount, onSelect, onRefresh }) {
  const [deletingId, setDeletingId] = React.useState(null);

  const handleDelete = async (accountId) => {
    if (!confirm('Are you sure you want to delete this bank account?')) return;

    try {
      setDeletingId(accountId);
      const result = await withdrawalRequestService?.deleteBankAccount(accountId);
      
      if (result?.error) throw result?.error;
      
      onRefresh?.();
    } catch (error) {
      alert(error?.message || 'Failed to delete bank account');
    } finally {
      setDeletingId(null);
    }
  };

  const handleSetPrimary = async (accountId) => {
    try {
      const result = await withdrawalRequestService?.updateBankAccount(accountId, { is_primary: true });
      
      if (result?.error) throw result?.error;
      
      onRefresh?.();
    } catch (error) {
      alert(error?.message || 'Failed to set primary account');
    }
  };

  if (!accounts || accounts?.length === 0) {
    return (
      <div className="text-center py-12">
        <CreditCard className="w-16 h-16 text-gray-400 mx-auto mb-4" />
        <p className="text-gray-600">No bank accounts added yet</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {accounts?.map((account) => (
        <div
          key={account?.id}
          className={`border-2 rounded-lg p-4 transition-colors cursor-pointer ${
            selectedAccount === account?.id
              ? 'border-blue-600 bg-blue-50' :'border-gray-200 hover:border-gray-300'
          }`}
          onClick={() => onSelect?.(account?.id)}
        >
          <div className="flex items-start justify-between">
            <div className="flex items-start gap-3 flex-1">
              <div className="bg-blue-100 rounded-full p-2">
                <CreditCard className="w-5 h-5 text-blue-600" />
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="font-semibold text-gray-900">{account?.account_nickname}</h3>
                  {account?.is_primary && (
                    <span className="px-2 py-0.5 bg-green-100 text-green-800 text-xs font-medium rounded-full">
                      Primary
                    </span>
                  )}
                  {account?.is_verified ? (
                    <CheckCircle className="w-4 h-4 text-green-600" />
                  ) : (
                    <AlertCircle className="w-4 h-4 text-yellow-600" />
                  )}
                </div>
                <p className="text-sm text-gray-600">{account?.bank_name}</p>
                <p className="text-sm text-gray-500 mt-1">
                  {account?.account_type?.charAt(0)?.toUpperCase() + account?.account_type?.slice(1)} •••• {account?.account_number_last4}
                </p>
                <p className="text-xs text-gray-500 mt-1">
                  Routing: {account?.routing_number}
                </p>
                {!account?.is_verified && (
                  <p className="text-xs text-yellow-600 mt-2">
                    Verification pending
                  </p>
                )}
              </div>
            </div>
            <div className="flex items-center gap-2">
              {!account?.is_primary && (
                <Button
                  size="sm"
                  variant="outline"
                  onClick={(e) => {
                    e?.stopPropagation();
                    handleSetPrimary(account?.id);
                  }}
                >
                  Set Primary
                </Button>
              )}
              <Button
                size="sm"
                variant="ghost"
                onClick={(e) => {
                  e?.stopPropagation();
                  handleDelete(account?.id);
                }}
                loading={deletingId === account?.id}
                disabled={deletingId === account?.id}
              >
                <Trash2 className="w-4 h-4 text-red-600" />
              </Button>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}