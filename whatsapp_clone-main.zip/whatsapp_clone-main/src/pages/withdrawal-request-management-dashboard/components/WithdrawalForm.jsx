import React, { useState } from 'react';
import { Calendar, DollarSign, AlertCircle } from 'lucide-react';
import { withdrawalRequestService } from '../../../services/withdrawalRequestService';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';

export default function WithdrawalForm({ availableBalance, bankAccounts, selectedBankAccount, onBankAccountChange, onSuccess, withdrawalLimits }) {
  const [amount, setAmount] = useState('');
  const [withdrawalType, setWithdrawalType] = useState('one_time');
  const [scheduleFrequency, setScheduleFrequency] = useState('monthly');
  const [scheduleDate, setScheduleDate] = useState('');
  const [notes, setNotes] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const calculateFee = (amt) => {
    const numAmount = parseFloat(amt) || 0;
    return Math.min(Math.max(numAmount * 0.01, 1.00), 10.00);
  };

  const calculateNetAmount = (amt) => {
    const numAmount = parseFloat(amt) || 0;
    const fee = calculateFee(amt);
    return numAmount - fee;
  };

  const validateAmount = () => {
    const numAmount = parseFloat(amount);

    if (!amount || numAmount <= 0) {
      return 'Please enter a valid amount';
    }

    if (numAmount > availableBalance) {
      return 'Amount exceeds available balance';
    }

    if (withdrawalLimits) {
      const dailyRemaining = withdrawalLimits?.daily_limit - withdrawalLimits?.daily_used;
      const weeklyRemaining = withdrawalLimits?.weekly_limit - withdrawalLimits?.weekly_used;
      const monthlyRemaining = withdrawalLimits?.monthly_limit - withdrawalLimits?.monthly_used;

      if (numAmount > dailyRemaining) {
        return `Amount exceeds daily limit. Remaining: ${withdrawalRequestService?.formatAmount(dailyRemaining)}`;
      }

      if (numAmount > weeklyRemaining) {
        return `Amount exceeds weekly limit. Remaining: ${withdrawalRequestService?.formatAmount(weeklyRemaining)}`;
      }

      if (numAmount > monthlyRemaining) {
        return `Amount exceeds monthly limit. Remaining: ${withdrawalRequestService?.formatAmount(monthlyRemaining)}`;
      }
    }

    return null;
  };

  const handleSubmit = async (e) => {
    e?.preventDefault();
    
    const validationError = validateAmount();
    if (validationError) {
      setError(validationError);
      return;
    }

    if (!selectedBankAccount) {
      setError('Please select a bank account');
      return;
    }

    try {
      setLoading(true);
      setError('');

      const requestData = {
        amount: parseFloat(amount),
        bankAccountId: selectedBankAccount,
        withdrawalType,
        scheduleFrequency: withdrawalType === 'recurring' ? scheduleFrequency : null,
        scheduleDate: withdrawalType === 'recurring' ? scheduleDate : null,
        notes
      };

      const result = await withdrawalRequestService?.createWithdrawalRequest(requestData);

      if (result?.error) throw result?.error;

      // Reset form
      setAmount('');
      setNotes('');
      setWithdrawalType('one_time');
      setScheduleDate('');

      onSuccess?.();
    } catch (err) {
      console.error('Error creating withdrawal request:', err);
      setError(err?.message || 'Failed to create withdrawal request');
    } finally {
      setLoading(false);
    }
  };

  const selectedAccount = bankAccounts?.find(acc => acc?.id === selectedBankAccount);

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Amount Input */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Withdrawal Amount
        </label>
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <DollarSign className="h-5 w-5 text-gray-400" />
          </div>
          <input
            type="number"
            step="0.01"
            min="0"
            max={availableBalance}
            value={amount}
            onChange={(e) => setAmount(e?.target?.value)}
            className="block w-full pl-10 pr-12 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            placeholder="0.00"
            required
          />
        </div>
        <p className="mt-2 text-sm text-gray-600">
          Available: {withdrawalRequestService?.formatAmount(availableBalance)}
        </p>
      </div>
      {/* Fee Calculation */}
      {amount && parseFloat(amount) > 0 && (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-gray-700">Withdrawal Amount:</span>
            <span className="font-medium text-gray-900">
              {withdrawalRequestService?.formatAmount(parseFloat(amount))}
            </span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-700">Processing Fee (1%, min $1, max $10):</span>
            <span className="font-medium text-gray-900">
              {withdrawalRequestService?.formatAmount(calculateFee(amount))}
            </span>
          </div>
          <div className="border-t border-blue-200 pt-2 flex justify-between">
            <span className="text-sm font-medium text-gray-900">You'll Receive:</span>
            <span className="text-lg font-bold text-green-600">
              {withdrawalRequestService?.formatAmount(calculateNetAmount(amount))}
            </span>
          </div>
        </div>
      )}
      {/* Bank Account Selection */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Bank Account
        </label>
        <select
          value={selectedBankAccount || ''}
          onChange={(e) => onBankAccountChange?.(e?.target?.value)}
          className="block w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          required
        >
          <option value="">Select bank account</option>
          {bankAccounts?.map((account) => (
            <option key={account?.id} value={account?.id}>
              {account?.account_nickname} - {account?.bank_name} (****{account?.account_number_last4})
              {account?.is_primary && ' - Primary'}
            </option>
          ))}
        </select>
      </div>
      {/* Withdrawal Type */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Withdrawal Type
        </label>
        <div className="grid grid-cols-2 gap-4">
          <button
            type="button"
            onClick={() => setWithdrawalType('one_time')}
            className={`p-4 border-2 rounded-lg text-left transition-colors ${
              withdrawalType === 'one_time' ?'border-blue-600 bg-blue-50' :'border-gray-200 hover:border-gray-300'
            }`}
          >
            <p className="font-medium text-gray-900">One-Time</p>
            <p className="text-sm text-gray-600 mt-1">Single withdrawal</p>
          </button>
          <button
            type="button"
            onClick={() => setWithdrawalType('recurring')}
            className={`p-4 border-2 rounded-lg text-left transition-colors ${
              withdrawalType === 'recurring' ?'border-blue-600 bg-blue-50' :'border-gray-200 hover:border-gray-300'
            }`}
          >
            <p className="font-medium text-gray-900">Recurring</p>
            <p className="text-sm text-gray-600 mt-1">Automatic schedule</p>
          </button>
        </div>
      </div>
      {/* Recurring Options */}
      {withdrawalType === 'recurring' && (
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Frequency
            </label>
            <select
              value={scheduleFrequency}
              onChange={(e) => setScheduleFrequency(e?.target?.value)}
              className="block w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="weekly">Weekly</option>
              <option value="monthly">Monthly</option>
              <option value="custom">Custom</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Start Date
            </label>
            <input
              type="date"
              value={scheduleDate}
              onChange={(e) => setScheduleDate(e?.target?.value)}
              min={new Date()?.toISOString()?.split('T')?.[0]}
              className="block w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              required
            />
          </div>
        </div>
      )}
      {/* Notes */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Notes (Optional)
        </label>
        <textarea
          value={notes}
          onChange={(e) => setNotes(e?.target?.value)}
          rows={3}
          className="block w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          placeholder="Add any notes about this withdrawal..."
        />
      </div>
      {/* Error Display */}
      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
          <p className="text-red-800 text-sm">{error}</p>
        </div>
      )}
      {/* Estimated Arrival */}
      <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
        <div className="flex items-center gap-2 text-sm text-gray-700">
          <Calendar className="w-4 h-4" />
          <span>Estimated arrival: 3-5 business days</span>
        </div>
      </div>
      {/* Submit Button */}
      <Button
        type="submit"
        loading={loading}
        disabled={loading || !amount || !selectedBankAccount}
        className="w-full"
        size="lg"
      >
        {loading ? 'Processing...' : 'Submit Withdrawal Request'}
      </Button>
    </form>
  );
}