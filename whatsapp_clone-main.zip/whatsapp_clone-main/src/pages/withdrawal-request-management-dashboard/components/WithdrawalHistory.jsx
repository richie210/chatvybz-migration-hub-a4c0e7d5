import React, { useState } from 'react';
import { Clock, CheckCircle, XCircle, AlertCircle, Search } from 'lucide-react';
import { withdrawalRequestService } from '../../../services/withdrawalRequestService';
import Button from '../../../components/ui/Button';

export default function WithdrawalHistory({ history, onRefresh }) {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [cancellingId, setCancellingId] = useState(null);

  const handleCancel = async (requestId) => {
    if (!confirm('Are you sure you want to cancel this withdrawal request?')) return;

    try {
      setCancellingId(requestId);
      const result = await withdrawalRequestService?.cancelWithdrawalRequest(requestId);
      
      if (result?.error) throw result?.error;
      
      onRefresh?.();
    } catch (error) {
      alert(error?.message || 'Failed to cancel withdrawal request');
    } finally {
      setCancellingId(null);
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="w-5 h-5 text-green-600" />;
      case 'failed': case'cancelled':
        return <XCircle className="w-5 h-5 text-red-600" />;
      case 'processing': case'under_review':
        return <Clock className="w-5 h-5 text-blue-600" />;
      default:
        return <AlertCircle className="w-5 h-5 text-yellow-600" />;
    }
  };

  const filteredHistory = history?.filter((item) => {
    const matchesSearch = searchQuery === '' || 
      item?.bank_account?.bank_name?.toLowerCase()?.includes(searchQuery?.toLowerCase()) ||
      item?.amount?.toString()?.includes(searchQuery);
    
    const matchesStatus = statusFilter === 'all' || item?.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  if (!history || history?.length === 0) {
    return (
      <div className="text-center py-12">
        <Clock className="w-16 h-16 text-gray-400 mx-auto mb-4" />
        <p className="text-gray-600">No withdrawal history yet</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="flex-1">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search by bank or amount..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e?.target?.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
        </div>
        <div>
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e?.target?.value)}
            className="w-full sm:w-auto px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="all">All Status</option>
            <option value="submitted">Submitted</option>
            <option value="under_review">Under Review</option>
            <option value="processing">Processing</option>
            <option value="completed">Completed</option>
            <option value="failed">Failed</option>
            <option value="cancelled">Cancelled</option>
          </select>
        </div>
      </div>
      {/* History List */}
      <div className="space-y-4">
        {filteredHistory?.map((item) => (
          <div
            key={item?.id}
            className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow"
          >
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-3 flex-1">
                {getStatusIcon(item?.status)}
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-semibold text-gray-900">
                      {withdrawalRequestService?.formatAmount(item?.amount)}
                    </h3>
                    <span
                      className={`px-2 py-0.5 text-xs font-medium rounded-full ${
                        item?.status === 'completed'
                          ? 'bg-green-100 text-green-800'
                          : item?.status === 'failed'|| item?.status === 'cancelled' ?'bg-red-100 text-red-800'
                          : item?.status === 'processing'|| item?.status === 'under_review' ?'bg-blue-100 text-blue-800' :'bg-yellow-100 text-yellow-800'
                      }`}
                    >
                      {withdrawalRequestService?.getStatusText(item?.status)}
                    </span>
                  </div>
                  <p className="text-sm text-gray-600">
                    {item?.bank_account?.bank_name} •••• {item?.bank_account?.account_number_last4}
                  </p>
                  <div className="mt-2 space-y-1 text-xs text-gray-500">
                    <p>Requested: {new Date(item?.created_at)?.toLocaleDateString()}</p>
                    {item?.estimated_arrival_date && (
                      <p>Estimated arrival: {new Date(item?.estimated_arrival_date)?.toLocaleDateString()}</p>
                    )}
                    {item?.actual_arrival_date && (
                      <p>Arrived: {new Date(item?.actual_arrival_date)?.toLocaleDateString()}</p>
                    )}
                    <p>Fee: {withdrawalRequestService?.formatAmount(item?.processing_fee)}</p>
                    <p className="font-medium text-gray-700">
                      Net: {withdrawalRequestService?.formatAmount(item?.net_amount)}
                    </p>
                  </div>
                  {item?.failure_reason && (
                    <p className="mt-2 text-sm text-red-600">
                      Reason: {item?.failure_reason}
                    </p>
                  )}
                  {item?.notes && (
                    <p className="mt-2 text-sm text-gray-600 italic">
                      Note: {item?.notes}
                    </p>
                  )}
                </div>
              </div>
              {item?.status === 'submitted' && (
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => handleCancel(item?.id)}
                  loading={cancellingId === item?.id}
                  disabled={cancellingId === item?.id}
                >
                  Cancel
                </Button>
              )}
            </div>
          </div>
        ))}
      </div>
      {filteredHistory?.length === 0 && (
        <div className="text-center py-12">
          <p className="text-gray-600">No results found</p>
        </div>
      )}
    </div>
  );
}