import React, { useState, useEffect } from 'react';
import { Bell, MessageSquare, Phone, Eye, Reply, Filter, Check, CheckCheck } from 'lucide-react';
import { notificationService } from '../../services/notificationService';
import { useAuth } from '../../contexts/AuthContext';
import { trackFeatureAdoption } from '../../utils/analytics';
import Icon from '../../components/AppIcon';


const NotificationsScreen = () => {
  const { user } = useAuth();
  const [notifications, setNotifications] = useState([]);
  const [filter, setFilter] = useState('all');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    trackFeatureAdoption?.featureUsed('notifications_screen');
    loadNotifications();

    // Subscribe to real-time updates
    const unsubscribe = notificationService?.subscribeToNotifications(
      user?.id,
      () => loadNotifications()
    );

    return () => unsubscribe?.();
  }, [user?.id]);

  const loadNotifications = async () => {
    if (!user?.id) return;
    
    try {
      setLoading(true);
      const data = await notificationService?.getUserNotifications(user?.id);
      setNotifications(data);
    } catch (error) {
      console.error('Failed to load notifications:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleMarkAsRead = async (notification) => {
    if (notification?.type === 'message' && !notification?.read) {
      try {
        await notificationService?.markMessageAsRead(notification?.id);
        loadNotifications();
      } catch (error) {
        console.error('Failed to mark as read:', error);
      }
    }
  };

  const getNotificationIcon = (type) => {
    const iconMap = {
      message: MessageSquare,
      call: Phone,
      status_view: Eye,
      status_reply: Reply
    };
    const Icon = iconMap?.[type] || Bell;
    return <Icon className="w-5 h-5" />;
  };

  const getIconColor = (type) => {
    const colorMap = {
      message: 'text-blue-500',
      call: 'text-green-500',
      status_view: 'text-purple-500',
      status_reply: 'text-orange-500'
    };
    return colorMap?.[type] || 'text-gray-500';
  };

  const filteredNotifications = notifications?.filter(notif => {
    if (filter === 'all') return true;
    if (filter === 'unread') return !notif?.read;
    return notif?.type === filter;
  });

  const formatTimestamp = (timestamp) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    if (diffDays < 7) return `${diffDays}d ago`;
    return date?.toLocaleDateString();
  };

  return (
    <div className="flex flex-col h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <div className="bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 p-4">
        <div className="flex items-center justify-between mb-4">
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
            <Bell className="w-6 h-6" />
            Notifications
          </h1>
          <button
            onClick={() => setFilter('unread')}
            className="text-sm text-blue-600 hover:text-blue-700 dark:text-blue-400 flex items-center gap-1"
          >
            <Filter className="w-4 h-4" />
            Filter
          </button>
        </div>

        {/* Filter Tabs */}
        <div className="flex gap-2 overflow-x-auto">
          {[
            { id: 'all', label: 'All', icon: Bell },
            { id: 'unread', label: 'Unread', icon: CheckCheck },
            { id: 'message', label: 'Messages', icon: MessageSquare },
            { id: 'call', label: 'Calls', icon: Phone },
            { id: 'status_reply', label: 'Replies', icon: Reply },
            { id: 'status_view', label: 'Views', icon: Eye }
          ]?.map(tab => {
            const Icon = tab?.icon;
            return (
              <button
                key={tab?.id}
                onClick={() => {
                  setFilter(tab?.id);
                  trackFeatureAdoption?.featureUsed(`notification_filter_${tab?.id}`);
                }}
                className={`px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-2 whitespace-nowrap transition-colors ${
                  filter === tab?.id
                    ? 'bg-blue-500 text-white' :'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
                }`}
              >
                <Icon className="w-4 h-4" />
                {tab?.label}
              </button>
            );
          })}
        </div>
      </div>
      {/* Notifications List */}
      <div className="flex-1 overflow-y-auto">
        {loading ? (
          <div className="flex items-center justify-center h-full">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
          </div>
        ) : filteredNotifications?.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-gray-500 dark:text-gray-400">
            <Bell className="w-16 h-16 mb-4 opacity-50" />
            <p className="text-lg font-medium">No notifications</p>
            <p className="text-sm">You're all caught up!</p>
          </div>
        ) : (
          <div className="divide-y divide-gray-200 dark:divide-gray-700">
            {filteredNotifications?.map(notification => (
              <div
                key={notification?.id}
                onClick={() => handleMarkAsRead(notification)}
                className={`p-4 hover:bg-gray-50 dark:hover:bg-gray-800 cursor-pointer transition-colors ${
                  !notification?.read ? 'bg-blue-50 dark:bg-blue-900/10' : ''
                }`}
              >
                <div className="flex gap-3">
                  {/* Avatar or Icon */}
                  <div className="flex-shrink-0">
                    {notification?.avatar ? (
                      <img
                        src={notification?.avatar}
                        alt={notification?.title}
                        className="w-12 h-12 rounded-full object-cover"
                      />
                    ) : (
                      <div className={`w-12 h-12 rounded-full bg-gray-100 dark:bg-gray-700 flex items-center justify-center ${getIconColor(notification?.type)}`}>
                        {getNotificationIcon(notification?.type)}
                      </div>
                    )}
                  </div>

                  {/* Content */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <p className="font-medium text-gray-900 dark:text-white truncate">
                        {notification?.title}
                      </p>
                      <span className="text-xs text-gray-500 dark:text-gray-400 whitespace-nowrap">
                        {formatTimestamp(notification?.timestamp)}
                      </span>
                    </div>
                    <p className="text-sm text-gray-600 dark:text-gray-300 mt-1 line-clamp-2">
                      {notification?.message}
                    </p>
                    
                    {/* Read indicator */}
                    {!notification?.read && notification?.type === 'message' && (
                      <div className="flex items-center gap-1 mt-2">
                        <Check className="w-4 h-4 text-blue-500" />
                        <span className="text-xs text-blue-600 dark:text-blue-400">Unread</span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default NotificationsScreen;