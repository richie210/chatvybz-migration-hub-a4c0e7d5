import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import { Checkbox } from '../../../components/ui/Checkbox';
import Select from '../../../components/ui/Select';

const GroupSettings = ({ settings, isAdmin, onUpdateSettings }) => {
  const [localSettings, setLocalSettings] = useState(settings);
  const [inviteLink, setInviteLink] = useState('https://chatvybz.app/invite/abc123xyz');
  const [linkCopied, setLinkCopied] = useState(false);

  const privacyOptions = [
    { value: 'public', label: 'Public', description: 'Anyone can join with invite link' },
    { value: 'private', label: 'Private', description: 'Only admins can add members' }
  ];

  const messagePermissionOptions = [
    { value: 'all', label: 'All Members', description: 'Everyone can send messages' },
    { value: 'admins', label: 'Admins Only', description: 'Only admins can send messages' }
  ];

  const linkExpirationOptions = [
    { value: 'never', label: 'Never' },
    { value: '1hour', label: '1 Hour' },
    { value: '1day', label: '1 Day' },
    { value: '7days', label: '7 Days' },
    { value: '30days', label: '30 Days' }
  ];

  const handleSettingChange = (key, value) => {
    const updatedSettings = { ...localSettings, [key]: value };
    setLocalSettings(updatedSettings);
    onUpdateSettings(updatedSettings);
  };

  const handleCopyLink = () => {
    navigator.clipboard?.writeText(inviteLink);
    setLinkCopied(true);
    setTimeout(() => setLinkCopied(false), 2000);
  };

  const handleGenerateNewLink = () => {
    const newLink = `https://chatvybz.app/invite/${Math.random()?.toString(36)?.substring(7)}`;
    setInviteLink(newLink);
  };

  return (
    <div className="space-y-4 md:space-y-6">
      {/* Privacy Settings */}
      <div className="bg-card rounded-xl border border-border p-4 md:p-6">
        <div className="flex items-center gap-3 mb-4 md:mb-6">
          <div className="w-10 h-10 md:w-12 md:h-12 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
            <Icon name="Lock" size={20} color="var(--color-primary)" />
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="text-base md:text-lg font-semibold text-foreground">Privacy Settings</h3>
            <p className="text-xs md:text-sm text-muted-foreground">Control who can join and interact</p>
          </div>
        </div>

        <div className="space-y-4">
          <Select
            label="Group Privacy"
            description="Set who can join this group"
            options={privacyOptions}
            value={localSettings?.privacy}
            onChange={(value) => handleSettingChange('privacy', value)}
            disabled={!isAdmin}
          />

          <Select
            label="Message Permissions"
            description="Control who can send messages"
            options={messagePermissionOptions}
            value={localSettings?.messagePermission}
            onChange={(value) => handleSettingChange('messagePermission', value)}
            disabled={!isAdmin}
          />

          <Checkbox
            label="Approve new members"
            description="Admins must approve before members can join"
            checked={localSettings?.approveMembers}
            onChange={(e) => handleSettingChange('approveMembers', e?.target?.checked)}
            disabled={!isAdmin}
          />
        </div>
      </div>
      {/* Invite Link */}
      <div className="bg-card rounded-xl border border-border p-4 md:p-6">
        <div className="flex items-center gap-3 mb-4 md:mb-6">
          <div className="w-10 h-10 md:w-12 md:h-12 rounded-full bg-accent/10 flex items-center justify-center flex-shrink-0">
            <Icon name="Link" size={20} color="var(--color-accent)" />
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="text-base md:text-lg font-semibold text-foreground">Invite Link</h3>
            <p className="text-xs md:text-sm text-muted-foreground">Share this link to invite members</p>
          </div>
        </div>

        <div className="space-y-4">
          <div className="flex flex-col sm:flex-row gap-2">
            <div className="flex-1 px-3 py-2 md:px-4 md:py-3 bg-muted rounded-lg text-sm md:text-base text-foreground font-mono truncate">
              {inviteLink}
            </div>
            <Button
              variant={linkCopied ? 'success' : 'outline'}
              onClick={handleCopyLink}
              iconName={linkCopied ? 'Check' : 'Copy'}
              iconPosition="left"
              className="sm:w-auto"
            >
              {linkCopied ? 'Copied!' : 'Copy'}
            </Button>
          </div>

          <Select
            label="Link Expiration"
            options={linkExpirationOptions}
            value={localSettings?.linkExpiration}
            onChange={(value) => handleSettingChange('linkExpiration', value)}
            disabled={!isAdmin}
          />

          {isAdmin && (
            <Button
              variant="outline"
              onClick={handleGenerateNewLink}
              iconName="RefreshCw"
              iconPosition="left"
              fullWidth
            >
              Generate New Link
            </Button>
          )}
        </div>
      </div>
      {/* Notification Settings */}
      <div className="bg-card rounded-xl border border-border p-4 md:p-6">
        <div className="flex items-center gap-3 mb-4 md:mb-6">
          <div className="w-10 h-10 md:w-12 md:h-12 rounded-full bg-warning/10 flex items-center justify-center flex-shrink-0">
            <Icon name="Bell" size={20} color="var(--color-warning)" />
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="text-base md:text-lg font-semibold text-foreground">Notifications</h3>
            <p className="text-xs md:text-sm text-muted-foreground">Manage group notification settings</p>
          </div>
        </div>

        <div className="space-y-3">
          <Checkbox
            label="Mute notifications"
            description="Stop receiving notifications from this group"
            checked={localSettings?.muteNotifications}
            onChange={(e) => handleSettingChange('muteNotifications', e?.target?.checked)}
          />

          <Checkbox
            label="Show message preview"
            description="Display message content in notifications"
            checked={localSettings?.showPreview}
            onChange={(e) => handleSettingChange('showPreview', e?.target?.checked)}
          />
        </div>
      </div>
      {/* Danger Zone */}
      {isAdmin && (
        <div className="bg-destructive/5 rounded-xl border border-destructive/20 p-4 md:p-6">
          <div className="flex items-center gap-3 mb-4 md:mb-6">
            <div className="w-10 h-10 md:w-12 md:h-12 rounded-full bg-destructive/10 flex items-center justify-center flex-shrink-0">
              <Icon name="AlertTriangle" size={20} color="var(--color-destructive)" />
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="text-base md:text-lg font-semibold text-destructive">Danger Zone</h3>
              <p className="text-xs md:text-sm text-muted-foreground">Irreversible actions</p>
            </div>
          </div>

          <div className="space-y-3">
            <Button
              variant="outline"
              fullWidth
              iconName="UserX"
              iconPosition="left"
              className="text-destructive border-destructive hover:bg-destructive/10"
            >
              Leave Group
            </Button>
            <Button
              variant="destructive"
              fullWidth
              iconName="Trash2"
              iconPosition="left"
            >
              Delete Group
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};

export default GroupSettings;