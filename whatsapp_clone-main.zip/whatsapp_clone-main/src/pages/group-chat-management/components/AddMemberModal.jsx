import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import { Checkbox } from '../../../components/ui/Checkbox';

const AddMemberModal = ({ isOpen, onClose, onAddMembers, existingMemberIds }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedContacts, setSelectedContacts] = useState([]);

  const contacts = [
    {
      id: 101,
      name: 'Robert Martinez',
      phone: '+1 (555) 111-2222',
      avatar: '/assets/images/contact1.jpg',
      avatarAlt: 'Professional headshot of Hispanic man with short black hair wearing navy blue suit and white shirt',
      status: 'Available'
    },
    {
      id: 102,
      name: 'Jennifer Lee',
      phone: '+1 (555) 222-3333',
      avatar: '/assets/images/contact2.jpg',
      avatarAlt: 'Professional portrait of Asian woman with long black hair in gray business blazer',
      status: 'Busy'
    },
    {
      id: 103,
      name: 'Thomas Anderson',
      phone: '+1 (555) 333-4444',
      avatar: '/assets/images/contact3.jpg',
      avatarAlt: 'Casual photo of Caucasian man with brown hair wearing blue denim shirt outdoors',
      status: 'Hey there!'
    },
    {
      id: 104,
      name: 'Maria Garcia',
      phone: '+1 (555) 444-5555',
      avatar: '/assets/images/contact4.jpg',
      avatarAlt: 'Smiling Hispanic woman with curly brown hair in red blouse against white background',
      status: 'At work'
    },
    {
      id: 105,
      name: 'Kevin Wong',
      phone: '+1 (555) 555-6666',
      avatar: '/assets/images/contact5.jpg',
      avatarAlt: 'Professional photo of Asian man with glasses wearing black turtleneck sweater',
      status: 'Available'
    }
  ];

  const availableContacts = contacts?.filter(
    contact => !existingMemberIds?.includes(contact?.id)
  );

  const filteredContacts = availableContacts?.filter(contact =>
    contact?.name?.toLowerCase()?.includes(searchQuery?.toLowerCase()) ||
    contact?.phone?.includes(searchQuery)
  );

  const handleToggleContact = (contactId) => {
    setSelectedContacts(prev =>
      prev?.includes(contactId)
        ? prev?.filter(id => id !== contactId)
        : [...prev, contactId]
    );
  };

  const handleAddMembers = () => {
    const membersToAdd = contacts?.filter(contact =>
      selectedContacts?.includes(contact?.id)
    );
    onAddMembers(membersToAdd);
    setSelectedContacts([]);
    setSearchQuery('');
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-card rounded-xl shadow-xl w-full max-w-2xl max-h-[90vh] flex flex-col">
        <div className="flex items-center justify-between p-4 md:p-6 border-b border-border">
          <h2 className="text-lg md:text-xl font-semibold text-foreground">Add Members</h2>
          <button
            onClick={onClose}
            className="p-2 rounded-lg hover:bg-muted transition-colors focus-ring"
            aria-label="Close modal"
          >
            <Icon name="X" size={24} color="var(--color-foreground)" />
          </button>
        </div>

        <div className="p-4 md:p-6 border-b border-border">
          <Input
            type="search"
            placeholder="Search contacts..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e?.target?.value)}
            className="w-full"
          />
          {selectedContacts?.length > 0 && (
            <div className="mt-3 flex items-center gap-2 text-sm text-muted-foreground">
              <Icon name="Users" size={16} />
              <span>{selectedContacts?.length} selected</span>
            </div>
          )}
        </div>

        <div className="flex-1 overflow-y-auto custom-scrollbar">
          {filteredContacts?.length > 0 ? (
            <div className="divide-y divide-border">
              {filteredContacts?.map((contact) => (
                <div
                  key={contact?.id}
                  className="flex items-center gap-3 p-4 md:p-5 hover:bg-muted/50 transition-colors cursor-pointer"
                  onClick={() => handleToggleContact(contact?.id)}
                >
                  <Checkbox
                    checked={selectedContacts?.includes(contact?.id)}
                    onChange={() => handleToggleContact(contact?.id)}
                  />

                  <div className="w-12 h-12 md:w-14 md:h-14 rounded-full overflow-hidden bg-muted flex-shrink-0">
                    <Image
                      src={contact?.avatar}
                      alt={contact?.avatarAlt}
                      className="w-full h-full object-cover"
                    />
                  </div>

                  <div className="flex-1 min-w-0">
                    <h3 className="text-sm md:text-base font-medium text-foreground truncate">
                      {contact?.name}
                    </h3>
                    <p className="text-xs md:text-sm text-muted-foreground truncate">
                      {contact?.status}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-12 px-4">
              <Icon name="Users" size={48} color="var(--color-muted-foreground)" />
              <p className="mt-4 text-muted-foreground text-center">
                {searchQuery ? 'No contacts found' : 'All contacts are already members'}
              </p>
            </div>
          )}
        </div>

        <div className="p-4 md:p-6 border-t border-border flex flex-col sm:flex-row gap-3">
          <Button
            variant="outline"
            fullWidth
            onClick={onClose}
          >
            Cancel
          </Button>
          <Button
            variant="default"
            fullWidth
            onClick={handleAddMembers}
            disabled={selectedContacts?.length === 0}
            iconName="UserPlus"
            iconPosition="left"
          >
            Add {selectedContacts?.length > 0 ? `${selectedContacts?.length} ` : ''}Members
          </Button>
        </div>
      </div>
    </div>
  );
};

export default AddMemberModal;