import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const MediaGallery = ({ media }) => {
  const [activeFilter, setActiveFilter] = useState('all');

  const filterOptions = [
    { value: 'all', label: 'All', icon: 'Grid3x3' },
    { value: 'photos', label: 'Photos', icon: 'Image' },
    { value: 'videos', label: 'Videos', icon: 'Video' },
    { value: 'documents', label: 'Documents', icon: 'FileText' }
  ];

  const filteredMedia = activeFilter === 'all'
    ? media
    : media?.filter(item => item?.type === activeFilter?.slice(0, -1));

  const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes?.[i];
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now - date);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    if (diffDays === 0) return 'Today';
    if (diffDays === 1) return 'Yesterday';
    if (diffDays < 7) return `${diffDays} days ago`;
    return date?.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  };

  return (
    <div className="bg-card rounded-xl border border-border">
      <div className="p-4 md:p-6 border-b border-border">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg md:text-xl font-semibold text-foreground">
            Media Gallery ({media?.length})
          </h2>
        </div>

        <div className="flex flex-wrap gap-2">
          {filterOptions?.map((option) => (
            <Button
              key={option?.value}
              variant={activeFilter === option?.value ? 'default' : 'outline'}
              size="sm"
              onClick={() => setActiveFilter(option?.value)}
              iconName={option?.icon}
              iconPosition="left"
            >
              {option?.label}
            </Button>
          ))}
        </div>
      </div>
      <div className="p-4 md:p-6">
        {filteredMedia?.length > 0 ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 md:gap-4">
            {filteredMedia?.map((item) => (
              <div
                key={item?.id}
                className="group relative aspect-square rounded-lg overflow-hidden bg-muted cursor-pointer hover:ring-2 hover:ring-primary transition-all"
              >
                {item?.type === 'photo' && (
                  <Image
                    src={item?.url}
                    alt={item?.alt}
                    className="w-full h-full object-cover"
                  />
                )}

                {item?.type === 'video' && (
                  <div className="relative w-full h-full">
                    <Image
                      src={item?.thumbnail}
                      alt={item?.thumbnailAlt}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 flex items-center justify-center bg-black/30">
                      <div className="w-12 h-12 md:w-16 md:h-16 rounded-full bg-white/90 flex items-center justify-center">
                        <Icon name="Play" size={24} color="#000000" />
                      </div>
                    </div>
                    <div className="absolute bottom-2 right-2 px-2 py-1 bg-black/70 text-white text-xs rounded">
                      {item?.duration}
                    </div>
                  </div>
                )}

                {item?.type === 'document' && (
                  <div className="w-full h-full flex flex-col items-center justify-center p-3 md:p-4">
                    <div className="w-12 h-12 md:w-16 md:h-16 rounded-full bg-primary/10 flex items-center justify-center mb-2">
                      <Icon name="FileText" size={24} color="var(--color-primary)" />
                    </div>
                    <p className="text-xs md:text-sm font-medium text-foreground text-center line-clamp-2 mb-1">
                      {item?.name}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {formatFileSize(item?.size)}
                    </p>
                  </div>
                )}

                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition-colors flex items-end p-2 md:p-3">
                  <div className="w-full opacity-0 group-hover:opacity-100 transition-opacity">
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-white truncate flex-1">
                        {formatDate(item?.date)}
                      </span>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="w-8 h-8 bg-white/90 hover:bg-white text-foreground flex-shrink-0"
                        onClick={(e) => {
                          e?.stopPropagation();
                          console.log('Download:', item?.name);
                        }}
                      >
                        <Icon name="Download" size={16} />
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center py-12 px-4">
            <Icon name="Image" size={48} color="var(--color-muted-foreground)" />
            <p className="mt-4 text-muted-foreground text-center">No media found</p>
            <p className="mt-2 text-sm text-muted-foreground text-center">
              Shared photos, videos, and documents will appear here
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default MediaGallery;