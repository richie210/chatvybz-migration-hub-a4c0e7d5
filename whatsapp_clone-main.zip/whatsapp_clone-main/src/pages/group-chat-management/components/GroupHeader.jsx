import React from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const GroupHeader = ({ group, onBack, onEdit, isAdmin }) => {
  return (
    <div className="bg-card border-b border-border">
      <div className="flex items-center gap-3 p-4 md:p-6">
        <Button
          variant="ghost"
          size="icon"
          onClick={onBack}
          className="lg:hidden"
        >
          <Icon name="ArrowLeft" size={24} />
        </Button>

        <div className="relative">
          <div className="w-16 h-16 md:w-20 md:h-20 lg:w-24 lg:h-24 rounded-full overflow-hidden bg-muted">
            <Image
              src={group?.avatar}
              alt={group?.avatarAlt}
              className="w-full h-full object-cover"
            />
          </div>
          {isAdmin && (
            <button
              onClick={onEdit}
              className="absolute bottom-0 right-0 w-8 h-8 md:w-10 md:h-10 rounded-full bg-primary text-primary-foreground flex items-center justify-center shadow-lg hover:bg-primary/90 transition-colors focus-ring"
              aria-label="Edit group photo"
            >
              <Icon name="Camera" size={16} color="currentColor" />
            </button>
          )}
        </div>

        <div className="flex-1 min-w-0">
          <h1 className="text-lg md:text-xl lg:text-2xl font-bold text-foreground truncate">
            {group?.name}
          </h1>
          <p className="text-sm md:text-base text-muted-foreground">
            {group?.memberCount} members
          </p>
          <p className="text-xs md:text-sm text-muted-foreground mt-1">
            Created {group?.createdDate}
          </p>
        </div>

        {isAdmin && (
          <Button
            variant="outline"
            size="icon"
            onClick={onEdit}
            className="hidden md:flex"
          >
            <Icon name="Settings" size={20} />
          </Button>
        )}
      </div>
      {group?.description && (
        <div className="px-4 md:px-6 pb-4 md:pb-6">
          <p className="text-sm md:text-base text-foreground line-clamp-2">
            {group?.description}
          </p>
        </div>
      )}
    </div>
  );
};

export default GroupHeader;