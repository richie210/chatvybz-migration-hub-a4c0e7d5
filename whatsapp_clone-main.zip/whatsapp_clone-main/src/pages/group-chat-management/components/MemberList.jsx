import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';

const MemberList = ({ members, currentUserId, isAdmin, onRemoveMember, onPromoteAdmin, onDemoteAdmin }) => {
  const [searchQuery, setSearchQuery] = useState('');

  const filteredMembers = members?.filter(member =>
    member?.name?.toLowerCase()?.includes(searchQuery?.toLowerCase())
  );

  const handleMemberAction = (memberId, action) => {
    switch (action) {
      case 'remove':
        onRemoveMember(memberId);
        break;
      case 'promote':
        onPromoteAdmin(memberId);
        break;
      case 'demote':
        onDemoteAdmin(memberId);
        break;
      default:
        break;
    }
  };

  return (
    <div className="bg-card rounded-xl border border-border">
      <div className="p-4 md:p-6 border-b border-border">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg md:text-xl font-semibold text-foreground">
            Members ({members?.length})
          </h2>
        </div>
        <Input
          type="search"
          placeholder="Search members..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e?.target?.value)}
          className="w-full"
        />
      </div>
      <div className="divide-y divide-border max-h-96 md:max-h-[500px] lg:max-h-[600px] overflow-y-auto custom-scrollbar">
        {filteredMembers?.map((member) => (
          <div
            key={member?.id}
            className="flex items-center gap-3 p-4 md:p-5 hover:bg-muted/50 transition-colors"
          >
            <div className="relative flex-shrink-0">
              <div className="w-12 h-12 md:w-14 md:h-14 rounded-full overflow-hidden bg-muted">
                <Image
                  src={member?.avatar}
                  alt={member?.avatarAlt}
                  className="w-full h-full object-cover"
                />
              </div>
              {member?.isOnline && (
                <div className="absolute bottom-0 right-0 w-3 h-3 md:w-4 md:h-4 bg-success rounded-full border-2 border-card" />
              )}
            </div>

            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <h3 className="text-sm md:text-base font-medium text-foreground truncate">
                  {member?.name}
                  {member?.id === currentUserId && (
                    <span className="text-xs text-muted-foreground ml-2">(You)</span>
                  )}
                </h3>
                {member?.isAdmin && (
                  <span className="px-2 py-0.5 text-xs font-medium bg-primary/10 text-primary rounded-md flex-shrink-0">
                    Admin
                  </span>
                )}
              </div>
              <p className="text-xs md:text-sm text-muted-foreground truncate mt-0.5">
                {member?.status}
              </p>
            </div>

            {isAdmin && member?.id !== currentUserId && (
              <div className="flex items-center gap-2 flex-shrink-0">
                {!member?.isAdmin ? (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleMemberAction(member?.id, 'promote')}
                    className="hidden md:flex"
                  >
                    <Icon name="ShieldPlus" size={16} className="mr-1" />
                    Make Admin
                  </Button>
                ) : (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleMemberAction(member?.id, 'demote')}
                    className="hidden md:flex"
                  >
                    <Icon name="ShieldMinus" size={16} className="mr-1" />
                    Remove Admin
                  </Button>
                )}
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => handleMemberAction(member?.id, 'remove')}
                  className="text-destructive hover:text-destructive hover:bg-destructive/10"
                >
                  <Icon name="UserMinus" size={18} />
                </Button>
              </div>
            )}
          </div>
        ))}

        {filteredMembers?.length === 0 && (
          <div className="flex flex-col items-center justify-center py-12 px-4">
            <Icon name="Users" size={48} color="var(--color-muted-foreground)" />
            <p className="mt-4 text-muted-foreground text-center">No members found</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default MemberList;