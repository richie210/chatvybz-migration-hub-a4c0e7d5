import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import ChatTabNavigation from '../../components/ui/ChatTabNavigation';
import ProfileSettingsTrigger from '../../components/ui/ProfileSettingsDropdown';
import GroupHeader from './components/GroupHeader';
import MemberList from './components/MemberList';
import GroupSettings from './components/GroupSettings';
import MediaGallery from './components/MediaGallery';
import AddMemberModal from './components/AddMemberModal';
import Button from '../../components/ui/Button';
import Icon from '../../components/AppIcon';

const GroupChatManagement = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('members');
  const [isAddMemberModalOpen, setIsAddMemberModalOpen] = useState(false);

  const currentUserId = 1;

  const [groupData, setGroupData] = useState({
    id: 1,
    name: 'Tech Team',
    description: 'Discussion group for all technical updates, project planning, and team coordination. Share your ideas and collaborate effectively.',
    avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_1feda45ac-1767136399160.png",
    avatarAlt: 'Group of diverse professionals collaborating around laptop in modern office with bright natural lighting',
    memberCount: 12,
    createdDate: 'October 15, 2024',
    createdBy: 'Sarah Johnson'
  });

  const [members, setMembers] = useState([
  {
    id: 1,
    name: 'Sarah Johnson',
    avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_16e75c406-1763294340369.png",
    avatarAlt: 'Professional headshot of Caucasian woman with blonde hair in navy blue blazer',
    status: 'Hey there! I am using ChatVybz',
    isAdmin: true,
    isOnline: true
  },
  {
    id: 2,
    name: 'Michael Chen',
    avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_144541ab0-1763293834444.png",
    avatarAlt: 'Professional portrait of Asian man with short black hair wearing gray suit',
    status: 'Available',
    isAdmin: true,
    isOnline: true
  },
  {
    id: 3,
    name: 'Emma Wilson',
    avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_1f9c90e41-1763300968551.png",
    avatarAlt: 'Casual photo of Caucasian woman with brown hair in white shirt outdoors',
    status: 'Busy',
    isAdmin: false,
    isOnline: false
  },
  {
    id: 4,
    name: 'David Brown',
    avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_1ab13fe30-1763292719033.png",
    avatarAlt: 'Professional headshot of African American man with beard in black suit',
    status: 'At work',
    isAdmin: false,
    isOnline: true
  },
  {
    id: 5,
    name: 'Lisa Anderson',
    avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_1e7da947d-1763300368901.png",
    avatarAlt: 'Smiling Hispanic woman with long dark hair in red blouse',
    status: 'Available for chat',
    isAdmin: false,
    isOnline: true
  },
  {
    id: 6,
    name: 'James Taylor',
    avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_1e893ff19-1763296800030.png",
    avatarAlt: 'Casual portrait of Caucasian man with glasses wearing blue denim shirt',
    status: 'In a meeting',
    isAdmin: false,
    isOnline: false
  },
  {
    id: 7,
    name: 'Maria Garcia',
    avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_1e585f295-1763295781616.png",
    avatarAlt: 'Professional photo of Hispanic woman with curly hair in green blazer',
    status: 'Working remotely',
    isAdmin: false,
    isOnline: true
  },
  {
    id: 8,
    name: 'Robert Martinez',
    avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_14760cf8e-1763296171419.png",
    avatarAlt: 'Headshot of Hispanic man with short hair in navy suit and tie',
    status: 'Available',
    isAdmin: false,
    isOnline: false
  },
  {
    id: 9,
    name: 'Jennifer Lee',
    avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_1e1f6a397-1763294207307.png",
    avatarAlt: 'Professional portrait of Asian woman with long black hair in gray business attire',
    status: 'On vacation',
    isAdmin: false,
    isOnline: false
  },
  {
    id: 10,
    name: 'Thomas Anderson',
    avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_19f3390ab-1763292177504.png",
    avatarAlt: 'Casual photo of Caucasian man with brown hair wearing plaid shirt',
    status: 'Hey there!',
    isAdmin: false,
    isOnline: true
  },
  {
    id: 11,
    name: 'Patricia Moore',
    avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_1b3f638fb-1763300697470.png",
    avatarAlt: 'Professional headshot of African American woman with short hair in purple blouse',
    status: 'Busy with project',
    isAdmin: false,
    isOnline: true
  },
  {
    id: 12,
    name: 'Kevin Wong',
    avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_15be4265d-1763301291596.png",
    avatarAlt: 'Professional photo of Asian man with glasses wearing black turtleneck',
    status: 'Available',
    isAdmin: false,
    isOnline: false
  }]
  );

  const [settings, setSettings] = useState({
    privacy: 'public',
    messagePermission: 'all',
    approveMembers: false,
    linkExpiration: 'never',
    muteNotifications: false,
    showPreview: true
  });

  const mediaData = [
  {
    id: 1,
    type: 'photo',
    url: "https://images.unsplash.com/photo-1666983909435-4e6b014d5be2",
    alt: 'Team collaboration meeting with laptops and documents on wooden table',
    date: '2024-12-21',
    size: 2456789
  },
  {
    id: 2,
    type: 'video',
    url: 'https://example.com/video1.mp4',
    thumbnail: "https://images.unsplash.com/photo-1586543354240-2187898bb2e8",
    thumbnailAlt: 'Video conference call with multiple participants on laptop screen',
    duration: '5:23',
    date: '2024-12-20',
    size: 15678901
  },
  {
    id: 3,
    type: 'photo',
    url: "https://img.rocket.new/generatedImages/rocket_gen_img_1abdc0f87-1767521790771.png",
    alt: 'Business presentation with charts and graphs on large screen in conference room',
    date: '2024-12-19',
    size: 3234567
  },
  {
    id: 4,
    type: 'document',
    name: 'Project_Proposal_2024.pdf',
    url: 'https://example.com/doc1.pdf',
    date: '2024-12-18',
    size: 1234567
  },
  {
    id: 5,
    type: 'photo',
    url: "https://img.rocket.new/generatedImages/rocket_gen_img_1fc4d0199-1767647317910.png",
    alt: 'Team brainstorming session with sticky notes on glass wall in modern office',
    date: '2024-12-17',
    size: 2789012
  },
  {
    id: 6,
    type: 'video',
    url: 'https://example.com/video2.mp4',
    thumbnail: "https://images.unsplash.com/photo-1730993961353-1e166ed6b12b",
    thumbnailAlt: 'Product demo presentation with speaker gesturing towards screen',
    duration: '12:45',
    date: '2024-12-16',
    size: 28901234
  },
  {
    id: 7,
    type: 'document',
    name: 'Meeting_Notes_Dec.docx',
    url: 'https://example.com/doc2.docx',
    date: '2024-12-15',
    size: 456789
  },
  {
    id: 8,
    type: 'photo',
    url: "https://img.rocket.new/generatedImages/rocket_gen_img_18c2f2e9f-1766999716632.png",
    alt: 'Team celebration with colleagues raising hands in success gesture',
    date: '2024-12-14',
    size: 3456789
  }];


  const tabs = [
  { id: 'members', label: 'Members', icon: 'Users' },
  { id: 'media', label: 'Media', icon: 'Image' },
  { id: 'settings', label: 'Settings', icon: 'Settings' }];


  const isAdmin = members?.find((m) => m?.id === currentUserId)?.isAdmin || false;

  const handleBack = () => {
    navigate('/main-chat-interface');
  };

  const handleEditGroup = () => {
    console.log('Edit group details');
  };

  const handleRemoveMember = (memberId) => {
    setMembers((prev) => prev?.filter((m) => m?.id !== memberId));
    setGroupData((prev) => ({ ...prev, memberCount: prev?.memberCount - 1 }));
  };

  const handlePromoteAdmin = (memberId) => {
    setMembers((prev) =>
    prev?.map((m) => m?.id === memberId ? { ...m, isAdmin: true } : m)
    );
  };

  const handleDemoteAdmin = (memberId) => {
    setMembers((prev) =>
    prev?.map((m) => m?.id === memberId ? { ...m, isAdmin: false } : m)
    );
  };

  const handleUpdateSettings = (newSettings) => {
    setSettings(newSettings);
  };

  const handleAddMembers = (newMembers) => {
    const membersToAdd = newMembers?.map((contact) => ({
      id: contact?.id,
      name: contact?.name,
      avatar: contact?.avatar,
      avatarAlt: contact?.avatarAlt,
      status: contact?.status,
      isAdmin: false,
      isOnline: true
    }));
    setMembers((prev) => [...prev, ...membersToAdd]);
    setGroupData((prev) => ({ ...prev, memberCount: prev?.memberCount + membersToAdd?.length }));
  };

  return (
    <>
      <Helmet>
        <title>Group Chat Management - ChatVybz</title>
        <meta name="description" content="Manage your group chat settings, members, and shared media in ChatVybz" />
      </Helmet>
      <div className="min-h-screen bg-background">
        <ChatTabNavigation />

        <div className="lg:ml-80 min-h-screen">
          <header className="sticky top-0 z-40 bg-card border-b border-border">
            <div className="flex items-center justify-between px-4 md:px-6 lg:px-8 py-3 md:py-4">
              <div className="flex items-center gap-3">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={handleBack}
                  className="lg:hidden">

                  <Icon name="ArrowLeft" size={24} />
                </Button>
                <h1 className="text-xl md:text-2xl font-bold text-foreground">Group Management</h1>
              </div>
              <ProfileSettingsTrigger />
            </div>
          </header>

          <main className="p-4 md:p-6 lg:p-8 pb-20 lg:pb-8">
            <div className="max-w-7xl mx-auto space-y-6 md:space-y-8">
              <GroupHeader
                group={groupData}
                onBack={handleBack}
                onEdit={handleEditGroup}
                isAdmin={isAdmin} />


              <div className="flex flex-wrap gap-2 md:gap-3 bg-card p-3 md:p-4 rounded-xl border border-border">
                {tabs?.map((tab) =>
                <Button
                  key={tab?.id}
                  variant={activeTab === tab?.id ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setActiveTab(tab?.id)}
                  iconName={tab?.icon}
                  iconPosition="left"
                  className="flex-1 sm:flex-none">

                    {tab?.label}
                  </Button>
                )}
              </div>

              {activeTab === 'members' &&
              <div className="space-y-4 md:space-y-6">
                  {isAdmin &&
                <Button
                  variant="default"
                  fullWidth
                  iconName="UserPlus"
                  iconPosition="left"
                  onClick={() => setIsAddMemberModalOpen(true)}>

                      Add Members
                    </Button>
                }
                  <MemberList
                  members={members}
                  currentUserId={currentUserId}
                  isAdmin={isAdmin}
                  onRemoveMember={handleRemoveMember}
                  onPromoteAdmin={handlePromoteAdmin}
                  onDemoteAdmin={handleDemoteAdmin} />

                </div>
              }

              {activeTab === 'media' && <MediaGallery media={mediaData} />}

              {activeTab === 'settings' &&
              <GroupSettings
                settings={settings}
                isAdmin={isAdmin}
                onUpdateSettings={handleUpdateSettings} />

              }
            </div>
          </main>
        </div>

        <AddMemberModal
          isOpen={isAddMemberModalOpen}
          onClose={() => setIsAddMemberModalOpen(false)}
          onAddMembers={handleAddMembers}
          existingMemberIds={members?.map((m) => m?.id)} />

      </div>
    </>);

};

export default GroupChatManagement;