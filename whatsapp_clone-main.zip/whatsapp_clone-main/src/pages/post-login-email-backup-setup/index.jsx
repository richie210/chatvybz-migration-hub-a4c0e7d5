import React, { useState, useRef } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../contexts/AuthContext';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';
import Icon from '../../components/AppIcon';

const PostLoginEmailBackupSetup = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useAuth();
  
  const [step, setStep] = useState('email'); // 'email' or 'verification'
  const [email, setEmail] = useState('');
  const [verificationCode, setVerificationCode] = useState(['', '', '', '', '', '']);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const inputRefs = React.useRef([]);

  // Handle email submission
  const handleSubmitEmail = async (e) => {
    e?.preventDefault();
    setIsLoading(true);
    setError('');
    setSuccess('');

    try {
      // Validate email format
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex?.test(email)) {
        throw new Error('Please enter a valid email address');
      }

      // Send verification email
      const { error: sendError } = await supabase?.auth?.updateUser({
        email: email,
      });

      if (sendError) throw sendError;

      setSuccess('Verification code sent to your email!');
      setStep('verification');
    } catch (err) {
      setError(err?.message || 'Failed to send verification email');
    } finally {
      setIsLoading(false);
    }
  };

  // Handle verification code input
  const handleCodeChange = (index, value) => {
    if (!/^\d*$/?.test(value)) return;

    const newCode = [...verificationCode];
    newCode[index] = value?.slice(-1);
    setVerificationCode(newCode);
    setError('');

    // Auto-focus next input
    if (value && index < 5) {
      inputRefs?.current?.[index + 1]?.focus();
    }

    // Auto-verify when all digits entered
    if (newCode?.every(digit => digit !== '') && value) {
      handleVerifyCode(newCode?.join(''));
    }
  };

  // Handle verification
  const handleVerifyCode = async (code) => {
    const finalCode = code || verificationCode?.join('');
    
    if (finalCode?.length !== 6) {
      setError('Please enter all 6 digits');
      return;
    }

    setIsLoading(true);
    setError('');

    try {
      // Verify email with code
      const { error: verifyError } = await supabase?.auth?.verifyOtp({
        email: email,
        token: finalCode,
        type: 'email'
      });

      if (verifyError) throw verifyError;

      setSuccess('Email verified successfully!');
      
      // Navigate to main chat after 1.5 seconds
      setTimeout(() => {
        navigate('/main-chat-interface');
      }, 1500);
    } catch (err) {
      setError(err?.message || 'Invalid verification code');
      setVerificationCode(['', '', '', '', '', '']);
      inputRefs?.current?.[0]?.focus();
    } finally {
      setIsLoading(false);
    }
  };

  // Handle skip
  const handleSkip = () => {
    navigate('/main-chat-interface');
  };

  // Handle paste
  const handlePaste = (e) => {
    e?.preventDefault();
    const pastedData = e?.clipboardData?.getData('text')?.trim()?.slice(0, 6);
    
    if (!/^\d+$/?.test(pastedData)) return;

    const digits = pastedData?.split('');
    const newCode = [...digits, ...Array(6 - digits?.length)?.fill('')]?.slice(0, 6);
    setVerificationCode(newCode);
    
    const nextFocusIndex = Math.min(digits?.length, 5);
    inputRefs?.current?.[nextFocusIndex]?.focus();

    if (digits?.length === 6) {
      handleVerifyCode(newCode?.join(''));
    }
  };

  return (
    <>
      <Helmet>
        <title>Email Backup Setup - ChatVybz</title>
        <meta
          name="description"
          content="Add an email address for account backup and recovery"
        />
      </Helmet>

      <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-green-50 flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="w-20 h-20 mx-auto bg-white rounded-full flex items-center justify-center mb-4 shadow-lg">
              <Icon name="Mail" size={40} color="#22B48A" />
            </div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">
              Email Backup Setup
            </h1>
            <p className="text-gray-600">
              {step === 'email' ?'Add an email for account recovery and backup' :'Verify your email address'
              }
            </p>
          </div>

          {/* Main Card */}
          <div className="bg-white rounded-2xl shadow-xl p-6 md:p-8">
            {error && (
              <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-start gap-3">
                <Icon name="AlertCircle" size={20} className="text-red-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm font-semibold text-red-800">Error</p>
                  <p className="text-sm text-red-600">{error}</p>
                </div>
              </div>
            )}

            {success && (
              <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg flex items-start gap-3">
                <Icon name="CheckCircle" size={20} className="text-green-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm font-semibold text-green-800">Success</p>
                  <p className="text-sm text-green-600">{success}</p>
                </div>
              </div>
            )}

            {step === 'email' ? (
              <form onSubmit={handleSubmitEmail} className="space-y-6">
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                    Email Address
                  </label>
                  <Input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e?.target?.value)}
                    placeholder="your.email@example.com"
                    disabled={isLoading}
                    required
                  />
                  <p className="mt-2 text-xs text-gray-500">
                    We'll send a verification code to this email
                  </p>
                </div>

                <Button
                  type="submit"
                  disabled={isLoading || !email}
                  loading={isLoading}
                  fullWidth
                >
                  Continue
                </Button>

                <button
                  type="button"
                  onClick={handleSkip}
                  className="w-full text-sm text-gray-600 hover:text-gray-900 transition-colors"
                >
                  Skip for now
                </button>
              </form>
            ) : (
              <div className="space-y-6">
                <div className="text-center space-y-2">
                  <p className="text-sm text-gray-600">
                    We've sent a 6-digit code to
                    <br />
                    <span className="font-medium text-gray-900">{email}</span>
                  </p>
                </div>

                <div className="flex justify-center gap-2 md:gap-3">
                  {verificationCode?.map((digit, index) => (
                    <input
                      key={index}
                      ref={(el) => (inputRefs.current[index] = el)}
                      type="text"
                      inputMode="numeric"
                      pattern="[0-9]*"
                      maxLength={1}
                      value={digit}
                      onChange={(e) => handleCodeChange(index, e?.target?.value)}
                      onPaste={handlePaste}
                      disabled={isLoading}
                      className={`w-10 h-12 md:w-12 md:h-14 text-center text-lg md:text-xl font-semibold bg-white border-2 rounded-lg transition-all focus:outline-none focus:ring-2 focus:ring-green-500 ${
                        error
                          ? 'border-red-500'
                          : digit
                          ? 'border-green-500' :'border-gray-300'
                      } ${isLoading ? 'opacity-50 cursor-not-allowed' : ''}`}
                    />
                  ))}
                </div>

                <Button
                  type="button"
                  onClick={() => handleVerifyCode()}
                  disabled={verificationCode?.some(digit => digit === '') || isLoading}
                  loading={isLoading}
                  fullWidth
                >
                  Verify Email
                </Button>

                <button
                  type="button"
                  onClick={handleSkip}
                  className="w-full text-sm text-gray-600 hover:text-gray-900 transition-colors"
                >
                  Skip for now
                </button>
              </div>
            )}
          </div>

          {/* Info Box */}
          <div className="mt-6 bg-blue-50 border border-blue-200 rounded-lg p-4">
            <div className="flex items-start gap-3">
              <Icon name="Shield" size={20} className="text-blue-600 flex-shrink-0 mt-0.5" />
              <div>
                <h4 className="text-sm font-semibold text-blue-900 mb-1">
                  Why Add Email?
                </h4>
                <ul className="space-y-1 text-xs text-blue-700">
                  <li className="flex items-start gap-2">
                    <span className="text-blue-500 mt-0.5">•</span>
                    <span>Account recovery if you lose your phone</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-blue-500 mt-0.5">•</span>
                    <span>Encrypted backup notifications</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-blue-500 mt-0.5">•</span>
                    <span>Security alerts for new device logins</span>
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="text-blue-500 mt-0.5">•</span>
                    <span>Your phone number remains your primary identifier</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default PostLoginEmailBackupSetup;