import React from 'react';
import Icon from '../../../components/AppIcon';

const EmailBackupBenefits = () => {
  const benefits = [
    {
      icon: 'Shield',
      title: 'Account Recovery',
      description: 'Recover your account if you lose access to your phone number'
    },
    {
      icon: 'Cloud',
      title: 'Encrypted Backups',
      description: 'Receive notifications when your encrypted chat backups are uploaded'
    },
    {
      icon: 'Bell',
      title: 'Security Alerts',
      description: 'Get notified of new device logins and unusual activity'
    },
    {
      icon: 'Smartphone',
      title: 'Cross-Device Sync',
      description: 'Seamlessly sync your messages across multiple devices'
    }
  ];

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-gray-900 mb-4">
        Benefits of Adding Email
      </h3>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {benefits?.map((benefit, index) => (
          <div
            key={index}
            className="p-4 bg-gray-50 rounded-lg border border-gray-200 hover:border-green-500 transition-colors"
          >
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                <Icon name={benefit?.icon} size={20} color="#22B48A" />
              </div>
              <div>
                <h4 className="text-sm font-semibold text-gray-900 mb-1">
                  {benefit?.title}
                </h4>
                <p className="text-xs text-gray-600">
                  {benefit?.description}
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-6 p-4 bg-green-50 border border-green-200 rounded-lg">
        <div className="flex items-start gap-3">
          <Icon name="Lock" size={20} className="text-green-600 flex-shrink-0 mt-0.5" />
          <div>
            <h4 className="text-sm font-semibold text-green-900 mb-1">
              Privacy First
            </h4>
            <p className="text-xs text-green-700">
              Your phone number remains your primary identifier. Email is only used for backup and recovery purposes. All backups are end-to-end encrypted.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EmailBackupBenefits;