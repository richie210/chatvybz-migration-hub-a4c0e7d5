import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { Shield, AlertTriangle, Ban, CheckCircle, Eye, Filter, Loader2, AlertCircle, TrendingUp } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { contentModerationService } from '../../services/contentModerationService';
import { adminAnalyticsService } from '../../services/adminAnalyticsService';
import Button from '../../components/ui/Button';


export default function AIContentModerationCenter() {
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();

  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [flaggedContent, setFlaggedContent] = useState([]);
  const [stats, setStats] = useState(null);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [error, setError] = useState('');

  // Filters
  const [filterStatus, setFilterStatus] = useState('pending');
  const [filterViolationType, setFilterViolationType] = useState('');
  const [filterSeverity, setFilterSeverity] = useState('');
  const [showFilters, setShowFilters] = useState(false);

  // Selected items for bulk actions
  const [selectedItems, setSelectedItems] = useState(new Set());

  // Review modal
  const [showReviewModal, setShowReviewModal] = useState(false);
  const [reviewTarget, setReviewTarget] = useState(null);
  const [reviewAction, setReviewAction] = useState('approve');
  const [adminNotes, setAdminNotes] = useState('');

  useEffect(() => {
    if (!authLoading && !user) {
      navigate('/login');
    }
  }, [user, authLoading, navigate]);

  useEffect(() => {
    if (!authLoading && user) {
      checkAdminAndLoadData();
    }
  }, [authLoading, user, page, filterStatus, filterViolationType, filterSeverity]);

  const checkAdminAndLoadData = async () => {
    try {
      setLoading(true);
      setError('');

      const adminStatus = await adminAnalyticsService?.isAdmin();
      setIsAdmin(adminStatus);

      if (!adminStatus) {
        setError('Access denied. Admin privileges required.');
        setLoading(false);
        return;
      }

      await loadModerationData();
    } catch (err) {
      console.error('Error checking admin status:', err);
      setError(err?.message || 'Failed to load moderation center');
    } finally {
      setLoading(false);
    }
  };

  const loadModerationData = async () => {
    try {
      const [contentResult, statsResult] = await Promise.all([
        contentModerationService?.getFlaggedContent({
          page,
          limit: 20,
          status: filterStatus || undefined,
          violationType: filterViolationType || undefined,
          severity: filterSeverity || undefined
        }),
        contentModerationService?.getModerationStats()
      ]);

      if (contentResult?.error) throw contentResult?.error;
      if (statsResult?.error) throw statsResult?.error;

      setFlaggedContent(contentResult?.data || []);
      setTotalPages(contentResult?.totalPages || 1);
      setStats(statsResult?.data);
    } catch (err) {
      console.error('Error loading moderation data:', err);
      setError(err?.message || 'Failed to load moderation data');
    }
  };

  const openReviewModal = (item) => {
    setReviewTarget(item);
    setReviewAction('approve');
    setAdminNotes('');
    setShowReviewModal(true);
  };

  const executeReview = async () => {
    if (!reviewTarget) return;

    try {
      const result = await contentModerationService?.reviewFlaggedContent(
        reviewTarget?.id,
        reviewAction,
        adminNotes
      );

      if (result?.error) throw result?.error;

      alert(`Content ${reviewAction} successfully`);
      setShowReviewModal(false);
      await loadModerationData();
    } catch (err) {
      console.error('Error reviewing content:', err);
      alert(err?.message || 'Failed to review content');
    }
  };

  const handleBulkReview = async (action) => {
    if (selectedItems?.size === 0) {
      alert('Please select items to review');
      return;
    }

    const confirmed = confirm(`Are you sure you want to ${action} ${selectedItems?.size} items?`);
    if (!confirmed) return;

    try {
      const result = await contentModerationService?.bulkReview(
        Array.from(selectedItems),
        action,
        'Bulk action'
      );

      if (result?.error) throw result?.error;

      alert(`Bulk ${action} completed: ${result?.data?.successful} successful, ${result?.data?.failed} failed`);
      setSelectedItems(new Set());
      await loadModerationData();
    } catch (err) {
      console.error('Error bulk reviewing:', err);
      alert(err?.message || 'Failed to bulk review');
    }
  };

  const toggleSelectItem = (id) => {
    const newSelected = new Set(selectedItems);
    if (newSelected?.has(id)) {
      newSelected?.delete(id);
    } else {
      newSelected?.add(id);
    }
    setSelectedItems(newSelected);
  };

  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'critical': return 'bg-red-100 text-red-700 border-red-300';
      case 'high': return 'bg-orange-100 text-orange-700 border-orange-300';
      case 'medium': return 'bg-yellow-100 text-yellow-700 border-yellow-300';
      case 'low': return 'bg-blue-100 text-blue-700 border-blue-300';
      default: return 'bg-gray-100 text-gray-700 border-gray-300';
    }
  };

  const getViolationIcon = (type) => {
    switch (type) {
      case 'spam': return '📧';
      case 'harassment': return '⚠️';
      case 'tos_violation': return '🚫';
      default: return '❓';
    }
  };

  if (authLoading || loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  if (error && !isAdmin) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-lg shadow-lg p-6 max-w-md w-full">
          <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <p className="text-center text-gray-700">{error}</p>
          <Button onClick={() => navigate('/chat-vybz-admin-dashboard')} className="w-full mt-4">
            Go to Admin Dashboard
          </Button>
        </div>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>AI Content Moderation Center | ChatVybz Admin</title>
      </Helmet>
      <div className="min-h-screen bg-gray-50 pb-20">
        {/* Header */}
        <div className="bg-white border-b border-gray-200 sticky top-0 z-10">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
                  <Shield className="w-7 h-7 text-blue-600" />
                  AI Content Moderation Center
                </h1>
                <p className="text-sm text-gray-600 mt-1">Powered by Anthropic Claude</p>
              </div>
              <Button onClick={() => navigate('/chat-vybz-admin-dashboard')} variant="outline">
                Back to Dashboard
              </Button>
            </div>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          {/* Statistics Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            <div className="bg-white rounded-lg shadow-sm p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Total Flagged</p>
                  <p className="text-2xl font-bold text-gray-900">{stats?.totalFlagged || 0}</p>
                </div>
                <AlertTriangle className="w-8 h-8 text-orange-500" />
              </div>
            </div>
            <div className="bg-white rounded-lg shadow-sm p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Pending Review</p>
                  <p className="text-2xl font-bold text-yellow-600">{stats?.pendingReview || 0}</p>
                </div>
                <Eye className="w-8 h-8 text-yellow-500" />
              </div>
            </div>
            <div className="bg-white rounded-lg shadow-sm p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Recent Flags (7d)</p>
                  <p className="text-2xl font-bold text-blue-600">{stats?.recentFlags || 0}</p>
                </div>
                <TrendingUp className="w-8 h-8 text-blue-500" />
              </div>
            </div>
            <div className="bg-white rounded-lg shadow-sm p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-gray-600">Spam Detected</p>
                  <p className="text-2xl font-bold text-red-600">{stats?.byViolationType?.spam || 0}</p>
                </div>
                <Ban className="w-8 h-8 text-red-500" />
              </div>
            </div>
          </div>

          {/* Filters */}
          <div className="bg-white rounded-lg shadow-sm p-4 mb-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-gray-900">Moderation Queue</h2>
              <Button onClick={() => setShowFilters(!showFilters)} variant="outline" size="sm">
                <Filter className="w-4 h-4 mr-2" />
                Filters
              </Button>
            </div>
            {showFilters && (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
                  <select
                    value={filterStatus}
                    onChange={(e) => setFilterStatus(e?.target?.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                  >
                    <option value="">All</option>
                    <option value="pending">Pending</option>
                    <option value="approved">Approved</option>
                    <option value="removed">Removed</option>
                    <option value="reviewed">Reviewed</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Violation Type</label>
                  <select
                    value={filterViolationType}
                    onChange={(e) => setFilterViolationType(e?.target?.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                  >
                    <option value="">All</option>
                    <option value="spam">Spam</option>
                    <option value="harassment">Harassment</option>
                    <option value="tos_violation">ToS Violation</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Severity</label>
                  <select
                    value={filterSeverity}
                    onChange={(e) => setFilterSeverity(e?.target?.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                  >
                    <option value="">All</option>
                    <option value="critical">Critical</option>
                    <option value="high">High</option>
                    <option value="medium">Medium</option>
                    <option value="low">Low</option>
                  </select>
                </div>
              </div>
            )}
          </div>

          {/* Bulk Actions */}
          {selectedItems?.size > 0 && (
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
              <div className="flex items-center justify-between">
                <p className="text-sm text-blue-900">{selectedItems?.size} items selected</p>
                <div className="flex gap-2">
                  <Button onClick={() => handleBulkReview('approve')} size="sm" variant="outline">
                    Approve All
                  </Button>
                  <Button onClick={() => handleBulkReview('remove')} size="sm" variant="outline">
                    Remove All
                  </Button>
                </div>
              </div>
            </div>
          )}

          {/* Flagged Content List */}
          <div className="space-y-4">
            {flaggedContent?.map((item) => (
              <div key={item?.id} className="bg-white rounded-lg shadow-sm p-6 border-l-4 border-orange-500">
                <div className="flex items-start gap-4">
                  <input
                    type="checkbox"
                    checked={selectedItems?.has(item?.id)}
                    onChange={() => toggleSelectItem(item?.id)}
                    className="mt-1"
                  />
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-2xl">{getViolationIcon(item?.violation_type)}</span>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium border ${getSeverityColor(item?.severity)}`}>
                        {item?.severity?.toUpperCase()}
                      </span>
                      <span className="px-2 py-1 rounded-full text-xs font-medium bg-gray-100 text-gray-700">
                        {item?.violation_type?.replace('_', ' ')?.toUpperCase()}
                      </span>
                      <span className="text-xs text-gray-500">
                        Confidence: {(item?.ai_confidence * 100)?.toFixed(0)}%
                      </span>
                    </div>
                    <div className="mb-3">
                      <p className="text-sm text-gray-600 mb-1">Flagged Content:</p>
                      <p className="text-gray-900 bg-gray-50 p-3 rounded border border-gray-200">{item?.content}</p>
                    </div>
                    <div className="mb-3">
                      <p className="text-sm text-gray-600 mb-1">AI Reasoning:</p>
                      <p className="text-sm text-gray-700">{item?.ai_reasoning}</p>
                    </div>
                    <div className="flex items-center gap-4 text-sm text-gray-600">
                      <span>Author: {item?.author?.full_name || item?.author?.email || 'Unknown'}</span>
                      <span>•</span>
                      <span>Type: {item?.content_type}</span>
                      <span>•</span>
                      <span>Flagged: {new Date(item?.flagged_at)?.toLocaleString()}</span>
                    </div>
                    <div className="mt-3">
                      <p className="text-sm font-medium text-blue-600">Recommended Action: {item?.recommended_action?.replace('_', ' ')?.toUpperCase()}</p>
                    </div>
                  </div>
                  <div className="flex flex-col gap-2">
                    <Button onClick={() => openReviewModal(item)} size="sm">
                      <Eye className="w-4 h-4 mr-1" />
                      Review
                    </Button>
                  </div>
                </div>
              </div>
            ))}
            {flaggedContent?.length === 0 && (
              <div className="bg-white rounded-lg shadow-sm p-12 text-center">
                <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
                <p className="text-gray-600">No flagged content to review</p>
              </div>
            )}
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex justify-center gap-2 mt-6">
              <Button
                onClick={() => setPage(p => Math.max(1, p - 1))}
                disabled={page === 1}
                variant="outline"
              >
                Previous
              </Button>
              <span className="px-4 py-2 text-gray-700">
                Page {page} of {totalPages}
              </span>
              <Button
                onClick={() => setPage(p => Math.min(totalPages, p + 1))}
                disabled={page === totalPages}
                variant="outline"
              >
                Next
              </Button>
            </div>
          )}
        </div>
      </div>
      {/* Review Modal */}
      {showReviewModal && reviewTarget && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <h2 className="text-xl font-bold text-gray-900 mb-4">Review Flagged Content</h2>
              <div className="mb-4">
                <p className="text-sm text-gray-600 mb-2">Content:</p>
                <p className="text-gray-900 bg-gray-50 p-3 rounded border border-gray-200">{reviewTarget?.content}</p>
              </div>
              <div className="mb-4">
                <p className="text-sm text-gray-600 mb-2">AI Analysis:</p>
                <p className="text-sm text-gray-700">{reviewTarget?.ai_reasoning}</p>
              </div>
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-700 mb-2">Action</label>
                <select
                  value={reviewAction}
                  onChange={(e) => setReviewAction(e?.target?.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                >
                  <option value="approve">Approve (No violation)</option>
                  <option value="remove">Remove Content</option>
                  <option value="ban_user">Remove & Ban User</option>
                </select>
              </div>
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">Admin Notes</label>
                <textarea
                  value={adminNotes}
                  onChange={(e) => setAdminNotes(e?.target?.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                  rows={3}
                  placeholder="Add notes about your decision..."
                />
              </div>
              <div className="flex gap-3">
                <Button onClick={executeReview} className="flex-1">
                  Confirm {reviewAction?.replace('_', ' ')?.toUpperCase()}
                </Button>
                <Button onClick={() => setShowReviewModal(false)} variant="outline" className="flex-1">
                  Cancel
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
