import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { X, ChevronLeft, ChevronRight, Pause, Play, Heart, Send } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { markStatusAsViewed } from '../../services/statusService';


export default function StatusStoriesViewerInterface() {
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useAuth();
  const [currentStoryIndex, setCurrentStoryIndex] = useState(0);
  const [progress, setProgress] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [showReplyInput, setShowReplyInput] = useState(false);
  const [replyText, setReplyText] = useState('');
  const progressInterval = useRef(null);
  const videoRef = useRef(null);

  // Get status data from navigation state
  const statusGroup = location?.state?.statusGroup;
  const currentStory = statusGroup?.statuses?.[currentStoryIndex];
  const isMyStatus = statusGroup?.user?.id === user?.id;

  useEffect(() => {
    if (!statusGroup) {
      navigate('/status');
      return;
    }

    // Mark status as viewed
    if (!isMyStatus && currentStory) {
      markStatusAsViewed(currentStory?.id);
    }
  }, [statusGroup, currentStory, isMyStatus, navigate]);

  // Progress bar animation
  useEffect(() => {
    if (isPaused || !currentStory) return;

    const duration = currentStory?.media_type === 'video' ? 15000 : 5000; // 15s for video, 5s for image
    const increment = 100 / (duration / 50);

    progressInterval.current = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          handleNext();
          return 0;
        }
        return prev + increment;
      });
    }, 50);

    return () => {
      if (progressInterval?.current) {
        clearInterval(progressInterval?.current);
      }
    };
  }, [currentStoryIndex, isPaused, currentStory]);

  // Keyboard navigation
  useEffect(() => {
    const handleKeyPress = (e) => {
      if (e?.key === 'ArrowLeft') handlePrevious();
      if (e?.key === 'ArrowRight') handleNext();
      if (e?.key === 'Escape') handleClose();
      if (e?.key === ' ') {
        e?.preventDefault();
        togglePause();
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [currentStoryIndex]);

  const handleNext = () => {
    if (currentStoryIndex < statusGroup?.statuses?.length - 1) {
      setCurrentStoryIndex(currentStoryIndex + 1);
      setProgress(0);
    } else {
      handleClose();
    }
  };

  const handlePrevious = () => {
    if (currentStoryIndex > 0) {
      setCurrentStoryIndex(currentStoryIndex - 1);
      setProgress(0);
    }
  };

  const togglePause = () => {
    setIsPaused(!isPaused);
    if (videoRef?.current) {
      if (isPaused) {
        videoRef?.current?.play();
      } else {
        videoRef?.current?.pause();
      }
    }
  };

  const handleClose = () => {
    navigate('/status');
  };

  const handleReply = async () => {
    if (!replyText?.trim()) return;

    try {
      // TODO: Implement reply functionality
      console.log('Reply:', replyText);
      setReplyText('');
      setShowReplyInput(false);
    } catch (error) {
      console.error('Error sending reply:', error);
    }
  };

  const getTimeRemaining = (expiresAt) => {
    const now = new Date();
    const expiry = new Date(expiresAt);
    const diffMs = expiry - now;
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffMinutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));

    if (diffHours > 0) return `${diffHours}h`;
    if (diffMinutes > 0) return `${diffMinutes}m`;
    return '<1m';
  };

  if (!statusGroup || !currentStory) {
    return null;
  }

  return (
    <div className="fixed inset-0 bg-black z-50 flex items-center justify-center">
      {/* Progress Bars */}
      <div className="absolute top-0 left-0 right-0 z-20 flex gap-1 p-2">
        {statusGroup?.statuses?.map((_, index) => (
          <div key={index} className="flex-1 h-1 bg-white/30 rounded-full overflow-hidden">
            <div
              className="h-full bg-white transition-all duration-100"
              style={{
                width: index === currentStoryIndex ? `${progress}%` : index < currentStoryIndex ? '100%' : '0%'
              }}
            />
          </div>
        ))}
      </div>
      {/* Header */}
      <div className="absolute top-4 left-0 right-0 z-20 px-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-full border-2 border-white overflow-hidden">
            <img
              src={statusGroup?.user?.avatar_url || '/assets/images/no_image.png'}
              alt={statusGroup?.user?.full_name || 'User'}
              className="w-full h-full object-cover"
            />
          </div>
          <div className="text-white">
            <p className="font-semibold text-sm">{statusGroup?.user?.full_name || statusGroup?.user?.username || 'Unknown'}</p>
            <p className="text-xs opacity-80">{getTimeRemaining(currentStory?.expires_at)} remaining</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={togglePause}
            className="p-2 rounded-full hover:bg-white/20 transition-colors"
            aria-label={isPaused ? 'Play' : 'Pause'}
          >
            {isPaused ? (
              <Play className="w-5 h-5 text-white" />
            ) : (
              <Pause className="w-5 h-5 text-white" />
            )}
          </button>
          <button
            onClick={handleClose}
            className="p-2 rounded-full hover:bg-white/20 transition-colors"
            aria-label="Close"
          >
            <X className="w-6 h-6 text-white" />
          </button>
        </div>
      </div>
      {/* Navigation Areas */}
      <div className="absolute inset-0 z-10 flex">
        {/* Previous area (left third) */}
        <div
          className="flex-1 cursor-pointer"
          onClick={handlePrevious}
          aria-label="Previous story"
        />
        
        {/* Pause area (middle third) */}
        <div
          className="flex-1 cursor-pointer"
          onClick={togglePause}
          aria-label="Pause/Play"
        />
        
        {/* Next area (right third) */}
        <div
          className="flex-1 cursor-pointer"
          onClick={handleNext}
          aria-label="Next story"
        />
      </div>
      {/* Story Content */}
      <div className="relative w-full h-full flex items-center justify-center">
        {currentStory?.media_type === 'video' ? (
          <video
            ref={videoRef}
            src={currentStory?.media_url}
            className="max-w-full max-h-full object-contain"
            autoPlay
            muted
            playsInline
            onEnded={handleNext}
          />
        ) : (
          <img
            src={currentStory?.media_url}
            alt="Story"
            className="max-w-full max-h-full object-contain"
          />
        )}

        {/* Caption */}
        {currentStory?.decrypted_caption && (
          <div className="absolute bottom-20 left-0 right-0 px-6 z-20">
            <p className="text-white text-center text-sm bg-black/50 rounded-lg px-4 py-2">
              {currentStory?.decrypted_caption}
            </p>
          </div>
        )}
      </div>
      {/* Navigation Arrows (Desktop) */}
      <div className="hidden md:block">
        {currentStoryIndex > 0 && (
          <button
            onClick={handlePrevious}
            className="absolute left-4 top-1/2 -translate-y-1/2 z-20 p-3 rounded-full bg-black/50 hover:bg-black/70 transition-colors"
            aria-label="Previous story"
          >
            <ChevronLeft className="w-6 h-6 text-white" />
          </button>
        )}

        {currentStoryIndex < statusGroup?.statuses?.length - 1 && (
          <button
            onClick={handleNext}
            className="absolute right-4 top-1/2 -translate-y-1/2 z-20 p-3 rounded-full bg-black/50 hover:bg-black/70 transition-colors"
            aria-label="Next story"
          >
            <ChevronRight className="w-6 h-6 text-white" />
          </button>
        )}
      </div>
      {/* Engagement Controls (Bottom) */}
      {!isMyStatus && (
        <div className="absolute bottom-0 left-0 right-0 z-20 p-4 bg-gradient-to-t from-black/80 to-transparent">
          {showReplyInput ? (
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={replyText}
                onChange={(e) => setReplyText(e?.target?.value)}
                placeholder="Reply to story..."
                className="flex-1 bg-white/20 text-white placeholder-white/60 rounded-full px-4 py-2 focus:outline-none focus:ring-2 focus:ring-white/50"
                autoFocus
                onKeyPress={(e) => e?.key === 'Enter' && handleReply()}
              />
              <button
                onClick={handleReply}
                className="p-2 rounded-full bg-blue-500 hover:bg-blue-600 transition-colors"
                aria-label="Send reply"
              >
                <Send className="w-5 h-5 text-white" />
              </button>
              <button
                onClick={() => setShowReplyInput(false)}
                className="p-2 rounded-full hover:bg-white/20 transition-colors"
                aria-label="Cancel"
              >
                <X className="w-5 h-5 text-white" />
              </button>
            </div>
          ) : (
            <div className="flex items-center justify-between">
              <button
                onClick={() => setShowReplyInput(true)}
                className="flex-1 bg-white/20 text-white rounded-full px-4 py-2 text-left hover:bg-white/30 transition-colors"
              >
                Reply to story...
              </button>
              <button
                className="ml-2 p-2 rounded-full hover:bg-white/20 transition-colors"
                aria-label="React"
              >
                <Heart className="w-6 h-6 text-white" />
              </button>
            </div>
          )}
        </div>
      )}
      {/* View Count (My Status Only) */}
      {isMyStatus && currentStory?.views && (
        <div className="absolute bottom-4 left-4 z-20 bg-black/50 rounded-full px-4 py-2">
          <p className="text-white text-sm">
            {currentStory?.views?.length || 0} {currentStory?.views?.length === 1 ? 'view' : 'views'}
          </p>
        </div>
      )}
    </div>
  );
}