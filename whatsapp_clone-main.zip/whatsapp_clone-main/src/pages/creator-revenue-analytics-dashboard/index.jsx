import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { DollarSign, TrendingUp, Users, CreditCard, FileText, Download, PieChart, BarChart3, Loader2, AlertCircle } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { creatorRevenueService } from '../../services/creatorRevenueService';
import Button from '../../components/ui/Button';
import MetricsCard from '../call-analytics-dashboard/components/MetricsCard';

export default function CreatorRevenueAnalyticsDashboard() {
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();

  const [loading, setLoading] = useState(true);
  const [revenue, setRevenue] = useState(null);
  const [payouts, setPayouts] = useState(null);
  const [forecast, setForecast] = useState(null);
  const [selectedChannel, setSelectedChannel] = useState(null);
  const [activeTab, setActiveTab] = useState('overview');
  const [taxYear, setTaxYear] = useState(new Date()?.getFullYear());
  const [error, setError] = useState('');

  useEffect(() => {
    if (!authLoading && !user) {
      navigate('/login');
    }
  }, [user, authLoading, navigate]);

  useEffect(() => {
    if (!authLoading && user) {
      loadRevenueData();
    }
  }, [authLoading, user]);

  const loadRevenueData = async () => {
    try {
      setLoading(true);
      setError('');

      const [revenueResult, payoutsResult] = await Promise.all([
        creatorRevenueService?.getCreatorRevenue(),
        creatorRevenueService?.getPayoutHistory()
      ]);

      if (revenueResult?.error) throw revenueResult?.error;
      if (payoutsResult?.error) throw payoutsResult?.error;

      setRevenue(revenueResult?.data);
      setPayouts(payoutsResult?.data);

      // Load forecast if channels exist
      if (revenueResult?.data?.channels?.length > 0) {
        const channelIds = revenueResult?.data?.channels?.map(c => c?.id);
        const forecastResult = await creatorRevenueService?.getRevenueForecast(channelIds);
        if (!forecastResult?.error) {
          setForecast(forecastResult?.data);
        }
      }
    } catch (err) {
      console.error('Error loading revenue data:', err);
      setError(err?.message || 'Failed to load revenue data');
    } finally {
      setLoading(false);
    }
  };

  const handleDownloadTaxDoc = async () => {
    try {
      const result = await creatorRevenueService?.generateTaxDocumentation(taxYear);
      if (result?.error) throw result?.error;

      // Create downloadable JSON file
      const dataStr = JSON.stringify(result?.data, null, 2);
      const dataBlob = new Blob([dataStr], { type: 'application/json' });
      const url = URL.createObjectURL(dataBlob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `tax-documentation-${taxYear}.json`;
      link?.click();
      URL.revokeObjectURL(url);

      alert('Tax documentation downloaded successfully');
    } catch (err) {
      console.error('Error downloading tax documentation:', err);
      alert(err?.message || 'Failed to download tax documentation');
    }
  };

  const handleRequestPayout = async () => {
    if (!selectedChannel) {
      alert('Please select a channel');
      return;
    }

    const amount = prompt('Enter payout amount (USD):');
    if (!amount || isNaN(amount)) return;

    try {
      const result = await creatorRevenueService?.requestPayout(selectedChannel, parseFloat(amount));
      if (result?.error) throw result?.error;

      alert('Payout request submitted successfully');
      await loadRevenueData();
    } catch (err) {
      console.error('Error requesting payout:', err);
      alert(err?.message || 'Failed to request payout');
    }
  };

  if (authLoading || loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-lg shadow-lg p-6 max-w-md w-full">
          <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <p className="text-center text-gray-700">{error}</p>
          <Button onClick={() => navigate('/channel-management-dashboard')} className="w-full mt-4">
            Go to Channel Management
          </Button>
        </div>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Creator Revenue Analytics | ChatVybz</title>
      </Helmet>
      <div className="min-h-screen bg-gray-50 pb-20">
        {/* Header */}
        <div className="bg-white border-b border-gray-200 sticky top-0 z-10">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Creator Revenue Analytics</h1>
                <p className="text-sm text-gray-600 mt-1">Track your earnings and manage payouts</p>
              </div>
              <Button onClick={() => navigate('/channel-management-dashboard')} variant="outline">
                Back to Channels
              </Button>
            </div>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          {/* Tab Navigation */}
          <div className="bg-white rounded-lg shadow-sm mb-6">
            <div className="border-b border-gray-200">
              <nav className="flex -mb-px">
                {['overview', 'subscriptions', 'ads', 'payouts', 'tax']?.map((tab) => (
                  <button
                    key={tab}
                    onClick={() => setActiveTab(tab)}
                    className={`px-6 py-3 text-sm font-medium border-b-2 transition-colors ${
                      activeTab === tab
                        ? 'border-blue-500 text-blue-600' :'border-transparent text-gray-600 hover:text-gray-900 hover:border-gray-300'
                    }`}
                  >
                    {tab?.charAt(0)?.toUpperCase() + tab?.slice(1)}
                  </button>
                ))}
              </nav>
            </div>
          </div>

          {/* Overview Tab */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* Key Metrics */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <MetricsCard
                  title="Total Revenue"
                  value={`$${revenue?.totalRevenue?.toFixed(2) || '0.00'}`}
                  icon={DollarSign}
                  trend="up"
                  trendValue="+12.5%"
                />
                <MetricsCard
                  title="Subscription Revenue"
                  value={`$${revenue?.subscriptionRevenue?.toFixed(2) || '0.00'}`}
                  icon={Users}
                  trend="up"
                  trendValue="+8.3%"
                />
                <MetricsCard
                  title="Ad Revenue"
                  value={`$${revenue?.adRevenue?.toFixed(2) || '0.00'}`}
                  icon={BarChart3}
                  trend="up"
                  trendValue="+15.2%"
                />
                <MetricsCard
                  title="Total Paid Out"
                  value={`$${payouts?.totalPaidOut?.toFixed(2) || '0.00'}`}
                  icon={CreditCard}
                  trend="neutral"
                />
              </div>

              {/* Revenue by Channel */}
              <div className="bg-white rounded-lg shadow-sm p-6">
                <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
                  <PieChart className="w-5 h-5 text-blue-600" />
                  Revenue by Channel
                </h2>
                <div className="space-y-3">
                  {revenue?.revenueByChannel?.map((channel) => (
                    <div key={channel?.channelId} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div>
                        <p className="font-medium text-gray-900">{channel?.channelName}</p>
                        <p className="text-sm text-gray-600">
                          Subscriptions: ${channel?.subscriptionRevenue?.toFixed(2)} | Ads: ${channel?.adRevenue?.toFixed(2)}
                        </p>
                      </div>
                      <p className="text-lg font-bold text-blue-600">${channel?.totalRevenue?.toFixed(2)}</p>
                    </div>
                  ))}
                  {(!revenue?.revenueByChannel || revenue?.revenueByChannel?.length === 0) && (
                    <p className="text-center text-gray-500 py-8">No revenue data available</p>
                  )}
                </div>
              </div>

              {/* Revenue Forecast */}
              {forecast && (
                <div className="bg-white rounded-lg shadow-sm p-6">
                  <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-green-600" />
                    Revenue Forecast (Next 3 Months)
                  </h2>
                  <div className="space-y-3">
                    {forecast?.forecast?.map((item) => (
                      <div key={item?.month} className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                        <p className="font-medium text-gray-900">{item?.month}</p>
                        <p className="text-lg font-bold text-green-600">${item?.projectedRevenue?.toFixed(2)}</p>
                      </div>
                    ))}
                  </div>
                  <p className="text-sm text-gray-600 mt-4">
                    Average monthly growth: ${forecast?.avgMonthlyGrowth?.toFixed(2)}
                  </p>
                </div>
              )}
            </div>
          )}

          {/* Subscriptions Tab */}
          {activeTab === 'subscriptions' && (
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Subscription Revenue Details</h2>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                <div className="p-4 bg-blue-50 rounded-lg">
                  <p className="text-sm text-gray-600">Monthly Recurring Revenue (MRR)</p>
                  <p className="text-2xl font-bold text-blue-600">${revenue?.subscriptionDetails?.mrr?.toFixed(2) || '0.00'}</p>
                </div>
                <div className="p-4 bg-green-50 rounded-lg">
                  <p className="text-sm text-gray-600">Total Subscribers</p>
                  <p className="text-2xl font-bold text-green-600">{revenue?.subscriptionDetails?.totalSubscribers || 0}</p>
                </div>
                <div className="p-4 bg-purple-50 rounded-lg">
                  <p className="text-sm text-gray-600">Growth Rate</p>
                  <p className="text-2xl font-bold text-purple-600">{revenue?.subscriptionDetails?.growthRate?.toFixed(1) || '0.0'}%</p>
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 border border-gray-200 rounded-lg">
                  <p className="text-sm text-gray-600">New Subscribers (30 days)</p>
                  <p className="text-xl font-bold text-gray-900">{revenue?.subscriptionDetails?.newSubscribers || 0}</p>
                </div>
                <div className="p-4 border border-gray-200 rounded-lg">
                  <p className="text-sm text-gray-600">Churned Subscribers (30 days)</p>
                  <p className="text-xl font-bold text-gray-900">{revenue?.subscriptionDetails?.churnedSubscribers || 0}</p>
                </div>
              </div>
            </div>
          )}

          {/* Ads Tab */}
          {activeTab === 'ads' && (
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4">Ad Revenue Details</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                <div className="p-4 bg-blue-50 rounded-lg">
                  <p className="text-sm text-gray-600">Total Impressions</p>
                  <p className="text-2xl font-bold text-blue-600">{revenue?.adDetails?.totalImpressions?.toLocaleString() || 0}</p>
                </div>
                <div className="p-4 bg-green-50 rounded-lg">
                  <p className="text-sm text-gray-600">Total Clicks</p>
                  <p className="text-2xl font-bold text-green-600">{revenue?.adDetails?.totalClicks?.toLocaleString() || 0}</p>
                </div>
                <div className="p-4 bg-purple-50 rounded-lg">
                  <p className="text-sm text-gray-600">Click-Through Rate</p>
                  <p className="text-2xl font-bold text-purple-600">{revenue?.adDetails?.ctr?.toFixed(2) || '0.00'}%</p>
                </div>
                <div className="p-4 bg-yellow-50 rounded-lg">
                  <p className="text-sm text-gray-600">Creator Share</p>
                  <p className="text-2xl font-bold text-yellow-600">${revenue?.adDetails?.creatorShare?.toFixed(2) || '0.00'}</p>
                </div>
              </div>
              <div className="p-4 border border-gray-200 rounded-lg">
                <h3 className="font-semibold text-gray-900 mb-2">Revenue Split</h3>
                <div className="flex items-center gap-4">
                  <div className="flex-1">
                    <div className="flex justify-between mb-1">
                      <span className="text-sm text-gray-600">Creator ({revenue?.adDetails?.splitPercentage || 70}%)</span>
                      <span className="text-sm font-medium text-gray-900">${revenue?.adDetails?.creatorShare?.toFixed(2) || '0.00'}</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div className="bg-blue-600 h-2 rounded-full" style={{ width: `${revenue?.adDetails?.splitPercentage || 70}%` }}></div>
                    </div>
                  </div>
                  <div className="flex-1">
                    <div className="flex justify-between mb-1">
                      <span className="text-sm text-gray-600">Platform ({100 - (revenue?.adDetails?.splitPercentage || 70)}%)</span>
                      <span className="text-sm font-medium text-gray-900">${revenue?.adDetails?.platformShare?.toFixed(2) || '0.00'}</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div className="bg-gray-600 h-2 rounded-full" style={{ width: `${100 - (revenue?.adDetails?.splitPercentage || 70)}%` }}></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Payouts Tab */}
          {activeTab === 'payouts' && (
            <div className="space-y-6">
              <div className="bg-white rounded-lg shadow-sm p-6">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-lg font-semibold text-gray-900">Payout History</h2>
                  <div className="flex gap-2">
                    <select
                      value={selectedChannel || ''}
                      onChange={(e) => setSelectedChannel(e?.target?.value)}
                      className="px-3 py-2 border border-gray-300 rounded-lg text-sm"
                    >
                      <option value="">Select Channel</option>
                      {revenue?.channels?.map((channel) => (
                        <option key={channel?.id} value={channel?.id}>{channel?.name}</option>
                      ))}
                    </select>
                    <Button onClick={handleRequestPayout} disabled={!selectedChannel}>
                      Request Payout
                    </Button>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                  <div className="p-4 bg-green-50 rounded-lg">
                    <p className="text-sm text-gray-600">Total Paid Out</p>
                    <p className="text-2xl font-bold text-green-600">${payouts?.totalPaidOut?.toFixed(2) || '0.00'}</p>
                  </div>
                  <div className="p-4 bg-yellow-50 rounded-lg">
                    <p className="text-sm text-gray-600">Pending Payouts</p>
                    <p className="text-2xl font-bold text-yellow-600">${payouts?.totalPending?.toFixed(2) || '0.00'}</p>
                  </div>
                  <div className="p-4 bg-blue-50 rounded-lg">
                    <p className="text-sm text-gray-600">Total Payouts</p>
                    <p className="text-2xl font-bold text-blue-600">{payouts?.totalPayouts || 0}</p>
                  </div>
                </div>
                <div className="space-y-3">
                  {payouts?.payouts?.map((payout) => (
                    <div key={payout?.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg">
                      <div>
                        <p className="font-medium text-gray-900">{payout?.channel?.name}</p>
                        <p className="text-sm text-gray-600">{new Date(payout?.created_at)?.toLocaleDateString()}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-lg font-bold text-gray-900">${payout?.amount?.toFixed(2)}</p>
                        <span className={`text-xs px-2 py-1 rounded-full ${
                          payout?.status === 'paid' ? 'bg-green-100 text-green-700' :
                          payout?.status === 'pending'? 'bg-yellow-100 text-yellow-700' : 'bg-red-100 text-red-700'
                        }`}>
                          {payout?.status}
                        </span>
                      </div>
                    </div>
                  ))}
                  {(!payouts?.payouts || payouts?.payouts?.length === 0) && (
                    <p className="text-center text-gray-500 py-8">No payout history available</p>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Tax Tab */}
          {activeTab === 'tax' && (
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h2 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
                <FileText className="w-5 h-5 text-blue-600" />
                Tax Documentation
              </h2>
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">Select Tax Year</label>
                <select
                  value={taxYear}
                  onChange={(e) => setTaxYear(parseInt(e?.target?.value))}
                  className="px-4 py-2 border border-gray-300 rounded-lg"
                >
                  {[2024, 2023, 2022, 2021]?.map((year) => (
                    <option key={year} value={year}>{year}</option>
                  ))}
                </select>
              </div>
              <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg mb-6">
                <p className="text-sm text-blue-900 mb-2">
                  <strong>Tax Documentation Available:</strong>
                </p>
                <ul className="text-sm text-blue-800 space-y-1">
                  <li>• 1099-MISC form data (US creators)</li>
                  <li>• International tax compliance reports</li>
                  <li>• Detailed payout breakdown with fees</li>
                  <li>• Annual earnings summary</li>
                </ul>
              </div>
              <Button onClick={handleDownloadTaxDoc} className="w-full">
                <Download className="w-4 h-4 mr-2" />
                Download Tax Documentation for {taxYear}
              </Button>
            </div>
          )}
        </div>
      </div>
    </>
  );
}
