import React from 'react';
import { Clock, CheckCircle, XCircle, AlertCircle, Ban } from 'lucide-react';
import Button from '../../../components/ui/Button';

export default function WithdrawalHistoryTable({ withdrawals, onCancel }) {
  const getStatusIcon = (status) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="w-5 h-5 text-green-600" />;
      case 'processing':
        return <Clock className="w-5 h-5 text-blue-600" />;
      case 'failed':
        return <XCircle className="w-5 h-5 text-red-600" />;
      case 'cancelled':
        return <Ban className="w-5 h-5 text-gray-600" />;
      default:
        return <AlertCircle className="w-5 h-5 text-yellow-600" />;
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800';
      case 'processing':
        return 'bg-blue-100 text-blue-800';
      case 'failed':
        return 'bg-red-100 text-red-800';
      case 'cancelled':
        return 'bg-gray-100 text-gray-800';
      default:
        return 'bg-yellow-100 text-yellow-800';
    }
  };

  const formatDate = (dateString) => {
    return new Date(dateString)?.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  if (withdrawals?.length === 0) {
    return (
      <div className="text-center py-12">
        <Clock className="w-16 h-16 text-gray-300 mx-auto mb-4" />
        <p className="text-gray-500">No withdrawal history yet</p>
      </div>
    );
  }

  return (
    <div>
      <h2 className="text-xl font-bold text-gray-900 mb-6">Withdrawal History</h2>
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gray-50 border-b border-gray-200">
            <tr>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Date
              </th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Amount
              </th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Fee
              </th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Net Amount
              </th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Bank Account
              </th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Status
              </th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {withdrawals?.map((withdrawal) => (
              <tr key={withdrawal?.id} className="hover:bg-gray-50">
                <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-900">
                  {formatDate(withdrawal?.created_at)}
                </td>
                <td className="px-4 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                  ${parseFloat(withdrawal?.amount)?.toFixed(2)}
                </td>
                <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-600">
                  ${parseFloat(withdrawal?.fee_amount)?.toFixed(2)}
                </td>
                <td className="px-4 py-4 whitespace-nowrap text-sm font-semibold text-green-600">
                  ${parseFloat(withdrawal?.net_amount)?.toFixed(2)}
                </td>
                <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-600">
                  {withdrawal?.bank_account?.bank_name}<br />
                  <span className="text-xs text-gray-500">
                    ****{withdrawal?.bank_account?.account_number_last4}
                  </span>
                </td>
                <td className="px-4 py-4 whitespace-nowrap">
                  <div className="flex items-center gap-2">
                    {getStatusIcon(withdrawal?.status)}
                    <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                      getStatusColor(withdrawal?.status)
                    }`}>
                      {withdrawal?.status?.charAt(0)?.toUpperCase() + withdrawal?.status?.slice(1)}
                    </span>
                  </div>
                </td>
                <td className="px-4 py-4 whitespace-nowrap text-sm">
                  {withdrawal?.status === 'pending' && (
                    <Button
                      onClick={() => onCancel(withdrawal?.id)}
                      variant="outline"
                      size="sm"
                    >
                      Cancel
                    </Button>
                  )}
                  {withdrawal?.status === 'failed' && withdrawal?.failure_reason && (
                    <span className="text-xs text-red-600">
                      {withdrawal?.failure_reason}
                    </span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Summary Stats */}
      <div className="mt-6 grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="p-4 bg-green-50 rounded-lg border border-green-200">
          <p className="text-sm text-green-700 mb-1">Completed</p>
          <p className="text-2xl font-bold text-green-900">
            {withdrawals?.filter(w => w?.status === 'completed')?.length}
          </p>
        </div>
        <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
          <p className="text-sm text-blue-700 mb-1">Processing</p>
          <p className="text-2xl font-bold text-blue-900">
            {withdrawals?.filter(w => w?.status === 'processing')?.length}
          </p>
        </div>
        <div className="p-4 bg-yellow-50 rounded-lg border border-yellow-200">
          <p className="text-sm text-yellow-700 mb-1">Pending</p>
          <p className="text-2xl font-bold text-yellow-900">
            {withdrawals?.filter(w => w?.status === 'pending')?.length}
          </p>
        </div>
        <div className="p-4 bg-red-50 rounded-lg border border-red-200">
          <p className="text-sm text-red-700 mb-1">Failed</p>
          <p className="text-2xl font-bold text-red-900">
            {withdrawals?.filter(w => w?.status === 'failed')?.length}
          </p>
        </div>
      </div>
    </div>
  );
}