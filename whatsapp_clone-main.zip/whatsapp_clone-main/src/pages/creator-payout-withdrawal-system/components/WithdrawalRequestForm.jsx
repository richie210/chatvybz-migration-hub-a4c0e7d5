import React, { useState, useEffect } from 'react';
import { DollarSign, Calendar, RefreshCw, AlertCircle, Info } from 'lucide-react';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import { creatorPayoutWithdrawalService } from '../../../services/creatorPayoutWithdrawalService';

export default function WithdrawalRequestForm({ availableBalance, bankAccounts, onSubmit }) {
  const [amount, setAmount] = useState('');
  const [selectedBankAccount, setSelectedBankAccount] = useState('');
  const [scheduledDate, setScheduledDate] = useState('');
  const [isRecurring, setIsRecurring] = useState(false);
  const [recurringFrequency, setRecurringFrequency] = useState('monthly');
  const [feeAmount, setFeeAmount] = useState(0);
  const [netAmount, setNetAmount] = useState(0);
  const [errors, setErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);

  const primaryAccount = bankAccounts?.find(acc => acc?.is_primary);

  useEffect(() => {
    if (primaryAccount && !selectedBankAccount) {
      setSelectedBankAccount(primaryAccount?.id);
    }
  }, [primaryAccount, selectedBankAccount]);

  useEffect(() => {
    if (amount) {
      const parsedAmount = parseFloat(amount);
      if (!isNaN(parsedAmount)) {
        const fee = creatorPayoutWithdrawalService?.calculateFee(parsedAmount);
        setFeeAmount(fee);
        setNetAmount(parsedAmount - fee);
      }
    } else {
      setFeeAmount(0);
      setNetAmount(0);
    }
  }, [amount]);

  const validateForm = () => {
    const newErrors = {};

    if (!amount || parseFloat(amount) < 10) {
      newErrors.amount = 'Minimum withdrawal amount is $10.00';
    }

    if (parseFloat(amount) > availableBalance) {
      newErrors.amount = 'Amount exceeds available balance';
    }

    if (!selectedBankAccount) {
      newErrors.bankAccount = 'Please select a bank account';
    }

    if (isRecurring && !recurringFrequency) {
      newErrors.recurringFrequency = 'Please select recurring frequency';
    }

    setErrors(newErrors);
    return Object.keys(newErrors)?.length === 0;
  };

  const handleSubmit = async (e) => {
    e?.preventDefault();
    if (!validateForm()) return;

    setSubmitting(true);
    try {
      await onSubmit({
        amount: parseFloat(amount),
        bankAccountId: selectedBankAccount,
        scheduledDate: scheduledDate || null,
        isRecurring,
        recurringFrequency: isRecurring ? recurringFrequency : null
      });

      // Reset form
      setAmount('');
      setScheduledDate('');
      setIsRecurring(false);
      setRecurringFrequency('monthly');
    } finally {
      setSubmitting(false);
    }
  };

  if (bankAccounts?.length === 0) {
    return (
      <div className="text-center py-12">
        <AlertCircle className="w-16 h-16 text-yellow-500 mx-auto mb-4" />
        <h3 className="text-lg font-semibold text-gray-900 mb-2">No Bank Accounts</h3>
        <p className="text-gray-600 mb-4">Please add a bank account before requesting a withdrawal</p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="max-w-2xl mx-auto">
      <h2 className="text-2xl font-bold text-gray-900 mb-6">Request Withdrawal</h2>
      {/* Amount Input */}
      <div className="mb-6">
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Withdrawal Amount
        </label>
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <DollarSign className="w-5 h-5 text-gray-400" />
          </div>
          <input
            type="number"
            step="0.01"
            min="10"
            max={availableBalance}
            value={amount}
            onChange={(e) => setAmount(e?.target?.value)}
            className="w-full pl-10 pr-3 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 text-lg"
            placeholder="0.00"
          />
        </div>
        {errors?.amount && (
          <p className="text-sm text-red-600 mt-1">{errors?.amount}</p>
        )}
        <p className="text-sm text-gray-500 mt-1">
          Available balance: ${availableBalance?.toFixed(2)}
        </p>
      </div>
      {/* Fee Breakdown */}
      {amount && parseFloat(amount) >= 10 && (
        <div className="mb-6 p-4 bg-blue-50 rounded-lg border border-blue-200">
          <div className="flex items-start gap-2 mb-3">
            <Info className="w-5 h-5 text-blue-600 mt-0.5" />
            <div className="flex-1">
              <h3 className="font-semibold text-blue-900 mb-2">Fee Breakdown</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-blue-700">Withdrawal Amount:</span>
                  <span className="font-medium text-blue-900">${parseFloat(amount)?.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-blue-700">Processing Fee (2.5%):</span>
                  <span className="font-medium text-blue-900">-${feeAmount?.toFixed(2)}</span>
                </div>
                <div className="border-t border-blue-300 pt-2 flex justify-between">
                  <span className="font-semibold text-blue-900">You'll Receive:</span>
                  <span className="font-bold text-blue-900 text-lg">${netAmount?.toFixed(2)}</span>
                </div>
              </div>
            </div>
          </div>
          <p className="text-xs text-blue-700 mt-2">
            Processing time: 3-5 business days
          </p>
        </div>
      )}
      {/* Bank Account Selection */}
      <div className="mb-6">
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Bank Account
        </label>
        <select
          value={selectedBankAccount}
          onChange={(e) => setSelectedBankAccount(e?.target?.value)}
          className="w-full px-3 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
          <option value="">Select bank account</option>
          {bankAccounts?.map((account) => (
            <option key={account?.id} value={account?.id}>
              {account?.bank_name} - ****{account?.account_number_last4}
              {account?.is_primary ? ' (Primary)' : ''}
            </option>
          ))}
        </select>
        {errors?.bankAccount && (
          <p className="text-sm text-red-600 mt-1">{errors?.bankAccount}</p>
        )}
      </div>
      {/* Scheduled Date */}
      <div className="mb-6">
        <label className="flex items-center gap-2 mb-2">
          <Calendar className="w-4 h-4 text-gray-600" />
          <span className="text-sm font-medium text-gray-700">Schedule Withdrawal (Optional)</span>
        </label>
        <input
          type="date"
          value={scheduledDate}
          onChange={(e) => setScheduledDate(e?.target?.value)}
          min={new Date()?.toISOString()?.split('T')?.[0]}
          className="w-full px-3 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
      </div>
      {/* Recurring Withdrawal */}
      <div className="mb-6 p-4 bg-gray-50 rounded-lg border border-gray-200">
        <label className="flex items-center gap-2 mb-3">
          <input
            type="checkbox"
            checked={isRecurring}
            onChange={(e) => setIsRecurring(e?.target?.checked)}
            className="w-4 h-4 text-blue-600 rounded"
          />
          <RefreshCw className="w-4 h-4 text-gray-600" />
          <span className="text-sm font-medium text-gray-700">Set up recurring withdrawal</span>
        </label>

        {isRecurring && (
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Frequency
            </label>
            <select
              value={recurringFrequency}
              onChange={(e) => setRecurringFrequency(e?.target?.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="weekly">Weekly</option>
              <option value="biweekly">Bi-weekly</option>
              <option value="monthly">Monthly</option>
              <option value="quarterly">Quarterly</option>
            </select>
          </div>
        )}
      </div>
      {/* Submit Button */}
      <Button
        type="submit"
        loading={submitting}
        disabled={!amount || parseFloat(amount) < 10 || !selectedBankAccount}
        className="w-full"
        size="lg"
      >
        Request Withdrawal
      </Button>
      {/* Security Notice */}
      <div className="mt-6 p-4 bg-gray-50 rounded-lg border border-gray-200">
        <p className="text-xs text-gray-600">
          🔒 All withdrawals require two-factor authentication. You'll receive a confirmation email once your withdrawal is processed.
        </p>
      </div>
    </form>
  );
}