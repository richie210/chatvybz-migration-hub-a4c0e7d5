import React from 'react';
import { CreditCard, CheckCircle, Trash2, Star } from 'lucide-react';
import Button from '../../../components/ui/Button';

export default function BankAccountCard({ account, onSetPrimary, onDelete }) {
  return (
    <div className={`p-4 rounded-lg border-2 ${
      account?.is_primary ? 'border-blue-500 bg-blue-50' : 'border-gray-200 bg-white'
    }`}>
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-blue-100 rounded-lg">
            <CreditCard className="w-5 h-5 text-blue-600" />
          </div>
          <div>
            <h3 className="font-semibold text-gray-900">{account?.bank_name}</h3>
            <p className="text-sm text-gray-500">****{account?.account_number_last4}</p>
          </div>
        </div>
        {account?.is_primary && (
          <div className="flex items-center gap-1 px-2 py-1 bg-blue-600 text-white text-xs rounded-full">
            <Star className="w-3 h-3" />
            Primary
          </div>
        )}
      </div>

      <div className="space-y-2 mb-4">
        <div className="flex justify-between text-sm">
          <span className="text-gray-600">Account Holder:</span>
          <span className="font-medium text-gray-900">{account?.account_holder_name}</span>
        </div>
        <div className="flex justify-between text-sm">
          <span className="text-gray-600">Account Type:</span>
          <span className="font-medium text-gray-900 capitalize">{account?.account_type}</span>
        </div>
        <div className="flex justify-between text-sm">
          <span className="text-gray-600">Status:</span>
          <div className="flex items-center gap-1">
            {account?.is_verified ? (
              <>
                <CheckCircle className="w-4 h-4 text-green-600" />
                <span className="text-green-600 font-medium">Verified</span>
              </>
            ) : (
              <span className="text-yellow-600 font-medium">Pending Verification</span>
            )}
          </div>
        </div>
      </div>

      <div className="flex gap-2">
        {!account?.is_primary && (
          <Button
            onClick={() => onSetPrimary(account?.id)}
            variant="outline"
            size="sm"
            className="flex-1"
          >
            Set as Primary
          </Button>
        )}
        <Button
          onClick={() => onDelete(account?.id)}
          variant="destructive"
          size="sm"
          iconName="Trash2"
        >
          Delete
        </Button>
      </div>
    </div>
  );
}