import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { DollarSign, CreditCard, Clock, Plus, Loader2, AlertCircle, TrendingUp, ArrowLeft } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { creatorPayoutWithdrawalService } from '../../services/creatorPayoutWithdrawalService';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';
import BankAccountCard from './components/BankAccountCard';
import WithdrawalRequestForm from './components/WithdrawalRequestForm';
import WithdrawalHistoryTable from './components/WithdrawalHistoryTable';
import Icon from '../../components/AppIcon';


export default function CreatorPayoutWithdrawalSystem() {
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();

  const [loading, setLoading] = useState(true);
  const [availableBalance, setAvailableBalance] = useState(0);
  const [bankAccounts, setBankAccounts] = useState([]);
  const [withdrawalHistory, setWithdrawalHistory] = useState([]);
  const [withdrawalStats, setWithdrawalStats] = useState(null);
  const [activeTab, setActiveTab] = useState('withdraw');
  const [showAddBankForm, setShowAddBankForm] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!authLoading && !user) {
      navigate('/login');
    }
  }, [user, authLoading, navigate]);

  useEffect(() => {
    if (!authLoading && user) {
      loadData();
    }
  }, [authLoading, user]);

  const loadData = async () => {
    try {
      setLoading(true);
      setError('');

      const [balanceResult, accountsResult, historyResult, statsResult] = await Promise.all([
        creatorPayoutWithdrawalService?.getAvailableBalance(),
        creatorPayoutWithdrawalService?.getBankAccounts(),
        creatorPayoutWithdrawalService?.getWithdrawalHistory(),
        creatorPayoutWithdrawalService?.getWithdrawalStats()
      ]);

      if (balanceResult?.error) throw balanceResult?.error;
      if (accountsResult?.error) throw accountsResult?.error;
      if (historyResult?.error) throw historyResult?.error;
      if (statsResult?.error) throw statsResult?.error;

      setAvailableBalance(balanceResult?.data?.available || 0);
      setBankAccounts(accountsResult?.data || []);
      setWithdrawalHistory(historyResult?.data || []);
      setWithdrawalStats(statsResult?.data);
    } catch (err) {
      console.error('Error loading data:', err);
      setError(err?.message || 'Failed to load withdrawal data');
    } finally {
      setLoading(false);
    }
  };

  const handleAddBankAccount = async (accountData) => {
    try {
      const result = await creatorPayoutWithdrawalService?.addBankAccount(accountData);
      if (result?.error) throw result?.error;

      setShowAddBankForm(false);
      await loadData();
      alert('Bank account added successfully!');
    } catch (err) {
      console.error('Error adding bank account:', err);
      alert(err?.message || 'Failed to add bank account');
    }
  };

  const handleDeleteBankAccount = async (accountId) => {
    if (!confirm('Are you sure you want to delete this bank account?')) return;

    try {
      const result = await creatorPayoutWithdrawalService?.deleteBankAccount(accountId);
      if (result?.error) throw result?.error;

      await loadData();
      alert('Bank account deleted successfully');
    } catch (err) {
      console.error('Error deleting bank account:', err);
      alert(err?.message || 'Failed to delete bank account');
    }
  };

  const handleSetPrimary = async (accountId) => {
    try {
      const result = await creatorPayoutWithdrawalService?.setPrimaryBankAccount(accountId);
      if (result?.error) throw result?.error;

      await loadData();
    } catch (err) {
      console.error('Error setting primary account:', err);
      alert(err?.message || 'Failed to set primary account');
    }
  };

  const handleWithdrawalRequest = async (withdrawalData) => {
    try {
      const result = await creatorPayoutWithdrawalService?.requestWithdrawal(withdrawalData);
      if (result?.error) throw result?.error;

      await loadData();
      alert('Withdrawal request submitted successfully!');
    } catch (err) {
      console.error('Error requesting withdrawal:', err);
      alert(err?.message || 'Failed to submit withdrawal request');
    }
  };

  const handleCancelWithdrawal = async (withdrawalId) => {
    if (!confirm('Are you sure you want to cancel this withdrawal?')) return;

    try {
      const result = await creatorPayoutWithdrawalService?.cancelWithdrawal(withdrawalId);
      if (result?.error) throw result?.error;

      await loadData();
      alert('Withdrawal cancelled successfully');
    } catch (err) {
      console.error('Error cancelling withdrawal:', err);
      alert(err?.message || 'Failed to cancel withdrawal');
    }
  };

  if (authLoading || loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-lg shadow-lg p-6 max-w-md w-full">
          <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <p className="text-center text-gray-700 mb-4">{error}</p>
          <Button onClick={() => navigate('/creator-revenue-settlement-dashboard')} className="w-full">
            Go to Revenue Dashboard
          </Button>
        </div>
      </div>
    );
  }

  const tabs = [
    { id: 'withdraw', label: 'Request Withdrawal', icon: DollarSign },
    { id: 'accounts', label: 'Bank Accounts', icon: CreditCard },
    { id: 'history', label: 'Withdrawal History', icon: Clock }
  ];

  return (
    <>
      <Helmet>
        <title>Payout Withdrawal System | ChatVybz</title>
      </Helmet>
      <div className="min-h-screen bg-gray-50 pb-20">
        {/* Header */}
        <div className="bg-gradient-to-r from-green-600 to-blue-600 text-white shadow-lg">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-4">
                <Button
                  onClick={() => navigate('/creator-revenue-settlement-dashboard')}
                  variant="ghost"
                  className="text-white hover:bg-white/20"
                  iconName="ArrowLeft"
                >
                  Back
                </Button>
                <div>
                  <h1 className="text-3xl font-bold">Payout Withdrawal System</h1>
                  <p className="text-green-100 mt-1">Manage withdrawals and bank accounts</p>
                </div>
              </div>
            </div>

            {/* Balance Overview */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
                <div className="flex items-center gap-3">
                  <div className="p-3 bg-white/20 rounded-lg">
                    <DollarSign className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="text-sm text-green-100">Available Balance</p>
                    <p className="text-2xl font-bold">${availableBalance?.toFixed(2)}</p>
                  </div>
                </div>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
                <div className="flex items-center gap-3">
                  <div className="p-3 bg-white/20 rounded-lg">
                    <TrendingUp className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="text-sm text-green-100">Total Withdrawn</p>
                    <p className="text-2xl font-bold">${withdrawalStats?.totalWithdrawn?.toFixed(2) || '0.00'}</p>
                  </div>
                </div>
              </div>
              <div className="bg-white/10 backdrop-blur-sm rounded-lg p-4">
                <div className="flex items-center gap-3">
                  <div className="p-3 bg-white/20 rounded-lg">
                    <Clock className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="text-sm text-green-100">Pending Amount</p>
                    <p className="text-2xl font-bold">${withdrawalStats?.pendingAmount?.toFixed(2) || '0.00'}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Tabs */}
          <div className="bg-white rounded-lg shadow-md mb-6">
            <div className="border-b border-gray-200">
              <nav className="flex -mb-px">
                {tabs?.map((tab) => {
                  const Icon = tab?.icon;
                  const isActive = activeTab === tab?.id;
                  return (
                    <button
                      key={tab?.id}
                      onClick={() => setActiveTab(tab?.id)}
                      className={`flex items-center gap-2 px-6 py-4 border-b-2 font-medium text-sm transition-colors ${
                        isActive
                          ? 'border-blue-600 text-blue-600' :'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                      }`}
                    >
                      <Icon className="w-5 h-5" />
                      {tab?.label}
                    </button>
                  );
                })}
              </nav>
            </div>
          </div>

          {/* Tab Content */}
          <div className="bg-white rounded-lg shadow-md p-6">
            {activeTab === 'withdraw' && (
              <WithdrawalRequestForm
                availableBalance={availableBalance}
                bankAccounts={bankAccounts}
                onSubmit={handleWithdrawalRequest}
              />
            )}

            {activeTab === 'accounts' && (
              <div>
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold text-gray-900">Bank Accounts</h2>
                  <Button
                    onClick={() => setShowAddBankForm(!showAddBankForm)}
                    iconName="Plus"
                  >
                    Add Bank Account
                  </Button>
                </div>

                {showAddBankForm && (
                  <div className="mb-6 p-6 bg-gray-50 rounded-lg border border-gray-200">
                    <h3 className="text-lg font-semibold mb-4">Add New Bank Account</h3>
                    <AddBankAccountForm
                      onSubmit={handleAddBankAccount}
                      onCancel={() => setShowAddBankForm(false)}
                    />
                  </div>
                )}

                {bankAccounts?.length === 0 ? (
                  <div className="text-center py-12">
                    <CreditCard className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                    <p className="text-gray-500 mb-4">No bank accounts added yet</p>
                    <Button onClick={() => setShowAddBankForm(true)} iconName="Plus">
                      Add Your First Bank Account
                    </Button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {bankAccounts?.map((account) => (
                      <BankAccountCard
                        key={account?.id}
                        account={account}
                        onSetPrimary={handleSetPrimary}
                        onDelete={handleDeleteBankAccount}
                      />
                    ))}
                  </div>
                )}
              </div>
            )}

            {activeTab === 'history' && (
              <WithdrawalHistoryTable
                withdrawals={withdrawalHistory}
                onCancel={handleCancelWithdrawal}
              />
            )}
          </div>
        </div>
      </div>
    </>
  );
}

// Add Bank Account Form Component
function AddBankAccountForm({ onSubmit, onCancel }) {
  const [formData, setFormData] = useState({
    accountHolderName: '',
    bankName: '',
    routingNumber: '',
    accountNumber: '',
    confirmAccountNumber: '',
    accountType: 'checking',
    isPrimary: false
  });
  const [errors, setErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);

  const validateForm = () => {
    const newErrors = {};

    if (!formData?.accountHolderName?.trim()) {
      newErrors.accountHolderName = 'Account holder name is required';
    }

    if (!formData?.bankName?.trim()) {
      newErrors.bankName = 'Bank name is required';
    }

    if (!formData?.routingNumber || formData?.routingNumber?.length !== 9) {
      newErrors.routingNumber = 'Routing number must be 9 digits';
    }

    if (!formData?.accountNumber || formData?.accountNumber?.length < 8) {
      newErrors.accountNumber = 'Account number must be at least 8 digits';
    }

    if (formData?.accountNumber !== formData?.confirmAccountNumber) {
      newErrors.confirmAccountNumber = 'Account numbers do not match';
    }

    setErrors(newErrors);
    return Object.keys(newErrors)?.length === 0;
  };

  const handleSubmit = async (e) => {
    e?.preventDefault();
    if (!validateForm()) return;

    setSubmitting(true);
    try {
      await onSubmit(formData);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <Input
        label="Account Holder Name"
        value={formData?.accountHolderName}
        onChange={(e) => setFormData({ ...formData, accountHolderName: e?.target?.value })}
        error={errors?.accountHolderName}
        required
      />
      <Input
        label="Bank Name"
        value={formData?.bankName}
        onChange={(e) => setFormData({ ...formData, bankName: e?.target?.value })}
        error={errors?.bankName}
        required
      />
      <Input
        label="Routing Number"
        type="text"
        maxLength={9}
        value={formData?.routingNumber}
        onChange={(e) => setFormData({ ...formData, routingNumber: e?.target?.value?.replace(/\D/g, '') })}
        error={errors?.routingNumber}
        required
      />
      <Input
        label="Account Number"
        type="password"
        value={formData?.accountNumber}
        onChange={(e) => setFormData({ ...formData, accountNumber: e?.target?.value?.replace(/\D/g, '') })}
        error={errors?.accountNumber}
        required
      />
      <Input
        label="Confirm Account Number"
        type="password"
        value={formData?.confirmAccountNumber}
        onChange={(e) => setFormData({ ...formData, confirmAccountNumber: e?.target?.value?.replace(/\D/g, '') })}
        error={errors?.confirmAccountNumber}
        required
      />
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Account Type</label>
        <select
          value={formData?.accountType}
          onChange={(e) => setFormData({ ...formData, accountType: e?.target?.value })}
          className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
          <option value="checking">Checking</option>
          <option value="savings">Savings</option>
        </select>
      </div>
      <label className="flex items-center gap-2">
        <input
          type="checkbox"
          checked={formData?.isPrimary}
          onChange={(e) => setFormData({ ...formData, isPrimary: e?.target?.checked })}
          className="w-4 h-4 text-blue-600 rounded"
        />
        <span className="text-sm text-gray-700">Set as primary account</span>
      </label>
      <div className="flex gap-3 pt-4">
        <Button type="submit" loading={submitting} className="flex-1">
          Add Bank Account
        </Button>
        <Button type="button" variant="outline" onClick={onCancel} disabled={submitting}>
          Cancel
        </Button>
      </div>
    </form>
  );
}