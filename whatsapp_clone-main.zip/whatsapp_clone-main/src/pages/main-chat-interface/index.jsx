import React, { useState, useEffect, useRef } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

import ProfileSettingsTrigger from '../../components/ui/ProfileSettingsDropdown';
import ContactAccessPanel from '../../components/ui/ContactAccessPanel';
import MediaCompositionOverlay from '../../components/ui/MediaCompositionOverlay';
import ChatHeader from './components/ChatHeader';
import MessageBubble from './components/MessageBubble';
import MessageInput from './components/MessageInput';
import ContactInfoPanel from './components/ContactInfoPanel';
import TypingIndicator from './components/TypingIndicator';
import Icon from '../../components/AppIcon';
import { messageService } from '../../services/messageService';
import { typingIndicatorService } from '../../services/typingIndicatorService';
import { presenceService } from '../../services/presenceService';
import { connectionMonitor } from '../../utils/connectionMonitor';
import { offlineStorageService } from '../../services/offlineStorageService';
import { pushNotificationService } from '../../services/pushNotificationService';
import { supabase } from '../../lib/supabase';
import { generateClaudeQuickResponses } from '../../services/claudeReplyService';
import { deliveryAnalysisService } from '../../services/deliveryAnalysisService';
import { disappearingMessagesService } from '../../services/disappearingMessagesService';
import DeliveryFailureAnalysis from './components/DeliveryFailureAnalysis';
import LiveLocationShare from './components/LiveLocationShare';
import DisappearingMessagesPanel from './components/DisappearingMessagesPanel';



export default function MainChatInterface() {
  const location = useLocation();
  const navigate = useNavigate();
  const messagesEndRef = useRef(null);
  const [selectedConversation, setSelectedConversation] = useState(null);
  const [messages, setMessages] = useState([]);
  const [isContactPanelOpen, setIsContactPanelOpen] = useState(false);
  const [isContactInfoOpen, setIsContactInfoOpen] = useState(false);
  const [isMediaOverlayOpen, setIsMediaOverlayOpen] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [replyingTo, setReplyingTo] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [typingUsers, setTypingUsers] = useState(new Map());
  const typingTimeoutRef = useRef(null);
  const [isOnline, setIsOnline] = useState(true);
  const [queuedMessageCount, setQueuedMessageCount] = useState(0);
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [currentUser, setCurrentUser] = useState(null);
  const [authChecked, setAuthChecked] = useState(false);
  const [onlineUsers, setOnlineUsers] = useState([]);
  const [contacts, setContacts] = useState([]);
  const [showDeliveryAnalysis, setShowDeliveryAnalysis] = useState(false);
  const [selectedFailedMessage, setSelectedFailedMessage] = useState(null);
  const [showLocationShare, setShowLocationShare] = useState(false);
  const [showDisappearingMessages, setShowDisappearingMessages] = useState(false);
  const [expiringMessages, setExpiringMessages] = useState([]);
  const [showContactInfo, setShowContactInfo] = useState(false);
  const [showDisappearingPanel, setShowDisappearingPanel] = useState(false);
  const [pinnedConversations, setPinnedConversations] = useState([]);
  const [pinnedCount, setPinnedCount] = useState(0);

  // Add viewport height tracking for mobile browsers (address bar handling)
  useEffect(() => {
    const setViewportHeight = () => {
      const vh = window.innerHeight * 0.01;
      document.documentElement?.style?.setProperty('--vh', `${vh}px`);
    };

    setViewportHeight();
    window.addEventListener('resize', setViewportHeight);
    window.addEventListener('orientationchange', setViewportHeight);

    return () => {
      window.removeEventListener('resize', setViewportHeight);
      window.removeEventListener('orientationchange', setViewportHeight);
    };
  }, []);

  // Get authenticated user on mount - Enhanced with auth checking
  useEffect(() => {
    const getUser = async () => {
      try {
        const { data: { session } } = await supabase?.auth?.getSession();

        if (!session) {
          // Not authenticated - redirect to login
          setAuthChecked(true);
          navigate('/login');
          return;
        }

        const user = session?.user;
        if (user) {
          // Fetch full user profile
          const { data: profile } = await supabase?.
          from('users')?.
          select('*')?.
          eq('id', user?.id)?.
          single();

          setCurrentUser({
            id: user?.id,
            name: profile?.full_name || 'User',
            email: user?.email,
            avatar: profile?.avatar_url
          });
        }

        setAuthChecked(true);
      } catch (error) {
        console.error('Error checking authentication:', error);
        setAuthChecked(true);
        navigate('/login');
      }
    };

    getUser();
  }, [navigate]);

  // Subscribe to presence updates for selected conversation
  useEffect(() => {
    if (!selectedConversation?.id) return;

    const cleanup = presenceService?.subscribeToPresence(
      selectedConversation?.id,
      (presenceUpdates) => {
        setOnlineUsers(presenceUpdates);
      }
    );

    return () => {
      if (cleanup) cleanup();
    };
  }, [selectedConversation?.id]);

  // Subscribe to real-time message delivery status updates
  useEffect(() => {
    if (!selectedConversation?.id) return;

    const subscriptions = messages?.map((msg) => {
      if (msg?.isSent && msg?.status !== 'read') {
        return messageService?.subscribeToDeliveryStatus(
          msg?.id,
          (updatedMessage) => {
            setMessages((prev) =>
            prev?.map((m) =>
            m?.id === updatedMessage?.id ?
            { ...m, status: updatedMessage?.status, deliveredAt: updatedMessage?.delivered_at, readAt: updatedMessage?.read_at } :
            m
            )
            );
          }
        );
      }
      return null;
    })?.filter(Boolean);

    return () => {
      subscriptions?.forEach((unsub) => unsub?.());
    };
  }, [messages, selectedConversation?.id]);

  // Subscribe to disappearing messages notifications
  useEffect(() => {
    if (!selectedConversation?.id) return;

    const cleanup = disappearingMessagesService?.subscribeToExpirations(
      selectedConversation?.id,
      (messages) => {
        setExpiringMessages(messages);

        // Show notification for expiring messages
        if (messages?.length > 0) {
          const firstExpiring = messages?.[0];
          if (firstExpiring?.timeRemaining?.totalMinutes <= 5) {
            // Show urgent notification
            console.log(`Message expiring in ${firstExpiring?.timeRemaining?.formatted}`);
          }
        }
      }
    );

    return () => {
      if (cleanup) cleanup();
    };
  }, [selectedConversation?.id]);

  const conversations = [
  {
    id: 1,
    name: 'Sarah Johnson',
    phone: '+1 (555) 123-4567',
    status: 'Hey there! I am using ChatVybz',
    isOnline: true,
    isTyping: false,
    lastSeen: 'today at 10:30 AM',
    lastMessage: 'See you tomorrow!',
    lastMessageTime: '10:30 AM',
    unreadCount: 2,
    avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_103b528db-1763293982935.png",
    avatarAlt: 'Professional woman with long brown hair wearing white blouse smiling at camera'
  },
  {
    id: 2,
    name: 'Michael Chen',
    phone: '+1 (555) 234-5678',
    status: 'Available',
    isOnline: true,
    isTyping: false,
    lastSeen: 'today at 9:45 AM',
    lastMessage: 'Thanks for the update',
    lastMessageTime: '9:45 AM',
    unreadCount: 0,
    avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_1244e2e8b-1763298566706.png",
    avatarAlt: 'Asian man with short black hair in navy blue suit with confident smile'
  },
  {
    id: 3,
    name: 'Emma Wilson',
    phone: '+1 (555) 345-6789',
    status: 'Busy',
    isOnline: false,
    isTyping: false,
    lastSeen: 'yesterday at 8:20 PM',
    lastMessage: 'Call me when you can',
    lastMessageTime: 'Yesterday',
    unreadCount: 0,
    avatar: "https://images.unsplash.com/photo-1583892709436-4379c0927e16",
    avatarAlt: 'Young woman with blonde hair in casual attire with warm smile outdoors'
  }];


  const handleSelectConversation = (conversation) => {
    setSelectedConversation(conversation);
    setIsSidebarOpen(false); // Close sidebar on mobile when selecting conversation
  };

  const handleRealtimeMessage = (update) => {
    if (update?.type === 'new') {
      setMessages((prev) => [...prev, update?.message]);

      // Auto-mark as read if window is focused
      if (document.hasFocus() && !update?.message?.isSent) {
        setTimeout(() => {
          messageService?.updateMessageStatus(update?.message?.id, 'read');
        }, 1000);
      }
    } else if (update?.type === 'update') {
      setMessages((prev) =>
      prev?.map((msg) =>
      msg?.id === update?.message?.id ?
      { ...msg, ...update?.message } :
      msg
      )
      );
    }
  };

  const handleTypingUpdate = (update) => {
    setTypingUsers((prev) => {
      const newMap = new Map(prev);
      if (update?.isTyping) {
        newMap?.set(update?.userId, update?.userName);
      } else {
        newMap?.delete(update?.userId);
      }
      return newMap;
    });
  };

  const updateQueuedMessageCount = async () => {
    const queued = await offlineStorageService?.getQueuedMessages();
    setQueuedMessageCount(queued?.length);
  };

  const loadMessages = async (conversationId) => {
    // Don't attempt to load messages until auth is checked
    if (!authChecked || !currentUser) {
      return;
    }

    try {
      setLoading(true);
      setError('');

      // For mock conversations, we need to get the actual user UUID from the database
      // Since conversations use numeric IDs, we need to map them to actual user UUIDs
      // In a real app, you'd fetch the actual contact's UUID from your contacts table

      // For now, let's try to fetch messages but handle the case where contact might not exist
      try {
        const data = await messageService?.getMessages(conversationId);
        setMessages(data);

        // Mark unread messages as read
        const unreadMessages = data?.filter((msg) => !msg?.isSent && msg?.status !== 'read');
        if (unreadMessages?.length > 0) {
          await messageService?.markMessagesAsRead(unreadMessages?.map((msg) => msg?.id));
        }
      } catch (err) {
        // If contact doesn't exist in database, show friendly message
        if (err?.message?.includes('uuid') || err?.message?.includes('Not authenticated')) {
          setError('This contact is not registered in the system yet. Invite them to join ChatVybz!');
          setMessages([]);
        } else {
          throw err;
        }
      }
    } catch (err) {
      setError(err?.message);
      console.error('Error loading messages:', err);
    } finally {
      setLoading(false);
    }
  };

  // Load messages from Supabase when conversation is selected - Only if authenticated
  useEffect(() => {
    if (selectedConversation && authChecked && currentUser) {
      loadMessages(selectedConversation?.id);
    }
  }, [selectedConversation?.id, authChecked, currentUser]);

  // Subscribe to real-time message updates
  useEffect(() => {
    if (!selectedConversation) return;

    let unsubscribeMessages;
    let unsubscribeTyping;

    const setupSubscriptions = async () => {
      try {
        unsubscribeMessages = await messageService?.subscribeToMessages(
          selectedConversation?.id,
          handleRealtimeMessage
        );

        unsubscribeTyping = typingIndicatorService?.subscribeToTypingIndicators(
          selectedConversation?.id,
          handleTypingUpdate
        );
      } catch (error) {
        console.error('Error setting up message subscriptions:', error);
      }
    };

    setupSubscriptions();

    return () => {
      if (unsubscribeMessages) unsubscribeMessages();
      if (unsubscribeTyping) unsubscribeTyping();
    };
  }, [selectedConversation?.id]);

  // Monitor connection status
  useEffect(() => {
    const unsubscribe = connectionMonitor?.subscribe(async (status) => {
      setIsOnline(status?.isOnline);

      if (status?.isOnline && status?.event === 'online') {
        // Connection restored - process queue
        await messageService?.processMessageQueue();
        updateQueuedMessageCount();
      }
    });

    // Initial queue count
    updateQueuedMessageCount();

    return () => unsubscribe();
  }, []);

  useEffect(() => {
    if (location?.state?.conversationId) {
      const conversation = conversations?.find((c) => c?.id === location?.state?.conversationId);
      if (conversation) {
        setSelectedConversation(conversation);
      }
    } else if (location?.state?.contactId) {
      const conversation = conversations?.find((c) => c?.id === location?.state?.contactId);
      if (conversation) {
        setSelectedConversation(conversation);
      }
    }
  }, [location?.state]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef?.current?.scrollIntoView({ behavior: 'smooth' });
  };

  // Load contacts for forwarding
  useEffect(() => {
    const loadContacts = async () => {
      if (!currentUser) return;

      try {
        const { data, error } = await supabase?.
        from('user_contacts')?.
        select(`
            id,
            contact_name,
            platform_user:platform_user_id(
              id,
              full_name,
              avatar_url
            )
          `)?.
        eq('user_id', currentUser?.id)?.
        eq('is_platform_user', true);

        if (error) throw error;

        const formattedContacts = data?.map((contact) => ({
          id: contact?.platform_user?.id,
          name: contact?.platform_user?.full_name || contact?.contact_name,
          avatar: contact?.platform_user?.avatar_url
        })) || [];

        setContacts(formattedContacts);
      } catch (error) {
        console.error('Error loading contacts:', error);
      }
    };

    loadContacts();
  }, [currentUser]);

  // Generate Claude AI suggestions when receiving new message
  useEffect(() => {
    const handleNewMessage = async (newMessage) => {
      // Only generate suggestions for received messages (not sent by current user)
      if (newMessage?.sender_id !== currentUser?.id && selectedConversation) {
        try {
          const suggestions = await generateClaudeQuickResponses(
            newMessage?.message,
            selectedConversation?.id,
            currentUser?.id
          );
          // Suggestions will be displayed in MessageInput component
        } catch (error) {
          console.error('Error generating AI suggestions:', error);
        }
      }
    };

    // Subscribe to new messages for AI suggestions
    if (selectedConversation && currentUser) {
      const channel = supabase?.
      channel(`messages:${selectedConversation?.id}`)?.
      on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'chat_messages',
          filter: `recipient_id=eq.${currentUser?.id}`
        },
        (payload) => handleNewMessage(payload?.new)
      )?.
      subscribe();

      return () => {
        channel?.unsubscribe();
      };
    }
  }, [selectedConversation, currentUser]);

  const handleSendMessage = async (messageData) => {
    if (!selectedConversation || !currentUser) return;

    try {
      const messageContent = messageData?.content || messageData;

      // Create message in database
      const { data: newMessage, error } = await supabase?.
      from('chat_messages')?.
      insert({
        sender_id: currentUser?.id,
        recipient_id: selectedConversation?.id,
        message: messageContent,
        sender_name: currentUser?.name,
        status: 'sent',
        parent_message_id: messageData?.replyTo || null
      })?.
      select()?.
      single();

      if (error) throw error;

      // Return message for attachment upload
      return newMessage;
    } catch (error) {
      console.error('Error sending message:', error);
      throw error;
    }
  };

  const handleTyping = async (isTyping) => {
    if (!selectedConversation) return;

    try {
      await typingIndicatorService?.updateTypingStatus(selectedConversation?.id, isTyping);

      // Clear typing after 3 seconds
      if (isTyping) {
        if (typingTimeoutRef?.current) {
          clearTimeout(typingTimeoutRef?.current);
        }
        typingTimeoutRef.current = setTimeout(() => {
          typingIndicatorService?.updateTypingStatus(selectedConversation?.id, false);
        }, 3000);
      }
    } catch (err) {
      console.error('Error updating typing status:', err);
    }
  };

  const handleReaction = async (messageId, emoji) => {
    try {
      await messageService?.toggleReaction(messageId, emoji);

      // Refresh messages to show updated reactions
      await loadMessages(selectedConversation?.id);
    } catch (err) {
      setError(err?.message);
      console.error('Error toggling reaction:', err);
    }
  };

  const handleMessageFailure = (messageId) => {
    setSelectedFailedMessage(messageId);
    setShowDeliveryAnalysis(true);
  };

  const handleRetryFailedMessage = async () => {
    try {
      if (selectedFailedMessage) {
        // Check if should retry
        const retryCheck = await deliveryAnalysisService?.shouldRetryMessage(selectedFailedMessage);

        if (retryCheck?.shouldRetry) {
          await messageService?.retryQueuedMessage(selectedFailedMessage);
          setShowDeliveryAnalysis(false);
          setSelectedFailedMessage(null);
          await loadMessages(selectedConversation?.id);
        } else {
          setError(retryCheck?.reason || 'Cannot retry at this time');
        }
      }
    } catch (err) {
      setError(err?.message || 'Failed to retry message');
    }
  };

  const handleEditMessage = async (messageId, newContent) => {
    try {
      await messageService?.editMessage(messageId, newContent);

      // Refresh messages to show edited content
      await loadMessages(selectedConversation?.id);
    } catch (err) {
      setError(err?.message);
      console.error('Error editing message:', err);
    }
  };

  const handleDeleteMessage = async (messageId, deleteForEveryone = false) => {
    try {
      await messageService?.deleteMessageWithVisibility(messageId, deleteForEveryone);

      // Refresh messages
      await loadMessages(selectedConversation?.id);
    } catch (err) {
      setError(err?.message);
      console.error('Error deleting message:', err);
    }
  };

  const handleForwardMessage = (message) => {
    navigate('/contact-management', { state: { forwardMessage: message } });
  };

  const handleReplyMessage = (message) => {
    setReplyingTo({
      sender: message?.isSent ? 'You' : selectedConversation?.name,
      content: message?.content || 'Media message'
    });
  };

  const handleMediaClick = (files) => {
    setIsMediaOverlayOpen(true);
  };

  const handleMediaSend = (mediaData) => {
    mediaData?.files?.forEach((file, index) => {
      setTimeout(() => {
        handleSendMessage({
          type: file?.type,
          mediaUrl: file?.url,
          mediaAlt: `Shared ${file?.type} file from user showing content uploaded on ${new Date()?.toLocaleDateString()}`,
          caption: index === 0 ? mediaData?.caption : '',
          timestamp: new Date()
        });
      }, index * 100);
    });
  };

  const handleVoiceRecord = (isRecording) => {
    if (!isRecording) {
      handleSendMessage({
        type: 'audio',
        duration: '0:05',
        content: 'Voice message',
        timestamp: new Date()
      });
    }
  };

  const handleVideoCall = () => {
    console.log('Starting video call with', selectedConversation?.name);
  };

  const handleVoiceCall = () => {
    console.log('Starting voice call with', selectedConversation?.name);
  };

  const handleBlockContact = () => {
    console.log('Blocking contact:', selectedConversation?.name);
    setIsContactInfoOpen(false);
  };

  const handleClearChat = async () => {
    try {
      // Delete all messages for this conversation
      for (const message of messages) {
        await messageService?.deleteMessage(message?.id);
      }
      setMessages([]);
      setIsContactInfoOpen(false);
    } catch (err) {
      setError(err?.message);
      console.error('Error clearing chat:', err);
    }
  };

  const handleDeleteChat = async () => {
    try {
      await handleClearChat();
      setSelectedConversation(null);
    } catch (err) {
      setError(err?.message);
      console.error('Error deleting chat:', err);
    }
  };

  const isTyping = typingUsers?.size > 0;
  const typingUserNames = Array.from(typingUsers?.values());

  useEffect(() => {
    // Initialize push notifications
    if (currentUser?.id) {
      initializePushNotifications();
    }

    return () => {
      // Cleanup notifications on unmount
      if (currentUser?.id) {
        pushNotificationService?.unsubscribe(currentUser?.id);
      }
    };
  }, [currentUser?.id]);

  const initializePushNotifications = async () => {
    if (!pushNotificationService?.isSupported()) {
      console.log('Push notifications not supported');
      return;
    }

    try {
      const result = await pushNotificationService?.initialize(currentUser?.id);
      if (result?.success) {
        setNotificationsEnabled(true);
        console.log('Push notifications enabled');
      }
    } catch (error) {
      console.error('Failed to initialize push notifications:', error);
    }
  };

  const toggleNotifications = async () => {
    if (notificationsEnabled) {
      const result = await pushNotificationService?.unsubscribe(currentUser?.id);
      if (result?.success) {
        setNotificationsEnabled(false);
      }
    } else {
      const result = await pushNotificationService?.initialize(currentUser?.id);
      if (result?.success) {
        setNotificationsEnabled(true);
      }
    }
  };

  // Cleanup presence on unmount
  useEffect(() => {
    return () => {
      presenceService?.cleanup();
    };
  }, []);

  // Show loading screen while checking authentication
  if (!authChecked) {
    return (
      <div className="flex h-screen items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading ChatVybz...</p>
        </div>
      </div>);

  }

  // Don't render if not authenticated (will redirect)
  if (!currentUser) {
    return null;
  }

  useEffect(() => {
    if (user?.id) {
      loadPinnedConversations();
    }
  }, [user]);

  const loadPinnedConversations = async () => {
    try {
      const { conversationPinService } = await import('../../services/conversationPinService');
      const pinned = await conversationPinService?.getPinnedConversations(user?.id);
      const count = await conversationPinService?.getPinnedCount(user?.id);
      setPinnedConversations(pinned);
      setPinnedCount(count);
    } catch (error) {
      console.error('Error loading pinned conversations:', error);
    }
  };

  const handleTogglePin = async (conversationId) => {
    try {
      const { conversationPinService } = await import('../../services/conversationPinService');
      const result = await conversationPinService?.togglePin(user?.id, conversationId?.toString(), 'direct');

      if (result?.success) {
        await loadPinnedConversations();
      }
    } catch (error) {
      console.error('Error toggling pin:', error);
    }
  };

  const isConversationPinned = (conversationId) => {
    return pinnedConversations?.some((pin) => pin?.conversation_id === conversationId?.toString());
  };

  // Sort conversations: pinned first, then by last message time
  const sortedConversations = [...conversations]?.sort((a, b) => {
    const aIsPinned = isConversationPinned(a?.id);
    const bIsPinned = isConversationPinned(b?.id);

    if (aIsPinned && !bIsPinned) return -1;
    if (!aIsPinned && bIsPinned) return 1;
    return 0;
  });

  // Show loading screen while checking authentication
  if (!authChecked) {
    return (
      <div className="flex h-screen items-center justify-center bg-gray-50">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading ChatVybz...</p>
        </div>
      </div>);

  }

  // Don't render if not authenticated (will redirect)
  if (!currentUser) {
    return null;
  }

  return (
    <div className="flex flex-col h-screen bg-background">
      {/* Mobile Header - Enhanced for better touch targets */}
      <div className="lg:hidden fixed top-0 left-0 right-0 z-50 bg-white border-b border-gray-200 safe-area-inset-top">
        <div className="flex items-center justify-between px-3 sm:px-4 py-3 min-h-[60px]">
          {!selectedConversation ?
          <>
              <div className="flex items-center gap-2 sm:gap-3">
                <div className="w-10 h-10 sm:w-12 sm:h-12 bg-primary rounded-full flex items-center justify-center flex-shrink-0">
                  <Icon name="MessageCircle" size={20} color="#FFFFFF" className="sm:w-6 sm:h-6" />
                </div>
                <h1 className="text-base sm:text-lg font-bold truncate">ChatVybz</h1>
              </div>
              <div className="flex items-center gap-1 sm:gap-2">
                <button
                onClick={() => setIsContactPanelOpen(true)}
                className="p-2 sm:p-2.5 rounded-lg hover:bg-gray-100 active:bg-gray-200 transition-colors touch-manipulation"
                aria-label="Open contacts">

                  <Icon name="Users" size={20} color="var(--color-foreground)" className="sm:w-6 sm:h-6" />
                </button>
                <ProfileSettingsTrigger />
              </div>
            </> :

          <>
              <button
              onClick={() => setSelectedConversation(null)}
              className="p-2 sm:p-2.5 rounded-lg hover:bg-gray-100 active:bg-gray-200 transition-colors touch-manipulation flex-shrink-0"
              aria-label="Back to conversations">

                <Icon name="ArrowLeft" size={20} color="var(--color-foreground)" className="sm:w-6 sm:h-6" />
              </button>
              <div className="flex-1 flex items-center gap-2 sm:gap-3 min-w-0 mx-2 sm:mx-3">
                <img
                src={selectedConversation?.avatar}
                alt={selectedConversation?.avatarAlt}
                className="w-9 h-9 sm:w-10 sm:h-10 rounded-full object-cover flex-shrink-0" />

                <div className="flex-1 min-w-0">
                  <h2 className="font-semibold text-sm sm:text-base truncate">{selectedConversation?.name}</h2>
                  <p className="text-xs sm:text-sm text-gray-600 truncate">
                    {selectedConversation?.isOnline ? 'Online' : selectedConversation?.lastSeen}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-1">
                <button
                onClick={handleVideoCall}
                className="p-2 sm:p-2.5 rounded-lg hover:bg-gray-100 active:bg-gray-200 transition-colors touch-manipulation"
                aria-label="Video call">

                  <Icon name="Video" size={18} color="var(--color-foreground)" className="sm:w-5 sm:h-5" />
                </button>
                <button
                onClick={handleVoiceCall}
                className="p-2 sm:p-2.5 rounded-lg hover:bg-gray-100 active:bg-gray-200 transition-colors touch-manipulation"
                aria-label="Voice call">

                  <Icon name="Phone" size={18} color="var(--color-foreground)" className="sm:w-5 sm:h-5" />
                </button>
                <button
                onClick={() => setIsContactInfoOpen(true)}
                className="p-2 sm:p-2.5 rounded-lg hover:bg-gray-100 active:bg-gray-200 transition-colors touch-manipulation"
                aria-label="Contact info">

                  <Icon name="MoreVertical" size={18} color="var(--color-foreground)" className="sm:w-5 sm:h-5" />
                </button>
              </div>
            </>
          }
        </div>

        {/* Connection Status Banner - Mobile - Enhanced visibility */}
        {!isOnline &&
        <div className="px-3 sm:px-4 py-2.5 bg-yellow-500/10 border-b border-yellow-500/20">
            <div className="flex items-center gap-2">
              <Icon name="WifiOff" size={16} color="#EAB308" />
              <p className="text-xs sm:text-sm font-medium text-yellow-600">You're offline - Messages will be sent when reconnected</p>
            </div>
          </div>
        }
      </div>
      {/* Desktop Sidebar / Mobile Conversation List - Enhanced scrolling */}
      <div className={`
        fixed lg:static inset-y-0 left-0 z-40
        w-full sm:w-96 lg:w-80 xl:w-96
        bg-white border-r border-gray-200 flex flex-col
        transform transition-transform duration-300 ease-in-out
        ${selectedConversation ? 'lg:flex hidden' : 'flex'}
        pt-[60px] lg:pt-0
        overscroll-contain
      `}>
        {/* Desktop Header */}
        <div className="hidden lg:flex items-center justify-between px-4 xl:px-6 py-4 border-b border-gray-200 flex-shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
              <Icon name="MessageCircle" size={20} color="#FFFFFF" />
            </div>
            <h1 className="text-xl font-bold">ChatVybz</h1>
            
            {/* Connection Status - Desktop */}
            {!isOnline &&
            <div className="flex items-center gap-2 px-2 py-1 bg-destructive/10 rounded-lg">
                <div className="w-2 h-2 bg-destructive rounded-full animate-pulse" />
                <span className="text-xs font-medium text-destructive">Offline</span>
              </div>
            }
            
            {/* Queued Messages */}
            {queuedMessageCount > 0 &&
            <div className="flex items-center gap-2 px-2 py-1 bg-yellow-500/10 rounded-lg">
                <Icon name="Clock" size={12} color="#EAB308" />
                <span className="text-xs font-medium text-yellow-600">
                  {queuedMessageCount}
                </span>
              </div>
            }
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsContactPanelOpen(true)}
              className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
              aria-label="Open contacts">

              <Icon name="Users" size={20} color="var(--color-foreground)" />
            </button>
            <button
              onClick={() => navigate('/semantic-search-interface')}
              className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
              aria-label="Semantic Search"
              title="AI-Powered Search">

              <Icon name="Sparkles" size={20} color="var(--color-foreground)" />
            </button>
            <button
              onClick={() => navigate('/call-analytics-dashboard')}
              className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
              aria-label="Call Analytics"
              title="Analytics Dashboard">

              <Icon name="BarChart3" size={20} color="var(--color-foreground)" />
            </button>
            <ProfileSettingsTrigger />
          </div>
        </div>

        {/* Search Bar - Enhanced for touch */}
        <div className="px-3 sm:px-4 py-3 border-b border-gray-200 flex-shrink-0">
          <div className="relative">
            <Icon
              name="Search"
              size={18}
              color="var(--color-muted-foreground)"
              className="absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />

            <input
              type="search"
              inputMode="search"
              placeholder="Search conversations..."
              className="w-full pl-10 pr-4 py-2.5 bg-gray-50 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary touch-manipulation" />

          </div>
        </div>

        {/* Notification Toggle */}
        <div className="px-3 sm:px-4 py-2 border-b border-gray-200 flex-shrink-0">
          <button
            onClick={toggleNotifications}
            className={`w-full px-3 py-2.5 rounded-lg text-sm font-medium transition-colors touch-manipulation ${
            notificationsEnabled ?
            'bg-green-100 text-green-700 hover:bg-green-200 active:bg-green-300' : 'bg-gray-100 text-gray-700 hover:bg-gray-200 active:bg-gray-300'}`
            }>

            {notificationsEnabled ? '🔔 Notifications On' : '🔕 Notifications Off'}
          </button>
        </div>

        {/* Conversations List - Enhanced scrolling performance */}
        <div className="flex-1 overflow-y-auto overscroll-contain -webkit-overflow-scrolling-touch">
          {pinnedCount > 0 &&
          <div className="px-4 py-2 bg-primary/5 border-b border-border">
              <p className="text-xs font-semibold text-primary flex items-center gap-1">
                <Icon name="Pin" size={12} />
                {pinnedCount} Pinned Conversation{pinnedCount !== 1 ? 's' : ''}
              </p>
            </div>
          }
          {sortedConversations?.map((conversation) => {
            const isPinned = isConversationPinned(conversation?.id);
            return (
              <div key={conversation?.id} className="relative group">
                <button
                  onClick={() => handleSelectConversation(conversation)}
                  className={`w-full px-3 sm:px-4 py-3 flex items-center gap-3 hover:bg-gray-50 active:bg-gray-100 transition-colors border-b border-gray-100 touch-manipulation ${
                  selectedConversation?.id === conversation?.id ? 'bg-primary/5' : ''} ${

                  isPinned ? 'bg-primary/5' : ''}`
                  }>

                  <div className="relative flex-shrink-0">
                    <img
                      src={conversation?.avatar}
                      alt={conversation?.avatarAlt}
                      className="w-12 h-12 sm:w-14 sm:h-14 rounded-full object-cover"
                      loading="lazy" />

                    {conversation?.isOnline &&
                    <div className="absolute bottom-0 right-0 w-3 h-3 sm:w-3.5 sm:h-3.5 bg-green-500 rounded-full border-2 border-white" />
                    }
                  </div>
                  <div className="flex-1 min-w-0 text-left">
                    <div className="flex items-center justify-between mb-1 gap-2">
                      <div className="flex items-center gap-2 flex-1 min-w-0">
                        <h3 className="font-semibold text-sm sm:text-base truncate">
                          {conversation?.name}
                        </h3>
                        {isPinned &&
                        <Icon name="Pin" size={14} className="text-primary flex-shrink-0" />
                        }
                      </div>
                      <span className="text-xs text-gray-500 flex-shrink-0">
                        {conversation?.lastMessageTime}
                      </span>
                    </div>
                    <div className="flex items-center justify-between gap-2">
                      <p className="text-sm text-gray-600 truncate flex-1">
                        {conversation?.lastMessage}
                      </p>
                      {conversation?.unreadCount > 0 &&
                      <span className="flex-shrink-0 min-w-[20px] h-5 px-1.5 bg-primary text-white text-xs rounded-full flex items-center justify-center font-medium">
                          {conversation?.unreadCount > 99 ? '99+' : conversation?.unreadCount}
                        </span>
                      }
                    </div>
                  </div>
                </button>
                {/* Pin/Unpin Button */}
                <button
                  onClick={(e) => {
                    e?.stopPropagation();
                    handleTogglePin(conversation?.id);
                  }}
                  className="absolute right-2 top-1/2 -translate-y-1/2 p-2 rounded-lg bg-white border border-border shadow-sm opacity-0 group-hover:opacity-100 transition-opacity hover:bg-gray-50"
                  title={isPinned ? 'Unpin conversation' : 'Pin conversation'}>

                  <Icon
                    name="Pin"
                    size={16}
                    className={isPinned ? 'text-primary' : 'text-muted-foreground'} />

                </button>
              </div>);

          })}
        </div>
      </div>
      {/* Main Content */}
      <div className="flex-1 flex overflow-hidden">
        {/* Chat Area */}
        {selectedConversation ?
        <div className="flex-1 flex flex-col">
            {/* Chat Header with new action buttons */}
            <ChatHeader
            contact={selectedConversation}
            onBack={() => setSelectedConversation(null)}
            onToggleInfo={() => setIsContactInfoOpen(!isContactInfoOpen)}
            onlineStatus={onlineUsers?.some((u) => u?.userId === selectedConversation?.id)}
            onLocationShare={() => setShowLocationShare(true)}
            onDisappearingMessages={() => setShowDisappearingMessages(true)} />


            {/* Messages Area */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              {loading ?
            <div className="flex items-center justify-center h-full">
                  <Icon name="Loader" size={32} className="animate-spin text-muted-foreground" />
                </div> :
            error ?
            <div className="flex items-center justify-center h-full">
                  <div className="text-center">
                    <Icon name="AlertCircle" size={48} color="var(--color-destructive)" />
                    <p className="mt-2 text-destructive">{error}</p>
                  </div>
                </div> :
            messages?.length === 0 ?
            <div className="flex items-center justify-center h-full">
                  <div className="text-center text-muted-foreground">
                    <Icon name="MessageSquare" size={48} color="var(--color-muted-foreground)" />
                    <p className="mt-2">No messages yet. Start the conversation!</p>
                  </div>
                </div> :

            messages?.map((msg) =>
            <MessageBubble
              key={msg?.id}
              message={msg}
              isOwn={msg?.sender_id === currentUser?.id}
              onDelete={handleDeleteMessage}
              onReply={setReplyingTo}
              onEdit={handleEditMessage}
              onReaction={handleReaction}
              contacts={contacts} />

            )
            }
              <div ref={messagesEndRef} />
            </div>

            {/* Expiring Messages Notification */}
            {expiringMessages?.length > 0 &&
          <div className="px-4 py-2 bg-orange-50 border-b border-orange-200">
                <div className="flex items-center gap-2 text-sm text-orange-800">
                  <Icon name="Clock" size={16} />
                  <span>
                    {expiringMessages?.length} message{expiringMessages?.length > 1 ? 's' : ''} expiring soon
                  </span>
                  <button
                onClick={() => setShowDisappearingMessages(true)}
                className="ml-auto text-orange-600 hover:text-orange-700 font-medium">

                    View
                  </button>
                </div>
              </div>
          }

            {/* Typing Indicator */}
            {typingUsers?.size > 0 &&
          <TypingIndicator users={Array.from(typingUsers?.values())} />
          }

            {/* Message Input */}
            <MessageInput
            conversationId={selectedConversation?.id}
            onSendMessage={handleSendMessage}
            replyTo={replyingTo}
            onCancelReply={() => setReplyingTo(null)} />

          </div> :

        <div className="flex-1 flex items-center justify-center bg-muted/20">
            <div className="text-center">
              <Icon name="MessageSquare" size={64} color="var(--color-muted-foreground)" />
              <p className="mt-4 text-lg text-muted-foreground">Select a conversation to start chatting</p>
            </div>
          </div>
        }
      </div>
      {/* Modals */}
      <ContactAccessPanel
        isOpen={isContactPanelOpen}
        onClose={() => setIsContactPanelOpen(false)} />

      <ContactInfoPanel
        contact={selectedConversation}
        isOpen={isContactInfoOpen}
        onClose={() => setIsContactInfoOpen(false)}
        onBlock={handleBlockContact}
        onClearChat={handleClearChat}
        onDeleteChat={handleDeleteChat} />

      <MediaCompositionOverlay
        isOpen={isMediaOverlayOpen}
        onClose={() => setIsMediaOverlayOpen(false)}
        onSend={handleMediaSend}
        targetConversation={selectedConversation} />

      {/* Delivery Analysis Modal */}
      {showDeliveryAnalysis && selectedFailedMessage &&
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <DeliveryFailureAnalysis
          messageId={selectedFailedMessage}
          onRetry={handleRetryFailedMessage}
          onClose={() => {
            setShowDeliveryAnalysis(false);
            setSelectedFailedMessage(null);
          }} />

        </div>
      }
      {/* Live Location Share Modal */}
      {showLocationShare &&
      <LiveLocationShare
        conversationId={selectedConversation?.id}
        onClose={() => setShowLocationShare(false)} />

      }
      {/* Disappearing Messages Panel */}
      {showDisappearingMessages &&
      <DisappearingMessagesPanel
        conversationId={selectedConversation?.id}
        onClose={() => setShowDisappearingMessages(false)} />

      }
    </div>);

}