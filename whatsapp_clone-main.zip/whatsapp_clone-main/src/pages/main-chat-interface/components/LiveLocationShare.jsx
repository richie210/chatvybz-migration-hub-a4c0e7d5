import React, { useState, useEffect } from 'react';
import { Clock, MapPin, Navigation, X, Loader } from 'lucide-react';
import { locationSharingService } from '../../../services/locationSharingService';

const LiveLocationShare = ({ conversationId, onClose }) => {
  const [isSharing, setIsSharing] = useState(false);
  const [locationShare, setLocationShare] = useState(null);
  const [activeShares, setActiveShares] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [duration, setDuration] = useState(60);
  const [watchId, setWatchId] = useState(null);

  const handleLocationUpdate = (update) => {
    if (update?.type === 'new' || update?.type === 'update') {
      setActiveShares(prev => {
        const existing = prev?.find(s => s?.id === update?.location?.id);
        if (existing) {
          return prev?.map(s => s?.id === update?.location?.id ? update?.location : s);
        }
        return [...prev, update?.location];
      });
    } else if (update?.type === 'stopped') {
      setActiveShares(prev => prev?.filter(s => s?.id !== update?.locationId));
    }
  };

  useEffect(() => {
    loadActiveShares();

    // Subscribe to location updates
    const cleanup = locationSharingService?.subscribeToLocationUpdates(
      conversationId,
      handleLocationUpdate
    );

    return () => {
      if (cleanup) cleanup();
      if (watchId) {
        locationSharingService?.clearWatch(watchId);
      }
    };
  }, [conversationId, watchId]);

  const loadActiveShares = async () => {
    try {
      const shares = await locationSharingService?.getActiveLocationShares(conversationId);
      setActiveShares(shares);
    } catch (err) {
      console.error('Load active shares error:', err);
    }
  };

  const handleStartSharing = async () => {
    try {
      setLoading(true);
      setError('');

      const result = await locationSharingService?.startLocationSharing(conversationId, duration);
      
      if (result?.success) {
        setLocationShare(result?.locationShare);
        setIsSharing(true);

        // Start watching position for live updates
        const id = locationSharingService?.watchPosition(async (position) => {
          if (result?.locationShare?.id) {
            await locationSharingService?.updateLocationCoordinates(
              result?.locationShare?.id,
              position
            );
          }
        });
        setWatchId(id);
      }
    } catch (err) {
      setError(err?.message || 'Failed to start location sharing');
    } finally {
      setLoading(false);
    }
  };

  const handleStopSharing = async () => {
    try {
      if (locationShare?.id) {
        await locationSharingService?.stopLocationSharing(locationShare?.id);
        
        if (watchId) {
          locationSharingService?.clearWatch(watchId);
          setWatchId(null);
        }

        setIsSharing(false);
        setLocationShare(null);
      }
    } catch (err) {
      setError(err?.message || 'Failed to stop location sharing');
    }
  };

  const formatTimeRemaining = (expiresAt) => {
    if (!expiresAt) return '';

    const now = new Date();
    const expires = new Date(expiresAt);
    const diffMs = expires - now;

    if (diffMs <= 0) return 'Expired';

    const minutes = Math.floor(diffMs / 60000);
    const hours = Math.floor(minutes / 60);

    if (hours > 0) {
      return `${hours}h ${minutes % 60}m remaining`;
    }
    return `${minutes}m remaining`;
  };

  const openInMaps = (latitude, longitude) => {
    const url = `https://www.google.com/maps?q=${latitude},${longitude}`;
    window.open(url, '_blank');
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="sticky top-0 bg-white border-b border-gray-200 p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-blue-100 rounded-lg">
              <MapPin className="w-6 h-6 text-blue-600" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-900">Live Location</h3>
              <p className="text-sm text-gray-600">Share your real-time location</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-gray-600" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {error && (
            <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
              <p className="text-sm text-red-700">{error}</p>
            </div>
          )}

          {/* Start Sharing Section */}
          {!isSharing && (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Duration
                </label>
                <select
                  value={duration}
                  onChange={(e) => setDuration(parseInt(e?.target?.value))}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value={15}>15 minutes</option>
                  <option value={30}>30 minutes</option>
                  <option value={60}>1 hour</option>
                  <option value={120}>2 hours</option>
                  <option value={480}>8 hours</option>
                </select>
              </div>

              <button
                onClick={handleStartSharing}
                disabled={loading}
                className="w-full px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                {loading ? (
                  <>
                    <Loader className="w-5 h-5 animate-spin" />
                    <span>Starting...</span>
                  </>
                ) : (
                  <>
                    <Navigation className="w-5 h-5" />
                    <span>Start Sharing Location</span>
                  </>
                )}
              </button>

              <p className="text-xs text-gray-500 text-center">
                Your location will be shared in real-time for the selected duration
              </p>
            </div>
          )}

          {/* Active Sharing Status */}
          {isSharing && locationShare && (
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-blue-600 rounded-full animate-pulse"></div>
                  <span className="font-medium text-blue-900">Sharing Live Location</span>
                </div>
                <button
                  onClick={handleStopSharing}
                  className="px-3 py-1 bg-red-600 text-white text-sm rounded-lg hover:bg-red-700 transition-colors"
                >
                  Stop
                </button>
              </div>
              <div className="space-y-2 text-sm text-blue-800">
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4" />
                  <span>{formatTimeRemaining(locationShare?.expiresAt)}</span>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4" />
                  <span>
                    {locationShare?.latitude?.toFixed(6)}, {locationShare?.longitude?.toFixed(6)}
                  </span>
                </div>
                {locationShare?.accuracy && (
                  <div className="text-xs text-blue-600">
                    Accuracy: ±{Math.round(locationShare?.accuracy)}m
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Active Shares from Others */}
          {activeShares?.length > 0 && (
            <div>
              <h4 className="font-semibold text-gray-900 mb-3">Active Location Shares</h4>
              <div className="space-y-3">
                {activeShares?.map((share) => (
                  <div
                    key={share?.id}
                    className="border border-gray-200 rounded-lg p-4 hover:border-blue-300 transition-colors"
                  >
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-center gap-3">
                        {share?.user?.avatarUrl ? (
                          <img
                            src={share?.user?.avatarUrl}
                            alt={share?.user?.fullName}
                            className="w-10 h-10 rounded-full object-cover"
                          />
                        ) : (
                          <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center">
                            <span className="text-purple-600 font-medium">
                              {share?.user?.fullName?.charAt(0)?.toUpperCase()}
                            </span>
                          </div>
                        )}
                        <div>
                          <div className="font-medium text-gray-900">
                            {share?.user?.fullName}
                          </div>
                          <div className="text-xs text-gray-500">
                            {formatTimeRemaining(share?.expiresAt)}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-1">
                        <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
                        <span className="text-xs text-green-600">Live</span>
                      </div>
                    </div>

                    <div className="space-y-2 text-sm text-gray-600">
                      <div className="flex items-center gap-2">
                        <MapPin className="w-4 h-4" />
                        <span>
                          {share?.latitude?.toFixed(6)}, {share?.longitude?.toFixed(6)}
                        </span>
                      </div>
                      {share?.speed !== null && share?.speed > 0 && (
                        <div className="flex items-center gap-2">
                          <Navigation className="w-4 h-4" />
                          <span>{Math.round(share?.speed * 3.6)} km/h</span>
                        </div>
                      )}
                    </div>

                    <button
                      onClick={() => openInMaps(share?.latitude, share?.longitude)}
                      className="mt-3 w-full px-4 py-2 bg-blue-600 text-white text-sm rounded-lg hover:bg-blue-700 transition-colors flex items-center justify-center gap-2"
                    >
                      <MapPin className="w-4 h-4" />
                      <span>View on Map</span>
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeShares?.length === 0 && !isSharing && (
            <div className="text-center py-8">
              <MapPin className="w-12 h-12 text-gray-400 mx-auto mb-3" />
              <p className="text-gray-600">No active location shares</p>
              <p className="text-sm text-gray-500 mt-1">
                Start sharing to let others see your live location
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default LiveLocationShare;