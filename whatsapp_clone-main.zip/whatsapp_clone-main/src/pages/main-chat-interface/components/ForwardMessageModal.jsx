import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import { X, Search, Check } from 'lucide-react';

const ForwardMessageModal = ({ isOpen, onClose, onForward, contacts = [] }) => {
  const [selectedContacts, setSelectedContacts] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [forwarding, setForwarding] = useState(false);

  if (!isOpen) return null;

  const filteredContacts = contacts?.filter(contact =>
    contact?.name?.toLowerCase()?.includes(searchQuery?.toLowerCase())
  );

  const toggleContact = (contactId) => {
    setSelectedContacts(prev =>
      prev?.includes(contactId)
        ? prev?.filter(id => id !== contactId)
        : [...prev, contactId]
    );
  };

  const handleForward = async () => {
    if (selectedContacts?.length === 0) return;

    setForwarding(true);
    try {
      await onForward(selectedContacts);
      setSelectedContacts([]);
      setSearchQuery('');
      onClose();
    } catch (error) {
      console.error('Error forwarding message:', error);
    } finally {
      setForwarding(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md max-h-[80vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900">Forward Message</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X className="w-5 h-5 text-gray-500" />
          </button>
        </div>

        {/* Search */}
        <div className="p-4 border-b border-gray-200">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search contacts..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e?.target?.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent"
            />
          </div>
        </div>

        {/* Contact List */}
        <div className="flex-1 overflow-y-auto p-4">
          {filteredContacts?.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <Icon name="Users" size={48} color="var(--color-muted-foreground)" />
              <p className="mt-2">No contacts found</p>
            </div>
          ) : (
            <div className="space-y-2">
              {filteredContacts?.map((contact) => {
                const isSelected = selectedContacts?.includes(contact?.id);
                return (
                  <button
                    key={contact?.id}
                    onClick={() => toggleContact(contact?.id)}
                    className={`w-full flex items-center gap-3 p-3 rounded-lg transition-colors ${
                      isSelected
                        ? 'bg-primary/10 border-2 border-primary' :'bg-gray-50 hover:bg-gray-100 border-2 border-transparent'
                    }`}
                  >
                    <div className="relative flex-shrink-0">
                      {contact?.avatar ? (
                        <img
                          src={contact?.avatar}
                          alt={contact?.name}
                          className="w-12 h-12 rounded-full object-cover"
                        />
                      ) : (
                        <div className="w-12 h-12 rounded-full bg-gradient-to-br from-primary to-primary/70 flex items-center justify-center text-white font-semibold">
                          {contact?.name?.charAt(0)?.toUpperCase()}
                        </div>
                      )}
                      {isSelected && (
                        <div className="absolute -top-1 -right-1 w-5 h-5 bg-primary rounded-full flex items-center justify-center">
                          <Check className="w-3 h-3 text-white" />
                        </div>
                      )}
                    </div>
                    <div className="flex-1 text-left">
                      <p className="font-medium text-gray-900">{contact?.name}</p>
                      {contact?.status && (
                        <p className="text-sm text-gray-500">{contact?.status}</p>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-gray-200 bg-gray-50">
          <div className="flex items-center justify-between mb-3">
            <p className="text-sm text-gray-600">
              {selectedContacts?.length} contact{selectedContacts?.length !== 1 ? 's' : ''} selected
            </p>
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              onClick={onClose}
              className="flex-1"
              disabled={forwarding}
            >
              Cancel
            </Button>
            <Button
              variant="default"
              onClick={handleForward}
              className="flex-1"
              disabled={selectedContacts?.length === 0 || forwarding}
              iconName={forwarding ? 'Loader' : 'Send'}
              iconPosition="left"
            >
              {forwarding ? 'Forwarding...' : 'Forward'}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ForwardMessageModal;