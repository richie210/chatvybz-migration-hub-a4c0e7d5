import React, { useState, useEffect } from 'react';
import { AlertCircle, Clock, RefreshCw, Sparkles, TrendingUp, Zap } from 'lucide-react';
import { deliveryAnalysisService } from '../../../services/deliveryAnalysisService';

const DeliveryFailureAnalysis = ({ messageId, onRetry, onClose }) => {
  const [analysis, setAnalysis] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [retrying, setRetrying] = useState(false);

  useEffect(() => {
    if (messageId) {
      analyzeFailure();
    }
  }, [messageId]);

  const analyzeFailure = async () => {
    try {
      setLoading(true);
      setError('');
      const result = await deliveryAnalysisService?.analyzeDeliveryFailure(messageId);
      setAnalysis(result);
    } catch (err) {
      setError(err?.message || 'Failed to analyze delivery failure');
    } finally {
      setLoading(false);
    }
  };

  const handleRetry = async () => {
    try {
      setRetrying(true);
      await onRetry?.();
      onClose?.();
    } catch (err) {
      setError(err?.message || 'Retry failed');
    } finally {
      setRetrying(false);
    }
  };

  const getCategoryIcon = (category) => {
    switch (category) {
      case 'network':
        return <Zap className="w-5 h-5 text-orange-600" />;
      case 'recipient_offline':
        return <Clock className="w-5 h-5 text-blue-600" />;
      case 'content_issue':
        return <AlertCircle className="w-5 h-5 text-red-600" />;
      case 'rate_limit':
        return <TrendingUp className="w-5 h-5 text-purple-600" />;
      default:
        return <AlertCircle className="w-5 h-5 text-gray-600" />;
    }
  };

  const getCategoryColor = (category) => {
    switch (category) {
      case 'network':
        return 'bg-orange-50 border-orange-200';
      case 'recipient_offline':
        return 'bg-blue-50 border-blue-200';
      case 'content_issue':
        return 'bg-red-50 border-red-200';
      case 'rate_limit':
        return 'bg-purple-50 border-purple-200';
      default:
        return 'bg-gray-50 border-gray-200';
    }
  };

  const getConfidenceBadge = (confidence) => {
    const colors = {
      high: 'bg-green-100 text-green-800',
      medium: 'bg-yellow-100 text-yellow-800',
      low: 'bg-gray-100 text-gray-800'
    };

    return (
      <span className={`px-2 py-1 rounded-full text-xs font-medium ${colors?.[confidence] || colors?.low}`}>
        {confidence?.toUpperCase()} CONFIDENCE
      </span>
    );
  };

  if (loading) {
    return (
      <div className="bg-white rounded-xl p-6 shadow-lg">
        <div className="flex items-center justify-center py-8">
          <div className="text-center">
            <Sparkles className="w-8 h-8 text-purple-600 animate-pulse mx-auto mb-3" />
            <p className="text-gray-600">Analyzing delivery failure with AI...</p>
          </div>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-white rounded-xl p-6 shadow-lg">
        <div className="flex items-start gap-3 p-4 bg-red-50 border border-red-200 rounded-lg">
          <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
          <div className="flex-1">
            <p className="text-sm font-medium text-red-900 mb-1">Analysis Failed</p>
            <p className="text-sm text-red-700">{error}</p>
          </div>
        </div>
        <div className="flex gap-3 mt-4">
          <button
            onClick={analyzeFailure}
            className="flex-1 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
          >
            Try Again
          </button>
          <button
            onClick={onClose}
            className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    );
  }

  if (!analysis) return null;

  return (
    <div className="bg-white rounded-xl shadow-lg overflow-hidden">
      {/* Header */}
      <div className="bg-gradient-to-r from-purple-600 to-blue-600 p-6 text-white">
        <div className="flex items-center gap-3 mb-2">
          <Sparkles className="w-6 h-6" />
          <h3 className="text-xl font-semibold">AI Delivery Analysis</h3>
        </div>
        <p className="text-purple-100 text-sm">Powered by Claude AI</p>
      </div>

      {/* Content */}
      <div className="p-6 space-y-6">
        {/* Failure Category */}
        <div className={`p-4 rounded-lg border ${getCategoryColor(analysis?.failureCategory)}`}>
          <div className="flex items-center gap-3 mb-2">
            {getCategoryIcon(analysis?.failureCategory)}
            <div className="flex-1">
              <h4 className="font-semibold text-gray-900 capitalize">
                {analysis?.failureCategory?.replace('_', ' ')}
              </h4>
            </div>
            {getConfidenceBadge(analysis?.confidence)}
          </div>
          <p className="text-sm text-gray-700 mt-2">{analysis?.reasoning}</p>
        </div>

        {/* Resend Timing */}
        {analysis?.suggestedResendTime && (
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <Clock className="w-5 h-5 text-blue-600" />
              <h4 className="font-semibold text-gray-900">Optimal Resend Time</h4>
            </div>
            <p className="text-sm text-gray-700 mb-2">
              Wait {analysis?.resendDelayMinutes} minutes for best delivery chance
            </p>
            <p className="text-xs text-blue-600">
              Suggested: {new Date(analysis?.suggestedResendTime)?.toLocaleString()}
            </p>
          </div>
        )}

        {/* Format Suggestions */}
        {analysis?.formatSuggestions?.length > 0 && (
          <div>
            <h4 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-purple-600" />
              Format Improvements
            </h4>
            <ul className="space-y-2">
              {analysis?.formatSuggestions?.map((suggestion, idx) => (
                <li key={idx} className="flex items-start gap-2 text-sm text-gray-700">
                  <span className="text-purple-600 mt-0.5">•</span>
                  <span>{suggestion}</span>
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* Content Recommendations */}
        {analysis?.contentRecommendations?.length > 0 && (
          <div>
            <h4 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-purple-600" />
              Content Recommendations
            </h4>
            <ul className="space-y-2">
              {analysis?.contentRecommendations?.map((recommendation, idx) => (
                <li key={idx} className="flex items-start gap-2 text-sm text-gray-700">
                  <span className="text-purple-600 mt-0.5">•</span>
                  <span>{recommendation}</span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>

      {/* Actions */}
      <div className="p-6 bg-gray-50 border-t border-gray-200 flex gap-3">
        <button
          onClick={handleRetry}
          disabled={retrying}
          className="flex-1 px-4 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed flex items-center justify-center gap-2"
        >
          {retrying ? (
            <>
              <RefreshCw className="w-5 h-5 animate-spin" />
              <span>Retrying...</span>
            </>
          ) : (
            <>
              <RefreshCw className="w-5 h-5" />
              <span>Retry Now</span>
            </>
          )}
        </button>
        <button
          onClick={onClose}
          className="px-4 py-3 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
        >
          Close
        </button>
      </div>
    </div>
  );
};

export default DeliveryFailureAnalysis;