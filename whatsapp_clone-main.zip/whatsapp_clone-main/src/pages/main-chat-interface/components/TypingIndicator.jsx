import React, { useState, useEffect } from 'react';
import { realtimeService } from '../../../services/realtimeService';
import { useAuth } from '../../../contexts/AuthContext';

export default function TypingIndicator({ conversationId }) {
  const { user } = useAuth();
  const [typingUsers, setTypingUsers] = useState([]);

  useEffect(() => {
    if (!conversationId) return;

    // Subscribe to typing indicators
    const channelName = realtimeService?.subscribeToTypingIndicators(
      conversationId,
      (typingData) => {
        // Add user to typing list if not current user
        if (typingData?.user_id !== user?.id) {
          setTypingUsers(prev => {
            const exists = prev?.find(u => u?.user_id === typingData?.user_id);
            if (!exists) {
              return [...prev, typingData];
            }
            return prev;
          });
        }
      },
      (typingData) => {
        // Remove user from typing list
        setTypingUsers(prev => prev?.filter(u => u?.user_id !== typingData?.user_id));
      }
    );

    return () => {
      realtimeService?.unsubscribe(channelName);
    };
  }, [conversationId, user?.id]);

  if (typingUsers?.length === 0) return null;

  const getTypingText = () => {
    if (typingUsers?.length === 1) {
      return `${typingUsers?.[0]?.username || 'Someone'} is typing...`;
    } else if (typingUsers?.length === 2) {
      return `${typingUsers?.[0]?.username} and ${typingUsers?.[1]?.username} are typing...`;
    } else {
      return `${typingUsers?.length} people are typing...`;
    }
  };

  return (
    <div className="flex items-center gap-2 px-4 py-2 text-sm text-gray-600">
      <div className="flex gap-1">
        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
      </div>
      <span className="italic">{getTypingText()}</span>
    </div>
  );
}