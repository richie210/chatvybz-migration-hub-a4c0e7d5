import React, { useState, useRef, useEffect, useMemo } from 'react';
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import { Mic, X, Send, Image, File, Calendar } from 'lucide-react';
import AudioRecorder from '../../../components/ui/AudioRecorder';
import { audioRecordingService } from '../../../services/audioRecordingService';


import { mentionService } from '../../../services/mentionService';
import { linkPreviewService } from '../../../services/linkPreviewService';

import { typingIndicatorService } from '../../../services/typingIndicatorService';
import { generateClaudeQuickResponses } from '../../../services/claudeReplyService';
import ClaudeReplySuggestions from './ClaudeReplySuggestions';
import { fileAttachmentService } from '../../../services/fileAttachmentService';
import { supabase } from '../../../lib/supabase';

export default function MessageInput({ conversationId, onSendMessage, replyTo, onCancelReply, onScheduleMessage }) {
  const [message, setMessage] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [showAudioRecorder, setShowAudioRecorder] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [error, setError] = useState(null);
  const [showMentionDropdown, setShowMentionDropdown] = useState(false);
  const [mentionSearch, setMentionSearch] = useState('');
  const [mentionPosition, setMentionPosition] = useState({ top: 0, left: 0 });
  const [mentions, setMentions] = useState([]);
  const [selectedFiles, setSelectedFiles] = useState([]);
  const [sending, setSending] = useState(false);
  const [mediaFiles, setMediaFiles] = useState([]);
  const [quickResponses, setQuickResponses] = useState([]);
  const [showQuickResponses, setShowQuickResponses] = useState(false);
  const [loadingQuickResponses, setLoadingQuickResponses] = useState(false);
  const [linkPreviews, setLinkPreviews] = useState([]);
  const [loadingPreviews, setLoadingPreviews] = useState(false);
  const [claudeSuggestions, setClaudeSuggestions] = useState([]);
  const [loadingClaudeSuggestions, setLoadingClaudeSuggestions] = useState(false);
  const [uploadingFiles, setUploadingFiles] = useState(false);
  const quillRef = useRef(null);
  const typingTimeoutRef = useRef(null);
  const fileInputRef = useRef(null);
  const [showScheduleModal, setShowScheduleModal] = useState(false);
  const [scheduledDate, setScheduledDate] = useState('');
  const [scheduledTime, setScheduledTime] = useState('');

  const emojis = ['😀', '😂', '😍', '🥰', '😊', '😎', '🤔', '😢', '😭', '😡', '👍', '👎', '👏', '🙏', '❤️', '🔥'];

  const extractMentions = (html) => {
    const tmp = document.createElement('div');
    tmp.innerHTML = html;
    const text = tmp?.textContent || tmp?.innerText || '';
    const mentionRegex = /@(\w+)/g;
    const mentions = [];
    let match;
    while ((match = mentionRegex?.exec(text)) !== null) {
      mentions?.push(match?.[1]);
    }
    return mentions;
  };

  // Quill editor modules configuration
  const modules = useMemo(() => ({
    toolbar: {
      container: [
        ['bold', 'italic', 'strike'],
        [{ 'list': 'ordered' }, { 'list': 'bullet' }],
        ['code-block'],
        ['link']
      ]
    },
    clipboard: {
      matchVisual: false
    }
  }), []);

  const formats = [
    'bold', 'italic', 'strike',
    'list', 'bullet',
    'code-block',
    'link'
  ];

  // Handle typing indicator
  useEffect(() => {
    const plainText = getPlainText(message);
    
    if (plainText?.trim() && conversationId) {
      if (!isTyping) {
        setIsTyping(true);
        typingIndicatorService?.updateTypingStatus(conversationId, true);
      }

      // Clear previous timeout
      if (typingTimeoutRef?.current) {
        clearTimeout(typingTimeoutRef?.current);
      }

      // Stop typing after 3 seconds of inactivity
      typingTimeoutRef.current = setTimeout(() => {
        setIsTyping(false);
        typingIndicatorService?.updateTypingStatus(conversationId, false);
      }, 3000);
    } else if (isTyping) {
      setIsTyping(false);
      typingIndicatorService?.updateTypingStatus(conversationId, false);
    }

    return () => {
      if (typingTimeoutRef?.current) {
        clearTimeout(typingTimeoutRef?.current);
      }
    };
  }, [message, conversationId, isTyping]);

  // Extract URLs and fetch link previews
  useEffect(() => {
    const plainText = getPlainText(message);
    const urls = linkPreviewService?.extractUrls(plainText);
    
    if (urls?.length > 0) {
      fetchLinkPreviews(urls);
    } else {
      setLinkPreviews([]);
    }
  }, [message]);

  const fetchLinkPreviews = async (urls) => {
    setLoadingPreviews(true);
    try {
      const previews = await Promise.all(
        urls?.map(url => linkPreviewService?.fetchPreviewWithCache(url))
      );
      setLinkPreviews(previews?.filter(p => p !== null));
    } catch (error) {
      console.error('Error fetching link previews:', error);
    } finally {
      setLoadingPreviews(false);
    }
  };

  const getPlainText = (html) => {
    const tmp = document.createElement('div');
    tmp.innerHTML = html;
    return tmp?.textContent || tmp?.innerText || '';
  };

  const handleMessageChange = (content, delta, source, editor) => {
    setMessage(content);

    // Check for @ mentions
    const text = editor?.getText();
    const lastAtIndex = text?.lastIndexOf('@');
    
    if (lastAtIndex !== -1 && lastAtIndex === text?.length - 1) {
      setShowMentionDropdown(true);
      setMentionSearch('');
      loadGroupMembers();
    } else if (lastAtIndex !== -1) {
      const textAfterAt = text?.substring(lastAtIndex + 1);
      const hasSpace = textAfterAt?.includes(' ');
      
      if (!hasSpace && textAfterAt?.length > 0) {
        setShowMentionDropdown(true);
        setMentionSearch(textAfterAt);
        loadGroupMembers(textAfterAt);
      } else if (hasSpace) {
        setShowMentionDropdown(false);
      }
    } else {
      setShowMentionDropdown(false);
    }
  };

  const loadGroupMembers = async (searchTerm = '') => {
    try {
      const result = await mentionService?.searchGroupMembers(conversationId, searchTerm);
      if (result?.error) throw result?.error;
      setMentions(result?.data || []);
    } catch (error) {
      console.error('Error loading group members:', error);
    }
  };

  const handleSelectMention = (user) => {
    const editor = quillRef?.current?.getEditor();
    const text = editor?.getText();
    const lastAtIndex = text?.lastIndexOf('@');
    
    if (lastAtIndex !== -1) {
      const range = editor?.getSelection();
      editor?.deleteText(lastAtIndex, range?.index - lastAtIndex);
      editor?.insertText(lastAtIndex, `@${user?.username} `);
      editor?.setSelection(lastAtIndex + user?.username?.length + 2);
    }
    
    setShowMentionDropdown(false);
  };

  const handleSend = async () => {
    const plainText = getPlainText(message);
    if (!plainText?.trim() && selectedFiles?.length === 0) return;

    setSending(true);
    setError(null);

    try {
      // Stop typing indicator
      if (isTyping) {
        setIsTyping(false);
        typingIndicatorService?.updateTypingStatus(conversationId, false);
      }

      // Prepare message data
      const messageData = {
        content: plainText,
        replyTo: replyTo?.id,
        mentions: extractMentions(message),
        linkPreviews,
        hasAttachments: selectedFiles?.length > 0
      };

      // Send message (will return message ID)
      const sentMessage = await onSendMessage(messageData);

      // Upload attachments if any
      if (selectedFiles?.length > 0 && sentMessage?.id) {
        setUploadingFiles(true);
        const { data: { user } } = await supabase?.auth?.getUser();
        
        for (const file of selectedFiles) {
          await fileAttachmentService?.uploadAttachment(
            file,
            sentMessage?.id,
            user?.id
          );
        }
        setUploadingFiles(false);
      }

      // Clear input
      setMessage('');
      setSelectedFiles([]);
      setLinkPreviews([]);
      setClaudeSuggestions([]);
      onCancelReply?.();

      // Reset Quill editor
      if (quillRef?.current) {
        const editor = quillRef?.current?.getEditor();
        editor?.setText('');
      }
    } catch (err) {
      setError(err?.message || 'Failed to send message');
    } finally {
      setSending(false);
    }
  };

  const handleKeyPress = (e) => {
    if (e?.key === 'Enter' && !e?.shiftKey) {
      e?.preventDefault();
      handleSend();
    }
  };

  const handleEmojiClick = (emoji) => {
    const editor = quillRef?.current?.getEditor();
    const range = editor?.getSelection();
    if (range) {
      editor?.insertText(range?.index, emoji);
      editor?.setSelection(range?.index + emoji?.length);
    }
    setShowEmojiPicker(false);
  };

  // Handle file selection
  const handleFileSelect = (event) => {
    const files = Array.from(event?.target?.files || []);
    
    // Validate files
    const validFiles = [];
    for (const file of files) {
      const validation = fileAttachmentService?.validateFile(file);
      if (validation?.isValid) {
        validFiles?.push(file);
      } else {
        setError(validation?.error);
        setTimeout(() => setError(null), 3000);
      }
    }

    setSelectedFiles(prev => [...prev, ...validFiles]);
  };

  // Remove selected file
  const handleRemoveFile = (index) => {
    setSelectedFiles(prev => prev?.filter((_, i) => i !== index));
  };

  // Generate Claude AI suggestions when receiving a message
  const generateAISuggestions = async (lastMessage) => {
    if (!lastMessage || !conversationId) return;

    setLoadingClaudeSuggestions(true);
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) return;

      const suggestions = await generateClaudeQuickResponses(
        lastMessage,
        conversationId,
        user?.id
      );
      setClaudeSuggestions(suggestions);
    } catch (error) {
      console.error('Error generating Claude suggestions:', error);
      setClaudeSuggestions([]);
    } finally {
      setLoadingClaudeSuggestions(false);
    }
  };

  // Handle Claude suggestion selection
  const handleSelectClaudeSuggestion = (suggestionText) => {
    setMessage(suggestionText);
    setClaudeSuggestions([]);
  };

  const handleFileAttachment = (file) => {
    setMediaFiles(prev => [...prev, file]);
  };

  const removeMediaFile = (index) => {
    setMediaFiles(prev => prev?.filter((_, i) => i !== index));
  };

  const removeLinkPreview = (index) => {
    setLinkPreviews(prev => prev?.filter((_, i) => i !== index));
  };

  // Handle audio message send
  const handleAudioSend = async (audioBlob, waveformData, duration) => {
    try {
      setSending(true);
      const { data: { user } } = await supabase?.auth?.getUser();
      
      if (!user) {
        setError('Not authenticated');
        return;
      }

      // Upload audio to Supabase storage
      const uploadResult = await audioRecordingService?.uploadAudio(audioBlob, user?.id);
      
      if (!uploadResult?.success) {
        setError('Failed to upload audio');
        return;
      }

      // Send audio message
      await onSendMessage({
        content: '',
        plainText: '[Voice Message]',
        messageType: 'audio',
        audioUrl: uploadResult?.path,
        audioDuration: duration,
        audioWaveform: waveformData
      });

      setShowAudioRecorder(false);
    } catch (error) {
      console.error('Error sending audio message:', error);
      setError('Failed to send audio message');
    } finally {
      setSending(false);
    }
  };

  const handleAudioCancel = () => {
    setShowAudioRecorder(false);
  };

  const handleScheduleMessage = async () => {
    if (!message?.trim() || !scheduledDate || !scheduledTime) {
      return;
    }

    try {
      const scheduledDateTime = new Date(`${scheduledDate}T${scheduledTime}`);
      
      if (scheduledDateTime <= new Date()) {
        alert('Scheduled time must be in the future');
        return;
      }

      await onScheduleMessage?.({
        message: message?.trim(),
        scheduledTime: scheduledDateTime?.toISOString(),
        recipientId: conversationId
      });

      setMessage('');
      setShowScheduleModal(false);
      setScheduledDate('');
      setScheduledTime('');
    } catch (err) {
      console.error('Schedule message error:', err);
    }
  };

  return (
    <div className="border-t border-border bg-card p-4">
      {/* Claude AI Suggestions */}
      {claudeSuggestions?.length > 0 && (
        <ClaudeReplySuggestions
          suggestions={claudeSuggestions}
          onSelect={handleSelectClaudeSuggestion}
          loading={loadingClaudeSuggestions}
          onRefresh={() => generateAISuggestions(message)}
        />
      )}

      {/* Reply Preview */}
      {replyTo && (
        <div className="mb-3 p-3 bg-muted rounded-lg flex items-start justify-between">
          <div className="flex-1">
            <p className="text-xs text-muted-foreground mb-1">Replying to {replyTo?.sender?.name}</p>
            <p className="text-sm text-foreground line-clamp-2">{replyTo?.content}</p>
          </div>
          <button
            onClick={onCancelReply}
            className="ml-2 p-1 hover:bg-background rounded transition-colors"
          >
            <X className="w-4 h-4 text-muted-foreground" />
          </button>
        </div>
      )}

      {/* Selected Files Preview */}
      {selectedFiles?.length > 0 && (
        <div className="mb-3 flex flex-wrap gap-2">
          {selectedFiles?.map((file, index) => (
            <div
              key={index}
              className="relative bg-muted rounded-lg p-2 flex items-center gap-2 max-w-xs"
            >
              <Icon
                name={file?.type?.startsWith('image/') ? 'Image' : 'FileText'}
                size={20}
                color="var(--color-muted-foreground)"
              />
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-foreground truncate">
                  {file?.name}
                </p>
                <p className="text-xs text-muted-foreground">
                  {fileAttachmentService?.formatFileSize(file?.size)}
                </p>
              </div>
              <button
                onClick={() => handleRemoveFile(index)}
                className="p-1 hover:bg-background rounded transition-colors"
              >
                <X className="w-4 h-4 text-muted-foreground" />
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Link previews */}
      {linkPreviews?.length > 0 && (
        <div className="px-4 py-2 bg-gray-50 border-b border-gray-200 space-y-2">
          {linkPreviews?.map((preview, index) => (
            <div key={index} className="flex items-start gap-2 p-2 bg-white rounded border border-gray-200">
              {preview?.image && (
                <img src={preview?.image} alt={preview?.title} className="w-16 h-16 object-cover rounded" />
              )}
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-gray-900 truncate">{preview?.title}</p>
                <p className="text-xs text-gray-500 truncate">{preview?.description}</p>
                <p className="text-xs text-blue-600 truncate">{preview?.siteName}</p>
              </div>
              <button onClick={() => removeLinkPreview(index)} className="text-gray-400 hover:text-gray-600">
                <X className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Media files preview */}
      {mediaFiles?.length > 0 && (
        <div className="px-4 py-2 bg-gray-50 border-b border-gray-200">
          <div className="flex flex-wrap gap-2">
            {mediaFiles?.map((file, index) => (
              <div key={index} className="relative">
                <div className="w-16 h-16 bg-gray-200 rounded flex items-center justify-center">
                  <span className="text-xs text-gray-600 truncate px-1">{file?.name}</span>
                </div>
                <button
                  onClick={() => removeMediaFile(index)}
                  className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1"
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Mention dropdown */}
      {showMentionDropdown && mentions?.length > 0 && (
        <div className="absolute bottom-full left-0 right-0 bg-white border border-gray-200 shadow-lg max-h-48 overflow-y-auto">
          {mentions?.map(user => (
            <button
              key={user?.id}
              onClick={() => handleSelectMention(user)}
              className="w-full px-4 py-2 text-left hover:bg-gray-100 flex items-center gap-2"
            >
              <div className="w-8 h-8 bg-gray-300 rounded-full" />
              <div>
                <p className="text-sm font-medium">{user?.full_name}</p>
                <p className="text-xs text-gray-500">@{user?.username}</p>
              </div>
            </button>
          ))}
        </div>
      )}

      {/* Rich text editor */}
      <div className="px-4 py-2">
        <ReactQuill
          ref={quillRef}
          theme="snow"
          value={message}
          onChange={handleMessageChange}
          modules={modules}
          formats={formats}
          placeholder="Type a message..."
          className="message-input-editor"
        />
      </div>

      {/* Action buttons */}
      <div className="flex items-end gap-2">
        {/* Emoji picker */}
        <div className="relative">
          <button
            onClick={() => setShowEmojiPicker(!showEmojiPicker)}
            className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-full"
          >
            <Icon name="smile" className="w-5 h-5" />
          </button>
          {showEmojiPicker && (
            <div className="absolute bottom-full left-0 mb-2 bg-white border border-gray-200 rounded-lg shadow-lg p-2 grid grid-cols-8 gap-1">
              {emojis?.map((emoji, index) => (
                <button
                  key={index}
                  onClick={() => handleEmojiClick(emoji)}
                  className="text-2xl hover:bg-gray-100 rounded p-1"
                >
                  {emoji}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* File attachment */}
        <button
          onClick={() => fileInputRef?.current?.click()}
          className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-full"
        >
          <Icon name="paperclip" className="w-5 h-5" />
        </button>
        <input
          ref={fileInputRef}
          type="file"
          multiple
          accept="image/*,video/*,audio/*,.pdf,.doc,.docx,.txt"
          onChange={handleFileSelect}
          className="hidden"
        />

        {/* Audio recorder */}
        <button
          onClick={() => setShowAudioRecorder(!showAudioRecorder)}
          className="p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-full"
        >
          <Mic className="w-5 h-5" />
        </button>

        {/* Schedule message */}
        <button
          type="button"
          onClick={() => setShowScheduleModal(true)}
          className="p-2 text-gray-500 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
          title="Schedule message"
        >
          <Calendar className="w-5 h-5" />
        </button>

        {/* Send button */}
        <Button
          onClick={handleSend}
          disabled={(!getPlainText(message)?.trim() && selectedFiles?.length === 0) || sending || uploadingFiles}
          variant="default"
          size="icon"
          className="flex-shrink-0"
        >
          {sending || uploadingFiles ? (
            <Icon name="Loader" size={20} className="animate-spin" />
          ) : (
            <Icon name="Send" size={20} />
          )}
        </Button>
      </div>

      {/* Error message */}
      {error && (
        <div className="mt-2 p-2 bg-red-50 border border-red-200 rounded-lg text-sm text-red-600">
          {error}
        </div>
      )}

      {/* Uploading Status */}
      {uploadingFiles && (
        <div className="mt-2 p-2 bg-blue-50 border border-blue-200 rounded-lg text-sm text-blue-600 flex items-center gap-2">
          <Icon name="Loader" size={16} className="animate-spin" />
          Uploading files...
        </div>
      )}

      {/* Audio Recorder Modal */}
      {showAudioRecorder && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg shadow-xl max-w-md w-full">
            <div className="p-4 border-b border-gray-200 flex items-center justify-between">
              <h3 className="text-lg font-semibold text-gray-900">Record Voice Message</h3>
              <button
                onClick={handleAudioCancel}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-4">
              <AudioRecorder
                onSend={handleAudioSend}
                onCancel={handleAudioCancel}
              />
            </div>
          </div>
        </div>
      )}

      {showScheduleModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-md">
            <div className="border-b border-gray-200 px-6 py-4 flex items-center justify-between">
              <h3 className="text-lg font-bold text-gray-900">Schedule Message</h3>
              <button onClick={() => setShowScheduleModal(false)} className="text-gray-500 hover:text-gray-700">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Date</label>
                <input
                  type="date"
                  value={scheduledDate}
                  onChange={(e) => setScheduledDate(e?.target?.value)}
                  min={new Date()?.toISOString()?.split('T')?.[0]}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Time</label>
                <input
                  type="time"
                  value={scheduledTime}
                  onChange={(e) => setScheduledTime(e?.target?.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                <p className="text-sm text-blue-800">Message: {message}</p>
              </div>
              <div className="flex gap-3">
                <button
                  onClick={handleScheduleMessage}
                  className="flex-1 px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Schedule
                </button>
                <button
                  onClick={() => setShowScheduleModal(false)}
                  className="flex-1 px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}