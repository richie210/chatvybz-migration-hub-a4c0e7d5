import React, { useState, useRef, useEffect } from 'react';


import Linkify from 'linkify-react';

import Image from '../../../components/AppImage';
import { Check, Clock, AlertCircle, RefreshCw, ExternalLink } from 'lucide-react';
import { messageService } from '../../../services/messageService';
import { translationService } from '../../../services/translationService';
import { threadService } from '../../../services/threadService';
import { realtimeService } from '../../../services/realtimeService';
import { messageForwardingService } from '../../../services/messageForwardingService';
import { fileAttachmentService } from '../../../services/fileAttachmentService';
import Icon from '../../../components/AppIcon';
import { supabase } from '../../../lib/supabase';





export default function MessageBubble({
  message,
  isOwn,
  onDelete,
  onForward,
  onReply,
  onEdit,
  onReaction
}) {
  const [showActions, setShowActions] = useState(false);
  const [showReactions, setShowReactions] = useState(false);
  const [reactions, setReactions] = useState([]);
  const [showReactionPicker, setShowReactionPicker] = useState(false);
  const [showTranslation, setShowTranslation] = useState(false);
  const [translatedText, setTranslatedText] = useState('');
  const [translating, setTranslating] = useState(false);
  const [targetLanguage, setTargetLanguage] = useState('en');
  const [isEditing, setIsEditing] = useState(false);
  const [editContent, setEditContent] = useState(message?.message || '');
  const [canEdit, setCanEdit] = useState(false);
  const [audioUrl, setAudioUrl] = useState(null);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const [audioProgress, setAudioProgress] = useState(0);
  const audioRef = useRef(null);
  const [showThreadPreview, setShowThreadPreview] = useState(false);
  const [threadMessages, setThreadMessages] = useState([]);
  const [isLoadingThread, setIsLoadingThread] = useState(false);
  const [replyText, setReplyText] = useState('');
  const [hoveredReaction, setHoveredReaction] = useState(null);
  const [isRetrying, setIsRetrying] = useState(false);
  const [attachments, setAttachments] = useState([]);
  const [loadingAttachments, setLoadingAttachments] = useState(false);
  const [showAttachmentPreview, setShowAttachmentPreview] = useState(false);
  const [showForwardModal, setShowForwardModal] = useState(false);
  const [showReactionViewers, setShowReactionViewers] = useState(false);
  const [reactionViewers, setReactionViewers] = useState([]);

  // Add missing variables
  const isSent = isOwn;
  const currentUserId = message?.senderId || message?.sender?.id;
  const userTimezone = Intl.DateTimeFormat()?.resolvedOptions()?.timeZone;

  // Emoji reactions
  const availableReactions = ['👍', '❤️', '😂', '😮', '😢', '🙏'];

  const formatTime = (date) => {
    return new Date(date)?.toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  };

  const formatDuration = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs?.toString()?.padStart(2, '0')}`;
  };

  const formatAudioDuration = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs?.toString()?.padStart(2, '0')}`;
  };

  // Close menus on outside click
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (showActions && !event?.target?.closest('.message-actions-menu')) {
        setShowActions(false);
      }
      if (showReactionPicker && !event?.target?.closest('.reaction-picker')) {
        setShowReactionPicker(false);
      }
    };

    if (showActions || showReactionPicker) {
      document.addEventListener('touchstart', handleClickOutside);
      document.addEventListener('click', handleClickOutside);
    }

    return () => {
      document.removeEventListener('touchstart', handleClickOutside);
      document.removeEventListener('click', handleClickOutside);
    };
  }, [showActions, showReactionPicker]);

  // Load reactions from database
  useEffect(() => {
    if (!message?.id) return;

    loadReactions();

    // Subscribe to real-time reaction updates
    const channelName = realtimeService?.subscribeToMessageReactions(
      message?.id,
      (newReaction) => {
        loadReactions();
      },
      (removedReaction) => {
        loadReactions();
      }
    );

    return () => {
      realtimeService?.unsubscribe(channelName);
    };
  }, [message?.id]);

  const loadReactions = async () => {
    try {
      const reactionsData = await messageService?.getReactionsForMessage(message?.id);
      setReactions(reactionsData);
    } catch (error) {
      console.error('Error loading reactions:', error);
    }
  };

  // Load reactions on mount and when message changes
  useEffect(() => {
    if (message?.id) {
      loadReactions();
    }
  }, [message?.id]);

  // Subscribe to real-time reaction updates
  useEffect(() => {
    if (!message?.id) return;

    const cleanup = realtimeService?.subscribeToMessageReactions(
      message?.id,
      () => loadReactions(),
      () => loadReactions()
    );

    return () => {
      if (cleanup) cleanup();
    };
  }, [message?.id]);

  const checkEditPermission = async () => {
    try {
      const canEditMsg = await messageService?.canEditMessage(message?.id);
      setCanEdit(canEditMsg);
    } catch (error) {
      console.error('Failed to check edit permission:', error);
    }
  };

  const loadAudioUrl = async () => {
    const url = await messageService?.getAudioUrl(message?.audio_url);
    setAudioUrl(url);
  };

  const toggleAudioPlayback = () => {
    if (!audioUrl) return;

    if (isPlayingAudio) {
      audioRef?.current?.pause();
      setIsPlayingAudio(false);
    } else {
      if (!audioRef?.current) {
        audioRef.current = new Audio(audioUrl);
        audioRef.current.onended = () => setIsPlayingAudio(false);
        // Update playback progress
        audioRef.current.ontimeupdate = () => {
          if (audioRef?.current) {
            const progress = (audioRef?.current?.currentTime / audioRef?.current?.duration) * 100;
            setAudioProgress(progress);
          }
        };
      }
      audioRef?.current?.play();
      setIsPlayingAudio(true);
    }
  };

  const handleTranslate = async () => {
    if (showTranslation) {
      setShowTranslation(false);
      return;
    }

    setTranslating(true);
    try {
      const result = await translationService?.translateMessage(
        message?.id,
        message?.message,
        targetLanguage
      );

      if (result?.success) {
        setTranslatedText(result?.translatedText);
        setShowTranslation(true);
      } else {
        console.error('Translation failed:', result?.error);
      }
    } catch (error) {
      console.error('Translation error:', error);
    } finally {
      setTranslating(false);
    }
  };

  const handleReaction = async (emoji) => {
    try {
      const result = await messageService?.addMessageReaction(message?.id, emoji, currentUserId);
      if (result?.error) throw result?.error;
      setShowReactionPicker(false);
      loadReactions();
    } catch (error) {
      console.error('Error adding reaction:', error);
    }
  };

  const handleReactionClick = async (emoji) => {
    try {
      // Load viewers for this reaction
      const allReactions = await messageService?.getReactionsForMessage(message?.id);
      const reactionData = allReactions?.find(r => r?.emoji === emoji);
      
      if (reactionData?.users) {
        setReactionViewers({
          emoji,
          users: reactionData?.users
        });
        setShowReactionViewers(true);
      }
    } catch (error) {
      console.error('Error loading reaction viewers:', error);
    }
  };

  const handleEdit = async () => {
    if (!editContent?.trim()) return;

    try {
      await onEdit?.(message?.id, editContent);
      setIsEditing(false);
    } catch (error) {
      console.error('Failed to edit message:', error);
    }
  };

  const handleDeleteOption = (deleteForEveryone) => {
    onDelete?.(message?.id, deleteForEveryone);
    setShowActions(false);
  };

  const handleRetry = async () => {
    if (!message?.queueId) return;

    setIsRetrying(true);
    try {
      const result = await messageService?.retryQueuedMessage(message?.queueId);
      if (result?.success) {
        // Message sent successfully - parent component will handle the update
        console.log('Message retry successful');
      } else {
        throw new Error(result?.error || 'Retry failed');
      }
    } catch (error) {
      console.error('Error retrying message:', error);
    } finally {
      setIsRetrying(false);
    }
  };

  // Load thread preview when message has replies
  useEffect(() => {
    if (message?.isThreadRoot && message?.replyCount > 0 && showThreadPreview) {
      loadThreadPreview();
    }
  }, [showThreadPreview, message?.isThreadRoot, message?.replyCount]);

  const loadThreadPreview = async () => {
    if (!message?.id) return;
    
    setIsLoadingThread(true);
    try {
      const preview = await threadService?.getThreadPreview(message?.id);
      setThreadMessages(preview);
    } catch (error) {
      console.error('Error loading thread preview:', error);
    } finally {
      setIsLoadingThread(false);
    }
  };

  const handleReply = async () => {
    if (!replyText?.trim()) return;

    try {
      await threadService?.replyToMessage(
        message?.id,
        replyText,
        currentUserId,
        message?.sender?.id
      );
      setReplyText('');
      setShowThreadPreview(true);
      loadThreadPreview();
    } catch (error) {
      console.error('Error replying to message:', error);
    }
  };

  const handleReplyAction = (msg) => {
    if (onReply) {
      onReply(msg);
    }
  };

  // Load attachments when message is rendered
  useEffect(() => {
    const loadAttachments = async () => {
      if (!message?.id) return;
      
      setLoadingAttachments(true);
      try {
        const data = await fileAttachmentService?.getMessageAttachments(message?.id);
        setAttachments(data);
      } catch (error) {
        console.error('Error loading attachments:', error);
      } finally {
        setLoadingAttachments(false);
      }
    };

    loadAttachments();
  }, [message?.id]);

  const handleForwardAction = async (recipientIds) => {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) return;

      await messageForwardingService?.forwardMessage(
        message?.id,
        recipientIds,
        user?.id,
        true // Include attachments
      );

      setShowForwardModal(false);
    } catch (error) {
      console.error('Error forwarding message:', error);
    }
  };

  const handleDeleteAttachment = async (attachmentId, fileUrl) => {
    try {
      await fileAttachmentService?.deleteAttachment(attachmentId, fileUrl);
      setAttachments(prev => prev?.filter(att => att?.id !== attachmentId));
    } catch (error) {
      console.error('Error deleting attachment:', error);
    }
  };

  // Render rich text content with markdown support
  const renderMessageContent = () => {
    const content = message?.content || message?.message;
    
    // Check if message has rich text formatting
    if (message?.isRichText || content?.includes('<')) {
      return (
        <div 
          className="prose prose-sm max-w-none"
          dangerouslySetInnerHTML={{ __html: content }}
        />
      );
    }
    
    // Render plain text with linkify
    return (
      <Linkify
        options={{
          className: 'text-blue-600 hover:underline',
          target: '_blank',
          rel: 'noopener noreferrer'
        }}
      >
        <p className="whitespace-pre-wrap break-words">{content}</p>
      </Linkify>
    );
  };

  // Render link previews
  const renderLinkPreviews = () => {
    if (!message?.linkPreviews || message?.linkPreviews?.length === 0) return null;

    return (
      <div className="mt-2 space-y-2">
        {message?.linkPreviews?.map((preview, index) => (
          <a
            key={index}
            href={preview?.url}
            target="_blank"
            rel="noopener noreferrer"
            className="block border border-gray-200 rounded-lg overflow-hidden hover:border-gray-300 transition-colors"
          >
            {preview?.image && (
              <img
                src={preview?.image}
                alt={preview?.title}
                className="w-full h-48 object-cover"
              />
            )}
            <div className="p-3 bg-gray-50">
              <div className="flex items-start justify-between gap-2">
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-sm text-gray-900 truncate">{preview?.title}</p>
                  {preview?.description && (
                    <p className="text-xs text-gray-600 line-clamp-2 mt-1">{preview?.description}</p>
                  )}
                  <p className="text-xs text-blue-600 mt-1 flex items-center gap-1">
                    {preview?.siteName}
                    <ExternalLink className="w-3 h-3" />
                  </p>
                </div>
              </div>
            </div>
          </a>
        ))}
      </div>
    );
  };

  const renderReactions = () => {
    if (!reactions || reactions?.length === 0) {
      return null;
    }

    return (
      <div className="flex flex-wrap gap-1 mt-2">
        {reactions?.map((reaction) => (
          <div
            key={reaction?.emoji}
            className="relative"
            onMouseEnter={() => setHoveredReaction(reaction?.emoji)}
            onMouseLeave={() => setHoveredReaction(null)}
          >
            <button
              onClick={() => handleReaction(reaction?.emoji)}
              className={`flex items-center gap-1 px-2 py-1 rounded-full text-xs transition-colors ${
                reaction?.users?.some(u => u?.id === currentUserId)
                  ? 'bg-blue-100 border border-blue-300' : 'bg-gray-100 border border-gray-200'
              } hover:bg-blue-50`}
            >
              <span>{reaction?.emoji}</span>
              <span className="text-gray-600">{reaction?.count}</span>
            </button>

            {/* Reaction tooltip with avatars */}
            {hoveredReaction === reaction?.emoji && (
              <div className="absolute bottom-full left-0 mb-2 bg-gray-900 text-white px-3 py-2 rounded-lg shadow-lg z-50 min-w-[150px]">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-lg">{reaction?.emoji}</span>
                  <span className="text-xs font-medium">{reaction?.count} {reaction?.count === 1 ? 'reaction' : 'reactions'}</span>
                </div>
                <div className="space-y-1">
                  {reaction?.users?.map((user) => (
                    <div key={user?.id} className="flex items-center gap-2">
                      {user?.avatar ? (
                        <img
                          src={user?.avatar}
                          alt={user?.name}
                          className="w-6 h-6 rounded-full"
                        />
                      ) : (
                        <div className="w-6 h-6 rounded-full bg-gray-600 flex items-center justify-center text-xs">
                          {user?.name?.charAt(0)?.toUpperCase()}
                        </div>
                      )}
                      <span className="text-xs">{user?.name}</span>
                    </div>
                  ))}
                </div>
                <div className="absolute top-full left-4 -mt-1 border-4 border-transparent border-t-gray-900"></div>
              </div>
            )}
          </div>
        ))}
      </div>
    );
  };

  const renderSyncStatus = () => {
    if (!isSent) return null;

    const statusConfig = {
      queued: {
        icon: Clock,
        text: 'Sending...',
        color: 'text-yellow-500',
        bgColor: 'bg-yellow-50',
        borderColor: 'border-yellow-200',
        animate: true,
        showRetry: true
      },
      sending: {
        icon: Clock,
        text: 'Sending...',
        color: 'text-blue-500',
        bgColor: 'bg-blue-50',
        borderColor: 'border-blue-200',
        animate: true,
        showRetry: false
      },
      sent: {
        icon: Check,
        text: 'Sent',
        color: 'text-gray-500',
        bgColor: 'bg-gray-50',
        borderColor: 'border-gray-200',
        animate: false,
        showRetry: false
      },
      delivered: {
        icon: Check,
        text: 'Delivered',
        color: 'text-green-500',
        bgColor: 'bg-green-50',
        borderColor: 'border-green-200',
        animate: false,
        showRetry: false
      },
      read: {
        icon: Check,
        text: 'Read',
        color: 'text-blue-500',
        bgColor: 'bg-blue-50',
        borderColor: 'border-blue-200',
        animate: false,
        showRetry: false
      },
      failed: {
        icon: AlertCircle,
        text: 'Failed',
        color: 'text-red-500',
        bgColor: 'bg-red-50',
        borderColor: 'border-red-200',
        animate: false,
        showRetry: true
      }
    };

    const status = statusConfig?.[message?.status] || statusConfig?.sent;
    const StatusIcon = status?.icon;

    return (
      <div className={`flex items-center gap-2 px-2 py-1 rounded-full text-xs ${status?.bgColor} ${status?.borderColor} border mt-2`}>
        <StatusIcon 
          className={`w-3 h-3 ${status?.color} ${status?.animate ? 'animate-pulse' : ''}`} 
        />
        <span className={`${status?.color} font-medium`}>{status?.text}</span>
        {status?.showRetry && message?.status === 'failed' && (
          <button
            onClick={handleRetry}
            disabled={isRetrying}
            className="ml-1 p-1 hover:bg-white/50 rounded-full transition-colors disabled:opacity-50"
            title="Retry sending"
          >
            <RefreshCw className={`w-3 h-3 ${status?.color} ${isRetrying ? 'animate-spin' : ''}`} />
          </button>
        )}
        {message?.status === 'queued' && message?.queueId && (
          <button
            onClick={handleRetry}
            disabled={isRetrying}
            className="ml-1 p-1 hover:bg-white/50 rounded-full transition-colors disabled:opacity-50"
            title="Retry sending"
          >
            <RefreshCw className={`w-3 h-3 ${status?.color} ${isRetrying ? 'animate-spin' : ''}`} />
          </button>
        )}
      </div>
    );
  };

  // Render attachments
  const renderAttachments = () => {
    if (!attachments || attachments?.length === 0) return null;

    return (
      <div className="mt-2 space-y-2">
        {attachments?.map((attachment) => {
          const isImage = attachment?.file_type === 'image';
          const isVideo = attachment?.file_type === 'video';
          const isAudio = attachment?.file_type === 'audio';

          if (isImage) {
            return (
              <button
                key={attachment?.id}
                onClick={() => setShowAttachmentPreview(true)}
                className="block w-full max-w-xs rounded-lg overflow-hidden hover:opacity-90 transition-opacity"
              >
                <img
                  src={attachment?.file_url}
                  alt={attachment?.file_name}
                  className="w-full h-auto"
                />
              </button>
            );
          } else if (isVideo) {
            return (
              <div key={attachment?.id} className="max-w-xs rounded-lg overflow-hidden">
                <video
                  src={attachment?.file_url}
                  controls
                  className="w-full h-auto"
                >
                  Your browser does not support the video tag.
                </video>
              </div>
            );
          } else if (isAudio) {
            return (
              <div key={attachment?.id} className="max-w-xs">
                <audio src={attachment?.file_url} controls className="w-full">
                  Your browser does not support the audio tag.
                </audio>
              </div>
            );
          } else {
            return (
              <button
                key={attachment?.id}
                onClick={() => setShowAttachmentPreview(true)}
                className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors max-w-xs w-full"
              >
                <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Icon name="FileText" size={20} color="var(--color-primary)" />
                </div>
                <div className="flex-1 min-w-0 text-left">
                  <p className="text-sm font-medium text-gray-900 truncate">
                    {attachment?.file_name}
                  </p>
                  <p className="text-xs text-gray-500">
                    {fileAttachmentService?.formatFileSize(attachment?.file_size)}
                  </p>
                </div>
                <Icon name="Download" size={16} color="var(--color-muted-foreground)" />
              </button>
            );
          }
        })}
      </div>
    );
  };

  return (
    <div className={`flex gap-2 mb-4 ${isOwn ? 'flex-row-reverse' : 'flex-row'}`}>
      {/* Avatar */}
      {!isOwn && (
        <div className="flex-shrink-0">
          <div className="w-8 h-8 rounded-full bg-gray-300 overflow-hidden">
            {message?.sender?.avatar && (
              <Image
                src={message?.sender?.avatar}
                alt={message?.sender?.name || 'User avatar'}
                className="w-full h-full object-cover"
              />
            )}
          </div>
        </div>
      )}
      {/* Message bubble */}
      <div className={`flex-1 max-w-[70%] ${isOwn ? 'items-end' : 'items-start'}`}>
        <div
          className={`rounded-lg px-4 py-2 ${
            isOwn ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-900'
          }`}
        >
          {/* Message content */}
          {renderMessageContent()}
          
          {/* Link previews */}
          {renderLinkPreviews()}

          {/* Audio Message */}
          {message?.message_type === 'audio' && message?.audio_url && (
            <div className="flex items-center gap-3 p-3 bg-white rounded-lg shadow-sm min-w-[280px]">
              {/* Play/Pause Button */}
              <button
                onClick={toggleAudioPlayback}
                className="flex-shrink-0 w-10 h-10 bg-green-500 hover:bg-green-600 text-white rounded-full flex items-center justify-center transition-colors"
              >
                {isPlayingAudio ? (
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M5 4h3v12H5V4zm7 0h3v12h-3V4z" />
                  </svg>
                ) : (
                  <svg className="w-5 h-5 ml-0.5" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M6.3 4.1c-.4-.2-.9 0-1.1.4-.2.4 0 .9.4 1.1l8 4.5c.4.2.9 0 1.1-.4.2-.4 0-.9-.4-1.1l-8-4.5z" />
                    <path d="M6.3 15.9c-.4.2-.6.7-.4 1.1.2.4.7.6 1.1.4l8-4.5c.4-.2.6-.7.4-1.1-.2-.4-.7-.6-1.1-.4l-8 4.5z" />
                  </svg>
                )}
              </button>

              {/* Waveform Visualization */}
              <div className="flex-1 flex flex-col gap-1">
                <div className="flex items-end justify-center gap-0.5 h-12">
                  {message?.audio_waveform && Array.isArray(message?.audio_waveform) ? (
                    message?.audio_waveform?.map((amplitude, index) => (
                      <div
                        key={index}
                        className="bg-green-500 rounded-full transition-all duration-100"
                        style={{
                          width: '2px',
                          height: `${Math.max(amplitude * 100, 8)}%`,
                          opacity: isPlayingAudio ? 0.9 : 0.6
                        }}
                      />
                    ))
                  ) : (
                    // Fallback waveform if data not available
                    (Array.from({ length: 40 })?.map((_, index) => (
                      <div
                        key={index}
                        className="bg-green-500 rounded-full"
                        style={{
                          width: '2px',
                          height: `${Math.random() * 60 + 20}%`,
                          opacity: 0.6
                        }}
                      />
                    )))
                  )}
                </div>
                
                {/* Duration */}
                <div className="text-xs text-gray-500 text-center">
                  {message?.audio_duration ? formatAudioDuration(message?.audio_duration) : '0:00'}
                </div>
              </div>
            </div>
          )}

          {/* Existing features: reactions, timestamp, status, etc. */}
          <div className="flex items-center justify-between mt-2 text-xs opacity-70">
            <span>{formatTime(message?.timestamp)}</span>
            {isOwn && (
              <div className="flex items-center gap-1">
                {message?.status === 'sent' && <Check className="w-3 h-3" />}
                {message?.status === 'delivered' && (
                  <div className="flex">
                    <Check className="w-3 h-3" />
                    <Check className="w-3 h-3 -ml-2" />
                  </div>
                )}
                {message?.status === 'read' && (
                  <div className="flex text-blue-400">
                    <Check className="w-3 h-3" />
                    <Check className="w-3 h-3 -ml-2" />
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Reactions display */}
        {reactions?.length > 0 && (
          <div className="flex flex-wrap gap-1 mt-1">
            {reactions?.map((reaction, index) => (
              <button
                key={index}
                onMouseEnter={() => setHoveredReaction(reaction)}
                onMouseLeave={() => setHoveredReaction(null)}
                onClick={() => handleReactionClick(reaction?.emoji)}
                className="bg-white border border-gray-200 rounded-full px-2 py-1 text-xs flex items-center gap-1 hover:bg-gray-50 relative"
              >
                <span>{reaction?.emoji}</span>
                <span className="text-gray-600">{reaction?.count}</span>
                
                {/* Hover tooltip with viewer names */}
                {hoveredReaction?.emoji === reaction?.emoji && (
                  <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 bg-gray-900 text-white text-xs rounded-lg px-3 py-2 whitespace-nowrap z-50 shadow-lg">
                    <div className="font-medium mb-1">{reaction?.emoji} Reactions</div>
                    <div className="space-y-1">
                      {reaction?.users?.slice(0, 5)?.map((user, idx) => (
                        <div key={idx} className="text-gray-200">{user?.name}</div>
                      ))}
                      {reaction?.users?.length > 5 && (
                        <div className="text-gray-400">+{reaction?.users?.length - 5} more</div>
                      )}
                    </div>
                    <div className="absolute top-full left-1/2 transform -translate-x-1/2 -mt-1">
                      <div className="w-2 h-2 bg-gray-900 transform rotate-45"></div>
                    </div>
                  </div>
                )}
              </button>
            ))}
          </div>
        )}

        {/* Reaction Viewers Modal */}
        {showReactionViewers && reactionViewers && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50" onClick={() => setShowReactionViewers(false)}>
            <div className="bg-white rounded-xl p-6 max-w-md w-full mx-4" onClick={(e) => e?.stopPropagation()}>
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <span className="text-3xl">{reactionViewers?.emoji}</span>
                  <h3 className="text-lg font-semibold">Reactions</h3>
                </div>
                <button
                  onClick={() => setShowReactionViewers(false)}
                  className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  <Icon name="X" size={20} />
                </button>
              </div>
              
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {reactionViewers?.users?.map((user, idx) => (
                  <div key={idx} className="flex items-center gap-3 p-2 hover:bg-gray-50 rounded-lg">
                    {user?.avatar ? (
                      <img
                        src={user?.avatar}
                        alt={user?.name}
                        className="w-10 h-10 rounded-full object-cover"
                      />
                    ) : (
                      <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center">
                        <span className="text-purple-600 font-medium">
                          {user?.name?.charAt(0)?.toUpperCase()}
                        </span>
                      </div>
                    )}
                    <div className="flex-1">
                      <div className="font-medium text-gray-900">{user?.name}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}