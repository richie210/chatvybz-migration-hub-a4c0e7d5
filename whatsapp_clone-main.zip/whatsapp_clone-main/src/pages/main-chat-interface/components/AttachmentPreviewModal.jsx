import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';

import { X, FileText, Image as ImageIcon, Video, Music, File, Download, Trash2 } from 'lucide-react';
import { fileAttachmentService } from '../../../services/fileAttachmentService';

const AttachmentPreviewModal = ({ isOpen, onClose, attachments = [], onDelete }) => {
  const [selectedAttachment, setSelectedAttachment] = useState(null);
  const [downloading, setDownloading] = useState(null);

  if (!isOpen) return null;

  const getFileIcon = (fileType) => {
    switch (fileType) {
      case 'image':
        return <ImageIcon className="w-6 h-6" />;
      case 'video':
        return <Video className="w-6 h-6" />;
      case 'audio':
        return <Music className="w-6 h-6" />;
      case 'document':
        return <FileText className="w-6 h-6" />;
      default:
        return <File className="w-6 h-6" />;
    }
  };

  const handleDownload = async (attachment) => {
    setDownloading(attachment?.id);
    try {
      // Get signed URL for download
      const filePath = attachment?.file_url?.split('/message-attachments/')?.[1];
      const signedUrl = await fileAttachmentService?.getSignedUrl(filePath);
      
      // Trigger download
      const link = document.createElement('a');
      link.href = signedUrl;
      link.download = attachment?.file_name;
      document.body?.appendChild(link);
      link?.click();
      document.body?.removeChild(link);
    } catch (error) {
      console.error('Error downloading file:', error);
    } finally {
      setDownloading(null);
    }
  };

  const handleDelete = async (attachment) => {
    if (window.confirm(`Delete ${attachment?.file_name}?`)) {
      try {
        await onDelete?.(attachment?.id, attachment?.file_url);
      } catch (error) {
        console.error('Error deleting attachment:', error);
      }
    }
  };

  const renderPreview = (attachment) => {
    if (attachment?.file_type === 'image') {
      return (
        <img
          src={attachment?.file_url}
          alt={attachment?.file_name}
          className="w-full h-full object-contain"
        />
      );
    } else if (attachment?.file_type === 'video') {
      return (
        <video
          src={attachment?.file_url}
          controls
          className="w-full h-full"
        >
          Your browser does not support the video tag.
        </video>
      );
    } else if (attachment?.file_type === 'audio') {
      return (
        <div className="flex items-center justify-center h-full">
          <audio src={attachment?.file_url} controls className="w-full max-w-md">
            Your browser does not support the audio tag.
          </audio>
        </div>
      );
    } else {
      return (
        <div className="flex flex-col items-center justify-center h-full text-gray-500">
          {getFileIcon(attachment?.file_type)}
          <p className="mt-4 text-lg font-medium">{attachment?.file_name}</p>
          <p className="text-sm text-gray-400 mt-2">
            {fileAttachmentService?.formatFileSize(attachment?.file_size)}
          </p>
        </div>
      );
    }
  };

  return (
    <div className="fixed inset-0 bg-black/90 flex items-center justify-center z-50">
      <div className="w-full h-full flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 bg-black/50">
          <div className="flex items-center gap-4">
            <button
              onClick={onClose}
              className="p-2 hover:bg-white/10 rounded-full transition-colors"
            >
              <X className="w-6 h-6 text-white" />
            </button>
            <div className="text-white">
              <h2 className="text-lg font-semibold">
                {selectedAttachment?.file_name || 'Attachments'}
              </h2>
              {selectedAttachment && (
                <p className="text-sm text-gray-300">
                  {fileAttachmentService?.formatFileSize(selectedAttachment?.file_size)}
                </p>
              )}
            </div>
          </div>
          {selectedAttachment && (
            <div className="flex items-center gap-2">
              <button
                onClick={() => handleDownload(selectedAttachment)}
                disabled={downloading === selectedAttachment?.id}
                className="p-2 hover:bg-white/10 rounded-full transition-colors text-white"
              >
                <Download className="w-5 h-5" />
              </button>
              {onDelete && (
                <button
                  onClick={() => handleDelete(selectedAttachment)}
                  className="p-2 hover:bg-red-500/20 rounded-full transition-colors text-red-400"
                >
                  <Trash2 className="w-5 h-5" />
                </button>
              )}
            </div>
          )}
        </div>

        {/* Main Preview Area */}
        <div className="flex-1 flex items-center justify-center p-4">
          {selectedAttachment ? (
            renderPreview(selectedAttachment)
          ) : (
            <div className="text-white text-center">
              <Icon name="FileText" size={64} color="white" />
              <p className="mt-4">Select an attachment to preview</p>
            </div>
          )}
        </div>

        {/* Thumbnail Strip */}
        {attachments?.length > 1 && (
          <div className="p-4 bg-black/50 overflow-x-auto">
            <div className="flex gap-2">
              {attachments?.map((attachment) => (
                <button
                  key={attachment?.id}
                  onClick={() => setSelectedAttachment(attachment)}
                  className={`flex-shrink-0 w-20 h-20 rounded-lg overflow-hidden border-2 transition-all ${
                    selectedAttachment?.id === attachment?.id
                      ? 'border-primary scale-105' :'border-transparent hover:border-white/50'
                  }`}
                >
                  {attachment?.file_type === 'image' ? (
                    <img
                      src={attachment?.thumbnail_url || attachment?.file_url}
                      alt={attachment?.file_name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full bg-gray-800 flex items-center justify-center text-white">
                      {getFileIcon(attachment?.file_type)}
                    </div>
                  )}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AttachmentPreviewModal;