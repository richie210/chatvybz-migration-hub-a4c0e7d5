import React, { useState, useEffect } from 'react';
import { Clock, Timer, AlertCircle, X } from 'lucide-react';
import { disappearingMessagesService } from '../../../services/disappearingMessagesService';

const DisappearingMessagesPanel = ({ conversationId, onClose }) => {
  const [enabled, setEnabled] = useState(false);
  const [durationType, setDurationType] = useState('24h');
  const [customHours, setCustomHours] = useState(24);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [expiringMessages, setExpiringMessages] = useState([]);
  const [stats, setStats] = useState({ total: 0, active: 0, expired: 0 });

  const durationOptions = [
    { value: '24h', label: '24 Hours', description: 'Messages disappear after 1 day' },
    { value: '7d', label: '7 Days', description: 'Messages disappear after 1 week' },
    { value: '30d', label: '30 Days', description: 'Messages disappear after 1 month' },
    { value: '90d', label: '90 Days', description: 'Messages disappear after 3 months' },
    { value: 'custom', label: 'Custom', description: 'Set your own duration' }
  ];

  useEffect(() => {
    loadExpiringMessages();
    loadStats();

    // Subscribe to expiration notifications
    const cleanup = disappearingMessagesService?.subscribeToExpirations(
      conversationId,
      (messages) => {
        setExpiringMessages(messages);
      }
    );

    return () => {
      if (cleanup) cleanup();
    };
  }, [conversationId]);

  const loadExpiringMessages = async () => {
    try {
      const messages = await disappearingMessagesService?.getMessagesExpiringSoon(conversationId);
      setExpiringMessages(messages);
    } catch (err) {
      console.error('Load expiring messages error:', err);
    }
  };

  const loadStats = async () => {
    try {
      const statistics = await disappearingMessagesService?.getDisappearingMessagesStats(conversationId);
      setStats(statistics);
    } catch (err) {
      console.error('Load stats error:', err);
    }
  };

  const handleToggle = async () => {
    try {
      setLoading(true);
      setError('');

      if (enabled) {
        await disappearingMessagesService?.disableDisappearingMessages(conversationId);
        setEnabled(false);
      } else {
        await disappearingMessagesService?.enableDisappearingMessages(
          conversationId,
          durationType,
          durationType === 'custom' ? customHours : null
        );
        setEnabled(true);
      }

      loadStats();
    } catch (err) {
      setError(err?.message || 'Failed to update settings');
    } finally {
      setLoading(false);
    }
  };

  const handleDurationChange = async (newDuration) => {
    setDurationType(newDuration);
    
    if (enabled) {
      try {
        await disappearingMessagesService?.enableDisappearingMessages(
          conversationId,
          newDuration,
          newDuration === 'custom' ? customHours : null
        );
      } catch (err) {
        setError(err?.message || 'Failed to update duration');
      }
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="sticky top-0 bg-white border-b border-gray-200 p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-purple-100 rounded-lg">
              <Timer className="w-6 h-6 text-purple-600" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-900">Disappearing Messages</h3>
              <p className="text-sm text-gray-600">Auto-delete after set time</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-gray-600" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {error && (
            <div className="p-4 bg-red-50 border border-red-200 rounded-lg flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
              <p className="text-sm text-red-700">{error}</p>
            </div>
          )}

          {/* Enable/Disable Toggle */}
          <div className="bg-gradient-to-r from-purple-50 to-blue-50 border border-purple-200 rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <h4 className="font-semibold text-gray-900 mb-1">Enable Disappearing Messages</h4>
                <p className="text-sm text-gray-600">
                  New messages will automatically delete after the set duration
                </p>
              </div>
              <button
                onClick={handleToggle}
                disabled={loading}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${enabled ? 'bg-purple-600' : 'bg-gray-300'} ${loading ? 'opacity-50 cursor-not-allowed' : ''}`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${enabled ? 'translate-x-6' : 'translate-x-1'}`}
                />
              </button>
            </div>
          </div>

          {/* Duration Selection */}
          {enabled && (
            <div>
              <h4 className="font-semibold text-gray-900 mb-3">Delete After</h4>
              <div className="space-y-2">
                {durationOptions?.map((option) => (
                  <button
                    key={option?.value}
                    onClick={() => handleDurationChange(option?.value)}
                    className={`w-full p-4 rounded-lg border transition-all text-left ${durationType === option?.value ? 'border-purple-600 bg-purple-50' : 'border-gray-200 hover:border-purple-300'}`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-medium text-gray-900">{option?.label}</span>
                      {durationType === option?.value && (
                        <div className="w-5 h-5 bg-purple-600 rounded-full flex items-center justify-center">
                          <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                          </svg>
                        </div>
                      )}
                    </div>
                    <p className="text-sm text-gray-600">{option?.description}</p>
                  </button>
                ))}
              </div>

              {/* Custom Duration Input */}
              {durationType === 'custom' && (
                <div className="mt-4 p-4 bg-purple-50 rounded-lg">
                  <label className="block text-sm font-medium text-gray-900 mb-2">
                    Custom Duration (Hours)
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="8760"
                    value={customHours}
                    onChange={(e) => setCustomHours(parseInt(e?.target?.value) || 24)}
                    className="w-full px-4 py-2 border border-purple-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                    placeholder="Enter hours"
                  />
                  <p className="text-xs text-gray-600 mt-2">
                    Messages will disappear after {customHours} hours
                  </p>
                </div>
              )}
            </div>
          )}

          {/* Statistics */}
          {enabled && (
            <div className="bg-gray-50 rounded-lg p-4">
              <h4 className="font-semibold text-gray-900 mb-3">Statistics</h4>
              <div className="grid grid-cols-3 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-600">{stats?.total}</div>
                  <div className="text-xs text-gray-600 mt-1">Total</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">{stats?.active}</div>
                  <div className="text-xs text-gray-600 mt-1">Active</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-gray-600">{stats?.expired}</div>
                  <div className="text-xs text-gray-600 mt-1">Expired</div>
                </div>
              </div>
            </div>
          )}

          {/* Expiring Soon Messages */}
          {expiringMessages?.length > 0 && (
            <div>
              <h4 className="font-semibold text-gray-900 mb-3 flex items-center gap-2">
                <AlertCircle className="w-5 h-5 text-orange-600" />
                Expiring Soon
              </h4>
              <div className="space-y-2">
                {expiringMessages?.map((msg) => (
                  <div
                    key={msg?.id}
                    className="p-3 bg-orange-50 border border-orange-200 rounded-lg"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1 min-w-0">
                        <p className="text-sm text-gray-900 truncate">{msg?.message}</p>
                      </div>
                      <div className="flex items-center gap-1 text-orange-600 flex-shrink-0">
                        <Clock className="w-4 h-4" />
                        <span className="text-xs font-medium">
                          {msg?.timeRemaining?.formatted}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Info Notice */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
              <div className="text-sm text-blue-900">
                <p className="font-medium mb-1">How it works</p>
                <ul className="space-y-1 text-blue-800">
                  <li>• New messages will automatically delete after the set time</li>
                  <li>• You will be notified before messages expire</li>
                  <li>• This setting applies to future messages only</li>
                  <li>• Both parties will see the timer on messages</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DisappearingMessagesPanel;