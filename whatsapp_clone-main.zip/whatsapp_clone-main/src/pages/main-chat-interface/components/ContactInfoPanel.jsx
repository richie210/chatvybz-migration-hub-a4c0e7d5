import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const ContactInfoPanel = ({ contact, isOpen, onClose, onBlock, onClearChat, onDeleteChat }) => {
  const [activeTab, setActiveTab] = useState('media');

  if (!isOpen || !contact) return null;

  const sharedMedia = [
  {
    id: 1,
    type: 'image',
    url: "https://images.unsplash.com/photo-1725500968235-2cd4a31e6df0",
    alt: 'Scenic mountain landscape with snow-capped peaks under blue sky at sunset',
    timestamp: '2025-12-20'
  },
  {
    id: 2,
    type: 'image',
    url: "https://images.unsplash.com/photo-1656604397205-93bbaa701da0",
    alt: 'Dense forest with tall trees and morning sunlight filtering through leaves',
    timestamp: '2025-12-19'
  },
  {
    id: 3,
    type: 'video',
    url: 'https://example.com/video1.mp4',
    thumbnail: "https://images.unsplash.com/photo-1647293476324-193d75696f6b",
    alt: 'Ocean waves crashing on rocky shore with seagulls flying overhead',
    timestamp: '2025-12-18'
  },
  {
    id: 4,
    type: 'image',
    url: "https://images.unsplash.com/photo-1633637568890-491517dea07b",
    alt: 'Misty lake surrounded by mountains during golden hour with reflection',
    timestamp: '2025-12-17'
  }];


  const sharedDocuments = [
  {
    id: 1,
    name: 'Project_Proposal.pdf',
    size: '2.4 MB',
    timestamp: '2025-12-20',
    icon: 'FileText'
  },
  {
    id: 2,
    name: 'Meeting_Notes.docx',
    size: '856 KB',
    timestamp: '2025-12-19',
    icon: 'FileText'
  },
  {
    id: 3,
    name: 'Budget_2025.xlsx',
    size: '1.2 MB',
    timestamp: '2025-12-18',
    icon: 'FileSpreadsheet'
  }];


  const sharedLinks = [
  {
    id: 1,
    url: 'https://github.com/example/project',
    title: 'GitHub Repository',
    description: 'Main project repository with documentation',
    timestamp: '2025-12-20'
  },
  {
    id: 2,
    url: 'https://docs.google.com/document/example',
    title: 'Google Docs',
    description: 'Shared document for collaboration',
    timestamp: '2025-12-19'
  }];


  return (
    <div className="fixed top-0 right-0 h-full w-full lg:w-96 bg-card border-l border-border z-50 overflow-y-auto custom-scrollbar">
      <div className="sticky top-0 bg-card border-b border-border p-4 md:p-6 flex items-center justify-between z-10">
        <h2 className="text-lg md:text-xl font-semibold">Contact Info</h2>
        <button
          onClick={onClose}
          className="p-2 rounded-lg hover:bg-muted transition-colors focus-ring"
          aria-label="Close contact info">

          <Icon name="X" size={20} color="var(--color-foreground)" className="md:w-6 md:h-6" />
        </button>
      </div>
      <div className="p-4 md:p-6 space-y-6 md:space-y-8">
        <div className="flex flex-col items-center text-center">
          <div className="relative mb-4">
            <div className="w-24 h-24 md:w-32 md:h-32 rounded-full overflow-hidden">
              <Image
                src={contact?.avatar}
                alt={contact?.avatarAlt}
                className="w-full h-full object-cover" />

            </div>
            {contact?.isOnline &&
            <div className="absolute bottom-2 right-2 w-5 h-5 md:w-6 md:h-6 bg-success rounded-full border-4 border-card" />
            }
          </div>
          <h3 className="text-xl md:text-2xl font-bold mb-2">{contact?.name}</h3>
          <p className="text-sm md:text-base text-muted-foreground mb-1">{contact?.phone}</p>
          <p className="text-sm md:text-base text-muted-foreground">{contact?.status}</p>
        </div>

        <div className="grid grid-cols-3 gap-3 md:gap-4">
          <button className="flex flex-col items-center gap-2 p-3 md:p-4 rounded-lg hover:bg-muted transition-colors focus-ring">
            <div className="w-10 h-10 md:w-12 md:h-12 rounded-full bg-primary/10 flex items-center justify-center">
              <Icon name="Phone" size={20} color="var(--color-primary)" className="md:w-6 md:h-6" />
            </div>
            <span className="text-xs md:text-sm font-medium">Audio</span>
          </button>
          <button className="flex flex-col items-center gap-2 p-3 md:p-4 rounded-lg hover:bg-muted transition-colors focus-ring">
            <div className="w-10 h-10 md:w-12 md:h-12 rounded-full bg-primary/10 flex items-center justify-center">
              <Icon name="Video" size={20} color="var(--color-primary)" className="md:w-6 md:h-6" />
            </div>
            <span className="text-xs md:text-sm font-medium">Video</span>
          </button>
          <button className="flex flex-col items-center gap-2 p-3 md:p-4 rounded-lg hover:bg-muted transition-colors focus-ring">
            <div className="w-10 h-10 md:w-12 md:h-12 rounded-full bg-primary/10 flex items-center justify-center">
              <Icon name="Search" size={20} color="var(--color-primary)" className="md:w-6 md:h-6" />
            </div>
            <span className="text-xs md:text-sm font-medium">Search</span>
          </button>
        </div>

        <div className="space-y-3 md:space-y-4">
          <div className="flex items-center gap-3 p-3 md:p-4 bg-muted rounded-lg">
            <Icon name="Bell" size={20} color="var(--color-foreground)" className="md:w-6 md:h-6" />
            <div className="flex-1">
              <p className="text-sm md:text-base font-medium">Notifications</p>
              <p className="text-xs md:text-sm text-muted-foreground">Enabled</p>
            </div>
            <button className="p-2 rounded-lg hover:bg-background transition-colors">
              <Icon name="ChevronRight" size={16} className="md:w-5 md:h-5" />
            </button>
          </div>

          <div className="flex items-center gap-3 p-3 md:p-4 bg-muted rounded-lg">
            <Icon name="Lock" size={20} color="var(--color-foreground)" className="md:w-6 md:h-6" />
            <div className="flex-1">
              <p className="text-sm md:text-base font-medium">Encryption</p>
              <p className="text-xs md:text-sm text-muted-foreground">End-to-end encrypted</p>
            </div>
            <Icon name="CheckCircle" size={16} color="var(--color-success)" className="md:w-5 md:h-5" />
          </div>
        </div>

        <div>
          <div className="flex gap-2 mb-4 border-b border-border">
            <button
              onClick={() => setActiveTab('media')}
              className={`flex-1 pb-3 text-sm md:text-base font-medium transition-colors ${
              activeTab === 'media' ? 'text-primary border-b-2 border-primary' : 'text-muted-foreground hover:text-foreground'}`
              }>

              Media
            </button>
            <button
              onClick={() => setActiveTab('docs')}
              className={`flex-1 pb-3 text-sm md:text-base font-medium transition-colors ${
              activeTab === 'docs' ?
              'text-primary border-b-2 border-primary' : 'text-muted-foreground hover:text-foreground'}`
              }>

              Docs
            </button>
            <button
              onClick={() => setActiveTab('links')}
              className={`flex-1 pb-3 text-sm md:text-base font-medium transition-colors ${
              activeTab === 'links' ? 'text-primary border-b-2 border-primary' : 'text-muted-foreground hover:text-foreground'}`
              }>

              Links
            </button>
          </div>

          {activeTab === 'media' &&
          <div className="grid grid-cols-3 gap-2 md:gap-3">
              {sharedMedia?.map((item) =>
            <div key={item?.id} className="aspect-square rounded-lg overflow-hidden cursor-pointer hover:opacity-80 transition-opacity">
                  {item?.type === 'image' ?
              <Image
                src={item?.url}
                alt={item?.alt}
                className="w-full h-full object-cover" /> :


              <div className="relative w-full h-full">
                      <Image
                  src={item?.thumbnail}
                  alt={item?.alt}
                  className="w-full h-full object-cover" />

                      <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                        <Icon name="Play" size={24} color="#FFFFFF" className="md:w-8 md:h-8" />
                      </div>
                    </div>
              }
                </div>
            )}
            </div>
          }

          {activeTab === 'docs' &&
          <div className="space-y-2 md:space-y-3">
              {sharedDocuments?.map((doc) =>
            <div key={doc?.id} className="flex items-center gap-3 p-3 md:p-4 bg-muted rounded-lg hover:bg-muted/80 transition-colors cursor-pointer">
                  <div className="w-10 h-10 md:w-12 md:h-12 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Icon name={doc?.icon} size={20} color="var(--color-primary)" className="md:w-6 md:h-6" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm md:text-base font-medium truncate">{doc?.name}</p>
                    <p className="text-xs md:text-sm text-muted-foreground">{doc?.size} • {doc?.timestamp}</p>
                  </div>
                  <button className="p-2 hover:bg-background rounded-lg transition-colors">
                    <Icon name="Download" size={16} className="md:w-5 md:h-5" />
                  </button>
                </div>
            )}
            </div>
          }

          {activeTab === 'links' &&
          <div className="space-y-2 md:space-y-3">
              {sharedLinks?.map((link) =>
            <a
              key={link?.id}
              href={link?.url}
              target="_blank"
              rel="noopener noreferrer"
              className="block p-3 md:p-4 bg-muted rounded-lg hover:bg-muted/80 transition-colors">

                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 md:w-12 md:h-12 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Icon name="Link" size={20} color="var(--color-primary)" className="md:w-6 md:h-6" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm md:text-base font-medium truncate">{link?.title}</p>
                      <p className="text-xs md:text-sm text-muted-foreground line-clamp-2">{link?.description}</p>
                      <p className="text-xs text-muted-foreground mt-1">{link?.timestamp}</p>
                    </div>
                  </div>
                </a>
            )}
            </div>
          }
        </div>

        <div className="space-y-2 md:space-y-3 pt-4 border-t border-border">
          <Button
            variant="outline"
            fullWidth
            iconName="Ban"
            iconPosition="left"
            onClick={onBlock}>

            Block Contact
          </Button>
          <Button
            variant="outline"
            fullWidth
            iconName="Trash"
            iconPosition="left"
            onClick={onClearChat}>

            Clear Chat
          </Button>
          <Button
            variant="destructive"
            fullWidth
            iconName="Trash2"
            iconPosition="left"
            onClick={onDeleteChat}>

            Delete Chat
          </Button>
        </div>
      </div>
    </div>);

};

export default ContactInfoPanel;