import React, { useState } from 'react';
import { Loader, Sparkles } from 'lucide-react';


const ClaudeReplySuggestions = ({ suggestions = [], onSelect, loading, onRefresh }) => {
  const [selectedIndex, setSelectedIndex] = useState(null);

  if (!suggestions || suggestions?.length === 0) return null;

  const getTypeIcon = (type) => {
    switch (type) {
      case 'acknowledgment':
        return '👍';
      case 'question':
        return '❓';
      case 'agreement':
        return '✅';
      case 'emoji':
        return '😊';
      default:
        return '💬';
    }
  };

  const getTypeColor = (type) => {
    switch (type) {
      case 'acknowledgment':
        return 'bg-blue-50 border-blue-200 hover:bg-blue-100';
      case 'question':
        return 'bg-purple-50 border-purple-200 hover:bg-purple-100';
      case 'agreement':
        return 'bg-green-50 border-green-200 hover:bg-green-100';
      case 'emoji':
        return 'bg-yellow-50 border-yellow-200 hover:bg-yellow-100';
      default:
        return 'bg-gray-50 border-gray-200 hover:bg-gray-100';
    }
  };

  return (
    <div className="bg-gradient-to-r from-purple-50 to-blue-50 border border-purple-200 rounded-lg p-3 mb-3 shadow-sm">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-purple-600" />
          <span className="text-sm font-medium text-purple-900">
            AI-Powered Reply Suggestions
          </span>
        </div>
        {onRefresh && (
          <button
            onClick={onRefresh}
            disabled={loading}
            className="p-1 hover:bg-white/50 rounded transition-colors"
            title="Refresh suggestions"
          >
            <Loader className={`w-4 h-4 text-purple-600 ${loading ? 'animate-spin' : ''}`} />
          </button>
        )}
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-4">
          <Loader className="w-5 h-5 text-purple-600 animate-spin" />
          <span className="ml-2 text-sm text-purple-700">Analyzing message...</span>
        </div>
      ) : (
        <div className="flex flex-wrap gap-2">
          {suggestions?.map((suggestion, index) => (
            <button
              key={index}
              onClick={() => {
                setSelectedIndex(index);
                onSelect?.(suggestion?.text);
              }}
              className={`flex items-center gap-2 px-3 py-2 rounded-lg border transition-all ${
                selectedIndex === index
                  ? 'ring-2 ring-purple-400 scale-95' :''
              } ${getTypeColor(suggestion?.type)}`}
            >
              <span className="text-base">{getTypeIcon(suggestion?.type)}</span>
              <span className="text-sm font-medium text-gray-700">
                {suggestion?.text}
              </span>
            </button>
          ))}
        </div>
      )}

      <p className="text-xs text-purple-600 mt-2 flex items-center gap-1">
        <Sparkles className="w-3 h-3" />
        Powered by Claude AI
      </p>
    </div>
  );
};

export default ClaudeReplySuggestions;