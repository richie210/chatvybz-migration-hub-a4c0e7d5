import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { Calendar, Clock, Send, X, CheckCircle, AlertCircle, Plus } from 'lucide-react';
import { scheduledMessageService } from '../../services/scheduledMessageService';
import { useAuth } from '../../contexts/AuthContext';
import Button from '../../components/ui/Button';

import ScheduleComposer from './components/ScheduleComposer';
import ScheduledMessageCard from './components/ScheduledMessageCard';
import CalendarView from './components/CalendarView';
import DeliveryTracker from './components/DeliveryTracker';

export default function MessageSchedulingHub() {
  const navigate = useNavigate();
  const { user, loading: authLoading, isAuthenticated } = useAuth();
  
  const [scheduledMessages, setScheduledMessages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [showComposer, setShowComposer] = useState(false);
  const [viewMode, setViewMode] = useState('list'); // list, calendar, tracking
  const [filterStatus, setFilterStatus] = useState('all'); // all, pending, delivered, cancelled

  useEffect(() => {
    if (authLoading) return;
    if (!isAuthenticated) {
      navigate('/login');
      return;
    }
    loadScheduledMessages();
    const unsubscribe = scheduledMessageService?.subscribeToChanges(() => {
      loadScheduledMessages();
    });
    return () => unsubscribe();
  }, [authLoading, isAuthenticated, navigate]);

  const loadScheduledMessages = async () => {
    try {
      setLoading(true);
      const messages = await scheduledMessageService?.getAll();
      setScheduledMessages(messages);
      setError('');
    } catch (err) {
      setError(err?.message || 'Failed to load scheduled messages');
    } finally {
      setLoading(false);
    }
  };

  const handleScheduleSuccess = async () => {
    setShowComposer(false);
    await loadScheduledMessages();
  };

  const handleCancelMessage = async (messageId) => {
    if (!window.confirm('Are you sure you want to cancel this scheduled message?')) {
      return;
    }
    try {
      await scheduledMessageService?.cancel(messageId);
      await loadScheduledMessages();
    } catch (err) {
      setError(err?.message || 'Failed to cancel message');
    }
  };

  const handleDeleteMessage = async (messageId) => {
    if (!window.confirm('Are you sure you want to delete this scheduled message?')) {
      return;
    }
    try {
      await scheduledMessageService?.delete(messageId);
      await loadScheduledMessages();
    } catch (err) {
      setError(err?.message || 'Failed to delete message');
    }
  };

  const filteredMessages = scheduledMessages?.filter(msg => {
    if (filterStatus === 'all') return true;
    return msg?.deliveryStatus === filterStatus;
  });

  const stats = {
    total: scheduledMessages?.length || 0,
    pending: scheduledMessages?.filter(m => m?.deliveryStatus === 'pending')?.length || 0,
    delivered: scheduledMessages?.filter(m => m?.deliveryStatus === 'delivered')?.length || 0,
    cancelled: scheduledMessages?.filter(m => m?.deliveryStatus === 'cancelled')?.length || 0
  };

  if (authLoading || loading) {
    return (
      <div className="flex items-center justify-center h-screen bg-gray-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Message Scheduling Hub - Manage Scheduled Messages</title>
        <meta name="description" content="Schedule messages, manage delivery, and track message status" />
      </Helmet>
      <div className="h-screen flex flex-col bg-gray-50">
        {/* Header */}
        <div className="bg-white border-b border-gray-200 shadow-sm">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-lg">
                  <Clock className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-gray-900">Message Scheduling Hub</h1>
                  <p className="text-sm text-gray-600">Centralized management for all scheduled messages</p>
                </div>
              </div>
              <Button 
                onClick={() => setShowComposer(true)}
                className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white"
              >
                <Plus className="w-4 h-4" />
                Schedule New Message
              </Button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-4 gap-4 mb-6">
              <div className="p-4 bg-gray-50 rounded-lg border border-gray-200">
                <p className="text-sm text-gray-600 mb-1">Total Scheduled</p>
                <p className="text-2xl font-bold text-gray-900">{stats?.total}</p>
              </div>
              <div className="p-4 bg-yellow-50 rounded-lg border border-yellow-200">
                <p className="text-sm text-yellow-700 mb-1">Pending</p>
                <p className="text-2xl font-bold text-yellow-900">{stats?.pending}</p>
              </div>
              <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                <p className="text-sm text-green-700 mb-1">Delivered</p>
                <p className="text-2xl font-bold text-green-900">{stats?.delivered}</p>
              </div>
              <div className="p-4 bg-gray-50 rounded-lg border border-gray-200">
                <p className="text-sm text-gray-600 mb-1">Cancelled</p>
                <p className="text-2xl font-bold text-gray-900">{stats?.cancelled}</p>
              </div>
            </div>

            {/* View Mode Toggle */}
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => setViewMode('list')}
                  className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
                    viewMode === 'list' ?'bg-blue-600 text-white' :'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50'
                  }`}
                >
                  <Send className="w-4 h-4 inline mr-2" />
                  List View
                </button>
                <button
                  onClick={() => setViewMode('calendar')}
                  className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
                    viewMode === 'calendar' ?'bg-blue-600 text-white' :'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50'
                  }`}
                >
                  <Calendar className="w-4 h-4 inline mr-2" />
                  Calendar View
                </button>
                <button
                  onClick={() => setViewMode('tracking')}
                  className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
                    viewMode === 'tracking' ?'bg-blue-600 text-white' :'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50'
                  }`}
                >
                  <CheckCircle className="w-4 h-4 inline mr-2" />
                  Delivery Tracking
                </button>
              </div>

              {/* Filter */}
              {viewMode === 'list' && (
                <select
                  value={filterStatus}
                  onChange={(e) => setFilterStatus(e?.target?.value)}
                  className="px-4 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="all">All Messages</option>
                  <option value="pending">Pending</option>
                  <option value="delivered">Delivered</option>
                  <option value="cancelled">Cancelled</option>
                </select>
              )}
            </div>
          </div>
        </div>

        {/* Error Display */}
        {error && (
          <div className="max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 mt-4">
            <div className="p-4 bg-red-50 border border-red-200 rounded-lg flex items-center gap-3">
              <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0" />
              <p className="text-sm text-red-800">{error}</p>
              <button onClick={() => setError('')} className="ml-auto text-red-600 hover:text-red-800">
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>
        )}

        {/* Main Content */}
        <div className="flex-1 overflow-y-auto">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            {viewMode === 'list' && (
              <div className="space-y-4">
                {filteredMessages?.length > 0 ? (
                  filteredMessages?.map((msg) => (
                    <ScheduledMessageCard
                      key={msg?.id}
                      message={msg}
                      onCancel={handleCancelMessage}
                      onDelete={handleDeleteMessage}
                    />
                  ))
                ) : (
                  <div className="text-center py-20 bg-white rounded-xl shadow-sm border border-gray-200">
                    <Clock className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-600 mb-2">No scheduled messages found</p>
                    <p className="text-sm text-gray-500">Click "Schedule New Message" to get started</p>
                  </div>
                )}
              </div>
            )}

            {viewMode === 'calendar' && (
              <CalendarView messages={scheduledMessages} />
            )}

            {viewMode === 'tracking' && (
              <DeliveryTracker messages={scheduledMessages} refreshKey={Date.now()} />
            )}
          </div>
        </div>

        {/* Composer Modal */}
        {showComposer && (
          <ScheduleComposer
            onClose={() => setShowComposer(false)}
            onSuccess={handleScheduleSuccess}
          />
        )}
      </div>
    </>
  );
}