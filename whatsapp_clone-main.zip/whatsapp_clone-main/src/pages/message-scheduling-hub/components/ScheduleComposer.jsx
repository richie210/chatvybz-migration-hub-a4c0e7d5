import React, { useState } from 'react';
import { X, Send, Calendar, Clock, Repeat, Globe, AlertCircle } from 'lucide-react';
import { scheduledMessageService } from '../../../services/scheduledMessageService';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';

function ScheduleComposer({ onClose, onSuccess }) {
  const [message, setMessage] = useState('');
  const [scheduledDate, setScheduledDate] = useState('');
  const [scheduledTime, setScheduledTime] = useState('');
  const [recipientId, setRecipientId] = useState('');
  const [recurringPattern, setRecurringPattern] = useState('');
  const [timezone, setTimezone] = useState(Intl.DateTimeFormat()?.resolvedOptions()?.timeZone);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e?.preventDefault();
    
    if (!message?.trim() || !scheduledDate || !scheduledTime) {
      setError('Please fill in all required fields');
      return;
    }

    try {
      setLoading(true);
      setError('');

      const scheduledDateTime = new Date(`${scheduledDate}T${scheduledTime}`);
      
      if (scheduledDateTime <= new Date()) {
        setError('Scheduled time must be in the future');
        return;
      }

      await scheduledMessageService?.create({
        message: message?.trim(),
        scheduledTime: scheduledDateTime?.toISOString(),
        recipientId: recipientId || null,
        recurringPattern: recurringPattern || null,
        timezone
      });

      onSuccess();
    } catch (err) {
      setError(err?.message || 'Failed to schedule message');
    } finally {
      setLoading(false);
    }
  };

  const getMinDateTime = () => {
    const now = new Date();
    return now?.toISOString()?.slice(0, 16);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
          <h2 className="text-xl font-bold text-gray-900">Schedule New Message</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <X className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {error && (
            <div className="p-4 bg-red-50 border border-red-200 rounded-lg flex items-center gap-3">
              <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0" />
              <p className="text-sm text-red-800">{error}</p>
            </div>
          )}

          {/* Message Content */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Message Content *
            </label>
            <textarea
              value={message}
              onChange={(e) => setMessage(e?.target?.value)}
              placeholder="Type your message here..."
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
              rows={5}
              required
            />
            <p className="text-xs text-gray-500 mt-1">{message?.length} characters</p>
          </div>

          {/* Date and Time */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <Calendar className="w-4 h-4 inline mr-1" />
                Date *
              </label>
              <Input
                type="date"
                value={scheduledDate}
                onChange={(e) => setScheduledDate(e?.target?.value)}
                min={new Date()?.toISOString()?.split('T')?.[0]}
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                <Clock className="w-4 h-4 inline mr-1" />
                Time *
              </label>
              <Input
                type="time"
                value={scheduledTime}
                onChange={(e) => setScheduledTime(e?.target?.value)}
                required
              />
            </div>
          </div>

          {/* Recipient (Optional) */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Recipient (Optional)
            </label>
            <Input
              type="text"
              value={recipientId}
              onChange={(e) => setRecipientId(e?.target?.value)}
              placeholder="Enter recipient ID or leave blank for broadcast"
            />
          </div>

          {/* Recurring Pattern */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Repeat className="w-4 h-4 inline mr-1" />
              Recurring Pattern (Optional)
            </label>
            <select
              value={recurringPattern}
              onChange={(e) => setRecurringPattern(e?.target?.value)}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="">One-time message</option>
              <option value="daily">Daily</option>
              <option value="weekly">Weekly</option>
              <option value="monthly">Monthly</option>
            </select>
          </div>

          {/* Timezone */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Globe className="w-4 h-4 inline mr-1" />
              Timezone
            </label>
            <Input
              type="text"
              value={timezone}
              onChange={(e) => setTimezone(e?.target?.value)}
              placeholder="Timezone"
            />
            <p className="text-xs text-gray-500 mt-1">Auto-detected: {Intl.DateTimeFormat()?.resolvedOptions()?.timeZone}</p>
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end space-x-3 pt-4 border-t border-gray-200">
            <Button
              type="button"
              onClick={onClose}
              className="px-6 py-2 text-gray-700 bg-white border border-gray-300 hover:bg-gray-50"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={loading}
              className="px-6 py-2 bg-blue-600 text-white hover:bg-blue-700 disabled:opacity-50 flex items-center gap-2"
            >
              {loading ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white" />
                  Scheduling...
                </>
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  Schedule Message
                </>
              )}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default ScheduleComposer;
