import React from 'react';
import { CheckCircle, Clock, XCircle, AlertTriangle, TrendingUp } from 'lucide-react';

function DeliveryTracker({ messages }) {
  const deliveryStats = {
    total: messages?.length || 0,
    delivered: messages?.filter(m => m?.deliveryStatus === 'delivered')?.length || 0,
    pending: messages?.filter(m => m?.deliveryStatus === 'pending')?.length || 0,
    failed: messages?.filter(m => m?.deliveryStatus === 'failed')?.length || 0,
    cancelled: messages?.filter(m => m?.deliveryStatus === 'cancelled')?.length || 0
  };

  const deliveryRate = deliveryStats?.total > 0
    ? ((deliveryStats?.delivered / deliveryStats?.total) * 100)?.toFixed(1)
    : 0;

  const recentDeliveries = messages
    ?.filter(m => m?.deliveredAt)
    ?.sort((a, b) => new Date(b?.deliveredAt) - new Date(a?.deliveredAt))
    ?.slice(0, 10);

  const formatDateTime = (dateTimeString) => {
    const date = new Date(dateTimeString);
    return date?.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="space-y-6">
      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-2">
            <CheckCircle className="w-8 h-8 text-green-600" />
            <span className="text-3xl font-bold text-green-600">{deliveryStats?.delivered}</span>
          </div>
          <p className="text-sm text-gray-600">Successfully Delivered</p>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-2">
            <Clock className="w-8 h-8 text-yellow-600" />
            <span className="text-3xl font-bold text-yellow-600">{deliveryStats?.pending}</span>
          </div>
          <p className="text-sm text-gray-600">Pending Delivery</p>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-2">
            <XCircle className="w-8 h-8 text-red-600" />
            <span className="text-3xl font-bold text-red-600">{deliveryStats?.failed}</span>
          </div>
          <p className="text-sm text-gray-600">Failed Deliveries</p>
        </div>

        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-2">
            <TrendingUp className="w-8 h-8 text-blue-600" />
            <span className="text-3xl font-bold text-blue-600">{deliveryRate}%</span>
          </div>
          <p className="text-sm text-gray-600">Delivery Success Rate</p>
        </div>
      </div>
      {/* Recent Deliveries */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Recent Deliveries</h3>
        {recentDeliveries?.length > 0 ? (
          <div className="space-y-3">
            {recentDeliveries?.map((msg) => (
              <div key={msg?.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg border border-gray-200">
                <div className="flex-1">
                  <p className="text-sm text-gray-900 mb-1 truncate">{msg?.message}</p>
                  <div className="flex items-center space-x-4 text-xs text-gray-600">
                    <span>Scheduled: {formatDateTime(msg?.scheduledTime)}</span>
                    <span>Delivered: {formatDateTime(msg?.deliveredAt)}</span>
                  </div>
                </div>
                <CheckCircle className="w-5 h-5 text-green-600 ml-4" />
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-8">
            <AlertTriangle className="w-12 h-12 text-gray-400 mx-auto mb-3" />
            <p className="text-gray-600">No delivery history available</p>
          </div>
        )}
      </div>
      {/* Delivery Performance Chart */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Delivery Performance</h3>
        <div className="space-y-4">
          <div>
            <div className="flex items-center justify-between text-sm mb-2">
              <span className="text-gray-700">Delivered</span>
              <span className="font-medium text-green-600">{deliveryStats?.delivered} ({deliveryRate}%)</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-3">
              <div
                className="bg-green-600 h-3 rounded-full transition-all duration-300"
                style={{ width: `${deliveryRate}%` }}
              />
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between text-sm mb-2">
              <span className="text-gray-700">Pending</span>
              <span className="font-medium text-yellow-600">
                {deliveryStats?.pending} ({deliveryStats?.total > 0 ? ((deliveryStats?.pending / deliveryStats?.total) * 100)?.toFixed(1) : 0}%)
              </span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-3">
              <div
                className="bg-yellow-600 h-3 rounded-full transition-all duration-300"
                style={{ width: `${deliveryStats?.total > 0 ? (deliveryStats?.pending / deliveryStats?.total) * 100 : 0}%` }}
              />
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between text-sm mb-2">
              <span className="text-gray-700">Failed</span>
              <span className="font-medium text-red-600">
                {deliveryStats?.failed} ({deliveryStats?.total > 0 ? ((deliveryStats?.failed / deliveryStats?.total) * 100)?.toFixed(1) : 0}%)
              </span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-3">
              <div
                className="bg-red-600 h-3 rounded-full transition-all duration-300"
                style={{ width: `${deliveryStats?.total > 0 ? (deliveryStats?.failed / deliveryStats?.total) * 100 : 0}%` }}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default DeliveryTracker;
