import React, { useState } from 'react';
import { Calendar as CalendarIcon, ChevronLeft, ChevronRight } from 'lucide-react';

function CalendarView({ messages }) {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [viewType, setViewType] = useState('month'); // month, week, day

  const getDaysInMonth = (date) => {
    const year = date?.getFullYear();
    const month = date?.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay?.getDate();
    const startingDayOfWeek = firstDay?.getDay();
    
    return { daysInMonth, startingDayOfWeek, year, month };
  };

  const getMessagesForDate = (date) => {
    return messages?.filter(msg => {
      const msgDate = new Date(msg?.scheduledTime);
      return msgDate?.toDateString() === date?.toDateString();
    });
  };

  const navigateMonth = (direction) => {
    const newDate = new Date(currentDate);
    newDate?.setMonth(currentDate?.getMonth() + direction);
    setCurrentDate(newDate);
  };

  const { daysInMonth, startingDayOfWeek, year, month } = getDaysInMonth(currentDate);
  const monthName = currentDate?.toLocaleString('default', { month: 'long', year: 'numeric' });

  const renderMonthView = () => {
    const days = [];
    const totalCells = Math.ceil((daysInMonth + startingDayOfWeek) / 7) * 7;

    for (let i = 0; i < totalCells; i++) {
      const dayNumber = i - startingDayOfWeek + 1;
      const isValidDay = dayNumber > 0 && dayNumber <= daysInMonth;
      const date = new Date(year, month, dayNumber);
      const dayMessages = isValidDay ? getMessagesForDate(date) : [];
      const isToday = isValidDay && date?.toDateString() === new Date()?.toDateString();

      days?.push(
        <div
          key={i}
          className={`min-h-24 p-2 border border-gray-200 ${
            !isValidDay ? 'bg-gray-50' : isToday ? 'bg-blue-50' : 'bg-white'
          }`}
        >
          {isValidDay && (
            <>
              <div className={`text-sm font-medium mb-1 ${
                isToday ? 'text-blue-600' : 'text-gray-700'
              }`}>
                {dayNumber}
              </div>
              {dayMessages?.length > 0 && (
                <div className="space-y-1">
                  {dayMessages?.slice(0, 3)?.map((msg, idx) => (
                    <div
                      key={idx}
                      className="text-xs p-1 bg-blue-100 text-blue-800 rounded truncate"
                      title={msg?.message}
                    >
                      {new Date(msg?.scheduledTime)?.toLocaleTimeString('en-US', {
                        hour: '2-digit',
                        minute: '2-digit'
                      })}
                    </div>
                  ))}
                  {dayMessages?.length > 3 && (
                    <div className="text-xs text-gray-500">+{dayMessages?.length - 3} more</div>
                  )}
                </div>
              )}
            </>
          )}
        </div>
      );
    }

    return days;
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <CalendarIcon className="w-6 h-6 text-blue-600" />
          <h2 className="text-xl font-bold text-gray-900">{monthName}</h2>
        </div>
        <div className="flex items-center space-x-2">
          <button
            onClick={() => navigateMonth(-1)}
            className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <button
            onClick={() => setCurrentDate(new Date())}
            className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50"
          >
            Today
          </button>
          <button
            onClick={() => navigateMonth(1)}
            className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      </div>
      {/* Calendar Grid */}
      <div className="grid grid-cols-7 gap-0 border border-gray-200 rounded-lg overflow-hidden">
        {/* Day Headers */}
        {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat']?.map((day) => (
          <div key={day} className="p-2 bg-gray-100 border-b border-gray-200 text-center">
            <span className="text-sm font-semibold text-gray-700">{day}</span>
          </div>
        ))}
        {/* Days */}
        {renderMonthView()}
      </div>
      {/* Legend */}
      <div className="mt-4 flex items-center space-x-4 text-sm text-gray-600">
        <div className="flex items-center space-x-2">
          <div className="w-4 h-4 bg-blue-50 border border-blue-200 rounded" />
          <span>Today</span>
        </div>
        <div className="flex items-center space-x-2">
          <div className="w-4 h-4 bg-blue-100 rounded" />
          <span>Scheduled Message</span>
        </div>
      </div>
    </div>
  );
}

export default CalendarView;
