import React from 'react';
import { Clock, User, Repeat, Trash2, X, CheckCircle, AlertCircle } from 'lucide-react';

function ScheduledMessageCard({ message, onCancel, onDelete }) {
  const formatDateTime = (dateTimeString) => {
    const date = new Date(dateTimeString);
    return date?.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'pending': return { bg: 'bg-yellow-50', text: 'text-yellow-700', border: 'border-yellow-300', icon: Clock };
      case 'delivered': return { bg: 'bg-green-50', text: 'text-green-700', border: 'border-green-300', icon: CheckCircle };
      case 'cancelled': return { bg: 'bg-gray-50', text: 'text-gray-700', border: 'border-gray-300', icon: X };
      case 'failed': return { bg: 'bg-red-50', text: 'text-red-700', border: 'border-red-300', icon: AlertCircle };
      default: return { bg: 'bg-gray-50', text: 'text-gray-700', border: 'border-gray-300', icon: Clock };
    }
  };

  const statusColors = getStatusColor(message?.deliveryStatus);
  const StatusIcon = statusColors?.icon;

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between mb-4">
        <div className="flex-1">
          <div className="flex items-center space-x-3 mb-2">
            <span className={`px-3 py-1 text-xs font-semibold rounded-full ${statusColors?.bg} ${statusColors?.text} border ${statusColors?.border} flex items-center space-x-1`}>
              <StatusIcon className="w-3 h-3" />
              <span className="capitalize">{message?.deliveryStatus}</span>
            </span>
            {message?.recurringPattern && (
              <span className="px-3 py-1 text-xs font-semibold text-purple-700 bg-purple-100 rounded-full border border-purple-300 flex items-center space-x-1">
                <Repeat className="w-3 h-3" />
                <span className="capitalize">{message?.recurringPattern}</span>
              </span>
            )}
          </div>
          <p className="text-gray-900 text-base mb-3">{message?.message}</p>
          <div className="flex items-center space-x-4 text-sm text-gray-600">
            <div className="flex items-center space-x-1">
              <Clock className="w-4 h-4" />
              <span>{formatDateTime(message?.scheduledTime)}</span>
            </div>
            {message?.recipient && (
              <div className="flex items-center space-x-1">
                <User className="w-4 h-4" />
                <span>{message?.recipient?.fullName}</span>
              </div>
            )}
          </div>
        </div>

        {/* Actions */}
        <div className="flex items-center space-x-2 ml-4">
          {message?.deliveryStatus === 'pending' && (
            <button
              onClick={() => onCancel(message?.id)}
              className="p-2 text-orange-600 hover:bg-orange-50 rounded-lg transition-colors"
              title="Cancel"
            >
              <X className="w-5 h-5" />
            </button>
          )}
          <button
            onClick={() => onDelete(message?.id)}
            className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
            title="Delete"
          >
            <Trash2 className="w-5 h-5" />
          </button>
        </div>
      </div>
      {/* Delivery Info */}
      {message?.deliveredAt && (
        <div className="pt-3 border-t border-gray-200">
          <p className="text-xs text-gray-500">
            Delivered at: {formatDateTime(message?.deliveredAt)}
          </p>
        </div>
      )}
    </div>
  );
}

export default ScheduledMessageCard;
