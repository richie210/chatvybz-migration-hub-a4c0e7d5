import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { QRCodeSVG } from 'qrcode.react';
import { qrAuthService } from '../../../services/qrAuthService';
import { useAuth } from '../../../contexts/AuthContext';
import Icon from '../../../components/AppIcon';

const QRCodeAuthForm = () => {
  const navigate = useNavigate();
  const { signIn } = useAuth();
  const [qrData, setQrData] = useState(null);
  const [tokenId, setTokenId] = useState(null);
  const [status, setStatus] = useState('generating');
  const [timeLeft, setTimeLeft] = useState(300);
  const [error, setError] = useState(null);
  const [verifiedUser, setVerifiedUser] = useState(null);
  const pollingIntervalRef = useRef(null);
  const timerIntervalRef = useRef(null);

  useEffect(() => {
    generateQRCode();
    return () => {
      if (pollingIntervalRef?.current) clearInterval(pollingIntervalRef?.current);
      if (timerIntervalRef?.current) clearInterval(timerIntervalRef?.current);
    };
  }, []);

  const generateQRCode = async () => {
    try {
      setStatus('generating');
      setError(null);
      
      const result = await qrAuthService?.generateQRToken();
      setQrData(result?.qrData);
      setTokenId(result?.tokenId);
      setTimeLeft(300);
      setStatus('waiting');

      startPolling(result?.tokenId);
      startTimer();
    } catch (err) {
      setError(err?.message || 'Failed to generate QR code');
      setStatus('error');
    }
  };

  const startPolling = (token) => {
    if (pollingIntervalRef?.current) clearInterval(pollingIntervalRef?.current);
    
    pollingIntervalRef.current = setInterval(async () => {
      try {
        const result = await qrAuthService?.checkQRTokenStatus(token);
        
        if (result?.status === 'verified') {
          setStatus('verified');
          setVerifiedUser(result?.profile);
          clearInterval(pollingIntervalRef?.current);
          clearInterval(timerIntervalRef?.current);
          
          setTimeout(() => {
            navigate('/main-chat-interface');
          }, 1500);
        } else if (result?.status === 'expired') {
          setStatus('expired');
          clearInterval(pollingIntervalRef?.current);
          clearInterval(timerIntervalRef?.current);
        }
      } catch (err) {
        console.error('Polling error:', err);
      }
    }, 2000);
  };

  const startTimer = () => {
    if (timerIntervalRef?.current) clearInterval(timerIntervalRef?.current);
    
    timerIntervalRef.current = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timerIntervalRef?.current);
          clearInterval(pollingIntervalRef?.current);
          setStatus('expired');
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs?.toString()?.padStart(2, '0')}`;
  };

  const handleRefresh = () => {
    if (pollingIntervalRef?.current) clearInterval(pollingIntervalRef?.current);
    if (timerIntervalRef?.current) clearInterval(timerIntervalRef?.current);
    generateQRCode();
  };

  return (
    <div className="space-y-6">
      {/* QR Code Display */}
      <div className="bg-gray-50 rounded-xl p-6 flex items-center justify-center min-h-[320px]">
        {status === 'generating' && (
          <div className="text-center">
            <Icon name="RefreshCw" size={48} className="text-blue-600 animate-spin mx-auto mb-4" />
            <p className="text-sm text-gray-600">Generating secure QR code...</p>
          </div>
        )}

        {(status === 'waiting' || status === 'scanning') && qrData && (
          <div className="text-center">
            <QRCodeSVG
              value={qrData}
              size={240}
              level="H"
              includeMargin={true}
              className="mx-auto"
            />
          </div>
        )}

        {status === 'verified' && verifiedUser && (
          <div className="text-center">
            <Icon name="CheckCircle" size={64} className="text-blue-600 mx-auto mb-4" />
            <h3 className="font-semibold text-gray-900 mb-2">
              Successfully Authenticated!
            </h3>
            <p className="text-sm text-gray-600">
              {verifiedUser?.full_name || verifiedUser?.phone_number_e164}
            </p>
          </div>
        )}

        {status === 'expired' && (
          <div className="text-center">
            <Icon name="Clock" size={64} className="text-orange-500 mx-auto mb-4" />
            <h3 className="font-semibold text-gray-900 mb-2">
              QR Code Expired
            </h3>
            <p className="text-sm text-gray-600 mb-4">
              Please refresh to generate a new code
            </p>
            <button
              onClick={handleRefresh}
              className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <Icon name="RefreshCw" size={16} />
              Refresh QR Code
            </button>
          </div>
        )}

        {status === 'error' && (
          <div className="text-center">
            <Icon name="XCircle" size={64} className="text-red-500 mx-auto mb-4" />
            <h3 className="font-semibold text-gray-900 mb-2">
              Error
            </h3>
            <p className="text-sm text-gray-600 mb-4">
              {error || 'Failed to generate QR code'}
            </p>
            <button
              onClick={handleRefresh}
              className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
            >
              <Icon name="RefreshCw" size={16} />
              Try Again
            </button>
          </div>
        )}
      </div>

      {/* Timer and Refresh */}
      {(status === 'waiting' || status === 'scanning') && (
        <div className="space-y-3">
          <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg border border-blue-200">
            <div className="flex items-center gap-2">
              <Icon name="Clock" size={20} className="text-blue-600" />
              <span className="text-sm font-semibold text-gray-900">
                Expires in
              </span>
            </div>
            <span className="text-lg font-bold text-blue-600">
              {formatTime(timeLeft)}
            </span>
          </div>

          <button
            onClick={handleRefresh}
            className="w-full flex items-center justify-center gap-2 p-3 text-sm text-gray-600 hover:text-gray-900 transition-colors"
          >
            <Icon name="RefreshCw" size={16} />
            <span>Refresh QR Code</span>
          </button>
        </div>
      )}

      {/* Instructions */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <div className="flex items-start gap-3">
          <Icon name="Smartphone" size={20} className="text-blue-600 flex-shrink-0 mt-0.5" />
          <div>
            <h4 className="text-sm font-semibold text-blue-900 mb-2">
              How to Login with QR Code
            </h4>
            <ol className="space-y-2 text-xs text-blue-700">
              <li className="flex items-start gap-2">
                <span className="font-bold text-blue-600">1.</span>
                <span>Open ChatVybz mobile app on your phone</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="font-bold text-blue-600">2.</span>
                <span>Tap the <strong>QR Scanner</strong> icon in the menu</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="font-bold text-blue-600">3.</span>
                <span>Point your camera at the QR code above</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="font-bold text-blue-600">4.</span>
                <span>Confirm login on your phone when prompted</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="font-bold text-blue-600">5.</span>
                <span>You'll be automatically logged in on this device</span>
              </li>
            </ol>
          </div>
        </div>
      </div>

      {/* Security Notice */}
      <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
        <div className="flex items-start gap-3">
          <Icon name="Shield" size={20} className="text-gray-600 flex-shrink-0 mt-0.5" />
          <div>
            <h4 className="text-sm font-semibold text-gray-900 mb-1">
              Secure & Fast
            </h4>
            <p className="text-xs text-gray-600">
              Your session is encrypted end-to-end. QR codes expire after 5 minutes for your security. No password needed.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default QRCodeAuthForm;