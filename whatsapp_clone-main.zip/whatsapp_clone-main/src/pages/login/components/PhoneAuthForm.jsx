import React, { useState, useEffect } from 'react';
import { Phone, ArrowRight, Clock, AlertCircle } from 'lucide-react';
import Button from '../../../components/ui/Button';
import Input from '../../../components/ui/Input';
import Icon from '../../../components/AppIcon';
import phoneValidationService from '../../../services/phoneValidationService';

const PhoneAuthForm = ({ onSendOTP, isLoading }) => {
  const [phoneNumber, setPhoneNumber] = useState('');
  const [email, setEmail] = useState('');
  const [showEmailInput, setShowEmailInput] = useState(false);
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [rateLimitInfo, setRateLimitInfo] = useState(null);
  const [timeUntilReset, setTimeUntilReset] = useState(null);
  const [validationHint, setValidationHint] = useState(null);

  // Countdown timer for rate limit reset
  useEffect(() => {
    if (!rateLimitInfo?.resetAt) {
      setTimeUntilReset(null);
      return;
    }

    const updateCountdown = () => {
      const resetTime = new Date(rateLimitInfo.resetAt);
      const now = new Date();
      const diff = resetTime - now;

      if (diff <= 0) {
        setRateLimitInfo(null);
        setTimeUntilReset(null);
        return;
      }

      const minutes = Math.floor(diff / 60000);
      const seconds = Math.floor((diff % 60000) / 1000);
      setTimeUntilReset(`${minutes}m ${seconds}s`);
    };

    updateCountdown();
    const interval = setInterval(updateCountdown, 1000);

    return () => clearInterval(interval);
  }, [rateLimitInfo]);

  const validatePhone = () => {
    const newErrors = {};

    if (!phoneNumber) {
      newErrors.phoneNumber = 'Phone number is required';
      setErrors(newErrors);
      return false;
    }

    try {
      // Use phoneValidationService for validation (now synchronous)
      const validation = phoneValidationService?.validateAndFormat(phoneNumber);
      
      if (!validation?.isValid) {
        newErrors.phoneNumber = validation?.error || 'Please enter a valid phone number';
        
        // Set hint for better user guidance
        if (validation?.hint) {
          setValidationHint(validation?.hint);
        }
        
        // Special handling for Caribbean regions
        if (validation?.region) {
          setValidationHint(`${validation?.region} format: ${validation?.hint}`);
        }
      } else {
        // Clear hint on successful validation
        setValidationHint(null);
        
        // Show success hint for Caribbean regions
        if (validation?.isCaribbean && validation?.regionInfo) {
          setValidationHint(`✓ Valid ${validation?.regionInfo?.name} phone number`);
        }
      }
    } catch (error) {
      console.error('❌ Validation error:', error);
      newErrors.phoneNumber = 'Error validating phone number. Please try again.';
    }

    setErrors(newErrors);
    return Object.keys(newErrors)?.length === 0;
  };

  const handleSubmit = async (e) => {
    e?.preventDefault();
    setErrors({});
    setRateLimitInfo(null);
    setValidationHint(null);

    // Validation
    if (!phoneNumber?.trim()) {
      setErrors({ phoneNumber: 'Phone number is required' });
      return;
    }

    // Extract country code and phone number
    const match = phoneNumber?.match(/^(\+\d{1,4})\s*(.+)$/);
    if (!match) {
      setErrors({ phoneNumber: 'Invalid phone number format. Please include country code (e.g., +596 for Martinique)' });
      return;
    }

    // Validate email if provided
    if (showEmailInput && email) {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex?.test(email)) {
        setErrors({ email: 'Please enter a valid email address' });
        return;
      }
    }

    try {
      setIsSubmitting(true);

      if (!match) {
        setErrors({ phoneNumber: 'Invalid phone number format' });
        return;
      }

      console.log('📞 Sending OTP to:', { 
        countryCode: match?.[1], 
        phoneNumber: match?.[2],
        email: showEmailInput ? email : null,
        fullNumber: phoneNumber 
      });

      // Call the parent handler with email for fallback
      await onSendOTP({ 
        countryCode: match?.[1], // e.g., "+596"
        phoneNumber: match?.[2],  // e.g., "696972158"
        email: showEmailInput && email ? email : null
      });
    } catch (error) {
      console.error('❌ Error in handleSubmit:', error);
      
      // Check if this is a rate limit error
      const errorMessage = error?.message || '';
      if (errorMessage?.includes('Too many') || errorMessage?.includes('Rate limit')) {
        // Extract reset time if available from error
        const resetMatch = errorMessage?.match(/(\d+)\s*(hour|minute|min)/i);
        const resetTime = new Date();
        
        if (resetMatch) {
          const amount = parseInt(resetMatch?.[1]);
          const unit = resetMatch?.[2]?.toLowerCase();
          
          if (unit?.includes('hour')) {
            resetTime?.setHours(resetTime?.getHours() + amount);
          } else {
            resetTime?.setMinutes(resetTime?.getMinutes() + amount);
          }
        } else {
          // Default to 1 hour if no time specified
          resetTime?.setHours(resetTime?.getHours() + 1);
        }
        
        setRateLimitInfo({
          blocked: true,
          resetAt: resetTime?.toISOString(),
          message: 'Too many verification attempts. Please wait before trying again.'
        });
        
        setErrors({ 
          phoneNumber: 'Maximum verification attempts reached. Please wait before trying again.' 
        });
      } else if (errorMessage?.includes('region') || errorMessage?.includes('Caribbean') || errorMessage?.includes('international')) {
        // Regional delivery error
        setErrors({ 
          phoneNumber: errorMessage
        });
        setValidationHint('If you\'re in Martinique or Caribbean region, ensure your Twilio account has international SMS enabled. Contact support for assistance.');
      } else {
        setErrors({ 
          phoneNumber: errorMessage || 'Failed to send verification code. Please try again.' 
        });
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const handlePhoneChange = (value) => {
    try {
      setPhoneNumber(value || '');
      if (errors?.phoneNumber) {
        setErrors(prev => ({ ...prev, phoneNumber: '' }));
      }
      if (validationHint) {
        setValidationHint(null);
      }
    } catch (error) {
      console.error('❌ Error in handlePhoneChange:', error);
    }
  };

  const handleEmailChange = (value) => {
    setEmail(value || '');
    if (errors?.email) {
      setErrors(prev => ({ ...prev, email: '' }));
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Error Display */}
      {errors?.phoneNumber && (
        <div className="p-3 bg-red-50 border border-red-200 rounded-lg flex items-start gap-2">
          <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
          <div className="text-sm text-red-800">
            <p className="font-medium">Error</p>
            <p>{errors?.phoneNumber}</p>
          </div>
        </div>
      )}
      {/* Validation Hint */}
      {validationHint && !errors?.phoneNumber && (
        <div className={`p-3 border rounded-lg flex items-start gap-2 ${
          validationHint?.startsWith('✓') 
            ? 'bg-green-50 border-green-200' :'bg-blue-50 border-blue-200'
        }`}>
          <Icon 
            name={validationHint?.startsWith('✓') ? 'CheckCircle' : 'Info'} 
            className={`w-5 h-5 flex-shrink-0 mt-0.5 ${
              validationHint?.startsWith('✓') ? 'text-green-600' : 'text-blue-600'
            }`} 
          />
          <div className={`text-sm ${
            validationHint?.startsWith('✓') ? 'text-green-800' : 'text-blue-800'
          }`}>
            <p>{validationHint}</p>
          </div>
        </div>
      )}
      <div className="space-y-4">
        {/* Phone Number Input */}
        <div>
          <label htmlFor="phoneNumber" className="block text-sm font-medium text-gray-700 mb-2">
            Phone Number
          </label>
          <div className="relative">
            <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
            <Input
              id="phoneNumber"
              type="tel"
              value={phoneNumber}
              onChange={(e) => handlePhoneChange(e?.target?.value)}
              onBlur={validatePhone}
              placeholder="+596 696 XX XX XX"
              className={`pl-10 ${
                errors?.phoneNumber ? 'border-red-500 focus:ring-red-500' : ''
              }`}
            />
          </div>
        </div>

        {/* Email Input Toggle */}
        <div>
          <button
            type="button"
            onClick={() => setShowEmailInput(!showEmailInput)}
            className="flex items-center gap-2 text-sm text-blue-600 hover:text-blue-700 font-medium"
          >
            <Icon name={showEmailInput ? 'ChevronUp' : 'ChevronDown'} size={16} />
            <span>{showEmailInput ? 'Hide' : 'Add'} email for backup delivery</span>
          </button>
          {showEmailInput && (
            <div className="mt-3">
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                Email Address (Optional)
              </label>
              <div className="relative">
                <Icon name="Mail" className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => handleEmailChange(e?.target?.value)}
                  placeholder="your.email@example.com"
                  className={`pl-10 ${
                    errors?.email ? 'border-red-500 focus:ring-red-500' : ''
                  }`}
                />
              </div>
              {errors?.email && (
                <p className="mt-1 text-xs text-red-600">{errors?.email}</p>
              )}
              <p className="mt-2 text-xs text-gray-500">
                If SMS fails, we'll automatically send the code to your email
              </p>
            </div>
          )}
        </div>

        {/* Rate Limit Warning */}
        {rateLimitInfo?.blocked && timeUntilReset && (
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
            <div className="flex items-start gap-3">
              <Clock className="text-amber-600 mt-0.5" size={20} />
              <div className="flex-1">
                <h4 className="text-sm font-semibold text-amber-900 mb-1">
                  Verification Limit Reached
                </h4>
                <p className="text-sm text-amber-800 mb-2">
                  You've reached the maximum number of verification attempts. Please wait before requesting a new code.
                </p>
                <div className="flex items-center gap-2 text-sm font-medium text-amber-900">
                  <Clock size={16} />
                  <span>Try again in: {timeUntilReset}</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Country Code Helper */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
          <p className="text-sm text-blue-800">
            <strong>Tip:</strong> Include your country code:
          </p>
          <ul className="text-xs text-blue-700 mt-1 ml-4 list-disc">
            <li>Martinique: +596 (9 digits)</li>
            <li>United States: +1</li>
            <li>United Kingdom: +44</li>
          </ul>
        </div>
      </div>
      {/* Submit Button */}
      <Button
        type="submit"
        disabled={isSubmitting}
        className="w-full flex items-center justify-center gap-2"
      >
        {isSubmitting ? (
          <>
            <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white" />
            Sending Code...
          </>
        ) : (
          <>
            Send Verification Code
            <ArrowRight size={20} />
          </>
        )}
      </Button>
      {/* Security Information */}
      <div className="mt-4 p-3 bg-green-50 border border-green-200 rounded-lg">
        <div className="flex items-start gap-2">
          <Icon name="ShieldCheck" className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
          <div className="text-sm text-green-800 space-y-1">
            <p className="font-medium">Secure Supabase Auth Phone Verification</p>
            <ul className="list-disc list-inside space-y-0.5 text-xs">
              <li>Built-in Supabase phone authentication</li>
              <li>Automatic SMS OTP delivery</li>
              <li>Secure session management</li>
              <li>Rate limiting and security features</li>
            </ul>
          </div>
        </div>
      </div>
    </form>
  );
};

export default PhoneAuthForm;