import React, { useState, useEffect, useRef } from 'react';
import Button from '../../../components/ui/Button';
import Icon from '../../../components/AppIcon';

const OTPVerificationForm = ({ contactInfo, onVerify, onResend, isLoading, deliveryMethod }) => {
    const [otp, setOtp] = useState(['', '', '', '', '', '']);
    const [error, setError] = useState('');
    const [resendTimer, setResendTimer] = useState(60);
    const [canResend, setCanResend] = useState(false);
    const inputRefs = useRef([]);

    // Fix 1: Explicitly set canResend to false when timer is running
    useEffect(() => {
        if (resendTimer > 0) {
            setCanResend(false); // Ensure button stays disabled while counting down
            const timer = setTimeout(() => setResendTimer(resendTimer - 1), 1000);
            return () => clearTimeout(timer);
        } else {
            setCanResend(true);
        }
    }, [resendTimer]);

    useEffect(() => {
        inputRefs?.current?.[0]?.focus();
    }, []);

    const handleChange = (index, value) => {
        // Fix 2: Only allow a single digit, and removed unnecessary optional chaining on regex
        if (!/^\d*$/?.test(value)) return;

        const newOtp = [...otp];
        
        // Ensure only the last character is kept if somehow multiple were entered
        newOtp[index] = value?.slice(-1); 
        
        setOtp(newOtp);
        setError('');

        // Auto-focus next input if a value was entered
        if (value && index < 5) {
            inputRefs?.current?.[index + 1]?.focus();
        }

        // Auto-verify when all digits are entered
        // Fix 3: Added a safety check for value being the trigger (prevents re-triggering on empty input)
        if (newOtp?.every(digit => digit !== '') && value) {
            handleVerify(newOtp?.join(''));
        }
    };

    const handleKeyDown = (index, e) => {
        // Fix 4: Crucial fix: Prevent default browser backspace action
        if (e?.key === 'Backspace') {
            e?.preventDefault(); 
            if (otp?.[index]) {
                // Clear current input first
                const newOtp = [...otp];
                newOtp[index] = '';
                setOtp(newOtp);
            } else if (index > 0) {
                // If current input is empty, move back and clear previous input
                const newOtp = [...otp];
                newOtp[index - 1] = '';
                setOtp(newOtp);
                inputRefs?.current?.[index - 1]?.focus();
            }
        } else if (e?.key === 'ArrowLeft' && index > 0) {
            inputRefs?.current?.[index - 1]?.focus();
        } else if (e?.key === 'ArrowRight' && index < 5) {
            inputRefs?.current?.[index + 1]?.focus();
        }
    };

    const handlePaste = (e) => {
        e?.preventDefault();
        const pastedData = e?.clipboardData?.getData('text')?.trim()?.slice(0, 6);
        // Fix 5: Removed unnecessary optional chaining on regex test
        if (!/^\d+$/?.test(pastedData)) return;

        // Correctly fill the array
        const digits = pastedData?.split('');
        const newOtp = [...digits, ...Array(6 - digits?.length)?.fill('')]?.slice(0, 6);
        setOtp(newOtp);
        
        // Focus next logical input
        const nextFocusIndex = Math.min(digits?.length, 5); // Focus on the first empty slot or the last one
        inputRefs?.current?.[nextFocusIndex]?.focus();

        // Auto-verify if 6 digits were pasted
        if (digits?.length === 6) {
            handleVerify(newOtp?.join(''));
        }
    };

    const handleVerify = (otpCode) => {
        // Fix 6: Check for an active loading state from parent before calling onVerify
        if (isLoading) return; 

        if (otpCode?.length !== 6) {
            setError('Please enter all 6 digits');
            return;
        }
        onVerify(otpCode);
    };

    const handleResendClick = () => {
        // Fix 7: Check for an active loading state from parent
        if (canResend && !isLoading) {
            setOtp(['', '', '', '', '', '']);
            setError('');
            setResendTimer(60);
            setCanResend(false);
            onResend();
            inputRefs?.current?.[0]?.focus();
        }
    };

    return (
        <div className="space-y-4 md:space-y-6">
            <div className="text-center space-y-2">
                <div className="w-16 h-16 md:w-20 md:h-20 mx-auto bg-primary/10 rounded-full flex items-center justify-center">
                    <Icon name="ShieldCheck" size={32} color="var(--color-primary)" />
                </div>
                <h3 className="text-lg md:text-xl font-semibold text-foreground">Verify Your Identity</h3>
                <p className="text-sm md:text-base text-muted-foreground">
                    {deliveryMethod === 'email' ? (
                        <>
                            We've sent a 6-digit code to your email
                            <br />
                            <span className="font-medium text-foreground">Check your inbox</span>
                        </>
                    ) : deliveryMethod === 'voice' ? (
                        <>
                            We're calling you with a 6-digit code
                            <br />
                            <span className="font-medium text-foreground">Answer the call and listen</span>
                        </>
                    ) : (
                        <>
                            We've sent a 6-digit code to
                            <br />
                            <span className="font-medium text-foreground">{contactInfo}</span>
                        </>
                    )}
                </p>
                {/* Countdown Timer Display */}
                <div className="mt-2 flex items-center justify-center gap-2">
                    <Icon name="Clock" size={16} color="var(--color-muted-foreground)" />
                    <p className="text-sm text-muted-foreground">
                        {resendTimer > 0 ? (
                            <>
                                Code expires in{' '}
                                <span className="font-semibold text-foreground">
                                    {Math.floor(resendTimer / 60)}:{String(resendTimer % 60)?.padStart(2, '0')}
                                </span>
                            </>
                        ) : (
                            <span className="text-destructive font-medium">Code expired</span>
                        )}
                    </p>
                </div>
            </div>
            <div className="space-y-4">
                <div className="flex justify-center gap-2 md:gap-3">
                    {otp?.map((digit, index) => (
                        <input
                            key={index}
                            ref={(el) => (inputRefs.current[index] = el)}
                            type="text"
                            inputMode="numeric"
                            pattern="[0-9]*" // Added for better mobile UX
                            maxLength={1}
                            value={digit}
                            onChange={(e) => handleChange(index, e?.target?.value)}
                            onKeyDown={(e) => handleKeyDown(index, e)}
                            onPaste={handlePaste}
                            disabled={isLoading}
                            className={`w-10 h-12 md:w-12 md:h-14 text-center text-lg md:text-xl font-semibold bg-background border-2 rounded-lg transition-all focus:outline-none focus:ring-2 focus:ring-ring ${
                                error
                                    ? 'border-destructive'
                                    : digit
                                    ? 'border-primary' :'border-input'
                            } ${isLoading ? 'opacity-50 cursor-not-allowed' : ''}`}
                        />
                    ))}
                </div>

                {error && (
                    <div className="flex items-center justify-center gap-2 text-destructive">
                        <Icon name="AlertCircle" size={16} />
                        <p className="text-sm">{error}</p>
                    </div>
                )}
            </div>
            <div className="flex flex-col items-center gap-3 pt-2">
                <Button
                    type="button"
                    variant="default"
                    fullWidth
                    loading={isLoading}
                    onClick={() => handleVerify(otp?.join(''))}
                    disabled={otp?.some(digit => digit === '') || isLoading} // Fix 8: Include isLoading in disabled prop
                >
                    Verify OTP
                </Button>

                <div className="text-center">
                    <p className="text-sm text-muted-foreground mb-2">
                        Didn't receive the code?
                    </p>
                    {canResend ? (
                        <button
                            type="button"
                            onClick={handleResendClick}
                            disabled={isLoading} // Fix 9: Disable resend button while loading
                            className={`text-sm font-medium transition-colors ${isLoading ? 'text-muted-foreground cursor-not-allowed' : 'text-primary hover:underline'}`}
                        >
                            Resend OTP
                        </button>
                    ) : (
                        <p className="text-sm text-muted-foreground">
                            Resend available in{' '}
                            <span className="font-medium text-foreground">{resendTimer}s</span>
                        </p>
                    )}
                </div>
            </div>
            <div className="flex items-start gap-2 p-3 md:p-4 bg-muted rounded-lg">
                <Icon name="Lock" size={16} color="var(--color-muted-foreground)" className="flex-shrink-0 mt-0.5" />
                <div className="text-xs md:text-sm text-muted-foreground space-y-1">
                    <p className="font-medium">
                        {deliveryMethod === 'email' ? 'Secure Email Verification' :
                         deliveryMethod === 'voice' ? 'Secure Voice Verification' :
                         'Secure Supabase Auth Phone Verification'}
                    </p>
                    <p>
                        {deliveryMethod === 'email' ? 'Your verification code was sent via secure email delivery. Never share it with anyone.' :
                         deliveryMethod === 'voice' ? 'Your verification code is being delivered via voice call. Never share it with anyone.' :
                         'Your verification code is sent via Supabase\'s secure SMS delivery system. Never share it with anyone.'}
                    </p>
                </div>
            </div>
        </div>
    );
};

export default OTPVerificationForm;