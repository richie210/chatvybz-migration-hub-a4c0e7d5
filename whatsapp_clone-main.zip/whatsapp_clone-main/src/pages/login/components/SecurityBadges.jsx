import React from 'react';
import Icon from '../../../components/AppIcon';

const SecurityBadges = () => {
  const badges = [
    {
      icon: 'Shield',
      label: 'SSL Encrypted',
      description: 'Secure connection'
    },
    {
      icon: 'Lock',
      label: 'End-to-End',
      description: 'Private messaging'
    },
    {
      icon: 'CheckCircle2',
      label: 'Verified',
      description: 'Trusted platform'
    }
  ];

  return (
    <div className="grid grid-cols-3 gap-3 md:gap-4 py-4 md:py-6 border-t border-border">
      {badges?.map((badge, index) => (
        <div key={index} className="flex flex-col items-center text-center gap-2">
          <div className="w-10 h-10 md:w-12 md:h-12 bg-success/10 rounded-full flex items-center justify-center">
            <Icon name={badge?.icon} size={20} color="var(--color-success)" />
          </div>
          <div>
            <p className="text-xs md:text-sm font-medium text-foreground">{badge?.label}</p>
            <p className="text-xs text-muted-foreground hidden md:block">{badge?.description}</p>
          </div>
        </div>
      ))}
    </div>
  );
};

export default SecurityBadges;