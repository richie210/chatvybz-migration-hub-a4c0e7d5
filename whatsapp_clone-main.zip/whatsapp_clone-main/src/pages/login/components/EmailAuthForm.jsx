import React, { useState } from 'react';
// Assuming these components are correctly imported from their respective paths
import Input from '../../../components/ui/Input';
import Button from '../../../components/ui/Button';
import Icon from '../../../components/AppIcon';

const EmailAuthForm = ({ onLogin, isLoading }) => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [showPassword, setShowPassword] = useState(false);
    const [errors, setErrors] = useState({});
    
    // NOTE: Adding state for 'Remember Me' for completeness
    const [rememberMe, setRememberMe] = useState(false);

    const validateForm = () => {
        const newErrors = {};

        // 1. Validation Logic Enhancement
        if (!email?.trim()) {
            newErrors.email = 'Email is required';
        } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/?.test(email)) { // Removed optional chaining `?.` on regex test
            newErrors.email = 'Please enter a valid email address';
        }

        if (!password) {
            newErrors.password = 'Password is required';
        } else if (password?.length < 6) {
            newErrors.password = 'Password must be at least 6 characters';
        }

        setErrors(newErrors);
        // Removed optional chaining `?.` on Object.keys for robustness
        return Object.keys(newErrors)?.length === 0; 
    };

    const handleSubmit = (e) => {
        e?.preventDefault();
        if (validateForm()) {
            // 2. Updated onLogin call to include 'rememberMe' state
            onLogin({ email, password, rememberMe }); 
        }
    };

    // 3. Extracted logic to manage error state when input changes
    const handleChange = (field, value) => {
        if (field === 'email') {
            setEmail(value);
            if (errors?.email) setErrors(prev => ({ ...prev, email: '' }));
        } else if (field === 'password') {
            setPassword(value);
            if (errors?.password) setErrors(prev => ({ ...prev, password: '' }));
        }
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-4 md:space-y-5">
            <Input
                type="email"
                label="Email Address"
                placeholder="your.email@example.com"
                value={email}
                // Use the new, clean handler
                onChange={(e) => handleChange('email', e?.target?.value)} 
                error={errors?.email}
                required
                disabled={isLoading}
            />
            <div className="relative">
                <Input
                    type={showPassword ? 'text' : 'password'}
                    label="Password"
                    placeholder="Enter your password"
                    value={password}
                    // Use the new, clean handler
                    onChange={(e) => handleChange('password', e?.target?.value)} 
                    error={errors?.password}
                    required
                    disabled={isLoading}
                />
                <button
                    type="button"
                    onClick={() => setShowPassword(prev => !prev)} // Use functional state update
                    className="absolute right-3 top-[38px] p-2 text-muted-foreground hover:text-foreground transition-colors"
                    aria-label={showPassword ? 'Hide password' : 'Show password'}
                    disabled={isLoading} // 4. Disable button while loading
                >
                    {/* 5. Added conditional rendering safeguard for Icon component */}
                    {Icon && <Icon name={showPassword ? 'EyeOff' : 'Eye'} size={18} />} 
                </button>
            </div>
            <div className="flex items-center justify-between">
                <label htmlFor="remember-me" className="flex items-center gap-2 cursor-pointer"> {/* 6. Added htmlFor */}
                    <input
                        id="remember-me" // 6. Added ID for accessibility
                        type="checkbox"
                        checked={rememberMe}
                        onChange={(e) => setRememberMe(e?.target?.checked)} // 7. Handle checkbox state
                        className="w-4 h-4 rounded border-input text-primary focus:ring-2 focus:ring-ring"
                        disabled={isLoading}
                    />
                    <span className="text-xs md:text-sm text-muted-foreground">Remember me</span>
                </label>
                <button
                    type="button"
                    className="text-xs md:text-sm text-primary hover:underline font-medium"
                    disabled={isLoading} // 4. Disable button while loading
                >
                    Forgot Password?
                </button>
            </div>
            <Button
                type="submit"
                variant="default"
                fullWidth
                loading={isLoading}
                iconName="LogIn"
                iconPosition="right"
                className="mt-6"
            >
                Login
            </Button>
        </form>
    );
};

export default EmailAuthForm;