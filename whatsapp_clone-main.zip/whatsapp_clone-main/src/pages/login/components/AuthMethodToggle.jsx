import React from 'react';
import Icon from '../../../components/AppIcon';

const AuthMethodToggle = ({ activeMethod, onMethodChange }) => {
  const methods = [
    { id: 'phone', label: 'Phone Number', icon: 'Phone' },
    { id: 'email', label: 'Email Address', icon: 'Mail' }
  ];

  return (
    <div className="flex gap-2 p-1 bg-muted rounded-lg">
      {methods?.map((method) => {
        const isActive = activeMethod === method?.id;
        
        return (
          <button
            key={method?.id}
            type="button"
            onClick={() => onMethodChange?.(method?.id)}
            className={`flex-1 flex items-center justify-center gap-2 px-4 py-3 rounded-md transition-all duration-200 ${
              isActive
                ? 'bg-primary text-primary-foreground shadow-sm'
                : 'text-muted-foreground hover:text-foreground hover:bg-background/50'
            }`}
          >
            <Icon
              name={method?.icon}
              size={18}
              color={isActive ? 'white' : 'currentColor'}
            />
            <span className="text-sm md:text-base font-medium">{method?.label}</span>
          </button>
        );
      })}
    </div>
  );
};

export default AuthMethodToggle;