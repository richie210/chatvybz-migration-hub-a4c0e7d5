import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { useAuth } from '../../contexts/AuthContext';
import PhoneAuthForm from './components/PhoneAuthForm';
import OTPVerificationForm from './components/OTPVerificationForm';
import QRCodeAuthForm from './components/QRCodeAuthForm';
import SecurityBadges from './components/SecurityBadges';
import Icon from '../../components/AppIcon';
import appwriteAuthService from '../../services/appwriteAuthService';

const Login = () => {
  const navigate = useNavigate();
  const { signInWithPhone, signUpWithPhone } = useAuth();
  
  const [authMethod, setAuthMethod] = useState('phone'); // 'phone' or 'qr'
  const [step, setStep] = useState('phone'); // 'phone' or 'otp'
  const [phoneData, setPhoneData] = useState({ countryCode: '', phoneNumber: '', fullPhone: '' });
  const [appwriteUserId, setAppwriteUserId] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState(null);
  const [userExists, setUserExists] = useState(null);
  const [deliveryMethod, setDeliveryMethod] = useState('sms');

  // Handle sending OTP using Appwrite
  const handleSendOTP = async ({ countryCode, phoneNumber, email }) => {
    try {
      console.log('📞 handleSendOTP called with:', { countryCode, phoneNumber });
      setError(null);
      setIsLoading(true);
      
      // Format phone to E.164
      const fullPhone = appwriteAuthService?.formatPhoneE164(countryCode, phoneNumber);
      console.log('📞 Formatted phone:', fullPhone);
      
      // Check if user exists in Supabase
      const { userExists: exists } = await appwriteAuthService?.checkUserExists(fullPhone);
      setUserExists(exists);
      
      // Send OTP via Appwrite
      const result = await appwriteAuthService?.sendOTP(fullPhone);
      
      if (!result?.success) {
        setError({ 
          message: result?.error || 'Failed to send verification code', 
          code: result?.code || 'SEND_FAILED',
          hint: 'Please check your phone number and try again'
        });
        return;
      }
      
      console.log('✅ OTP sent successfully via Appwrite');
      
      // Store data for verification step
      setAppwriteUserId(result?.userId);
      setPhoneData({ countryCode, phoneNumber, fullPhone });
      setDeliveryMethod(result?.deliveryMethod);
      setStep('otp');
    } catch (err) {
      console.error('❌ handleSendOTP error:', err);
      setError({ 
        message: err?.message || 'Failed to send verification code', 
        code: 'UNKNOWN_ERROR',
        hint: 'Please try again or contact support'
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Handle OTP verification and sign in/sign up
  const handleVerifyOTP = async (otpCode) => {
    setIsLoading(true);
    setError('');
    
    try {
      console.log('🔐 Verifying OTP with Appwrite');
      
      // Verify OTP with Appwrite
      const result = await appwriteAuthService?.verifyOTP(appwriteUserId, otpCode);
      
      if (!result?.success) {
        setError({ 
          message: result?.error || 'Invalid verification code', 
          code: result?.code || 'INVALID_OTP',
          hint: 'Please check the code and try again'
        });
        setIsLoading(false);
        return;
      }
      
      console.log('✅ OTP verified successfully');
      
      if (userExists) {
        // Sign in existing user
        const { data, error: signInError } = await signInWithPhone(
          phoneData?.phoneNumber,
          phoneData?.countryCode,
          otpCode
        );
        
        if (signInError) {
          throw new Error(signInError?.message);
        }
        
        // Navigate to main chat
        navigate('/main-chat-interface');
      } else {
        // New user - navigate to profile setup
        navigate('/profile-setup', {
          state: {
            phoneNumber: phoneData?.phoneNumber,
            countryCode: phoneData?.countryCode,
            fullPhone: phoneData?.fullPhone,
            otpCode,
            appwriteSession: result?.session
          }
        });
      }
    } catch (err) {
      console.error('❌ Verify OTP error:', err);
      setError({ 
        message: err?.message || 'Invalid verification code',
        code: 'VERIFY_FAILED',
        hint: 'Please try again'
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Handle resending OTP
  const handleResendOTP = async () => {
    await handleSendOTP(phoneData);
  };

  return (
    <>
      <Helmet>
        <title>Login - ChatVybz</title>
        <meta
          name="description"
          content="Securely login to ChatVybz using phone number OTP verification to access your messages and conversations."
        />
      </Helmet>
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-blue-50 flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="w-20 h-20 mx-auto bg-white rounded-full flex items-center justify-center mb-4 shadow-lg">
              <Icon name="MessageCircle" size={40} color="#3B82F6" />
            </div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">
              ChatVybz
            </h1>
            <p className="text-gray-600">
              {authMethod === 'qr' ?'Scan QR code to login instantly'
                : step === 'phone' ?'Enter your phone number to continue' :'Verify your phone number'
              }
            </p>
          </div>

          {/* Auth Method Toggle */}
          {step === 'phone' && (
            <div className="mb-6 bg-white rounded-xl shadow-md p-1 flex gap-1">
              <button
                onClick={() => setAuthMethod('phone')}
                className={`flex-1 flex items-center justify-center gap-2 py-3 px-4 rounded-lg font-medium transition-all ${
                  authMethod === 'phone' ?'bg-blue-600 text-white shadow-sm' :'text-gray-600 hover:text-gray-900'
                }`}
              >
                <Icon name="Phone" size={18} />
                <span>Phone Number</span>
              </button>
              <button
                onClick={() => setAuthMethod('qr')}
                className={`flex-1 flex items-center justify-center gap-2 py-3 px-4 rounded-lg font-medium transition-all ${
                  authMethod === 'qr' ?'bg-blue-600 text-white shadow-sm' :'text-gray-600 hover:text-gray-900'
                }`}
              >
                <Icon name="QrCode" size={18} />
                <span>QR Code</span>
              </button>
            </div>
          )}

          {/* Main Card */}
          <div className="bg-white rounded-2xl shadow-xl p-6 md:p-8">
            {/* Error Display */}
            {error && (
              <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg">
                <div className="flex items-start gap-3">
                  <Icon name="AlertCircle" size={20} className="text-red-600 flex-shrink-0 mt-0.5" />
                  <div className="flex-1">
                    <p className="text-sm font-semibold text-red-800 mb-1">{error?.message || 'An error occurred'}</p>
                    {error?.hint && (
                      <p className="text-xs text-red-600">{error?.hint}</p>
                    )}
                    {error?.code && (
                      <p className="text-xs text-red-500 mt-1">Error Code: {error?.code}</p>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* Success Message */}
            {step === 'otp' && !error && (
              <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg">
                <div className="flex items-start gap-3">
                  <Icon name="CheckCircle" size={20} className="text-green-600 flex-shrink-0 mt-0.5" />
                  <div className="flex-1">
                    <p className="text-sm font-semibold text-green-800 mb-1">Verification code sent via {deliveryMethod?.toUpperCase()}</p>
                    <p className="text-xs text-green-600">Please check your phone for the 6-digit code</p>
                  </div>
                </div>
              </div>
            )}

            {/* Auth Forms */}
            {authMethod === 'phone' ? (
              step === 'phone' ? (
                <PhoneAuthForm 
                  onSendOTP={handleSendOTP} 
                  isLoading={isLoading}
                />
              ) : (
                <OTPVerificationForm
                  contactInfo={phoneData?.fullPhone || `${phoneData?.countryCode}${phoneData?.phoneNumber}`}
                  onVerify={handleVerifyOTP}
                  onResend={handleResendOTP}
                  isLoading={isLoading}
                  deliveryMethod={deliveryMethod}
                />
              )
            ) : (
              <QRCodeAuthForm />
            )}
          </div>

          {/* Security Badges */}
          <SecurityBadges />

          {/* Footer Links */}
          <div className="mt-6 text-center text-sm text-gray-600">
            <p>
              By continuing, you agree to our{' '}
              <a href="#" className="text-blue-600 hover:underline">
                Terms of Service
              </a>{' '}
              and{' '}
              <a href="#" className="text-blue-600 hover:underline">
                Privacy Policy
              </a>
            </p>
          </div>
        </div>
      </div>
    </>
  );
};

export default Login;