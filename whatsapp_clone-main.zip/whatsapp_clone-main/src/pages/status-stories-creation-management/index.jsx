import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Image, Video, Type } from 'lucide-react';

export default function StatusStoriesCreationManagement() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white p-6 shadow-lg">
        <div className="max-w-6xl mx-auto">
          <button
            onClick={() => navigate('/status')}
            className="flex items-center gap-2 mb-4 hover:opacity-80 transition-opacity"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Back to Status</span>
          </button>
          <h1 className="text-2xl font-bold mb-2">Create Status</h1>
          <p className="text-blue-100">Share photos, videos, or text that disappear after 24 hours</p>
        </div>
      </div>

      <div className="max-w-6xl mx-auto p-6">
        <div className="bg-white rounded-lg shadow-md p-8">
          <div className="text-center">
            <div className="flex justify-center gap-6 mb-8">
              <div className="flex flex-col items-center">
                <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mb-3">
                  <Image className="w-10 h-10 text-blue-600" />
                </div>
                <p className="text-sm font-medium text-gray-700">Photo</p>
              </div>
              <div className="flex flex-col items-center">
                <div className="w-20 h-20 bg-purple-100 rounded-full flex items-center justify-center mb-3">
                  <Video className="w-10 h-10 text-purple-600" />
                </div>
                <p className="text-sm font-medium text-gray-700">Video</p>
              </div>
              <div className="flex flex-col items-center">
                <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mb-3">
                  <Type className="w-10 h-10 text-green-600" />
                </div>
                <p className="text-sm font-medium text-gray-700">Text</p>
              </div>
            </div>
            <h3 className="text-xl font-semibold text-gray-900 mb-2">Advanced Status Creation</h3>
            <p className="text-gray-600 mb-6">
              This page is for advanced status creation features. For quick status updates, use the main Status page.
            </p>
            <button
              onClick={() => navigate('/status')}
              className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors"
            >
              Go to Status Page
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}