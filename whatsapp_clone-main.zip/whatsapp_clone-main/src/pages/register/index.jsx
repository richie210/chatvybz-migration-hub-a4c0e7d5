import React, { useState, useCallback } from 'react';
import { MessageCircle, Phone, Mail, Upload, User, Check } from 'lucide-react';
import { isValidPhoneNumber } from 'react-phone-number-input';

// --- Mock Data: Country Codes (for display purposes) ---
// Note: In a real app, this should be a comprehensive list (like the one provided previously).
const COUNTRY_CODES = [
  { name: 'Canada', code: 'CA', dial_code: '+1' },
  { name: 'United States', code: 'US', dial_code: '+1' },
  { name: 'United Kingdom', code: 'GB', dial_code: '+44' },
  { name: 'India', code: 'IN', dial_code: '+91' },
];

// --- Custom Tailwind Color (Assumed to be defined in tailwind.config.js) ---
// Since the image uses a distinct teal/green color, we define a custom color set:
const CUSTOM_COLORS = {
  vybz: {
    DEFAULT: '#22B48A', // Main button color
    light: '#EAF8F4', // Light background for the frame
    dark: '#1C9E7A',
    bg: 'linear-gradient(135deg, #A8F0DF 0%, #C4F7F4 100%)', // Gradient background
    top: '#75D8C1', // Top icon border/background
  },
  accent: '#2C8E4A', // For the checkmark
};

// =========================================================
//                   MAIN COMPONENT
// =========================================================

const Register = () => {
  // State for switching between Phone/Email
  const [method, setMethod] = useState('phone'); // 'phone' or 'email'

  // State for form inputs
  const [formState, setFormState] = useState({
    countryCode: COUNTRY_CODES?.[0]?.dial_code,
    phoneNumber: '',
    email: '',
    statusMessage: 'Hey there! I am using ChatVybz',
    agreedToTerms: false,
    profilePicture: null,
    isUploading: false,
  });

  // State for form validation
  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);

  // Handler for basic inputs
  const handleChange = (e) => {
    const { name, value, type, checked } = e?.target;
    setFormState(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value,
    }));
  };

  // Handler for file upload via button/drag-and-drop
  const handleFileUpload = useCallback((file) => {
    if (file) {
      setFormState(prev => ({
        profilePicture: URL.createObjectURL(file),
      }));
      // Simulate API upload process
      setFormState(prev => ({ ...prev, isUploading: true }));
      setTimeout(() => {
        setFormState(prev => ({ ...prev, isUploading: false }));
        console.log('Upload simulated successfully.');
      }, 1500);
    }
  }, []);

  const handleDragOver = (e) => {
    e?.preventDefault();
    e?.stopPropagation();
  };

  const handleDrop = (e) => {
    e?.preventDefault();
    e?.stopPropagation();
    if (e?.dataTransfer?.files && e?.dataTransfer?.files?.[0]) {
      handleFileUpload(e?.dataTransfer?.files?.[0]);
    }
  };

  // Handler for final submission
  const handleSubmit = async (e) => {
    e?.preventDefault();
    
    // Validation
    if (!formState?.agreedToTerms) {
      alert('You must agree to the Terms and Privacy Policy.');
      return;
    }

    // Validate phone number if using phone method
    if (method === 'phone') {
      if (!formState?.phoneNumber) {
        setErrors({ phoneNumber: 'Phone number is required' });
        return;
      }
      
      try {
        const isValid = isValidPhoneNumber(formState?.phoneNumber);
        if (!isValid) {
          setErrors({ phoneNumber: 'Please enter a valid phone number' });
          return;
        }
      } catch (error) {
        setErrors({ phoneNumber: 'Invalid phone number format' });
        return;
      }
    }

    setIsLoading(true);
    setErrors({});

    try {
      if (method === 'email') {
        // For email registration, handle email verification
        console.log('Email registration:', {
          email: formState?.email,
          profileData: {
            profilePicture: formState?.profilePicture,
            statusMessage: formState?.statusMessage
          }
        });
        // Logic for email verification redirect goes here
      } else {
        // Phone registration logic
        console.log('Form Submitted with data:', formState);
        // Logic for API call (registering user) goes here
      }
    } catch (error) {
      console.error('Registration error:', error);
      setErrors({ general: 'An error occurred during registration. Please try again.' });
    } finally {
      setIsLoading(false);
    }
  };

  // Render the Country Code selector based on the custom list
  const CountryCodeSelect = () => (
    <select
      name="countryCode"
      value={formState?.countryCode}
      onChange={handleChange}
      className="appearance-none block w-full bg-white border border-gray-300 rounded-lg py-3 px-4 text-gray-700 leading-tight focus:outline-none focus:border-vybz"
      style={{
        backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 20 20'%3E%3Cpath d='M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z' fill='%236B7280'/%3E%3C/svg%3E")`,
        backgroundRepeat: 'no-repeat',
        backgroundPosition: 'right 0.75rem center',
        backgroundSize: '1.5em 1.5em',
        paddingRight: '2.5rem',
      }}
    >
      {COUNTRY_CODES?.map(country => (
        <option key={country?.code} value={country?.dial_code}>
          {country?.code} ({country?.dial_code})
        </option>
      ))}
    </select>
  );
  
  // Custom Checkbox component to match the style
  const CustomCheckbox = () => (
    <div className="flex items-center">
      <input
        id="termsCheckbox"
        name="agreedToTerms"
        type="checkbox"
        checked={formState?.agreedToTerms}
        onChange={handleChange}
        className="hidden"
      />
      <label htmlFor="termsCheckbox" className="flex items-center cursor-pointer">
        <div 
            className={`w-5 h-5 border-2 rounded-md flex items-center justify-center transition-all duration-200 ${
                formState?.agreedToTerms ? 'bg-vybz border-vybz' : 'bg-white border-gray-300'
            }`}
        >
          {formState?.agreedToTerms && <Check size={14} className="text-white" />}
        </div>
        <span className="ml-2 text-sm text-gray-600">
          I agree to the{' '}
          <a 
            href="/terms-of-service" 
            target="_blank" 
            rel="noopener noreferrer"
            className="font-semibold text-vybz hover:underline"
            onClick={(e) => e?.stopPropagation()}
          >
            Terms of Service
          </a>
          {' '}and{' '}
          <a 
            href="/privacy-policy" 
            target="_blank" 
            rel="noopener noreferrer"
            className="font-semibold text-vybz hover:underline"
            onClick={(e) => e?.stopPropagation()}
          >
            Privacy Policy
          </a>
          {' '}<span className="text-red-500">*</span>
        </span>
      </label>
    </div>
  );


  return (
    <div className="flex min-h-screen items-center justify-center p-4" style={{ background: CUSTOM_COLORS?.vybz?.bg }}>
      <div className="bg-white rounded-[2rem] shadow-2xl max-w-lg w-full p-8 relative">
        
        {/* Top Icon */}
        <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-white rounded-full p-2 border-[5px] border-vybz-light">
          <div className="w-12 h-12 rounded-full flex items-center justify-center" style={{ backgroundColor: CUSTOM_COLORS?.vybz?.top }}>
            <MessageCircle size={28} className="text-white" />
          </div>
        </div>

        <div className="text-center pt-8">
          <h1 className="text-3xl font-bold text-gray-800">ChatVybz</h1>
          <p className="text-gray-500 mt-1 mb-6">Join ChatVybz to start messaging</p>

          <h2 className="text-xl font-semibold text-gray-700 mt-8 mb-4">Create Account</h2>
          <p className="text-gray-500 text-sm mb-6">Join ChatVybz to start messaging</p>
        </div>

        <form onSubmit={handleSubmit}>
          {/* Method Selector Tabs */}
          <div className="flex bg-gray-100 rounded-lg p-1 mb-6">
            <button
              type="button"
              onClick={() => setMethod('phone')}
              className={`flex-1 flex items-center justify-center py-2 px-4 rounded-lg transition-all text-sm font-medium ${
                method === 'phone' ? 'bg-white shadow-md text-vybz' : 'text-gray-500 hover:text-vybz'
              }`}
            >
              <Phone size={16} className="mr-2" /> Phone Number
            </button>
            <button
              type="button"
              onClick={() => setMethod('email')}
              className={`flex-1 flex items-center justify-center py-2 px-4 rounded-lg transition-all text-sm font-medium ${
                method === 'email' ? 'bg-white shadow-md text-vybz' : 'text-gray-500 hover:text-vybz'
              }`}
            >
              <Mail size={16} className="mr-2" /> Email
            </button>
          </div>

          {/* Conditional Input Fields */}
          <div className="space-y-4">
            {method === 'phone' ? (
              // Phone Number Input Section
              (<div className="grid grid-cols-5 gap-3">
                <div className="col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Country Code <span className="text-red-500">*</span>
                  </label>
                  <CountryCodeSelect />
                </div>
                <div className="col-span-3">
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Phone Number <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="tel"
                    name="phoneNumber"
                    value={formState?.phoneNumber}
                    onChange={handleChange}
                    placeholder="Enter your phone number"
                    className="block w-full border border-gray-300 rounded-lg py-3 px-4 text-gray-700 leading-tight focus:outline-none focus:border-vybz"
                    required
                  />
                </div>
              </div>)
            ) : (
              // Email Input Section
              (<div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Email <span className="text-red-500">*</span>
                </label>
                <input
                  type="email"
                  name="email"
                  value={formState?.email}
                  onChange={handleChange}
                  placeholder="Enter your email address"
                  className="block w-full border border-gray-300 rounded-lg py-3 px-4 text-gray-700 leading-tight focus:outline-none focus:border-vybz"
                  required
                />
              </div>)
            )}
          </div>

          {/* Profile Picture Upload Section */}
          <div
            className="mt-8 border-2 border-dashed border-gray-300 rounded-lg p-6 text-center cursor-pointer hover:border-vybz transition-colors"
            onDragOver={handleDragOver}
            onDrop={handleDrop}
            onClick={() => document.getElementById('file-upload')?.click()}
          >
            {formState?.profilePicture ? (
              <div className="flex flex-col items-center">
                <img 
                  src={formState?.profilePicture} 
                  alt="Profile Preview" 
                  className="w-20 h-20 rounded-full object-cover mb-3 border-4 border-vybz"
                />
                <p className="text-sm font-medium text-gray-700">Image uploaded successfully!</p>
              </div>
            ) : (
              <div className="flex flex-col items-center">
                <User size={36} className="text-gray-400 mb-2" />
                <p className="text-lg font-semibold text-gray-700 mb-1">Upload profile picture</p>
                <p className="text-sm text-gray-500 mb-4">Drag and drop or choose as a file</p>
                <button
                  type="button"
                  className={`flex items-center px-4 py-2 text-white rounded-full text-sm font-medium transition-colors ${
                    formState?.isUploading ? 'bg-vybz-dark cursor-wait' : 'bg-vybz hover:bg-vybz-dark'
                  }`}
                  disabled={formState?.isUploading}
                >
                  <Upload size={16} className="mr-2" />
                  {formState?.isUploading ? 'Uploading...' : 'Upload Photo'}
                </button>
              </div>
            )}
            <input
              id="file-upload"
              type="file"
              accept="image/*"
              onChange={(e) => handleFileUpload(e?.target?.files?.[0])}
              className="hidden"
            />
          </div>

          {/* Status Message Field */}
          <div className="mt-6">
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Status Message
            </label>
            <input
              type="text"
              name="statusMessage"
              value={formState?.statusMessage}
              onChange={handleChange}
              className="block w-full border border-gray-300 rounded-lg py-3 px-4 text-gray-700 leading-tight focus:outline-none focus:border-vybz"
              placeholder="Hey there! I am using ChatVybz"
            />
            <p className="text-xs text-gray-500 mt-1">
              Optional - This will be visible to your contacts
            </p>
          </div>

          {/* Terms Checkbox */}
          <div className="mt-6 mb-8">
            <CustomCheckbox />
          </div>

          {/* Sign Up Button */}
          <button
            type="submit"
            className={`w-full py-3 rounded-xl text-white text-lg font-bold transition-colors ${
                formState?.agreedToTerms && !isLoading 
                  ? 'bg-vybz hover:bg-vybz-dark' :'bg-gray-400 cursor-not-allowed'
            }`}
            disabled={!formState?.agreedToTerms || isLoading}
          >
            {isLoading ? 'Signing Up...' : 'Sign Up'}
          </button>
        </form>

        {/* Footer Link */}
        <p className="text-center text-sm text-gray-500 mt-6">
          Already have an account? <a href="#" className="font-semibold text-vybz hover:underline">Sign In</a>
        </p>

      </div>
    </div>
  );
};

export default Register;