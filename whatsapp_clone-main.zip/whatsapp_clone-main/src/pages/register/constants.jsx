export const COUNTRIES = null;

// Default logo - using a placeholder SVG data URL or you can replace with actual logo path
const APP_LOGO = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHZpZXdCb3g9IjAgMCA0MCA0MCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPGNpcmNsZSBjeD0iMjAiIGN5PSIyMCIgcj0iMjAiIGZpbGw9IiMyNTYzRUUiLz4KPHBhdGggZD0iTTIwIDEwQzE0LjQ3NzEgMTAgMTAgMTQuNDc3MSAxMCAyMEMxMCAyNS41MjI5IDE0LjQ3NzEgMzAgMjAgMzBDMjUuNTIyOSAzMCAzMCAyNS41MjI5IDMwIDIwQzMwIDE0LjQ3NzEgMjUuNTIyOSAxMCAyMCAxMFoiIGZpbGw9IndoaXRlIi8+CjxwYXRoIGQ9Ik0xNiAxOEwyNCAxOEwyMCAyMkwxNiAxOFoiIGZpbGw9IiMyNTYzRUUiLz4KPC9zdmc+';

export const LANGUAGES = [
  'English',
  'Spanish',
  'French',
  'German',
  'Italian',
  'Portuguese',
  'Russian',
  'Japanese',
  'Korean',
  'Chinese (Simplified)',
  'Arabic',
  'Hindi'
];

export { APP_LOGO };