import React from 'react';

const StepIndicator = ({ currentStep, totalSteps }) => {
  return (
    <div className="flex items-center justify-center gap-2 mb-6 md:mb-8">
      {Array.from({ length: totalSteps })?.map((_, index) => (
        <div
          key={index}
          className={`h-1.5 rounded-full transition-all duration-300 ${
            index === currentStep
              ? 'w-8 md:w-12 bg-primary'
              : index < currentStep
              ? 'w-6 md:w-8 bg-primary/60' :'w-6 md:w-8 bg-muted'
          }`}
          aria-label={`Step ${index + 1} ${
            index === currentStep ? 'active' : index < currentStep ? 'completed' : 'pending'
          }`}
        />
      ))}
    </div>
  );
};

export default StepIndicator;