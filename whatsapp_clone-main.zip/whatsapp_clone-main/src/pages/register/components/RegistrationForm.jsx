import React, { useState, useRef } from 'react';
import { Upload, User, X } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import PhoneInput from 'react-phone-number-input';
import 'react-phone-number-input/style.css';
import { isValidPhoneNumber } from 'react-phone-number-input';
import Icon from '../../../components/AppIcon';


const RegistrationForm = ({ formData, errors, onChange, onSubmit, isLoading }) => {
  const navigate = useNavigate();
  const fileInputRef = useRef(null);
  const [profilePreview, setProfilePreview] = useState(formData?.profilePicture || null);
  const [phoneValidation, setPhoneValidation] = useState(null);

  const handleInputChange = (field, value) => {
    onChange({
      ...formData,
      [field]: value
    });
  };

  // Enhanced phone number change handler with real-time validation
  const handlePhoneNumberChange = (value) => {
    // value is already in E.164 format from react-phone-number-input
    handleInputChange('phoneNumber', value || '');
    
    // Real-time validation feedback
    if (value) {
      try {
        const isValid = isValidPhoneNumber(value);
        setPhoneValidation({
          isValid,
          message: isValid ? '✓ Valid phone number' : 'Invalid phone number'
        });
      } catch (error) {
        setPhoneValidation({
          isValid: false,
          message: 'Invalid phone number format'
        });
      }
    } else {
      setPhoneValidation(null);
    }
  };

  const handleProfilePictureChange = (file) => {
    setProfilePreview(file);
    handleInputChange('profilePicture', file);
  };

  const handleFileSelect = (e) => {
    const file = e?.target?.files?.[0];
    if (file) {
      if (file?.size > 5 * 1024 * 1024) {
        alert('File size must be less than 5MB');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        handleProfilePictureChange(reader?.result);
      };
      reader?.readAsDataURL(file);
    }
  };

  const removeProfilePicture = () => {
    setProfilePreview(null);
    handleInputChange('profilePicture', null);
    if (fileInputRef?.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <form onSubmit={onSubmit} className="space-y-6">
      {/* Header */}
      <div className="text-center mb-6">
        <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-2">Create Account</h2>
        <p className="text-gray-600 text-sm md:text-base">Join ChatVybz to start messaging</p>
      </div>

      {/* Full Name */}
      <div>
        <label htmlFor="fullName" className="block text-sm font-medium text-gray-700 mb-2">
          Full Name <span className="text-red-500">*</span>
        </label>
        <input
          type="text"
          id="fullName"
          value={formData?.fullName || ''}
          onChange={(e) => handleInputChange('fullName', e?.target?.value)}
          placeholder="Enter your full name"
          className={`w-full px-4 py-3 border rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent ${
            errors?.fullName ? 'border-red-500' : 'border-gray-300'
          }`}
        />
        {errors?.fullName && (
          <p className="mt-1 text-sm text-red-500">{errors?.fullName}</p>
        )}
      </div>

      {/* Contact Method Selection */}
      <div>
        <div className="flex gap-2">
          <button
            type="button"
            onClick={() => handleInputChange('registrationType', 'phone')}
            className={`flex-1 py-2.5 px-4 rounded-lg font-medium transition-all ${
              formData?.registrationType === 'phone' ?'bg-green-500 text-white shadow-md' :'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Phone Number
          </button>
          <button
            type="button"
            onClick={() => handleInputChange('registrationType', 'email')}
            className={`flex-1 py-2.5 px-4 rounded-lg font-medium transition-all ${
              formData?.registrationType === 'email' ?'bg-green-500 text-white shadow-md' :'bg-gray-100 text-gray-700 hover:bg-gray-200'
            }`}
          >
            Email
          </button>
        </div>
      </div>

      {/* Phone Number with International Format */}
      <div>
        <label htmlFor="phoneNumber" className="block text-sm font-medium text-gray-700 mb-2">
          Phone Number <span className="text-red-500">*</span>
        </label>
        <PhoneInput
          international
          defaultCountry="MQ"
          value={formData?.phoneNumber || ''}
          onChange={handlePhoneNumberChange}
          placeholder="Enter phone number"
          className={`w-full ${
            errors?.phoneNumber ? 'phone-input-error' : ''
          } ${
            phoneValidation?.isValid === false ? 'phone-input-error' : ''
          }`}
          disabled={isLoading}
          countryCallingCodeEditable={false}
          style={{
            '--PhoneInputCountryFlag-height': '1em',
            '--PhoneInput-color--focus': '#10b981',
          }}
        />
        {phoneValidation && (
          <p className={`mt-1 text-sm flex items-center gap-1 ${
            phoneValidation?.isValid ? 'text-green-600' : 'text-red-500'
          }`}>
            {phoneValidation?.isValid ? (
              <Icon name="CheckCircle" className="w-4 h-4" />
            ) : (
              <Icon name="AlertCircle" className="w-4 h-4" />
            )}
            {phoneValidation?.message}
          </p>
        )}
        {errors?.phoneNumber && (
          <p className="mt-1 text-sm text-red-500 flex items-center gap-1">
            <Icon name="AlertCircle" className="w-4 h-4" />
            {errors?.phoneNumber}
          </p>
        )}
        <p className="mt-2 text-xs text-gray-500">
          We'll send you a verification code via SMS to verify your number
        </p>
      </div>

      {/* Profile Picture Upload */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Profile Picture <span className="text-gray-500 font-normal">(Optional)</span>
        </label>
        <div 
          className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center hover:border-green-500 transition-colors cursor-pointer bg-gray-50"
          onClick={() => !profilePreview && fileInputRef?.current?.click()}
          onDragOver={(e) => { e?.preventDefault(); }}
          onDrop={(e) => {
            e?.preventDefault();
            const file = e?.dataTransfer?.files?.[0];
            if (file) handleFileSelect({ target: { files: [file] } });
          }}
        >
          {profilePreview ? (
            <div className="relative inline-block">
              <img
                src={profilePreview}
                alt="Profile preview"
                className="w-24 h-24 rounded-full object-cover mx-auto border-2 border-white shadow-md"
              />
              <button
                type="button"
                onClick={(e) => {
                  e?.stopPropagation();
                  removeProfilePicture();
                }}
                className="absolute -top-1 -right-1 bg-red-500 text-white rounded-full p-1 hover:bg-red-600 shadow-lg"
              >
                <X size={14} />
              </button>
            </div>
          ) : (
            <>
              <div className="w-20 h-20 rounded-full bg-gray-200 flex items-center justify-center mx-auto mb-3">
                <User size={32} className="text-gray-400" />
              </div>
              <p className="text-sm font-medium text-gray-700 mb-1">Upload profile picture</p>
              <p className="text-xs text-gray-500 mb-3">Drag and drop or click to browse</p>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/jpeg,image/png,image/gif"
                onChange={handleFileSelect}
                className="hidden"
              />
              <button
                type="button"
                onClick={(e) => {
                  e?.stopPropagation();
                  fileInputRef?.current?.click();
                }}
                className="bg-white hover:bg-gray-50 text-gray-700 px-4 py-2 rounded-lg text-sm font-medium transition-colors border border-gray-300"
              >
                Choose File
              </button>
            </>
          )}
        </div>
        <p className="mt-2 text-xs text-gray-500">Supported formats: JPG, PNG, GIF (Max 5MB)</p>
      </div>

      {/* Status Message */}
      <div>
        <label htmlFor="statusMessage" className="block text-sm font-medium text-gray-700 mb-2">
          Status Message
        </label>
        <input
          type="text"
          id="statusMessage"
          value={formData?.statusMessage || 'Hey there! I am using ChatVybz'}
          onChange={(e) => handleInputChange('statusMessage', e?.target?.value)}
          placeholder="Hey there! I am using ChatVybz"
          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
        />
        <p className="mt-1 text-xs text-gray-500">Optional - This will be visible to your contacts</p>
      </div>

      {/* Terms and Privacy */}
      <div className="flex items-start">
        <input
          type="checkbox"
          id="acceptTerms"
          checked={formData?.acceptTerms || false}
          onChange={(e) => handleInputChange('acceptTerms', e?.target?.checked)}
          className="mt-1 mr-3 w-4 h-4 text-green-600 border-gray-300 rounded focus:ring-green-500"
        />
        <label htmlFor="acceptTerms" className="text-sm text-gray-700">
          I agree to the{' '}
          <a href="#" className="text-green-600 hover:underline font-medium">Terms of Service</a>
          {' '}and{' '}
          <a href="#" className="text-green-600 hover:underline font-medium">Privacy Policy</a>
          {' '}<span className="text-red-500">*</span>
        </label>
      </div>
      {errors?.acceptTerms && (
        <p className="text-sm text-red-500">{errors?.acceptTerms}</p>
      )}

      {/* Continue Button */}
      <button
        type="submit"
        disabled={isLoading}
        className="w-full bg-green-500 hover:bg-green-600 text-white font-bold py-3 px-4 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
      >
        {isLoading ? (
          <>
            <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
            Processing...
          </>
        ) : (
          'Continue'
        )}
      </button>

      {/* Sign In Link */}
      <div className="text-center text-sm">
        <span className="text-gray-600">Already have an account? </span>
        <button
          type="button"
          onClick={() => navigate('/login')}
          className="text-green-600 hover:underline font-medium"
        >
          Sign In
        </button>
      </div>
    </form>
  );
};

export default RegistrationForm;