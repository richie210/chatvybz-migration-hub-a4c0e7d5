import React, { useState, useRef } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const ProfilePictureUpload = ({ value, onChange, error }) => {
  const [isDragging, setIsDragging] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef(null);

  const handleFileSelect = (file) => {
    if (file && file?.type?.startsWith('image/')) {
      setIsUploading(true);
      setUploadProgress(0);

      // Simulate upload progress
      const interval = setInterval(() => {
        setUploadProgress((prev) => {
          if (prev >= 100) {
            clearInterval(interval);
            setIsUploading(false);
            const reader = new FileReader();
            reader.onloadend = () => {
              onChange(reader?.result);
            };
            reader?.readAsDataURL(file);
            return 100;
          }
          return prev + 10;
        });
      }, 100);
    }
  };

  const handleDragOver = (e) => {
    e?.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e) => {
    e?.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e) => {
    e?.preventDefault();
    setIsDragging(false);
    const file = e?.dataTransfer?.files?.[0];
    handleFileSelect(file);
  };

  const handleFileInputChange = (e) => {
    const file = e?.target?.files?.[0];
    handleFileSelect(file);
  };

  const handleRemove = () => {
    onChange(null);
    setUploadProgress(0);
    if (fileInputRef?.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="w-full">
      <label className="block text-sm font-medium text-foreground mb-2">
        Profile Picture <span className="text-muted-foreground">(Optional)</span>
      </label>
      <div
        className={`relative border-2 border-dashed rounded-xl transition-all duration-200 ${
          isDragging
            ? 'border-primary bg-primary/5'
            : error
            ? 'border-destructive' :'border-border hover:border-primary/50'
        }`}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
      >
        {value ? (
          <div className="relative w-full aspect-square max-w-xs mx-auto p-4">
            <div className="relative w-full h-full rounded-xl overflow-hidden">
              <Image
                src={value}
                alt="Profile picture preview showing uploaded user photo"
                className="w-full h-full object-cover"
              />
              {isUploading && (
                <div className="absolute inset-0 bg-background/80 flex items-center justify-center">
                  <div className="text-center">
                    <div className="w-16 h-16 mx-auto mb-2">
                      <svg className="animate-spin" viewBox="0 0 24 24">
                        <circle
                          className="opacity-25"
                          cx="12"
                          cy="12"
                          r="10"
                          stroke="currentColor"
                          strokeWidth="4"
                          fill="none"
                        />
                        <path
                          className="opacity-75"
                          fill="currentColor"
                          d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                        />
                      </svg>
                    </div>
                    <p className="text-sm font-medium">{uploadProgress}%</p>
                  </div>
                </div>
              )}
            </div>
            {!isUploading && (
              <button
                onClick={handleRemove}
                className="absolute top-2 right-2 w-8 h-8 md:w-10 md:h-10 rounded-full bg-destructive text-destructive-foreground flex items-center justify-center hover:bg-destructive/90 transition-colors focus-ring"
                aria-label="Remove profile picture"
              >
                <Icon name="X" size={16} />
              </button>
            )}
          </div>
        ) : (
          <div className="p-6 md:p-8 text-center">
            <div className="w-16 h-16 md:w-20 md:h-20 mx-auto mb-4 rounded-full bg-muted flex items-center justify-center">
              <Icon name="User" size={32} color="var(--color-muted-foreground)" />
            </div>
            <p className="text-sm md:text-base font-medium text-foreground mb-2">
              {isDragging ? 'Drop image here' : 'Upload profile picture'}
            </p>
            <p className="text-xs md:text-sm text-muted-foreground mb-4">
              Drag and drop or click to browse
            </p>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleFileInputChange}
              className="hidden"
            />
            <Button
              variant="outline"
              size="sm"
              iconName="Upload"
              iconPosition="left"
              onClick={() => fileInputRef?.current?.click()}
            >
              Choose File
            </Button>
          </div>
        )}
      </div>
      {error && <p className="mt-2 text-sm text-destructive">{error}</p>}
      <p className="mt-2 text-xs md:text-sm text-muted-foreground">
        Supported formats: JPG, PNG, GIF (Max 5MB)
      </p>
    </div>
  );
};

export default ProfilePictureUpload;