import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Radio, Globe, Lock, Hash, CheckCircle } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { createChannel } from '../../services/channelService';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';

export default function ChannelCreationSetup() {
  const { user, loading: authLoading, isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(false);
  const [currentStep, setCurrentStep] = useState(1);

  const [formData, setFormData] = useState({
    name: '',
    description: '',
    type: 'public',
    username: '',
    subscriberLimit: 'unlimited',
    welcomeMessage: '',
    enableDiscussion: false,
    enableVerification: false
  });

  useEffect(() => {
    if (authLoading) return;

    if (!isAuthenticated) {
      navigate('/login');
      return;
    }
  }, [authLoading, isAuthenticated, navigate]);

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e?.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleSubmit = async (e) => {
    e?.preventDefault();
    setError(null);
    setLoading(true);

    try {
      // Validate required fields
      if (!formData?.name?.trim()) {
        throw new Error('Channel name is required');
      }

      if (formData?.type === 'public' && !formData?.username?.trim()) {
        throw new Error('Username is required for public channels');
      }

      // Create channel
      const result = await createChannel(
        formData?.name,
        formData?.description,
        formData?.type,
        formData?.username
      );

      if (result?.error) throw result?.error;

      setSuccess(true);
      setTimeout(() => {
        navigate('/channel-management-dashboard');
      }, 2000);
    } catch (err) {
      console.error('Error creating channel:', err);
      setError(err?.message || 'Failed to create channel');
    } finally {
      setLoading(false);
    }
  };

  const nextStep = () => {
    if (currentStep < 3) setCurrentStep(currentStep + 1);
  };

  const prevStep = () => {
    if (currentStep > 1) setCurrentStep(currentStep - 1);
  };

  if (authLoading) {
    return (
      <div className="flex items-center justify-center h-screen bg-gray-50">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white p-6 shadow-lg">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center gap-3 mb-2">
            <Radio className="w-8 h-8" />
            <h1 className="text-2xl font-bold">Create Channel</h1>
          </div>
          <p className="text-blue-100">Set up your broadcast channel with advanced features</p>
        </div>
      </div>

      <div className="max-w-4xl mx-auto p-6">
        {/* Step Indicator */}
        <div className="mb-8">
          <div className="flex items-center justify-between">
            {[1, 2, 3]?.map((step) => (
              <div key={step} className="flex items-center flex-1">
                <div className={`flex items-center justify-center w-10 h-10 rounded-full ${
                  currentStep >= step ? 'bg-blue-600 text-white' : 'bg-gray-300 text-gray-600'
                } font-semibold`}>
                  {step}
                </div>
                {step < 3 && (
                  <div className={`flex-1 h-1 mx-2 ${
                    currentStep > step ? 'bg-blue-600' : 'bg-gray-300'
                  }`}></div>
                )}
              </div>
            ))}
          </div>
          <div className="flex justify-between mt-2 text-sm">
            <span className={currentStep >= 1 ? 'text-blue-600 font-medium' : 'text-gray-500'}>Basic Info</span>
            <span className={currentStep >= 2 ? 'text-blue-600 font-medium' : 'text-gray-500'}>Configuration</span>
            <span className={currentStep >= 3 ? 'text-blue-600 font-medium' : 'text-gray-500'}>Review</span>
          </div>
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-6">
            <p className="font-medium">Error</p>
            <p className="text-sm">{error}</p>
          </div>
        )}

        {success && (
          <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg mb-6 flex items-center gap-2">
            <CheckCircle className="w-5 h-5" />
            <div>
              <p className="font-medium">Channel created successfully!</p>
              <p className="text-sm">Redirecting to dashboard...</p>
            </div>
          </div>
        )}

        <form onSubmit={handleSubmit}>
          <div className="bg-white rounded-lg shadow-md p-6">
            {/* Step 1: Basic Information */}
            {currentStep === 1 && (
              <div className="space-y-6">
                <h2 className="text-xl font-semibold text-gray-900 mb-4">Basic Information</h2>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Channel Name *
                  </label>
                  <Input
                    type="text"
                    name="name"
                    value={formData?.name}
                    onChange={handleInputChange}
                    placeholder="Enter channel name"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Description
                  </label>
                  <textarea
                    name="description"
                    value={formData?.description}
                    onChange={handleInputChange}
                    placeholder="Describe your channel purpose"
                    rows={4}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-3">
                    Channel Type *
                  </label>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <label className={`flex items-start p-4 border-2 rounded-lg cursor-pointer transition-all ${
                      formData?.type === 'public' ? 'border-blue-600 bg-blue-50' : 'border-gray-300 hover:border-blue-300'
                    }`}>
                      <input
                        type="radio"
                        name="type"
                        value="public"
                        checked={formData?.type === 'public'}
                        onChange={handleInputChange}
                        className="mt-1 mr-3"
                      />
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <Globe className="w-5 h-5 text-blue-600" />
                          <span className="font-medium text-gray-900">Public Channel</span>
                        </div>
                        <p className="text-sm text-gray-600">Anyone can find and subscribe to your channel</p>
                      </div>
                    </label>

                    <label className={`flex items-start p-4 border-2 rounded-lg cursor-pointer transition-all ${
                      formData?.type === 'private' ? 'border-blue-600 bg-blue-50' : 'border-gray-300 hover:border-blue-300'
                    }`}>
                      <input
                        type="radio"
                        name="type"
                        value="private"
                        checked={formData?.type === 'private'}
                        onChange={handleInputChange}
                        className="mt-1 mr-3"
                      />
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <Lock className="w-5 h-5 text-gray-600" />
                          <span className="font-medium text-gray-900">Private Channel</span>
                        </div>
                        <p className="text-sm text-gray-600">Invite-only access via link</p>
                      </div>
                    </label>
                  </div>
                </div>

                {formData?.type === 'public' && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Username *
                    </label>
                    <div className="relative">
                      <Hash className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                      <Input
                        type="text"
                        name="username"
                        value={formData?.username}
                        onChange={handleInputChange}
                        placeholder="channel_username"
                        className="pl-10"
                        required={formData?.type === 'public'}
                      />
                    </div>
                    <p className="text-sm text-gray-500 mt-1">Public handle for your channel (e.g., @channel_username)</p>
                  </div>
                )}
              </div>
            )}

            {/* Step 2: Configuration */}
            {currentStep === 2 && (
              <div className="space-y-6">
                <h2 className="text-xl font-semibold text-gray-900 mb-4">Channel Configuration</h2>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Subscriber Limit
                  </label>
                  <select
                    name="subscriberLimit"
                    value={formData?.subscriberLimit}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="100">100 subscribers</option>
                    <option value="500">500 subscribers</option>
                    <option value="1000">1,000 subscribers</option>
                    <option value="5000">5,000 subscribers</option>
                    <option value="unlimited">Unlimited</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Welcome Message
                  </label>
                  <textarea
                    name="welcomeMessage"
                    value={formData?.welcomeMessage}
                    onChange={handleInputChange}
                    placeholder="Automated message sent to new subscribers"
                    rows={3}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div className="space-y-3">
                  <label className="flex items-center gap-3 p-4 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50">
                    <input
                      type="checkbox"
                      name="enableDiscussion"
                      checked={formData?.enableDiscussion}
                      onChange={handleInputChange}
                      className="w-5 h-5 text-blue-600"
                    />
                    <div>
                      <span className="font-medium text-gray-900">Enable Discussion</span>
                      <p className="text-sm text-gray-600">Allow subscribers to comment on posts</p>
                    </div>
                  </label>

                  <label className="flex items-center gap-3 p-4 border border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50">
                    <input
                      type="checkbox"
                      name="enableVerification"
                      checked={formData?.enableVerification}
                      onChange={handleInputChange}
                      className="w-5 h-5 text-blue-600"
                    />
                    <div>
                      <span className="font-medium text-gray-900">Request Verification</span>
                      <p className="text-sm text-gray-600">Apply for official verified status</p>
                    </div>
                  </label>
                </div>
              </div>
            )}

            {/* Step 3: Review */}
            {currentStep === 3 && (
              <div className="space-y-6">
                <h2 className="text-xl font-semibold text-gray-900 mb-4">Review & Create</h2>

                <div className="bg-gray-50 rounded-lg p-6 space-y-4">
                  <div>
                    <span className="text-sm font-medium text-gray-600">Channel Name</span>
                    <p className="text-lg font-semibold text-gray-900">{formData?.name}</p>
                  </div>

                  {formData?.description && (
                    <div>
                      <span className="text-sm font-medium text-gray-600">Description</span>
                      <p className="text-gray-900">{formData?.description}</p>
                    </div>
                  )}

                  <div className="flex items-center gap-4">
                    <div>
                      <span className="text-sm font-medium text-gray-600">Type</span>
                      <p className="text-gray-900 capitalize">{formData?.type}</p>
                    </div>
                    {formData?.type === 'public' && formData?.username && (
                      <div>
                        <span className="text-sm font-medium text-gray-600">Username</span>
                        <p className="text-gray-900">@{formData?.username}</p>
                      </div>
                    )}
                  </div>

                  <div>
                    <span className="text-sm font-medium text-gray-600">Subscriber Limit</span>
                    <p className="text-gray-900 capitalize">{formData?.subscriberLimit}</p>
                  </div>

                  <div className="flex gap-4">
                    <div className="flex items-center gap-2">
                      <CheckCircle className={`w-5 h-5 ${
                        formData?.enableDiscussion ? 'text-green-600' : 'text-gray-300'
                      }`} />
                      <span className="text-sm text-gray-700">Discussion Enabled</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className={`w-5 h-5 ${
                        formData?.enableVerification ? 'text-green-600' : 'text-gray-300'
                      }`} />
                      <span className="text-sm text-gray-700">Verification Requested</span>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Navigation Buttons */}
            <div className="flex justify-between mt-8 pt-6 border-t">
              <Button
                type="button"
                onClick={prevStep}
                disabled={currentStep === 1}
                className="px-6 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Previous
              </Button>

              {currentStep < 3 ? (
                <Button
                  type="button"
                  onClick={nextStep}
                  className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  Next
                </Button>
              ) : (
                <Button
                  type="submit"
                  disabled={loading}
                  className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 flex items-center gap-2"
                >
                  {loading ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      Creating...
                    </>
                  ) : (
                    <>
                      <Radio className="w-5 h-5" />
                      Create Channel
                    </>
                  )}
                </Button>
              )}
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}