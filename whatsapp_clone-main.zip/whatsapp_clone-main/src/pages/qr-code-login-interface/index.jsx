import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { QRCodeSVG } from 'qrcode.react';

import Button from '../../components/ui/Button';
import { qrAuthService } from '../../services/qrAuthService';
import { useAuth } from '../../contexts/AuthContext';
import { Smartphone, RefreshCw, CheckCircle, XCircle, Clock, Shield } from 'lucide-react';

export default function QRCodeLoginInterface() {
  const navigate = useNavigate();
  const { signIn } = useAuth();
  const [qrData, setQrData] = useState(null);
  const [tokenId, setTokenId] = useState(null);
  const [status, setStatus] = useState('generating'); // generating, waiting, scanning, verified, expired, error
  const [timeLeft, setTimeLeft] = useState(300); // 5 minutes
  const [error, setError] = useState(null);
  const [verifiedUser, setVerifiedUser] = useState(null);
  const pollingIntervalRef = useRef(null);
  const timerIntervalRef = useRef(null);

  useEffect(() => {
    generateQRCode();
    return () => {
      if (pollingIntervalRef?.current) clearInterval(pollingIntervalRef?.current);
      if (timerIntervalRef?.current) clearInterval(timerIntervalRef?.current);
    };
  }, []);

  const generateQRCode = async () => {
    try {
      setStatus('generating');
      setError(null);
      
      const result = await qrAuthService?.generateQRToken();
      setQrData(result?.qrData);
      setTokenId(result?.tokenId);
      setTimeLeft(300);
      setStatus('waiting');

      // Start polling for verification
      startPolling(result?.tokenId);
      
      // Start countdown timer
      startTimer();
    } catch (err) {
      setError(err?.message || 'Failed to generate QR code');
      setStatus('error');
    }
  };

  const startPolling = (token) => {
    if (pollingIntervalRef?.current) clearInterval(pollingIntervalRef?.current);
    
    pollingIntervalRef.current = setInterval(async () => {
      try {
        const result = await qrAuthService?.checkQRTokenStatus(token);
        
        if (result?.status === 'verified') {
          setStatus('verified');
          setVerifiedUser(result?.profile);
          clearInterval(pollingIntervalRef?.current);
          clearInterval(timerIntervalRef?.current);
          
          // Create session and redirect
          setTimeout(async () => {
            const session = await qrAuthService?.createQRSession(result?.userId);
            navigate('/chat');
          }, 2000);
        } else if (result?.status === 'expired') {
          setStatus('expired');
          clearInterval(pollingIntervalRef?.current);
          clearInterval(timerIntervalRef?.current);
        }
      } catch (err) {
        console.error('Polling error:', err);
      }
    }, 2000); // Poll every 2 seconds
  };

  const startTimer = () => {
    if (timerIntervalRef?.current) clearInterval(timerIntervalRef?.current);
    
    timerIntervalRef.current = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timerIntervalRef?.current);
          clearInterval(pollingIntervalRef?.current);
          setStatus('expired');
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs?.toString()?.padStart(2, '0')}`;
  };

  const handleRefresh = () => {
    if (pollingIntervalRef?.current) clearInterval(pollingIntervalRef?.current);
    if (timerIntervalRef?.current) clearInterval(timerIntervalRef?.current);
    generateQRCode();
  };

  const getStatusIcon = () => {
    switch (status) {
      case 'generating':
        return <RefreshCw size={48} className="text-primary animate-spin" />;
      case 'waiting':
        return <Smartphone size={48} className="text-primary" />;
      case 'verified':
        return <CheckCircle size={48} className="text-green-500" />;
      case 'expired':
        return <Clock size={48} className="text-orange-500" />;
      case 'error':
        return <XCircle size={48} className="text-red-500" />;
      default:
        return null;
    }
  };

  const getStatusMessage = () => {
    switch (status) {
      case 'generating':
        return 'Generating secure QR code...';
      case 'waiting':
        return 'Scan with your mobile app';
      case 'verified':
        return 'Successfully authenticated!';
      case 'expired':
        return 'QR code expired';
      case 'error':
        return 'Failed to generate QR code';
      default:
        return '';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-primary/5 via-background to-primary/10 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-primary rounded-full mb-4">
            <Shield size={32} className="text-white" />
          </div>
          <h1 className="text-3xl font-bold text-foreground mb-2">
            QR Code Login
          </h1>
          <p className="text-muted-foreground">
            Scan to login on web or desktop
          </p>
        </div>

        {/* Main Card */}
        <div className="bg-card border border-border rounded-2xl shadow-xl overflow-hidden">
          {/* QR Code Section */}
          <div className="p-8">
            <div className="bg-white rounded-xl p-6 mb-6 flex items-center justify-center min-h-[320px]">
              {status === 'generating' && (
                <div className="text-center">
                  <RefreshCw size={48} className="text-primary animate-spin mx-auto mb-4" />
                  <p className="text-sm text-muted-foreground">Generating QR code...</p>
                </div>
              )}

              {(status === 'waiting' || status === 'scanning') && qrData && (
                <div className="text-center">
                  <QRCodeSVG
                    value={qrData}
                    size={256}
                    level="H"
                    includeMargin={true}
                    className="mx-auto"
                  />
                </div>
              )}

              {status === 'verified' && verifiedUser && (
                <div className="text-center">
                  <CheckCircle size={64} className="text-green-500 mx-auto mb-4" />
                  <h3 className="font-semibold text-foreground mb-2">
                    Welcome back!
                  </h3>
                  <p className="text-sm text-muted-foreground">
                    {verifiedUser?.full_name || verifiedUser?.email}
                  </p>
                </div>
              )}

              {status === 'expired' && (
                <div className="text-center">
                  <Clock size={64} className="text-orange-500 mx-auto mb-4" />
                  <h3 className="font-semibold text-foreground mb-2">
                    QR Code Expired
                  </h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    Please refresh to generate a new code
                  </p>
                  <Button onClick={handleRefresh} iconName="RefreshCw" iconPosition="left">
                    Refresh QR Code
                  </Button>
                </div>
              )}

              {status === 'error' && (
                <div className="text-center">
                  <XCircle size={64} className="text-red-500 mx-auto mb-4" />
                  <h3 className="font-semibold text-foreground mb-2">
                    Error
                  </h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    {error || 'Failed to generate QR code'}
                  </p>
                  <Button onClick={handleRefresh} iconName="RefreshCw" iconPosition="left">
                    Try Again
                  </Button>
                </div>
              )}
            </div>

            {/* Status Bar */}
            {(status === 'waiting' || status === 'scanning') && (
              <div className="space-y-4">
                <div className="flex items-center justify-between p-3 bg-primary/5 rounded-lg">
                  <div className="flex items-center gap-2">
                    <Clock size={20} className="text-primary" />
                    <span className="text-sm font-semibold text-foreground">
                      Expires in
                    </span>
                  </div>
                  <span className="text-lg font-bold text-primary">
                    {formatTime(timeLeft)}
                  </span>
                </div>

                <button
                  onClick={handleRefresh}
                  className="w-full flex items-center justify-center gap-2 p-3 text-sm text-muted-foreground hover:text-foreground transition-colors"
                >
                  <RefreshCw size={16} />
                  <span>Refresh QR Code</span>
                </button>
              </div>
            )}
          </div>

          {/* Instructions */}
          <div className="bg-muted/50 p-6 border-t border-border">
            <h3 className="font-semibold text-foreground mb-3 flex items-center gap-2">
              <Smartphone size={20} />
              How to scan
            </h3>
            <ol className="space-y-2 text-sm text-muted-foreground">
              <li className="flex items-start gap-2">
                <span className="font-semibold text-primary">1.</span>
                <span>Open the mobile app on your phone</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="font-semibold text-primary">2.</span>
                <span>Tap the QR code scanner icon</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="font-semibold text-primary">3.</span>
                <span>Point your camera at this screen</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="font-semibold text-primary">4.</span>
                <span>Confirm login on your phone</span>
              </li>
            </ol>
          </div>
        </div>

        {/* Alternative Login */}
        <div className="mt-6 text-center">
          <button
            onClick={() => navigate('/login')}
            className="text-sm text-muted-foreground hover:text-foreground transition-colors"
          >
            Use email/password instead
          </button>
        </div>

        {/* Security Notice */}
        <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
          <div className="flex items-start gap-3">
            <Shield size={20} className="text-blue-600 flex-shrink-0 mt-0.5" />
            <div>
              <h4 className="text-sm font-semibold text-blue-900 mb-1">
                Secure Authentication
              </h4>
              <p className="text-xs text-blue-700">
                Your session is encrypted end-to-end. QR codes expire after 5 minutes for security.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
