import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import { autoDeleteService } from '../../services/autoDeleteService';
import { useAuth } from '../../contexts/AuthContext';

const MessageAutoDeleteSettings = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { user, loading: authLoading } = useAuth();
  const conversationId = location?.state?.conversationId || 'default-conversation';

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [settings, setSettings] = useState({
    isEnabled: false,
    durationType: '24h',
    customDurationHours: 24,
    applyToMedia: true,
    applyToDocuments: true,
    applyToText: true,
    isEncrypted: true
  });

  const durationOptions = [
    { value: '24h', label: '24 Hours', description: 'Messages deleted after 1 day' },
    { value: '7d', label: '7 Days', description: 'Messages deleted after 1 week' },
    { value: '30d', label: '30 Days', description: 'Messages deleted after 1 month' },
    { value: '90d', label: '90 Days', description: 'Messages deleted after 3 months' },
    { value: 'custom', label: 'Custom', description: 'Set your own duration' }
  ];

  useEffect(() => {
    // Wait for auth to load before checking authentication
    if (authLoading) return;
    
    // Redirect to login if not authenticated
    if (!user) {
      navigate('/login', { 
        state: { 
          from: location?.pathname,
          message: 'Please sign in to access auto-delete settings' 
        } 
      });
      return;
    }
    
    // Load settings once authenticated
    loadSettings();
  }, [user, authLoading, conversationId, navigate, location?.pathname]);

  const loadSettings = async () => {
    try {
      setLoading(true);
      setError('');
      const existingSettings = await autoDeleteService?.getSettings(conversationId);
      
      if (existingSettings) {
        setSettings(existingSettings);
      }
    } catch (err) {
      console.error('Error loading settings:', err);
      if (err?.message?.includes('Not authenticated')) {
        setError('Authentication required. Please sign in again.');
        setTimeout(() => navigate('/login'), 2000);
      } else {
        setError(err?.message || 'Failed to load auto-delete settings');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleSaveSettings = async () => {
    try {
      setSaving(true);
      setError('');

      await autoDeleteService?.upsertSettings(conversationId, settings);
      
      navigate(-1);
    } catch (err) {
      console.error('Error saving settings:', err);
      setError(err?.message || 'Failed to save auto-delete settings');
    } finally {
      setSaving(false);
    }
  };

  const handleToggleEnabled = () => {
    setSettings({ ...settings, isEnabled: !settings?.isEnabled });
  };

  const handleDurationChange = (durationType) => {
    setSettings({ ...settings, durationType });
  };

  const handleCustomDurationChange = (e) => {
    const hours = parseInt(e?.target?.value) || 24;
    setSettings({ ...settings, customDurationHours: hours });
  };

  const handleContentTypeToggle = (type) => {
    setSettings({ 
      ...settings, 
      [type]: !settings?.[type]
    });
  };

  if (authLoading || loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">
            {authLoading ? 'Checking authentication...' : 'Loading settings...'}
          </p>
        </div>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Auto-Delete Settings - ChatVybz</title>
        <meta name="description" content="Configure automatic message deletion with time-limited options and E2EE encryption for enhanced privacy" />
      </Helmet>

      <div className="min-h-screen bg-background">
        {/* Header */}
        <div className="bg-card border-b border-border sticky top-0 z-10">
          <div className="max-w-4xl mx-auto px-4 py-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <button
                onClick={() => navigate(-1)}
                className="p-2 hover:bg-accent rounded-lg transition-colors"
              >
                <Icon name="ArrowLeft" size={20} />
              </button>
              <div>
                <h1 className="text-xl font-semibold text-foreground">Auto-Delete Settings</h1>
                <p className="text-sm text-muted-foreground">Time-limited message deletion</p>
              </div>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="max-w-4xl mx-auto px-4 py-6 space-y-6">
          {error && (
            <div className="p-4 bg-destructive/10 border border-destructive/20 rounded-lg flex items-start gap-3">
              <Icon name="AlertCircle" size={20} color="var(--color-destructive)" />
              <div className="flex-1">
                <p className="text-sm font-medium text-destructive">{error}</p>
              </div>
            </div>
          )}

          {/* Enable/Disable Toggle */}
          <div className="bg-card border border-border rounded-xl p-6">
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  Enable Auto-Delete
                </h3>
                <p className="text-sm text-muted-foreground">
                  Automatically delete messages after the specified duration for enhanced privacy
                </p>
              </div>
              <button
                onClick={handleToggleEnabled}
                className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                  settings?.isEnabled ? 'bg-primary' : 'bg-input'
                }`}
              >
                <span
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    settings?.isEnabled ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
            </div>
          </div>

          {/* Duration Options */}
          <div className="bg-card border border-border rounded-xl p-6">
            <h3 className="text-lg font-semibold text-foreground mb-4">
              Delete Duration
            </h3>
            <div className="space-y-3">
              {durationOptions?.map((option) => (
                <button
                  key={option?.value}
                  onClick={() => handleDurationChange(option?.value)}
                  disabled={!settings?.isEnabled}
                  className={`w-full p-4 rounded-lg border transition-all text-left ${
                    settings?.durationType === option?.value
                      ? 'border-primary bg-primary/5' :'border-border hover:border-primary/50'
                  } ${!settings?.isEnabled ? 'opacity-50 cursor-not-allowed' : ''}`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="font-medium text-foreground">{option?.label}</span>
                    {settings?.durationType === option?.value && (
                      <Icon name="Check" size={20} color="var(--color-primary)" />
                    )}
                  </div>
                  <p className="text-sm text-muted-foreground">{option?.description}</p>
                </button>
              ))}
            </div>

            {/* Custom Duration Input */}
            {settings?.durationType === 'custom' && settings?.isEnabled && (
              <div className="mt-4 p-4 bg-accent/10 rounded-lg">
                <label className="block text-sm font-medium text-foreground mb-2">
                  Custom Duration (Hours)
                </label>
                <input
                  type="number"
                  min="1"
                  max="8760"
                  value={settings?.customDurationHours}
                  onChange={handleCustomDurationChange}
                  className="w-full px-4 py-2 bg-background border border-input rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                  placeholder="Enter hours"
                />
                <p className="text-xs text-muted-foreground mt-2">
                  Set duration between 1 hour and 8760 hours (365 days)
                </p>
              </div>
            )}
          </div>

          {/* Content Type Selection */}
          <div className="bg-card border border-border rounded-xl p-6">
            <h3 className="text-lg font-semibold text-foreground mb-4">
              Apply To Content Types
            </h3>
            <div className="space-y-3">
              {[
                { key: 'applyToText', label: 'Text Messages', icon: 'MessageSquare' },
                { key: 'applyToMedia', label: 'Media Files', icon: 'Image' },
                { key: 'applyToDocuments', label: 'Documents', icon: 'File' }
              ]?.map((item) => (
                <div key={item?.key} className="flex items-center justify-between p-4 rounded-lg border border-border">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                      <Icon name={item?.icon} size={20} color="var(--color-primary)" />
                    </div>
                    <span className="font-medium text-foreground">{item?.label}</span>
                  </div>
                  <button
                    onClick={() => handleContentTypeToggle(item?.key)}
                    disabled={!settings?.isEnabled}
                    className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                      settings?.[item?.key] ? 'bg-primary' : 'bg-input'
                    } ${!settings?.isEnabled ? 'opacity-50 cursor-not-allowed' : ''}`}
                  >
                    <span
                      className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                        settings?.[item?.key] ? 'translate-x-6' : 'translate-x-1'
                      }`}
                    />
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* E2EE Status */}
          <div className="bg-card border border-border rounded-xl p-6">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-lg bg-accent/10 flex items-center justify-center flex-shrink-0">
                <Icon name="Shield" size={20} color="var(--color-accent)" />
              </div>
              <div className="flex-1">
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  End-to-End Encryption
                </h3>
                <p className="text-sm text-muted-foreground">
                  All auto-delete operations maintain E2EE integrity. Your messages remain encrypted throughout the deletion process, ensuring complete privacy.
                </p>
              </div>
            </div>
          </div>

          {/* Warning Notice */}
          <div className="bg-destructive/10 border border-destructive/20 rounded-xl p-6">
            <div className="flex items-start gap-3">
              <Icon name="AlertTriangle" size={20} color="var(--color-destructive)" className="flex-shrink-0 mt-0.5" />
              <div>
                <h3 className="text-base font-semibold text-destructive mb-2">
                  Important Notice
                </h3>
                <p className="text-sm text-muted-foreground">
                  Once messages are auto-deleted, they cannot be recovered. Make sure you have backed up any important information before enabling this feature.
                </p>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3">
            <Button
              variant="outline"
              fullWidth
              onClick={() => navigate(-1)}
            >
              Cancel
            </Button>
            <Button
              variant="default"
              fullWidth
              loading={saving}
              onClick={handleSaveSettings}
            >
              Save Settings
            </Button>
          </div>
        </div>
      </div>
    </>
  );
};

export default MessageAutoDeleteSettings;