import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { MessageSquare, Shield, Zap, Globe, Smartphone, Lock, Users, Clock, Download, ChevronDown, ChevronUp, Star, Mail, Phone, MapPin, Instagram, Twitter, Linkedin, Youtube, Facebook, Check, Monitor, Laptop, QrCode, FileText } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { LANGUAGES, APP_LOGO } from '../register/constants';
import FooterPages from './FooterPages';

const LandingPage = ({ onStartApp, onOpenHelpCenter }) => {
  const navigate = useNavigate();

  // Default handlers if not provided
  const handleStartApp = onStartApp || (() => {
    // Navigate to login page
    navigate('/login');
  });

  const handleOpenHelpCenter = onOpenHelpCenter || (() => {
    console.log('Help Center clicked');
  });
  const [openFaq, setOpenFaq] = useState(null);
  const [isScrolled, setIsScrolled] = useState(false);
  const [isLangMenuOpen, setIsLangMenuOpen] = useState(false);
  const [activeFooterPage, setActiveFooterPage] = useState(null);
  const [activeSection, setActiveSection] = useState('features');
  const { currentLanguage, setLanguage, t, dir } = useLanguage();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);

      // Update active section based on scroll position
      const sections = ['features', 'security', 'download'];
      const scrollPosition = window.scrollY + 200;

      for (let i = sections?.length - 1; i >= 0; i--) {
        const section = document.getElementById(sections?.[i]);
        if (section && section?.offsetTop <= scrollPosition) {
          setActiveSection(sections?.[i]);
          break;
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    handleScroll(); // Initial check
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (sectionId) => {
    const element = document.getElementById(sectionId);
    if (element) {
      const offset = 80; // Account for fixed header
      const elementPosition = element?.getBoundingClientRect()?.top;
      const offsetPosition = elementPosition + window.pageYOffset - offset;
      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  const handleLogoClick = () => {
    setActiveFooterPage(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
    navigate('/');
  };

  const handleDownloadApp = () => {
    scrollToSection('download');
  };

  const handleSecurityClick = () => {
    scrollToSection('security');
  };

  const handleHelpCenterClick = () => {
    if (onOpenHelpCenter) {
      onOpenHelpCenter();
    } else {
      // Scroll to FAQ section or open help
      scrollToSection('faq');
    }
  };

  const toggleFaq = (index) => {
    setOpenFaq(openFaq === index ? null : index);
  };

  const handleFooterLinkClick = (page) => {
    window.scrollTo(0, 0);
    setActiveFooterPage(page);
  };

  const featuresList = [
  { icon: Shield, color: 'text-blue-600', bg: 'bg-blue-50', title: 'End-to-End Encryption', desc: 'Military-grade encryption ensures your messages, calls, and shared files remain completely private and secure.' },
  { icon: Users, color: 'text-purple-600', bg: 'bg-purple-50', title: 'Group Chats', desc: 'Create groups with up to 10,000 members. Share updates, files, and collaborate seamlessly with your team.' },
  { icon: FileText, color: 'text-green-600', bg: 'bg-green-50', title: 'File Sharing', desc: 'Share documents, photos, videos, and any file type up to 2GB. Preview files instantly without downloading.' },
  { icon: Smartphone, color: 'text-orange-600', bg: 'bg-orange-50', title: 'Cross-Platform Sync', desc: 'Access your chats from web, mobile, or desktop. Messages sync instantly across all your devices.' },
  { icon: Lock, color: 'text-red-600', bg: 'bg-red-50', title: 'Privacy Controls', desc: 'Control who can see your status, profile picture, and last seen. Block unwanted contacts with one tap.' },
  { icon: Clock, color: 'text-indigo-600', bg: 'bg-indigo-50', title: 'Message History', desc: 'Never lose important conversations. Cloud backup keeps your chat history safe and accessible forever.' },
  { icon: Globe, color: 'text-teal-600', bg: 'bg-teal-50', title: 'Global Reach', desc: 'Connect with anyone, anywhere. Available in 150+ countries with support for 60+ languages.' },
  { icon: Zap, color: 'text-yellow-600', bg: 'bg-yellow-50', title: 'Lightning Speed', desc: 'Optimized infrastructure delivers messages in milliseconds. Experience the fastest messaging platform.' }];


  const faqList = [
  { q: 'Is ChatVybz really free?', a: 'Yes, ChatVybz is completely free to download and use. We do not charge subscription fees for basic features.' },
  { q: 'How secure is ChatVybz?', a: 'We use state-of-the-art end-to-end encryption for all messages and calls. This means only you and the person you\'re communicating with can read or listen to them, and nobody in between, not even ChatVybz.' },
  { q: 'Can I use ChatVybz on multiple devices?', a: 'Yes, you can use ChatVybz on up to 4 linked devices and 1 phone at the same time.' },
  { q: 'Do I need a phone number to sign up?', a: 'Yes, ChatVybz uses your phone number as your unique identifier to connect you with your contacts easily.' },
  { q: 'What file types can I share?', a: 'You can share photos, videos, documents (PDF, DOC, etc.), and audio files up to 2GB in size.' },
  { q: 'Is there a limit to group size?', a: 'ChatVybz groups support up to 10,000 members, making it perfect for large communities and organizations.' },
  { q: 'Does ChatVybz work offline?', a: 'You can draft messages offline, and they will be sent automatically once your connection is restored.' },
  { q: 'How is my data protected?', a: 'We adhere to strict data protection regulations including GDPR and CCPA. We do not sell your personal data to advertisers.' }];


  if (activeFooterPage) {
    return (
      <FooterPages
        page={activeFooterPage}
        onBack={() => setActiveFooterPage(null)}
        onLaunchWebApp={handleStartApp} />);


  }

  return (
    <div className="min-h-screen bg-white text-gray-800 font-sans" dir={dir}>
          {/* --- STICKY HEADER --- */}
          <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      isScrolled ? 'bg-white/95 backdrop-blur-md shadow-md py-2 md:py-3 text-gray-800' : 'bg-transparent py-4 md:py-6 text-white'}`
      }>
              <div className="container mx-auto px-4 md:px-6 flex justify-between items-center">
                {/* Logo */}
                <div className="flex items-center space-x-2 cursor-pointer" onClick={handleLogoClick}>
                  <div className={`w-8 h-8 md:w-10 md:h-10 rounded-lg flex items-center justify-center transition-colors overflow-hidden ${isScrolled ? 'bg-blue-600' : 'bg-white'}`}>
                    {APP_LOGO ?
              <img src={APP_LOGO} alt="ChatVybz" className="w-full h-full object-contain p-1" /> :

              <MessageSquare size={20} className={isScrolled ? 'text-white' : 'text-blue-600'} />
              }
                  </div>
                  <span className={`text-xl md:text-2xl font-bold tracking-tight transition-colors ${isScrolled ? 'text-blue-600' : 'text-white'}`}>ChatVybz</span>
                </div>

                {/* Desktop Links */}
                <div className={`hidden md:flex space-x-8 text-sm font-medium transition-colors ${isScrolled ? 'text-gray-600' : 'text-blue-100'}`}>
                  <button
              onClick={() => scrollToSection('features')}
              className={`hover:text-blue-600 transition-colors ${!isScrolled && 'hover:text-white'} ${activeSection === 'features' ? isScrolled ? 'text-blue-600 font-semibold' : 'text-white font-semibold' : ''}`}>

                    Features
                  </button>
                  <button
              onClick={handleSecurityClick}
              className={`hover:text-blue-600 transition-colors ${!isScrolled && 'hover:text-white'} ${activeSection === 'security' ? isScrolled ? 'text-blue-600 font-semibold' : 'text-white font-semibold' : ''}`}>

                    Security
                  </button>
                  <button
              onClick={() => scrollToSection('download')}
              className={`hover:text-blue-600 transition-colors ${!isScrolled && 'hover:text-white'} ${activeSection === 'download' ? isScrolled ? 'text-blue-600 font-semibold' : 'text-white font-semibold' : ''}`}>

                    Download
                  </button>
                  <button
              onClick={handleHelpCenterClick}
              className={`hover:text-blue-600 transition-colors ${!isScrolled && 'hover:text-white'}`}>

                    Help Center
                  </button>
                </div>

                {/* Right Actions */}
                <div className="flex items-center space-x-2 md:space-x-4">
                   {/* Language Selector */}
                   <div className="relative">
                      <button
                onClick={() => setIsLangMenuOpen(!isLangMenuOpen)}
                className={`flex items-center space-x-1 text-xs md:text-sm font-medium px-2 py-1.5 md:px-3 md:py-2 rounded-full transition-colors ${
                isScrolled ? 'hover:bg-gray-100' : 'hover:bg-white/10'}`
                }>

                          <Globe size={16} className="md:w-[18px] md:h-[18px]" />
                          <span className="uppercase">{currentLanguage && currentLanguage?.length >= 2 ? currentLanguage?.substring(0, 2) : 'EN'}</span>
                          <ChevronDown size={14} />
                      </button>

                      {isLangMenuOpen &&
              <>
                            <div className="fixed inset-0 z-40" onClick={() => setIsLangMenuOpen(false)}></div>
                            <div className={`absolute top-full ${dir === 'rtl' ? 'left-0' : 'right-0'} mt-2 w-48 bg-white text-gray-800 rounded-xl shadow-xl border border-gray-100 py-2 max-h-64 overflow-y-auto z-50 animate-scale-in`}>
                                {LANGUAGES?.map((lang) =>
                  <button
                    key={lang}
                    onClick={() => {setLanguage(lang);setIsLangMenuOpen(false);}}
                    className="w-full text-start px-4 py-2 text-sm hover:bg-gray-50 flex items-center justify-between transition-colors">

                                        <span>{lang}</span>
                                        {currentLanguage === lang && <Check size={14} className="text-blue-600" />}
                                    </button>
                  )}
                            </div>
                          </>
              }
                   </div>

                   <button
              onClick={handleStartApp}
              className={`px-4 py-2 text-xs md:text-sm md:px-6 md:py-2.5 rounded-full font-bold transition-all hover:scale-105 shadow-lg whitespace-nowrap ${
              isScrolled ? 'bg-blue-600 text-white hover:bg-blue-700' : 'bg-white text-blue-600 hover:bg-blue-50'}`
              }>

                     {t('landing_cta_web')}
                   </button>
                </div>
              </div>
          </nav>
          {/* --- HERO SECTION --- */}
          <div className="bg-gradient-to-br from-blue-600 to-indigo-700 text-white relative overflow-hidden" dir={dir}>
            <div className={`absolute top-0 ${dir === 'rtl' ? 'left-0' : 'right-0'} w-1/2 h-full bg-white opacity-[0.03] transform skew-x-12`}></div>
            <div className="container mx-auto px-4 md:px-6 pt-32 pb-20 md:pt-48 md:pb-32 flex flex-col md:flex-row items-center relative z-10">
              <div className="md:w-1/2 text-center md:text-start mb-16 md:mb-0">
                <div className="inline-flex items-center bg-white/10 backdrop-blur-sm rounded-full px-4 py-1.5 text-xs font-semibold mb-8 border border-white/20">
                  <Shield size={14} className="mr-2 text-blue-200" /> End-to-End Encrypted
                </div>
                <h1 className="text-4xl md:text-6xl font-bold leading-tight mb-6 tracking-tight">
                  Connect Securely,<br />
                  <span className="text-blue-200">Chat Instantly</span>
                </h1>
                <p className="text-lg md:text-xl text-blue-100 mb-10 max-w-lg mx-auto md:mx-0 leading-relaxed font-light">
                  Experience the future of messaging with ChatVybz. Secure, fast, and reliable communication across all your devices.
                </p>
                <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4 justify-center md:justify-start rtl:space-x-reverse">
                  <button
                onClick={handleStartApp}
                className="bg-white text-blue-600 px-8 py-4 rounded-xl font-bold hover:bg-blue-50 transition-all shadow-xl flex items-center justify-center whitespace-nowrap text-lg">

                    Try Web Version
                  </button>
                  <button
                onClick={handleDownloadApp}
                className="bg-blue-700/50 text-white border border-blue-400/30 px-8 py-4 rounded-xl font-bold hover:bg-blue-600/50 transition-all flex items-center justify-center text-lg backdrop-blur-sm">

                    Download App
                  </button>
                </div>
              </div>
              {/* Hero Image/Graphics Placeholder */}
              <div className="md:w-1/2 relative w-full flex justify-center md:justify-end">
                 <div className="relative w-full max-w-md">
                    <div className="space-y-4 relative z-10">
                       {/* Card 1 */}
                       <div className="bg-white/10 backdrop-blur-md border border-white/20 p-5 rounded-2xl flex items-center shadow-lg transform translate-x-4 md:translate-x-8">
                          <div className="w-12 h-12 rounded-full bg-blue-500 flex items-center justify-center mr-4 text-white shadow-lg">
                              <MessageSquare size={24} />
                          </div>
                          <div>
                             <h3 className="font-bold text-lg">Real-Time Messaging</h3>
                             <p className="text-sm text-blue-100 opacity-80">Instant message delivery</p>
                          </div>
                       </div>
                       
                       {/* Card 2 */}
                       <div className="bg-white/10 backdrop-blur-md border border-white/20 p-5 rounded-2xl flex items-center shadow-lg transform -translate-x-2">
                          <div className="w-12 h-12 rounded-full bg-indigo-500 flex items-center justify-center mr-4 text-white shadow-lg">
                              <Shield size={24} />
                          </div>
                          <div>
                             <h3 className="font-bold text-lg">End-to-End Encryption</h3>
                             <p className="text-sm text-blue-100 opacity-80">Your privacy is guaranteed</p>
                          </div>
                       </div>

                       {/* Card 3 */}
                       <div className="bg-white/10 backdrop-blur-md border border-white/20 p-5 rounded-2xl flex items-center shadow-lg transform translate-x-2 md:translate-x-4">
                          <div className="w-12 h-12 rounded-full bg-purple-500 flex items-center justify-center mr-4 text-white shadow-lg">
                              <Zap size={24} />
                          </div>
                          <div>
                             <h3 className="font-bold text-lg">Lightning Fast</h3>
                             <p className="text-sm text-blue-100 opacity-80">Optimized for speed</p>
                          </div>
                       </div>

                       {/* Card 4 */}
                       <div className="bg-white/10 backdrop-blur-md border border-white/20 p-5 rounded-2xl flex items-center shadow-lg transform -translate-x-4 md:translate-x-0">
                          <div className="w-12 h-12 rounded-full bg-teal-500 flex items-center justify-center mr-4 text-white shadow-lg">
                              <Globe size={24} />
                          </div>
                          <div>
                             <h3 className="font-bold text-lg">Cross-Platform</h3>
                             <p className="text-sm text-blue-100 opacity-80">Works everywhere</p>
                          </div>
                       </div>
                    </div>
                    
                    {/* Glow effect behind cards */}
                    <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[300px] h-[300px] bg-blue-400/30 rounded-full blur-[80px] -z-10"></div>
                 </div>
              </div>
            </div>
            
            {/* Curve Divider */}
            <div className="absolute bottom-0 w-full overflow-hidden leading-none">
              <svg className="relative block w-full h-[60px] md:h-[100px]" data-name="Layer 1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1200 120" preserveAspectRatio="none">
                  <path d="M985.66,92.83C906.67,72,823.78,31,743.84,14.19c-82.26-17.34-168.06-16.33-250.45.39-57.84,11.73-114,31.07-172,41.86A600.21,600.21,0,0,1,0,27.35V120H1200V95.8C1132.19,118.92,1055.71,111.31,985.66,92.83Z" className="fill-white"></path>
              </svg>
            </div>
          </div>
          {/* --- FEATURES SECTION --- */}
          <section id="features" className="py-20 md:py-28 container mx-auto px-4 md:px-6 bg-white">
            <div className="text-center mb-16 max-w-3xl mx-auto">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">Powerful Features for Modern Communication</h2>
              <p className="text-gray-600 text-lg">Everything you need to stay connected, secure, and productive. Built with cutting-edge technology for the best messaging experience.</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {featuresList?.map((feature, idx) =>
          <div key={idx} className="bg-white p-8 rounded-2xl border border-gray-100 shadow-lg hover:shadow-xl transition-all hover:-translate-y-1 group">
                  <div className={`w-14 h-14 ${feature?.bg} rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform`}>
                    <feature.icon size={28} className={feature?.color} />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-3">{feature?.title}</h3>
                  <p className="text-gray-500 text-sm leading-relaxed">{feature?.desc}</p>
                </div>
          )}
            </div>
          </section>
          {/* --- SECURITY SECTION --- */}
          <section id="security" className="py-20 md:py-28 container mx-auto px-4 md:px-6 bg-gray-50">
            <div className="text-center mb-16 max-w-3xl mx-auto">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">Enterprise-Grade Security</h2>
              <p className="text-gray-600 text-lg">Your privacy and security are our top priorities. We use military-grade encryption to protect your data.</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
              <div className="bg-white p-8 rounded-2xl border border-gray-100 shadow-lg text-center">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Shield size={32} className="text-blue-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">End-to-End Encryption</h3>
                <p className="text-gray-500 text-sm">All messages, calls, and files are encrypted. Only you and the recipient can access them.</p>
              </div>
              <div className="bg-white p-8 rounded-2xl border border-gray-100 shadow-lg text-center">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Lock size={32} className="text-green-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">Privacy First</h3>
                <p className="text-gray-500 text-sm">We don't store your messages on our servers. Your data stays on your devices.</p>
              </div>
              <div className="bg-white p-8 rounded-2xl border border-gray-100 shadow-lg text-center">
                <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Check size={32} className="text-purple-600" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">Verified Security</h3>
                <p className="text-gray-500 text-sm">Regular security audits and compliance with GDPR, CCPA, and other privacy regulations.</p>
              </div>
            </div>
          </section>
          {/* --- WHY CHOOSE US --- */}
          <section className="py-20 bg-blue-600 text-white rounded-3xl mx-4 md:mx-8 lg:mx-16 shadow-2xl overflow-hidden relative mb-20">
             <div className={`absolute top-0 ${dir === 'rtl' ? 'left-0' : 'right-0'} w-[600px] h-[600px] bg-blue-500 rounded-full blur-3xl opacity-30 -mr-32 -mt-32`}></div>
             <div className={`absolute bottom-0 ${dir === 'rtl' ? 'right-0' : 'left-0'} w-[500px] h-[500px] bg-indigo-600 rounded-full blur-3xl opacity-40 -ml-20 -mb-20`}></div>
             
             <div className="container mx-auto px-6 relative z-10 flex flex-col lg:flex-row items-center">
                <div className="lg:w-1/2 mb-12 lg:mb-0 lg:pr-12">
                   <h2 className="text-3xl md:text-5xl font-bold mb-6">Why Choose ChatVybz?</h2>
                   <p className="text-blue-100 mb-8 text-lg leading-relaxed">Join millions of users who trust ChatVybz for their daily communication needs.</p>
                   
                   <div className="space-y-4">
                      {[
              'No ads or tracking - Your privacy comes first',
              'Free forever - All features included',
              'Regular updates - New features every month',
              'Reliable support - 24/7 customer service']?.
              map((item, i) =>
              <div key={i} className="flex items-center space-x-4">
                            <div className="w-6 h-6 bg-blue-400 rounded-full flex items-center justify-center flex-shrink-0 shadow-sm">
                               <Check size={14} className="text-blue-900 stroke-[3px]" />
                            </div>
                            <span className="text-lg">{item}</span>
                         </div>
              )}
                   </div>
                </div>
                
                <div className="lg:w-1/2 w-full">
                   <div className="bg-white/10 backdrop-blur-lg rounded-3xl p-8 border border-white/20 shadow-2xl">
                      {[
              { label: 'Security Rating', val: 'A+', color: 'text-white' },
              { label: 'User Satisfaction', val: '98%', color: 'text-white' },
              { label: 'App Store Rating', val: '4.8', color: 'text-white', star: true }]?.
              map((stat, idx) =>
              <div key={idx} className={`flex justify-between items-center py-5 ${idx !== 2 ? 'border-b border-white/10' : ''}`}>
                           <span className="text-blue-200 font-medium">{stat?.label}</span>
                           <div className="flex items-center">
                              <span className={`text-3xl font-bold ${stat?.color} mr-2`}>{stat?.val}</span>
                              {stat?.star && <Star size={24} className="fill-yellow-400 text-yellow-400" />}
                           </div>
                        </div>
              )}
                   </div>
                </div>
             </div>
          </section>
          {/* --- MID STATS --- */}
          <section className="py-16 container mx-auto px-6 bg-white">
             <div className="grid grid-cols-2 md:grid-cols-4 gap-12 text-center">
                {[
          { val: '10M+', label: 'Active Users', color: 'text-blue-600' },
          { val: '5B+', label: 'Messages Sent Daily', color: 'text-blue-500' },
          { val: '150+', label: 'Countries', color: 'text-indigo-600' },
          { val: '99.9%', label: 'Uptime', color: 'text-purple-600' }]?.
          map((stat, i) =>
          <div key={i} className="space-y-2">
                     <p className={`text-4xl md:text-5xl font-bold ${stat?.color}`}>{stat?.val}</p>
                     <p className="text-gray-500 font-medium">{stat?.label}</p>
                  </div>
          )}
             </div>
          </section>
          {/* --- TESTIMONIALS --- */}
          <section className="py-20 bg-gray-50/50">
             <div className="container mx-auto px-6">
                <div className="text-center mb-16">
                   <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Trusted by Millions Worldwide</h2>
                   <p className="text-gray-600">See what our users have to say about their experience with ChatVybz</p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                   {[
            { name: 'Sarah Johnson', role: 'Small Business Owner', img: "https://img.rocket.new/generatedImages/rocket_gen_img_164a41da3-1767826088543.png", text: '"ChatVybz has transformed how my team communicates. The encryption gives us peace of mind when discussing sensitive client information."' },
            { name: 'Michael Chen', role: 'Software Developer', img: "https://img.rocket.new/generatedImages/rocket_gen_img_18591d91f-1767978242303.png", text: '"Lightning fast and incredibly reliable. The cross-platform sync works flawlessly. Best messaging app I\'ve used in my career."' },
            { name: 'Emily Rodriguez', role: 'Marketing Director', img: "https://img.rocket.new/generatedImages/rocket_gen_img_1163bdf74-1766575714215.png", text: '"The group chat features are perfect for our global team. File sharing is seamless, and the interface is incredibly intuitive."' }]?.
            map((user, i) =>
            <div key={i} className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100 hover:shadow-xl transition-all relative">
                         <div className="absolute top-8 right-8 text-blue-100">
                            <svg width="40" height="40" viewBox="0 0 24 24" fill="currentColor"><path d="M14.017 21L14.017 18C14.017 16.8954 14.9124 16 16.017 16H19.017C19.5693 16 20.017 15.5523 20.017 15V9C20.017 8.44772 19.5693 8 19.017 8H15.017C14.4647 8 14.017 8.44772 14.017 9V11C14.017 11.5523 13.5693 12 13.017 12H12.017V5H22.017V15C22.017 18.3137 19.3307 21 16.017 21H14.017ZM5.0166 21L5.0166 18C5.0166 16.8954 5.91203 16 7.0166 16H10.0166C10.5689 16 11.0166 15.5523 11.0166 15V9C11.0166 8.44772 10.5689 8 10.0166 8H6.0166C5.46432 8 5.0166 8.44772 5.0166 9V11C5.0166 11.5523 4.56889 12 4.0166 12H3.0166V5H13.0166V15C13.0166 18.3137 10.3303 21 7.0166 21H5.0166Z" /></svg>
                         </div>
                         <div className="flex items-center mb-6">
                            <img src={user?.img} alt={user?.name} className="w-14 h-14 rounded-full mr-4 border-2 border-white shadow-sm object-cover" />
                            <div>
                               <h4 className="font-bold text-gray-900 text-lg">{user?.name}</h4>
                               <p className="text-xs text-gray-500 uppercase tracking-wide font-semibold">{user?.role}</p>
                            </div>
                         </div>
                         <div className="flex text-yellow-400 mb-4 space-x-1">
                            {[...Array(5)]?.map((_, j) => <Star key={j} size={16} fill="currentColor" />)}
                         </div>
                         <p className="text-gray-600 leading-relaxed italic">{user?.text}</p>
                      </div>
            )}
                </div>
             </div>
          </section>
          {/* --- DOWNLOAD SECTION --- */}
          <section id="download" className="py-10 container mx-auto px-4 md:px-6">
              <div className="bg-gradient-to-r from-blue-600 to-indigo-700 rounded-3xl p-8 md:p-16 text-white shadow-2xl relative overflow-hidden">
                  {/* Bg patterns */}
                  <div className="absolute top-0 right-0 w-96 h-96 bg-white opacity-5 rounded-full blur-3xl -mr-20 -mt-20"></div>
                  
                  <div className="text-center mb-16 relative z-10">
                      <h2 className="text-3xl md:text-4xl font-bold mb-4">Get ChatVybz on All Your Devices</h2>
                      <p className="text-blue-100 max-w-2xl mx-auto">Download our app or use the web version instantly. Your messages sync seamlessly across all platforms.</p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12 relative z-10">
                      {/* Mobile & Desktop */}
                      <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8 border border-white/20">
                          <div className="flex items-center mb-6">
                              <Smartphone size={24} className="mr-3" />
                              <h3 className="text-xl font-bold">Mobile & Desktop Apps</h3>
                          </div>
                          
                          <div className="space-y-4">
                              <div className="flex items-center justify-between p-4 bg-white/10 rounded-xl hover:bg-white/20 transition-colors cursor-pointer group">
                                  <div className="flex items-center">
                                      <div className="w-10 h-10 rounded-full bg-red-500 flex items-center justify-center mr-4 shadow-md group-hover:scale-110 transition-transform">
                                          <span className="font-bold text-sm">iOS</span>
                                      </div>
                                      <div>
                                          <div className="font-bold">iOS</div>
                                          <div className="text-xs text-blue-200">iPhone & iPad</div>
                                          <div className="text-[10px] text-blue-300 opacity-70">iOS 13.0 or later • 85 MB</div>
                                      </div>
                                  </div>
                                  <button className="bg-white text-blue-600 px-4 py-1.5 rounded-full text-xs font-bold flex items-center">
                                      <Download size={12} className="mr-1" /> Download
                                  </button>
                              </div>

                              <div className="flex items-center justify-between p-4 bg-white/10 rounded-xl hover:bg-white/20 transition-colors cursor-pointer group">
                                  <div className="flex items-center">
                                      <div className="w-10 h-10 rounded-full bg-green-500 flex items-center justify-center mr-4 shadow-md group-hover:scale-110 transition-transform">
                                          <span className="font-bold text-xs">AND</span>
                                      </div>
                                      <div>
                                          <div className="font-bold">Android</div>
                                          <div className="text-xs text-blue-200">All Android devices</div>
                                          <div className="text-[10px] text-blue-300 opacity-70">Android 6.0 or later • 62 MB</div>
                                      </div>
                                  </div>
                                  <button className="bg-white text-blue-600 px-4 py-1.5 rounded-full text-xs font-bold flex items-center">
                                      <Download size={12} className="mr-1" /> Download
                                  </button>
                              </div>

                              <div className="flex items-center justify-between p-4 bg-white/10 rounded-xl hover:bg-white/20 transition-colors cursor-pointer group">
                                  <div className="flex items-center">
                                      <div className="w-10 h-10 rounded-full bg-blue-400 flex items-center justify-center mr-4 shadow-md group-hover:scale-110 transition-transform">
                                          <Monitor size={20} />
                                      </div>
                                      <div>
                                          <div className="font-bold">Windows</div>
                                          <div className="text-xs text-blue-200">Desktop PC</div>
                                          <div className="text-[10px] text-blue-300 opacity-70">Windows 10 or later • 120 MB</div>
                                      </div>
                                  </div>
                                  <button className="bg-white text-blue-600 px-4 py-1.5 rounded-full text-xs font-bold flex items-center">
                                      <Download size={12} className="mr-1" /> Download
                                  </button>
                              </div>

                              <div className="flex items-center justify-between p-4 bg-white/10 rounded-xl hover:bg-white/20 transition-colors cursor-pointer group">
                                  <div className="flex items-center">
                                      <div className="w-10 h-10 rounded-full bg-gray-200 text-black flex items-center justify-center mr-4 shadow-md group-hover:scale-110 transition-transform">
                                          <Laptop size={20} />
                                      </div>
                                      <div>
                                          <div className="font-bold">macOS</div>
                                          <div className="text-xs text-blue-200">Mac computers</div>
                                          <div className="text-[10px] text-blue-300 opacity-70">macOS 10.15 or later • 95 MB</div>
                                      </div>
                                  </div>
                                  <button className="bg-white text-blue-600 px-4 py-1.5 rounded-full text-xs font-bold flex items-center">
                                      <Download size={12} className="mr-1" /> Download
                                  </button>
                              </div>
                          </div>
                          
                          {/* QR Code Mini Section */}
                          <div className="mt-6 pt-6 border-t border-white/10 flex items-center">
                              <div className="bg-white p-2 rounded-lg mr-4">
                                  <QrCode size={40} className="text-black" />
                              </div>
                              <div>
                                  <div className="font-bold text-sm">Scan to Download</div>
                                  <div className="text-xs text-blue-200">Scan this QR code with your phone camera to download the mobile app instantly</div>
                              </div>
                          </div>
                      </div>

                      {/* Web Version */}
                      <div className="bg-white/10 backdrop-blur-md rounded-2xl p-8 border border-white/20 flex flex-col">
                          <div className="flex items-center mb-6">
                              <Globe size={24} className="mr-3" />
                              <h3 className="text-xl font-bold">Web Version</h3>
                          </div>
                          
                          <p className="text-blue-100 text-sm mb-8 flex-1">
                              No download required. Access ChatVybz directly from your browser with full functionality.
                          </p>

                          <ul className="space-y-4 mb-8">
                              {['Instant Access', 'Full Features', 'Auto Sync', 'Works Everywhere']?.map((item, i) =>
                <li key={i} className="flex items-start">
                                      <div className="mt-1 w-4 h-4 rounded-full border-2 border-white flex items-center justify-center mr-3 flex-shrink-0">
                                          <div className="w-2 h-2 bg-white rounded-full"></div>
                                      </div>
                                      <div>
                                          <span className="font-bold text-sm block">{item}</span>
                                          <span className="text-xs text-blue-200">
                                              {i === 0 && 'Start chatting immediately without installation'}
                                              {i === 1 && 'All messaging features available in your browser'}
                                              {i === 2 && 'Messages sync with your mobile app in real-time'}
                                              {i === 3 && 'Compatible with all modern browsers'}
                                          </span>
                                      </div>
                                  </li>
                )}
                          </ul>

                          <button
                onClick={handleStartApp}
                className="w-full bg-white text-blue-600 font-bold py-3 rounded-xl hover:bg-blue-50 transition-all shadow-lg mb-4">

                              Launch Web App
                          </button>
                          <button className="w-full bg-blue-800/50 text-white font-medium py-3 rounded-xl hover:bg-blue-800/70 transition-all border border-blue-400/30">
                              Sign In to Web Version
                          </button>
                          <p className="text-center text-[10px] text-blue-300 mt-4">Works on Chrome, Firefox, Safari, and Edge</p>
                      </div>
                  </div>
                  
                  <div className="text-center mt-10 text-xs text-blue-300">
                      Free on all platforms • No subscription required • Regular updates included
                  </div>
              </div>
          </section>
          {/* --- FAQ SECTION --- */}
          <section id="faq" className="py-20 container mx-auto px-4 md:px-6">
             <div className="text-center mb-16">
                <h2 className="text-3xl font-bold text-gray-900 mb-4">{t('landing_faq_title')}</h2>
                <p className="text-gray-600">{t('landing_faq_desc')}</p>
             </div>
             
             <div className="max-w-3xl mx-auto space-y-4">
                {faqList?.map((item, idx) =>
          <div key={idx} className="bg-gray-50 rounded-2xl overflow-hidden border border-gray-100">
                      <button
              onClick={() => toggleFaq(idx)}
              className="w-full flex justify-between items-center p-5 text-left font-medium text-gray-900 hover:bg-gray-100 transition-colors">

                         <span>{item?.q}</span>
                         {openFaq === idx ? <ChevronUp size={20} className="text-blue-600" /> : <ChevronDown size={20} className="text-gray-400" />}
                      </button>
                      {openFaq === idx &&
            <div className="p-5 pt-0 text-gray-600 text-sm leading-relaxed border-t border-gray-100 bg-white">
                            {item?.a}
                         </div>
            }
                   </div>
          )}
             </div>
             
             <div className="mt-16 bg-blue-50 rounded-2xl p-8 text-center max-w-3xl mx-auto">
                 <h3 className="text-xl font-bold text-gray-900 mb-2">Still Have Questions?</h3>
                 <p className="text-gray-600 mb-6 text-sm">Our support team is here to help 24/7</p>
                 <div className="flex justify-center space-x-4">
                     <button className="bg-blue-600 text-white px-6 py-2 rounded-lg text-sm font-bold shadow-lg hover:bg-blue-700">Contact Support</button>
                     <button className="bg-white text-blue-600 border border-blue-200 px-6 py-2 rounded-lg text-sm font-bold hover:bg-blue-50">View Help Center</button>
                 </div>
             </div>
          </section>
          {/* --- FOOTER --- */}
          <footer className="bg-[#0b141a] text-gray-400 py-16 text-sm">
             <div className="container mx-auto px-6">
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-8 mb-12">
                   <div className="col-span-2 md:col-span-1 lg:col-span-1">
                      <div className="flex items-center space-x-2 text-white mb-6">
                         {APP_LOGO ?
                <img src={APP_LOGO} alt="ChatVybz" className="w-8 h-8 object-contain" /> :

                <MessageSquare size={24} className="text-white" />
                }
                         <span className="text-xl font-bold">ChatVybz</span>
                      </div>
                      <p className="text-xs mb-6 leading-relaxed">
                          Secure, fast, and reliable messaging for everyone. Connect with friends, family, and colleagues worldwide.
                      </p>
                      <div className="space-y-3 text-xs">
                         <div className="flex items-center hover:text-white transition-colors cursor-pointer"><Mail size={14} className="mr-3 text-blue-500" /> support@chatvybz.com</div>
                         <div className="flex items-center hover:text-white transition-colors cursor-pointer"><Phone size={14} className="mr-3 text-blue-500" /> +1 (758) 718-7931</div>
                         <div className="flex items-center hover:text-white transition-colors cursor-pointer"><MapPin size={14} className="mr-3 text-blue-500" /> Castries, Saint Lucia</div>
                      </div>
                   </div>
                   
                   <div>
                      <h4 className="text-white font-bold mb-6">{t('footer_product')}</h4>
                      <ul className="space-y-3">
                         <li><button onClick={() => handleFooterLinkClick('features')} className="hover:text-blue-400 transition-colors text-left">Features</button></li>
                         <li><button onClick={() => handleFooterLinkClick('security')} className="hover:text-blue-400 transition-colors text-left">Security</button></li>
                         <li><button onClick={() => handleFooterLinkClick('downloads')} className="hover:text-blue-400 transition-colors text-left">Downloads</button></li>
                         <li><button onClick={() => handleFooterLinkClick('webapp')} className="hover:text-blue-400 transition-colors text-left">Web App</button></li>
                         <li><button onClick={() => handleFooterLinkClick('pricing')} className="hover:text-blue-400 transition-colors text-left">Pricing</button></li>
                      </ul>
                   </div>

                   <div>
                      <h4 className="text-white font-bold mb-6">{t('footer_company')}</h4>
                      <ul className="space-y-3">
                         <li><button onClick={() => handleFooterLinkClick('about')} className="hover:text-blue-400 transition-colors text-left">About Us</button></li>
                         <li><button onClick={() => handleFooterLinkClick('careers')} className="hover:text-blue-400 transition-colors text-left">Careers</button></li>
                         <li><button onClick={() => handleFooterLinkClick('press')} className="hover:text-blue-400 transition-colors text-left">Press Kit</button></li>
                         <li><button onClick={() => handleFooterLinkClick('blog')} className="hover:text-blue-400 transition-colors text-left">Blog</button></li>
                         <li><button onClick={() => handleFooterLinkClick('contact')} className="hover:text-blue-400 transition-colors text-left">Contact</button></li>
                      </ul>
                   </div>

                   <div>
                      <h4 className="text-white font-bold mb-6">{t('footer_support')}</h4>
                      <ul className="space-y-3">
                         <li>
                            <button
                    onClick={onOpenHelpCenter}
                    className="hover:text-blue-400 transition-colors text-left">

                              Help Center
                            </button>
                         </li>
                         <li><button onClick={() => handleFooterLinkClick('safety')} className="hover:text-blue-400 transition-colors text-left">Safety Center</button></li>
                         <li><button onClick={() => handleFooterLinkClick('community')} className="hover:text-blue-400 transition-colors text-left">Community</button></li>
                         <li><button onClick={() => handleFooterLinkClick('status')} className="hover:text-blue-400 transition-colors text-left">Status</button></li>
                         <li><button onClick={() => handleFooterLinkClick('feedback')} className="hover:text-blue-400 transition-colors text-left">Feedback</button></li>
                      </ul>
                   </div>
                   
                   <div>
                       <h4 className="text-white font-bold mb-6">{t('footer_legal')}</h4>
                       <ul className="space-y-3">
                           <li><button onClick={() => handleFooterLinkClick('privacy')} className="hover:text-blue-400 transition-colors text-left">Privacy Policy</button></li>
                           <li><button onClick={() => handleFooterLinkClick('terms')} className="hover:text-blue-400 transition-colors text-left">Terms of Service</button></li>
                           <li><button onClick={() => handleFooterLinkClick('cookie')} className="hover:text-blue-400 transition-colors text-left">Cookie Policy</button></li>
                           <li><button onClick={() => handleFooterLinkClick('gdpr')} className="hover:text-blue-400 transition-colors text-left">GDPR</button></li>
                           <li><button onClick={() => handleFooterLinkClick('compliance')} className="hover:text-blue-400 transition-colors text-left">Compliance</button></li>
                       </ul>
                   </div>
                </div>

                <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center">
                   <p className="text-xs mb-4 md:mb-0">© 2025 ItechCaribbean. All rights reserved. Built with security and privacy in mind.</p>
                   
                   <div className="flex items-center space-x-6">
                       <div className="flex space-x-4">
                          <a href="#" className="w-8 h-8 rounded-full bg-gray-800 flex items-center justify-center hover:bg-blue-600 hover:text-white transition-colors"><Facebook size={14} /></a>
                          <a href="#" className="w-8 h-8 rounded-full bg-gray-800 flex items-center justify-center hover:bg-blue-400 hover:text-white transition-colors"><Twitter size={14} /></a>
                          <a href="#" className="w-8 h-8 rounded-full bg-gray-800 flex items-center justify-center hover:bg-pink-600 hover:text-white transition-colors"><Instagram size={14} /></a>
                          <a href="#" className="w-8 h-8 rounded-full bg-gray-800 flex items-center justify-center hover:bg-blue-700 hover:text-white transition-colors"><Linkedin size={14} /></a>
                          <a href="#" className="w-8 h-8 rounded-full bg-gray-800 flex items-center justify-center hover:bg-red-600 hover:text-white transition-colors"><Youtube size={14} /></a>
                       </div>
                   </div>
                </div>
                
                <div className="mt-8 flex justify-center space-x-4">
                    <button className="bg-gray-800 hover:bg-gray-700 text-white px-4 py-2 rounded-lg flex items-center space-x-2 transition-colors border border-gray-700">
                        <img src="https://images.unsplash.com/photo-1601999532525-d4d616b5f104" className="w-4 h-4" alt="Apple" />
                        <div className="text-left">
                            <div className="text-[8px] uppercase">Download on the</div>
                            <div className="text-xs font-bold leading-none">App Store</div>
                        </div>
                    </button>
                    <button className="bg-gray-800 hover:bg-gray-700 text-white px-4 py-2 rounded-lg flex items-center space-x-2 transition-colors border border-gray-700">
                        <img src="https://images.unsplash.com/photo-1537718506398-b08533ca18e0" className="w-4 h-4" alt="Android" />
                        <div className="text-left">
                            <div className="text-[8px] uppercase">Get it on</div>
                            <div className="text-xs font-bold leading-none">Google Play</div>
                        </div>
                    </button>
                </div>
             </div>
          </footer>
      </div>);


};

export default LandingPage;