import React, { useEffect } from 'react';

const FooterPages = () => {
  React.useEffect(() => {
    // eslint-disable-next-line no-console
    console.warn('Placeholder: FooterPages is not implemented yet.');
  }, []);
  return (
    <>
  { /*FooterPages */} 
 </>
  );
};

export default FooterPages;

const FooterPageKey = () => {
  React.useEffect(() => {
    // eslint-disable-next-line no-console
    console.warn('Placeholder: FooterPageKey is not implemented yet.');
  }, []);
  return (
    <div>
      {/* FooterPageKey placeholder */}
    </div>
  );
};

export { FooterPageKey };