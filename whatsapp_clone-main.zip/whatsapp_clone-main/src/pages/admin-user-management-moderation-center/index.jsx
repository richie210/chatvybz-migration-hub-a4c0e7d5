import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { Users, Shield, Search, Filter, AlertTriangle, Ban, Clock, CheckCircle, XCircle, Eye, FileText, Loader2, AlertCircle, Calendar, MapPin, Download } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { adminAnalyticsService } from '../../services/adminAnalyticsService';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';

export default function AdminUserManagementModerationCenter() {
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();

  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [users, setUsers] = useState([]);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalUsers, setTotalUsers] = useState(0);
  const [error, setError] = useState('');
  
  // Search and filter state
  const [searchQuery, setSearchQuery] = useState('');
  const [filterCountry, setFilterCountry] = useState('');
  const [filterStatus, setFilterStatus] = useState('all'); // all, active, banned, suspended
  const [filterDateFrom, setFilterDateFrom] = useState('');
  const [filterDateTo, setFilterDateTo] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  
  // Selected users for bulk operations
  const [selectedUsers, setSelectedUsers] = useState(new Set());
  
  // Moderation modal state
  const [showModerationModal, setShowModerationModal] = useState(false);
  const [moderationAction, setModerationAction] = useState(null);
  const [moderationTarget, setModerationTarget] = useState(null);
  const [moderationReason, setModerationReason] = useState('');
  const [suspensionDays, setSuspensionDays] = useState(7);
  
  // User detail modal
  const [showUserDetail, setShowUserDetail] = useState(false);
  const [selectedUserDetail, setSelectedUserDetail] = useState(null);
  const [userAuditLog, setUserAuditLog] = useState([]);

  useEffect(() => {
    if (!authLoading && !user) {
      navigate('/login');
    }
  }, [user, authLoading, navigate]);

  useEffect(() => {
    if (!authLoading && user) {
      checkAdminAndLoadData();
    }
  }, [authLoading, user, page, filterStatus]);

  const checkAdminAndLoadData = async () => {
    try {
      setLoading(true);
      setError('');

      const adminStatus = await adminAnalyticsService?.isAdmin();
      setIsAdmin(adminStatus);

      if (!adminStatus) {
        setError('Access denied. Admin privileges required.');
        setLoading(false);
        return;
      }

      await loadUsers();
    } catch (err) {
      console.error('Error checking admin status:', err);
      setError(err?.message || 'Failed to load data');
    } finally {
      setLoading(false);
    }
  };

  const loadUsers = async () => {
    try {
      let result = await adminAnalyticsService?.getUsers({
        page,
        limit: 20,
        search: searchQuery,
        country: filterCountry
      });

      if (result?.error) throw result?.error;

      setUsers(result?.data || []);
      setTotalPages(result?.totalPages || 1);
      setTotalUsers(result?.count || 0);
    } catch (err) {
      console.error('Error loading users:', err);
      setError(err?.message || 'Failed to load users');
    }
  };

  const handleSearch = async () => {
    setPage(1);
    await loadUsers();
  };

  const handleBulkSelect = (userId) => {
    const newSelected = new Set(selectedUsers);
    if (newSelected?.has(userId)) {
      newSelected?.delete(userId);
    } else {
      newSelected?.add(userId);
    }
    setSelectedUsers(newSelected);
  };

  const handleSelectAll = () => {
    if (selectedUsers?.size === users?.length) {
      setSelectedUsers(new Set());
    } else {
      setSelectedUsers(new Set(users?.map(u => u?.id)));
    }
  };

  const openModerationModal = (action, userId) => {
    setModerationAction(action);
    setModerationTarget(userId);
    setModerationReason('');
    setSuspensionDays(7);
    setShowModerationModal(true);
  };

  const executeModerationAction = async () => {
    if (!moderationReason?.trim()) {
      alert('Please provide a reason for this action');
      return;
    }

    try {
      let result;
      
      if (moderationAction === 'ban') {
        result = await adminAnalyticsService?.banUser(moderationTarget, moderationReason);
      } else if (moderationAction === 'suspend') {
        result = await adminAnalyticsService?.suspendUser(moderationTarget, moderationReason, suspensionDays);
      } else if (moderationAction === 'restore') {
        result = await adminAnalyticsService?.restoreUser(moderationTarget, moderationReason);
      }

      if (result?.error) throw result?.error;

      alert(`User ${moderationAction} action completed successfully`);
      setShowModerationModal(false);
      await loadUsers();
    } catch (err) {
      alert(err?.message || `Failed to ${moderationAction} user`);
    }
  };

  const viewUserDetail = async (userData) => {
    setSelectedUserDetail(userData);
    setShowUserDetail(true);
    // In a real implementation, load audit log from database
    setUserAuditLog([]);
  };

  const exportUserData = () => {
    const csv = [
      ['Email', 'Name', 'Country', 'Joined', 'Status']?.join(','),
      ...users?.map(u => [
        u?.email,
        u?.full_name || 'N/A',
        u?.country_code || 'N/A',
        new Date(u?.created_at)?.toLocaleDateString(),
        'Active'
      ]?.join(','))
    ]?.join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL?.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `users-export-${new Date()?.toISOString()}.csv`;
    a?.click();
  };

  if (authLoading || loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-50">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-50">
        <div className="text-center">
          <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Access Denied</h2>
          <p className="text-gray-600 mb-4">Admin privileges required to access this page.</p>
          <Button onClick={() => navigate('/chat')}>Return to Chat</Button>
        </div>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>User Management & Moderation - ChatVybz Admin</title>
        <meta name="description" content="Comprehensive user oversight and moderation tools for platform administrators" />
      </Helmet>
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <div className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Shield className="w-8 h-8" />
                <div>
                  <h1 className="text-2xl font-bold">User Management & Moderation Center</h1>
                  <p className="text-indigo-100 text-sm">Comprehensive user oversight and account management</p>
                </div>
              </div>
              <div className="flex gap-3">
                <Button
                  variant="outline"
                  className="bg-white text-indigo-600 hover:bg-indigo-50"
                  onClick={() => navigate('/chat-vybz-admin-dashboard')}
                >
                  Dashboard
                </Button>
                <Button
                  variant="outline"
                  className="bg-white text-indigo-600 hover:bg-indigo-50"
                  onClick={exportUserData}
                >
                  <Download className="w-4 h-4 mr-2" />
                  Export
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Stats Bar */}
        <div className="bg-white border-b border-gray-200">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="flex items-center gap-3">
                <Users className="w-5 h-5 text-blue-600" />
                <div>
                  <p className="text-sm text-gray-600">Total Users</p>
                  <p className="text-lg font-semibold text-gray-900">{totalUsers?.toLocaleString()}</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <CheckCircle className="w-5 h-5 text-green-600" />
                <div>
                  <p className="text-sm text-gray-600">Active</p>
                  <p className="text-lg font-semibold text-gray-900">{users?.length}</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Ban className="w-5 h-5 text-red-600" />
                <div>
                  <p className="text-sm text-gray-600">Banned</p>
                  <p className="text-lg font-semibold text-gray-900">0</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <Clock className="w-5 h-5 text-orange-600" />
                <div>
                  <p className="text-sm text-gray-600">Suspended</p>
                  <p className="text-lg font-semibold text-gray-900">0</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Search and Filters */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-4">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <Input
                    type="text"
                    placeholder="Search by email or name..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e?.target?.value)}
                    onKeyPress={(e) => e?.key === 'Enter' && handleSearch()}
                    className="pl-10"
                  />
                </div>
              </div>
              <Button onClick={handleSearch}>
                <Search className="w-4 h-4 mr-2" />
                Search
              </Button>
              <Button
                variant="outline"
                onClick={() => setShowFilters(!showFilters)}
              >
                <Filter className="w-4 h-4 mr-2" />
                Filters
              </Button>
            </div>

            {showFilters && (
              <div className="mt-4 pt-4 border-t border-gray-200 grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Country</label>
                  <Input
                    type="text"
                    placeholder="Country code"
                    value={filterCountry}
                    onChange={(e) => setFilterCountry(e?.target?.value)}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
                  <select
                    value={filterStatus}
                    onChange={(e) => setFilterStatus(e?.target?.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                  >
                    <option value="all">All Users</option>
                    <option value="active">Active</option>
                    <option value="banned">Banned</option>
                    <option value="suspended">Suspended</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Joined From</label>
                  <Input
                    type="date"
                    value={filterDateFrom}
                    onChange={(e) => setFilterDateFrom(e?.target?.value)}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Joined To</label>
                  <Input
                    type="date"
                    value={filterDateTo}
                    onChange={(e) => setFilterDateTo(e?.target?.value)}
                  />
                </div>
              </div>
            )}
          </div>

          {error && (
            <div className="mt-4 bg-red-50 border border-red-200 rounded-lg p-4">
              <p className="text-red-800">{error}</p>
            </div>
          )}

          {/* Bulk Actions */}
          {selectedUsers?.size > 0 && (
            <div className="mt-4 bg-blue-50 border border-blue-200 rounded-lg p-4">
              <div className="flex items-center justify-between">
                <p className="text-blue-900 font-medium">
                  {selectedUsers?.size} user{selectedUsers?.size > 1 ? 's' : ''} selected
                </p>
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setSelectedUsers(new Set())}
                  >
                    Clear Selection
                  </Button>
                </div>
              </div>
            </div>
          )}

          {/* Users Table */}
          <div className="mt-6 bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left">
                      <input
                        type="checkbox"
                        checked={selectedUsers?.size === users?.length && users?.length > 0}
                        onChange={handleSelectAll}
                        className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                      />
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      User
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Location
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Joined
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Status
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Actions
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {users?.length === 0 ? (
                    <tr>
                      <td colSpan="6" className="px-6 py-12 text-center text-gray-500">
                        <Users className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                        <p>No users found</p>
                      </td>
                    </tr>
                  ) : (
                    users?.map((userData) => (
                      <tr key={userData?.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4">
                          <input
                            type="checkbox"
                            checked={selectedUsers?.has(userData?.id)}
                            onChange={() => handleBulkSelect(userData?.id)}
                            className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                          />
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex items-center">
                            <div className="flex-shrink-0 h-10 w-10">
                              {userData?.avatar_url ? (
                                <img
                                  src={userData?.avatar_url}
                                  alt={userData?.full_name || 'User'}
                                  className="h-10 w-10 rounded-full object-cover"
                                />
                              ) : (
                                <div className="h-10 w-10 rounded-full bg-indigo-100 flex items-center justify-center">
                                  <Users className="w-5 h-5 text-indigo-600" />
                                </div>
                              )}
                            </div>
                            <div className="ml-4">
                              <div className="text-sm font-medium text-gray-900">
                                {userData?.full_name || 'No name'}
                              </div>
                              <div className="text-sm text-gray-500">{userData?.email}</div>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex items-center text-sm text-gray-900">
                            <MapPin className="w-4 h-4 mr-1 text-gray-400" />
                            {userData?.country_code || 'Unknown'}
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex items-center text-sm text-gray-900">
                            <Calendar className="w-4 h-4 mr-1 text-gray-400" />
                            {new Date(userData?.created_at)?.toLocaleDateString()}
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                            Active
                          </span>
                        </td>
                        <td className="px-6 py-4 text-sm font-medium">
                          <div className="flex items-center gap-2">
                            <button
                              onClick={() => viewUserDetail(userData)}
                              className="text-indigo-600 hover:text-indigo-900"
                              title="View Details"
                            >
                              <Eye className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => openModerationModal('suspend', userData?.id)}
                              className="text-orange-600 hover:text-orange-900"
                              title="Suspend User"
                            >
                              <Clock className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => openModerationModal('ban', userData?.id)}
                              className="text-red-600 hover:text-red-900"
                              title="Ban User"
                            >
                              <Ban className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="bg-gray-50 px-6 py-4 flex items-center justify-between border-t border-gray-200">
                <div className="text-sm text-gray-700">
                  Page {page} of {totalPages}
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setPage(p => Math.max(1, p - 1))}
                    disabled={page === 1}
                  >
                    Previous
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setPage(p => Math.min(totalPages, p + 1))}
                    disabled={page === totalPages}
                  >
                    Next
                  </Button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
      {/* Moderation Modal */}
      {showModerationModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg max-w-md w-full p-6">
            <div className="flex items-center gap-3 mb-4">
              <AlertTriangle className="w-6 h-6 text-orange-600" />
              <h3 className="text-lg font-semibold text-gray-900">
                {moderationAction === 'ban' ? 'Ban User' : moderationAction === 'suspend' ? 'Suspend User' : 'Restore User'}
              </h3>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Reason *
                </label>
                <textarea
                  value={moderationReason}
                  onChange={(e) => setModerationReason(e?.target?.value)}
                  placeholder="Provide a detailed reason for this action..."
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                  rows="4"
                />
              </div>

              {moderationAction === 'suspend' && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Suspension Duration (days)
                  </label>
                  <Input
                    type="number"
                    value={suspensionDays}
                    onChange={(e) => setSuspensionDays(parseInt(e?.target?.value) || 7)}
                    min="1"
                    max="365"
                  />
                </div>
              )}

              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
                <p className="text-sm text-yellow-800">
                  <strong>Warning:</strong> This action will be logged in the audit trail and cannot be undone without proper authorization.
                </p>
              </div>
            </div>

            <div className="flex gap-3 mt-6">
              <Button
                variant="outline"
                onClick={() => setShowModerationModal(false)}
                className="flex-1"
              >
                Cancel
              </Button>
              <Button
                onClick={executeModerationAction}
                className="flex-1 bg-red-600 hover:bg-red-700"
              >
                Confirm {moderationAction}
              </Button>
            </div>
          </div>
        </div>
      )}
      {/* User Detail Modal */}
      {showUserDetail && selectedUserDetail && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-900">User Details</h3>
                <button
                  onClick={() => setShowUserDetail(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  <XCircle className="w-6 h-6" />
                </button>
              </div>
            </div>

            <div className="p-6 space-y-6">
              {/* User Info */}
              <div className="flex items-center gap-4">
                {selectedUserDetail?.avatar_url ? (
                  <img
                    src={selectedUserDetail?.avatar_url}
                    alt={selectedUserDetail?.full_name || 'User'}
                    className="h-16 w-16 rounded-full object-cover"
                  />
                ) : (
                  <div className="h-16 w-16 rounded-full bg-indigo-100 flex items-center justify-center">
                    <Users className="w-8 h-8 text-indigo-600" />
                  </div>
                )}
                <div>
                  <h4 className="text-xl font-semibold text-gray-900">
                    {selectedUserDetail?.full_name || 'No name'}
                  </h4>
                  <p className="text-gray-600">{selectedUserDetail?.email}</p>
                </div>
              </div>

              {/* Account Metadata */}
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-gray-50 rounded-lg p-4">
                  <p className="text-sm text-gray-600 mb-1">User ID</p>
                  <p className="text-sm font-mono text-gray-900 truncate">{selectedUserDetail?.id}</p>
                </div>
                <div className="bg-gray-50 rounded-lg p-4">
                  <p className="text-sm text-gray-600 mb-1">Country</p>
                  <p className="text-sm font-semibold text-gray-900">{selectedUserDetail?.country_code || 'Unknown'}</p>
                </div>
                <div className="bg-gray-50 rounded-lg p-4">
                  <p className="text-sm text-gray-600 mb-1">Joined</p>
                  <p className="text-sm font-semibold text-gray-900">
                    {new Date(selectedUserDetail?.created_at)?.toLocaleDateString()}
                  </p>
                </div>
                <div className="bg-gray-50 rounded-lg p-4">
                  <p className="text-sm text-gray-600 mb-1">Status</p>
                  <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                    Active
                  </span>
                </div>
              </div>

              {/* Audit Log */}
              <div>
                <h5 className="text-sm font-semibold text-gray-900 mb-3 flex items-center gap-2">
                  <FileText className="w-4 h-4" />
                  Moderation History
                </h5>
                {userAuditLog?.length === 0 ? (
                  <div className="bg-gray-50 rounded-lg p-4 text-center text-gray-500">
                    <p className="text-sm">No moderation actions recorded</p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    {userAuditLog?.map((log, index) => (
                      <div key={index} className="bg-gray-50 rounded-lg p-3">
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-sm font-medium text-gray-900">{log?.action}</span>
                          <span className="text-xs text-gray-500">{log?.timestamp}</span>
                        </div>
                        <p className="text-sm text-gray-600">{log?.reason}</p>
                        <p className="text-xs text-gray-500 mt-1">By: {log?.admin}</p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}