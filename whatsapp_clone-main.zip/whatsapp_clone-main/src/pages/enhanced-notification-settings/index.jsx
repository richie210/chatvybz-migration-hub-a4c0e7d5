import React, { useState, useEffect } from 'react';
import { Bell, Volume2, MessageSquare, Users, AtSign, Shield, ChevronRight, Check } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { enhancedNotificationService } from '../../services/enhancedNotificationService';
import { useAuth } from '../../contexts/AuthContext';

export default function EnhancedNotificationSettings() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [preferences, setPreferences] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }

    loadPreferences();

    // Subscribe to preference changes
    const unsubscribe = enhancedNotificationService?.subscribeToPreferenceChanges(
      user?.id,
      (updatedPreferences) => {
        setPreferences(updatedPreferences);
      }
    );

    return () => {
      unsubscribe();
    };
  }, [user, navigate]);

  const loadPreferences = async () => {
    try {
      setLoading(true);
      const prefs = await enhancedNotificationService?.getNotificationPreferences(user?.id);
      setPreferences(prefs);
    } catch (err) {
      setError(err?.message);
    } finally {
      setLoading(false);
    }
  };

  const handleToggle = async (key) => {
    if (!preferences) return;

    try {
      setSaving(true);
      setError('');
      
      const updatedPreferences = await enhancedNotificationService?.updateNotificationPreferences(
        user?.id,
        {
          [key]: !preferences?.[key],
        }
      );
      
      setPreferences(updatedPreferences);
      setSuccessMessage('Settings updated successfully');
      setTimeout(() => setSuccessMessage(''), 3000);
    } catch (err) {
      setError(err?.message);
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-slate-600">Loading notification settings...</p>
        </div>
      </div>
    );
  }

  if (error && !preferences) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
        <div className="max-w-md w-full bg-white rounded-lg shadow-lg p-6">
          <div className="text-center">
            <div className="bg-red-100 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
              <Bell className="w-8 h-8 text-red-600" />
            </div>
            <h2 className="text-xl font-semibold text-slate-900 mb-2">
              Failed to Load Settings
            </h2>
            <p className="text-slate-600 mb-6">{error}</p>
            <button
              onClick={loadPreferences}
              className="px-6 py-3 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors"
            >
              Try Again
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <div className="bg-white border-b border-slate-200">
        <div className="max-w-4xl mx-auto px-6 py-4">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate(-1)}
              className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
            >
              <ChevronRight className="w-6 h-6 text-slate-600 rotate-180" />
            </button>
            <div>
              <h1 className="text-2xl font-bold text-slate-900">
                Notification Settings
              </h1>
              <p className="text-sm text-slate-600">
                Manage your notification preferences
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-6 py-8">
        {/* Success Message */}
        {successMessage && (
          <div className="mb-6 bg-green-50 border border-green-200 rounded-lg p-4 flex items-center gap-3">
            <div className="bg-green-500 rounded-full p-1">
              <Check className="w-4 h-4 text-white" />
            </div>
            <p className="text-green-800 font-medium">{successMessage}</p>
          </div>
        )}

        {/* Error Message */}
        {error && (
          <div className="mb-6 bg-red-50 border border-red-200 rounded-lg p-4">
            <p className="text-red-800">{error}</p>
          </div>
        )}

        {/* Call Alerts Section */}
        <div className="bg-white rounded-lg shadow-sm border border-slate-200 mb-6">
          <div className="p-6 border-b border-slate-200">
            <div className="flex items-center gap-3 mb-2">
              <div className="bg-blue-100 rounded-lg p-2">
                <Volume2 className="w-5 h-5 text-blue-600" />
              </div>
              <h2 className="text-lg font-semibold text-slate-900">
                Call Alerts
              </h2>
            </div>
            <p className="text-sm text-slate-600">
              Configure ringtone, vibration patterns, and caller ID display
            </p>
          </div>
          <div className="p-6">
            <label className="flex items-center justify-between cursor-pointer group">
              <div className="flex-1">
                <p className="font-medium text-slate-900 group-hover:text-blue-600 transition-colors">
                  Enable Call Notifications
                </p>
                <p className="text-sm text-slate-600">
                  Receive alerts for incoming calls
                </p>
              </div>
              <button
                onClick={() => handleToggle('callNotifications')}
                disabled={saving}
                className={`relative w-14 h-8 rounded-full transition-colors duration-300 ${
                  preferences?.callNotifications ? 'bg-blue-600' : 'bg-slate-300'
                } disabled:opacity-50`}
              >
                <span
                  className={`absolute top-1 left-1 w-6 h-6 bg-white rounded-full shadow-md transition-transform duration-300 ${
                    preferences?.callNotifications ? 'translate-x-6' : ''
                  }`}
                />
              </button>
            </label>
          </div>
        </div>

        {/* Message Notifications Section */}
        <div className="bg-white rounded-lg shadow-sm border border-slate-200 mb-6">
          <div className="p-6 border-b border-slate-200">
            <div className="flex items-center gap-3 mb-2">
              <div className="bg-green-100 rounded-lg p-2">
                <MessageSquare className="w-5 h-5 text-green-600" />
              </div>
              <h2 className="text-lg font-semibold text-slate-900">
                Message Notifications
              </h2>
            </div>
            <p className="text-sm text-slate-600">
              Per-chat customization, priority senders, and quiet hours
            </p>
          </div>
          <div className="p-6 space-y-6">
            <label className="flex items-center justify-between cursor-pointer group">
              <div className="flex-1">
                <p className="font-medium text-slate-900 group-hover:text-blue-600 transition-colors">
                  Message Notifications
                </p>
                <p className="text-sm text-slate-600">
                  Get notified for new messages
                </p>
              </div>
              <button
                onClick={() => handleToggle('messageNotifications')}
                disabled={saving}
                className={`relative w-14 h-8 rounded-full transition-colors duration-300 ${
                  preferences?.messageNotifications ? 'bg-blue-600' : 'bg-slate-300'
                } disabled:opacity-50`}
              >
                <span
                  className={`absolute top-1 left-1 w-6 h-6 bg-white rounded-full shadow-md transition-transform duration-300 ${
                    preferences?.messageNotifications ? 'translate-x-6' : ''
                  }`}
                />
              </button>
            </label>

            <label className="flex items-center justify-between cursor-pointer group">
              <div className="flex-1">
                <p className="font-medium text-slate-900 group-hover:text-blue-600 transition-colors">
                  Reply Notifications
                </p>
                <p className="text-sm text-slate-600">
                  Get notified when someone replies to your message
                </p>
              </div>
              <button
                onClick={() => handleToggle('replyNotifications')}
                disabled={saving}
                className={`relative w-14 h-8 rounded-full transition-colors duration-300 ${
                  preferences?.replyNotifications ? 'bg-blue-600' : 'bg-slate-300'
                } disabled:opacity-50`}
              >
                <span
                  className={`absolute top-1 left-1 w-6 h-6 bg-white rounded-full shadow-md transition-transform duration-300 ${
                    preferences?.replyNotifications ? 'translate-x-6' : ''
                  }`}
                />
              </button>
            </label>
          </div>
        </div>

        {/* Mention Alerts Section */}
        <div className="bg-white rounded-lg shadow-sm border border-slate-200 mb-6">
          <div className="p-6 border-b border-slate-200">
            <div className="flex items-center gap-3 mb-2">
              <div className="bg-purple-100 rounded-lg p-2">
                <AtSign className="w-5 h-5 text-purple-600" />
              </div>
              <h2 className="text-lg font-semibold text-slate-900">
                Mention Alerts
              </h2>
            </div>
            <p className="text-sm text-slate-600">
              Sound customization and mention-only notification modes
            </p>
          </div>
          <div className="p-6">
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <p className="text-sm text-blue-800">
                <strong>Note:</strong> Mention alerts are handled through the message notification system.
                When someone mentions you with @username, you'll receive a notification based on your message notification preferences.
              </p>
            </div>
          </div>
        </div>

        {/* Group Message Preferences Section */}
        <div className="bg-white rounded-lg shadow-sm border border-slate-200 mb-6">
          <div className="p-6 border-b border-slate-200">
            <div className="flex items-center gap-3 mb-2">
              <div className="bg-orange-100 rounded-lg p-2">
                <Users className="w-5 h-5 text-orange-600" />
              </div>
              <h2 className="text-lg font-semibold text-slate-900">
                Group Message Preferences
              </h2>
            </div>
            <p className="text-sm text-slate-600">
              Bulk management, admin-only alerts, and keyword filtering
            </p>
          </div>
          <div className="p-6">
            <label className="flex items-center justify-between cursor-pointer group">
              <div className="flex-1">
                <p className="font-medium text-slate-900 group-hover:text-blue-600 transition-colors">
                  Group Notifications
                </p>
                <p className="text-sm text-slate-600">
                  Receive notifications from group chats
                </p>
              </div>
              <button
                onClick={() => handleToggle('groupNotifications')}
                disabled={saving}
                className={`relative w-14 h-8 rounded-full transition-colors duration-300 ${
                  preferences?.groupNotifications ? 'bg-blue-600' : 'bg-slate-300'
                } disabled:opacity-50`}
              >
                <span
                  className={`absolute top-1 left-1 w-6 h-6 bg-white rounded-full shadow-md transition-transform duration-300 ${
                    preferences?.groupNotifications ? 'translate-x-6' : ''
                  }`}
                />
              </button>
            </label>
          </div>
        </div>

        {/* Device Permission Management Section */}
        <div className="bg-white rounded-lg shadow-sm border border-slate-200">
          <div className="p-6 border-b border-slate-200">
            <div className="flex items-center gap-3 mb-2">
              <div className="bg-slate-100 rounded-lg p-2">
                <Shield className="w-5 h-5 text-slate-600" />
              </div>
              <h2 className="text-lg font-semibold text-slate-900">
                Device Permission Management
              </h2>
            </div>
            <p className="text-sm text-slate-600">
              Current authorization status for camera, microphone, contacts, and storage
            </p>
          </div>
          <div className="p-6">
            <div className="bg-slate-50 border border-slate-200 rounded-lg p-4">
              <p className="text-sm text-slate-700 mb-4">
                Permissions are managed through your browser settings. Click below to open system settings
                and grant necessary permissions for the app to function properly.
              </p>
              <button
                onClick={() => {
                  // This would typically open browser permission settings
                  alert('Please check your browser settings to manage permissions for this site.');
                }}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition-colors"
              >
                Manage Permissions
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}