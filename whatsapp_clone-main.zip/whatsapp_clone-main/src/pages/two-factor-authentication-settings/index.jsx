import React, { useState, useEffect } from 'react';
import { Shield, Smartphone, Key, Download, Trash2, AlertTriangle, CheckCircle, Clock, MapPin } from 'lucide-react';
import twoFactorAuthService from '../../services/twoFactorAuthService';

export default function TwoFactorAuthenticationSettings() {
  const [activeTab, setActiveTab] = useState('overview');
  const [totpStatus, setTotpStatus] = useState(null);
  const [backupCodesStatus, setBackupCodesStatus] = useState(null);
  const [trustedDevices, setTrustedDevices] = useState([]);
  const [auditLog, setAuditLog] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // TOTP Setup State
  const [totpSetup, setTotpSetup] = useState(null);
  const [verificationCode, setVerificationCode] = useState('');
  const [showSetupModal, setShowSetupModal] = useState(false);

  // Backup Codes State
  const [generatedCodes, setGeneratedCodes] = useState(null);
  const [showCodesModal, setShowCodesModal] = useState(false);

  useEffect(() => {
    loadInitialData();
  }, []);

  const loadInitialData = async () => {
    setLoading(true);
    try {
      const [totp, backup, devices, audit] = await Promise.all([
        twoFactorAuthService?.getTOTPStatus(),
        twoFactorAuthService?.getBackupCodesStatus(),
        twoFactorAuthService?.getTrustedDevices(),
        twoFactorAuthService?.getAuditLog()
      ]);

      setTotpStatus(totp);
      setBackupCodesStatus(backup);
      setTrustedDevices(devices);
      setAuditLog(audit);
    } catch (err) {
      setError('Failed to load 2FA settings: ' + err?.message);
    } finally {
      setLoading(false);
    }
  };

  // TOTP Functions
  const handleSetupTOTP = async () => {
    setLoading(true);
    setError('');
    try {
      const setup = await twoFactorAuthService?.setupTOTP();
      setTotpSetup(setup);
      setShowSetupModal(true);
    } catch (err) {
      setError('Failed to setup TOTP: ' + err?.message);
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyTOTP = async () => {
    if (verificationCode?.length !== 6) {
      setError('Please enter a 6-digit code');
      return;
    }

    setLoading(true);
    setError('');
    try {
      await twoFactorAuthService?.verifyTOTP(verificationCode);
      setSuccess('TOTP successfully enabled!');
      setShowSetupModal(false);
      setVerificationCode('');
      await loadInitialData();
    } catch (err) {
      setError('Verification failed: ' + err?.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDisableTOTP = async () => {
    if (!window.confirm('Are you sure you want to disable 2FA? This will reduce your account security.')) {
      return;
    }

    setLoading(true);
    setError('');
    try {
      await twoFactorAuthService?.disableTOTP();
      setSuccess('TOTP disabled successfully');
      await loadInitialData();
    } catch (err) {
      setError('Failed to disable TOTP: ' + err?.message);
    } finally {
      setLoading(false);
    }
  };

  // Backup Codes Functions
  const handleGenerateBackupCodes = async () => {
    setLoading(true);
    setError('');
    try {
      const codes = await twoFactorAuthService?.generateBackupCodes();
      setGeneratedCodes(codes);
      setShowCodesModal(true);
      await loadInitialData();
    } catch (err) {
      setError('Failed to generate backup codes: ' + err?.message);
    } finally {
      setLoading(false);
    }
  };

  const handleDownloadCodes = () => {
    const codesText = generatedCodes?.join('\n');
    const blob = new Blob([codesText], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'backup-codes.txt';
    a?.click();
    URL.revokeObjectURL(url);
  };

  // Device Management Functions
  const handleRevokeDevice = async (deviceId) => {
    if (!window.confirm('Are you sure you want to revoke this device?')) {
      return;
    }

    setLoading(true);
    setError('');
    try {
      await twoFactorAuthService?.revokeTrustedDevice(deviceId);
      setSuccess('Device revoked successfully');
      await loadInitialData();
    } catch (err) {
      setError('Failed to revoke device: ' + err?.message);
    } finally {
      setLoading(false);
    }
  };

  if (loading && !totpStatus) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading 2FA settings...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <div className="flex items-center space-x-3 mb-4">
            <Shield className="w-8 h-8 text-green-600" />
            <h1 className="text-2xl font-bold text-gray-900">Two-Factor Authentication</h1>
          </div>
          <p className="text-gray-600">
            Add an extra layer of security to your account by enabling two-factor authentication.
          </p>
        </div>

        {/* Status Messages */}
        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6 flex items-start space-x-3">
            <AlertTriangle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-semibold text-red-800">Error</p>
              <p className="text-sm text-red-700">{error}</p>
            </div>
          </div>
        )}

        {success && (
          <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6 flex items-start space-x-3">
            <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-semibold text-green-800">Success</p>
              <p className="text-sm text-green-700">{success}</p>
            </div>
          </div>
        )}

        {/* Tabs */}
        <div className="bg-white rounded-lg shadow-md mb-6">
          <div className="border-b border-gray-200">
            <nav className="flex space-x-8 px-6" aria-label="Tabs">
              {['overview', 'authenticator', 'backup-codes', 'devices', 'activity']?.map((tab) => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`py-4 px-1 border-b-2 font-medium text-sm capitalize ${
                    activeTab === tab
                      ? 'border-green-600 text-green-600' :'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  {tab?.replace('-', ' ')}
                </button>
              ))}
            </nav>
          </div>

          <div className="p-6">
            {/* Overview Tab */}
            {activeTab === 'overview' && (
              <div className="space-y-6">
                <div>
                  <h2 className="text-lg font-semibold text-gray-900 mb-4">Security Status</h2>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className={`p-4 rounded-lg border-2 ${totpStatus?.isEnabled ? 'bg-green-50 border-green-200' : 'bg-gray-50 border-gray-200'}`}>
                      <div className="flex items-center justify-between mb-2">
                        <Smartphone className={`w-6 h-6 ${totpStatus?.isEnabled ? 'text-green-600' : 'text-gray-400'}`} />
                        <span className={`text-xs font-semibold px-2 py-1 rounded ${totpStatus?.isEnabled ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-600'}`}>
                          {totpStatus?.isEnabled ? 'Active' : 'Inactive'}
                        </span>
                      </div>
                      <h3 className="font-semibold text-gray-900">Authenticator App</h3>
                      <p className="text-sm text-gray-600 mt-1">
                        {totpStatus?.isEnabled ? 'TOTP enabled' : 'Not configured'}
                      </p>
                    </div>

                    <div className={`p-4 rounded-lg border-2 ${backupCodesStatus?.remaining > 0 ? 'bg-blue-50 border-blue-200' : 'bg-gray-50 border-gray-200'}`}>
                      <div className="flex items-center justify-between mb-2">
                        <Key className={`w-6 h-6 ${backupCodesStatus?.remaining > 0 ? 'text-blue-600' : 'text-gray-400'}`} />
                        <span className={`text-xs font-semibold px-2 py-1 rounded ${backupCodesStatus?.remaining > 0 ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-600'}`}>
                          {backupCodesStatus?.remaining || 0} left
                        </span>
                      </div>
                      <h3 className="font-semibold text-gray-900">Backup Codes</h3>
                      <p className="text-sm text-gray-600 mt-1">
                        {backupCodesStatus?.remaining > 0 ? `${backupCodesStatus?.remaining} codes available` : 'No codes generated'}
                      </p>
                    </div>

                    <div className="p-4 rounded-lg border-2 bg-purple-50 border-purple-200">
                      <div className="flex items-center justify-between mb-2">
                        <Shield className="w-6 h-6 text-purple-600" />
                        <span className="text-xs font-semibold px-2 py-1 rounded bg-purple-100 text-purple-700">
                          {trustedDevices?.length} devices
                        </span>
                      </div>
                      <h3 className="font-semibold text-gray-900">Trusted Devices</h3>
                      <p className="text-sm text-gray-600 mt-1">
                        {trustedDevices?.length} trusted devices
                      </p>
                    </div>
                  </div>
                </div>

                <div>
                  <h2 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h2>
                  <div className="space-y-3">
                    {!totpStatus?.isEnabled && (
                      <button
                        onClick={handleSetupTOTP}
                        className="w-full bg-green-600 text-white py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors"
                      >
                        Enable Two-Factor Authentication
                      </button>
                    )}
                    {totpStatus?.isEnabled && (
                      <>
                        <button
                          onClick={handleGenerateBackupCodes}
                          className="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors"
                        >
                          Generate New Backup Codes
                        </button>
                        <button
                          onClick={handleDisableTOTP}
                          className="w-full bg-red-600 text-white py-3 rounded-lg font-semibold hover:bg-red-700 transition-colors"
                        >
                          Disable Two-Factor Authentication
                        </button>
                      </>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* Authenticator Tab */}
            {activeTab === 'authenticator' && (
              <div className="space-y-6">
                {!totpStatus?.isEnabled ? (
                  <div>
                    <h2 className="text-lg font-semibold text-gray-900 mb-4">Setup Authenticator App</h2>
                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
                      <p className="text-sm text-blue-800">
                        Use an authenticator app like Google Authenticator, Authy, or Microsoft Authenticator to generate verification codes.
                      </p>
                    </div>
                    <button
                      onClick={handleSetupTOTP}
                      className="bg-green-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-green-700 transition-colors"
                    >
                      Start Setup
                    </button>
                  </div>
                ) : (
                  <div>
                    <h2 className="text-lg font-semibold text-gray-900 mb-4">Authenticator App Status</h2>
                    <div className="bg-green-50 border border-green-200 rounded-lg p-6">
                      <div className="flex items-start space-x-4">
                        <CheckCircle className="w-6 h-6 text-green-600 flex-shrink-0 mt-1" />
                        <div>
                          <h3 className="font-semibold text-green-900 mb-2">Two-Factor Authentication is Active</h3>
                          <p className="text-sm text-green-700 mb-4">
                            Enabled on: {new Date(totpStatus.setupDate)?.toLocaleDateString()}
                          </p>
                          <button
                            onClick={handleDisableTOTP}
                            className="bg-red-600 text-white px-4 py-2 rounded-lg text-sm font-semibold hover:bg-red-700 transition-colors"
                          >
                            Disable TOTP
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Backup Codes Tab */}
            {activeTab === 'backup-codes' && (
              <div className="space-y-6">
                <div>
                  <h2 className="text-lg font-semibold text-gray-900 mb-4">Recovery Backup Codes</h2>
                  <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-4">
                    <p className="text-sm text-yellow-800">
                      Backup codes are single-use codes that can be used to access your account if you lose access to your authenticator app.
                      Keep them in a safe place!
                    </p>
                  </div>

                  {backupCodesStatus && (
                    <div className="bg-white border border-gray-200 rounded-lg p-6 mb-4">
                      <div className="grid grid-cols-3 gap-4 text-center">
                        <div>
                          <p className="text-2xl font-bold text-gray-900">{backupCodesStatus?.total}</p>
                          <p className="text-sm text-gray-600">Total Generated</p>
                        </div>
                        <div>
                          <p className="text-2xl font-bold text-green-600">{backupCodesStatus?.remaining}</p>
                          <p className="text-sm text-gray-600">Remaining</p>
                        </div>
                        <div>
                          <p className="text-2xl font-bold text-red-600">{backupCodesStatus?.used}</p>
                          <p className="text-sm text-gray-600">Used</p>
                        </div>
                      </div>
                    </div>
                  )}

                  <button
                    onClick={handleGenerateBackupCodes}
                    disabled={loading}
                    className="bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 disabled:bg-gray-300 transition-colors"
                  >
                    Generate New Codes
                  </button>
                </div>
              </div>
            )}

            {/* Devices Tab */}
            {activeTab === 'devices' && (
              <div className="space-y-6">
                <div>
                  <h2 className="text-lg font-semibold text-gray-900 mb-4">Trusted Devices</h2>
                  <p className="text-sm text-gray-600 mb-6">
                    These devices don't require 2FA verification. You can revoke access at any time.
                  </p>

                  {trustedDevices?.length === 0 ? (
                    <div className="text-center py-12 bg-gray-50 rounded-lg">
                      <Shield className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-600">No trusted devices yet</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {trustedDevices?.map((device) => (
                        <div key={device?.id} className="bg-white border border-gray-200 rounded-lg p-4">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <h3 className="font-semibold text-gray-900">{device?.deviceName}</h3>
                              <div className="mt-2 space-y-1">
                                <p className="text-sm text-gray-600 flex items-center">
                                  <Smartphone className="w-4 h-4 mr-2" />
                                  {device?.deviceType} • {device?.browserInfo?.browser}
                                </p>
                                <p className="text-sm text-gray-600 flex items-center">
                                  <MapPin className="w-4 h-4 mr-2" />
                                  {device?.location?.city || 'Unknown'}, {device?.location?.country || 'Unknown'}
                                </p>
                                <p className="text-sm text-gray-600 flex items-center">
                                  <Clock className="w-4 h-4 mr-2" />
                                  Last accessed: {new Date(device.lastAccessed)?.toLocaleString()}
                                </p>
                              </div>
                            </div>
                            <button
                              onClick={() => handleRevokeDevice(device?.id)}
                              className="ml-4 text-red-600 hover:text-red-700 transition-colors"
                            >
                              <Trash2 className="w-5 h-5" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Activity Tab */}
            {activeTab === 'activity' && (
              <div className="space-y-6">
                <div>
                  <h2 className="text-lg font-semibold text-gray-900 mb-4">Security Activity Log</h2>
                  <p className="text-sm text-gray-600 mb-6">
                    Recent 2FA authentication events and security changes.
                  </p>

                  {auditLog?.length === 0 ? (
                    <div className="text-center py-12 bg-gray-50 rounded-lg">
                      <Clock className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-600">No activity recorded yet</p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      {auditLog?.map((log) => (
                        <div key={log?.id} className="bg-white border border-gray-200 rounded-lg p-4">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center space-x-2 mb-2">
                                {log?.success ? (
                                  <CheckCircle className="w-4 h-4 text-green-600" />
                                ) : (
                                  <AlertTriangle className="w-4 h-4 text-red-600" />
                                )}
                                <span className="font-medium text-gray-900">
                                  {log?.eventType?.replace(/_/g, ' ')?.replace(/\b\w/g, l => l?.toUpperCase())}
                                </span>
                              </div>
                              <p className="text-sm text-gray-600">
                                {new Date(log.createdAt)?.toLocaleString()}
                              </p>
                              {log?.ipAddress && (
                                <p className="text-xs text-gray-500 mt-1">
                                  IP: {log?.ipAddress}
                                </p>
                              )}
                            </div>
                            <span className={`text-xs font-semibold px-2 py-1 rounded ${
                              log?.success ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
                            }`}>
                              {log?.success ? 'Success' : 'Failed'}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
      {/* TOTP Setup Modal */}
      {showSetupModal && totpSetup && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl shadow-xl max-w-md w-full p-6">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Setup Authenticator App</h2>
            
            <div className="space-y-4 mb-6">
              <div>
                <p className="text-sm text-gray-600 mb-3">
                  1. Scan this QR code with your authenticator app:
                </p>
                <div className="flex justify-center bg-gray-50 p-4 rounded-lg">
                  <img src={totpSetup?.qrCodeUrl} alt="QR Code" className="w-48 h-48" />
                </div>
              </div>

              <div>
                <p className="text-sm text-gray-600 mb-2">
                  2. Or manually enter this key:
                </p>
                <div className="bg-gray-50 p-3 rounded-lg">
                  <code className="text-sm font-mono text-gray-900 break-all">
                    {totpSetup?.manualEntryKey}
                  </code>
                </div>
              </div>

              <div>
                <p className="text-sm text-gray-600 mb-2">
                  3. Enter the 6-digit code from your app:
                </p>
                <input
                  type="text"
                  inputMode="numeric"
                  maxLength={6}
                  value={verificationCode}
                  onChange={(e) => setVerificationCode(e?.target?.value?.replace(/\D/g, ''))}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                  placeholder="000000"
                />
              </div>
            </div>

            <div className="flex space-x-3">
              <button
                onClick={() => {
                  setShowSetupModal(false);
                  setVerificationCode('');
                }}
                className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-gray-700 font-semibold hover:bg-gray-50 transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={handleVerifyTOTP}
                disabled={verificationCode?.length !== 6 || loading}
                className="flex-1 bg-green-600 text-white px-4 py-2 rounded-lg font-semibold hover:bg-green-700 disabled:bg-gray-300 transition-colors"
              >
                {loading ? 'Verifying...' : 'Verify & Enable'}
              </button>
            </div>
          </div>
        </div>
      )}
      {/* Backup Codes Modal */}
      {showCodesModal && generatedCodes && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-2xl shadow-xl max-w-md w-full p-6">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Your Backup Codes</h2>
            
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-4">
              <p className="text-sm text-yellow-800 font-semibold mb-2">
                ⚠️ Save these codes in a safe place!
              </p>
              <p className="text-xs text-yellow-700">
                Each code can only be used once. You won't be able to see them again.
              </p>
            </div>

            <div className="bg-gray-50 p-4 rounded-lg mb-4 max-h-64 overflow-y-auto">
              <div className="grid grid-cols-2 gap-2">
                {generatedCodes?.map((code, index) => (
                  <div key={index} className="bg-white p-2 rounded border border-gray-200">
                    <code className="text-sm font-mono text-gray-900">{code}</code>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex space-x-3">
              <button
                onClick={handleDownloadCodes}
                className="flex-1 bg-blue-600 text-white px-4 py-2 rounded-lg font-semibold hover:bg-blue-700 transition-colors flex items-center justify-center"
              >
                <Download className="w-4 h-4 mr-2" />
                Download
              </button>
              <button
                onClick={() => {
                  setShowCodesModal(false);
                  setGeneratedCodes(null);
                }}
                className="flex-1 bg-gray-600 text-white px-4 py-2 rounded-lg font-semibold hover:bg-gray-700 transition-colors"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}