import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Radio, Users, Send, TrendingUp, Trash2, MessageSquare, BarChart3 } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { getChannels, getChannelMessages, postChannelMessage, deleteChannelMessage, deleteChannel } from '../../services/channelService';
import Button from '../../components/ui/Button';
import { stripePaymentService } from '../../services/stripePaymentService';
import Icon from '../../components/AppIcon';


export default function ChannelManagementDashboard() {
  const { user, loading: authLoading, isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const [channels, setChannels] = useState([]);
  const [selectedChannel, setSelectedChannel] = useState(null);
  const [channelMessages, setChannelMessages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [activeTab, setActiveTab] = useState('overview');
  const [messageText, setMessageText] = useState('');
  const [sendingMessage, setSendingMessage] = useState(false);
  const [subscriptionTiers, setSubscriptionTiers] = useState([]);
  const [userSubscription, setUserSubscription] = useState(null);

  useEffect(() => {
    if (authLoading) return;

    if (!isAuthenticated) {
      navigate('/login');
      return;
    }

    loadChannels();
  }, [authLoading, isAuthenticated, navigate]);

  useEffect(() => {
    if (selectedChannel) {
      loadChannelMessages(selectedChannel?.id);
      loadSubscriptionTiers(selectedChannel?.id);
      checkUserSubscription(selectedChannel?.id);
    }
  }, [selectedChannel]);

  const loadChannels = async () => {
    try {
      setLoading(true);
      setError(null);

      const result = await getChannels();
      if (result?.error) throw result?.error;

      setChannels(result?.data || []);
      if (result?.data?.length > 0) {
        setSelectedChannel(result?.data?.[0]);
      }
    } catch (err) {
      console.error('Error loading channels:', err);
      setError(err?.message);
    } finally {
      setLoading(false);
    }
  };

  const loadChannelMessages = async (channelId) => {
    try {
      const result = await getChannelMessages(channelId);
      if (result?.error) throw result?.error;

      setChannelMessages(result?.data || []);
    } catch (err) {
      console.error('Error loading channel messages:', err);
    }
  };

  const loadSubscriptionTiers = async (channelId) => {
    try {
      const result = await stripePaymentService?.getChannelSubscriptionTiers(channelId);
      if (result?.data) {
        setSubscriptionTiers(result?.data);
      }
    } catch (err) {
      console.error('Error loading subscription tiers:', err);
    }
  };

  const checkUserSubscription = async (channelId) => {
    try {
      const result = await stripePaymentService?.getUserSubscriptions();
      if (result?.data) {
        const subscription = result?.data?.find(s => s?.channel_id === channelId && s?.status === 'active');
        setUserSubscription(subscription);
      }
    } catch (err) {
      console.error('Error checking subscription:', err);
    }
  };

  const handleSendMessage = async (e) => {
    e?.preventDefault();
    if (!messageText?.trim() || !selectedChannel) return;

    try {
      setSendingMessage(true);
      const result = await postChannelMessage(selectedChannel?.id, messageText);
      if (result?.error) throw result?.error;

      setMessageText('');
      await loadChannelMessages(selectedChannel?.id);
    } catch (err) {
      console.error('Error sending message:', err);
      setError(err?.message);
    } finally {
      setSendingMessage(false);
    }
  };

  const handleDeleteMessage = async (messageId) => {
    if (!window.confirm('Are you sure you want to delete this message?')) return;

    try {
      const result = await deleteChannelMessage(messageId);
      if (result?.error) throw result?.error;

      await loadChannelMessages(selectedChannel?.id);
    } catch (err) {
      console.error('Error deleting message:', err);
      setError(err?.message);
    }
  };

  const handleDeleteChannel = async (channelId) => {
    if (!window.confirm('Are you sure you want to delete this channel? This action cannot be undone.')) return;

    try {
      const result = await deleteChannel(channelId);
      if (result?.error) throw result?.error;

      await loadChannels();
    } catch (err) {
      console.error('Error deleting channel:', err);
      setError(err?.message);
    }
  };

  const handleUpgradeSubscription = () => {
    if (selectedChannel) {
      navigate(`/channel-subscription-payment?channelId=${selectedChannel?.id}`);
    }
  };

  const handleManageMonetization = () => {
    navigate('/channel-monetization-dashboard');
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return date?.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  };

  const formatTime = (dateString) => {
    const date = new Date(dateString);
    return date?.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
  };

  if (authLoading || loading) {
    return (
      <div className="flex items-center justify-center h-screen bg-gray-50">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading channels...</p>
        </div>
      </div>
    );
  }

  if (channels?.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white p-6 shadow-lg">
          <div className="max-w-6xl mx-auto">
            <h1 className="text-2xl font-bold mb-2">Channel Management</h1>
            <p className="text-blue-100">Manage your broadcast channels and content</p>
          </div>
        </div>

        <div className="max-w-6xl mx-auto p-6">
          <div className="bg-white rounded-lg shadow-md p-12 text-center">
            <Radio className="w-16 h-16 mx-auto mb-4 text-gray-300" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">No channels yet</h3>
            <p className="text-gray-600 mb-6">Create your first channel to start broadcasting</p>
            <Button
              onClick={() => navigate('/channel-creation-setup')}
              className="inline-flex items-center gap-2 bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700"
            >
              <Radio className="w-5 h-5" />
              Create Channel
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white p-6 shadow-lg">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold mb-2">Channel Management</h1>
              <p className="text-blue-100">Manage your broadcast channels and content</p>
            </div>
            <Button
              onClick={() => navigate('/channel-creation-setup')}
              className="bg-white text-blue-600 px-4 py-2 rounded-lg hover:bg-blue-50 flex items-center gap-2"
            >
              <Radio className="w-5 h-5" />
              New Channel
            </Button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-6">
        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-6">
            <p className="font-medium">Error</p>
            <p className="text-sm">{error}</p>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Channel List Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-md overflow-hidden">
              <div className="p-4 bg-gray-50 border-b">
                <h2 className="font-semibold text-gray-900">Your Channels</h2>
              </div>
              <div className="divide-y max-h-[600px] overflow-y-auto">
                {channels?.map((channel) => (
                  <button
                    key={channel?.id}
                    onClick={() => setSelectedChannel(channel)}
                    className={`w-full p-4 text-left hover:bg-gray-50 transition-colors ${
                      selectedChannel?.id === channel?.id ? 'bg-blue-50 border-l-4 border-blue-600' : ''
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center text-white font-bold">
                        {channel?.name?.charAt(0)?.toUpperCase()}
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="font-semibold text-gray-900 truncate">{channel?.name}</h3>
                        <div className="flex items-center gap-3 text-sm text-gray-600 mt-1">
                          <span className="flex items-center gap-1">
                            <Users className="w-4 h-4" />
                            {channel?.subscribers_count || 0}
                          </span>
                          <span className="flex items-center gap-1">
                            <MessageSquare className="w-4 h-4" />
                            {channel?.messages_count || 0}
                          </span>
                        </div>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Main Content Area */}
          <div className="lg:col-span-2">
            {selectedChannel && (
              <div className="bg-white rounded-lg shadow-md">
                {/* Channel Header */}
                <div className="p-6 border-b">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-4">
                      <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center text-white font-bold text-xl">
                        {selectedChannel?.name?.charAt(0)?.toUpperCase()}
                      </div>
                      <div>
                        <h2 className="text-xl font-bold text-gray-900">{selectedChannel?.name}</h2>
                        {selectedChannel?.username && (
                          <p className="text-sm text-gray-600">@{selectedChannel?.username}</p>
                        )}
                        {selectedChannel?.description && (
                          <p className="text-sm text-gray-700 mt-2">{selectedChannel?.description}</p>
                        )}
                      </div>
                    </div>
                    <button
                      onClick={() => handleDeleteChannel(selectedChannel?.id)}
                      className="text-red-600 hover:text-red-700 p-2 rounded-lg hover:bg-red-50"
                      title="Delete channel"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>

                  {/* Stats */}
                  <div className="grid grid-cols-3 gap-4 mt-6">
                    <div className="bg-blue-50 rounded-lg p-4">
                      <div className="flex items-center gap-2 text-blue-600 mb-1">
                        <Users className="w-5 h-5" />
                        <span className="text-sm font-medium">Subscribers</span>
                      </div>
                      <p className="text-2xl font-bold text-gray-900">{selectedChannel?.subscribers_count || 0}</p>
                    </div>
                    <div className="bg-green-50 rounded-lg p-4">
                      <div className="flex items-center gap-2 text-green-600 mb-1">
                        <MessageSquare className="w-5 h-5" />
                        <span className="text-sm font-medium">Messages</span>
                      </div>
                      <p className="text-2xl font-bold text-gray-900">{selectedChannel?.messages_count || 0}</p>
                    </div>
                    <div className="bg-purple-50 rounded-lg p-4">
                      <div className="flex items-center gap-2 text-purple-600 mb-1">
                        <TrendingUp className="w-5 h-5" />
                        <span className="text-sm font-medium">Type</span>
                      </div>
                      <p className="text-lg font-bold text-gray-900 capitalize">{selectedChannel?.type}</p>
                    </div>
                  </div>

                  {/* Analytics Button */}
                  <div className="mt-4">
                    <button
                      onClick={() => navigate(`/channel-subscriber-analytics-dashboard?channelId=${selectedChannel?.id}`)}
                      className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg hover:from-blue-700 hover:to-purple-700 transition-colors font-medium"
                    >
                      <BarChart3 className="w-5 h-5" />
                      View Analytics Dashboard
                    </button>
                  </div>
                </div>

                {/* Tabs */}
                <div className="border-b">
                  <div className="flex gap-6 px-6">
                    <button
                      onClick={() => setActiveTab('overview')}
                      className={`py-3 border-b-2 font-medium transition-colors ${
                        activeTab === 'overview' ?'border-blue-600 text-blue-600' :'border-transparent text-gray-600 hover:text-gray-900'
                      }`}
                    >
                      Overview
                    </button>
                    <button
                      onClick={() => setActiveTab('broadcast')}
                      className={`py-3 border-b-2 font-medium transition-colors ${
                        activeTab === 'broadcast' ?'border-blue-600 text-blue-600' :'border-transparent text-gray-600 hover:text-gray-900'
                      }`}
                    >
                      Broadcast
                    </button>
                  </div>
                </div>

                {/* Tab Content */}
                <div className="p-6">
                  {activeTab === 'overview' && (
                    <div className="space-y-6">
                      <div>
                        <h3 className="font-semibold text-gray-900 mb-3">Recent Messages</h3>
                        {channelMessages?.length === 0 ? (
                          <div className="text-center py-8 text-gray-500">
                            <MessageSquare className="w-12 h-12 mx-auto mb-2 text-gray-300" />
                            <p>No messages yet</p>
                          </div>
                        ) : (
                          <div className="space-y-3 max-h-96 overflow-y-auto">
                            {channelMessages?.slice(0, 5)?.map((message) => (
                              <div key={message?.id} className="bg-gray-50 rounded-lg p-4">
                                <div className="flex items-start justify-between">
                                  <div className="flex-1">
                                    <p className="text-gray-900">{message?.text_content}</p>
                                    <p className="text-xs text-gray-500 mt-2">
                                      {formatDate(message?.sent_at)} at {formatTime(message?.sent_at)}
                                    </p>
                                  </div>
                                  <button
                                    onClick={() => handleDeleteMessage(message?.id)}
                                    className="text-red-600 hover:text-red-700 p-1"
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </button>
                                </div>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>

                      {/* Monetization Section - Show for channel admins */}
                      {activeTab === 'overview' && selectedChannel && (
                        <div className="bg-gradient-to-r from-green-50 to-green-100 rounded-lg p-6 mb-6">
                          <div className="flex items-center justify-between">
                            <div>
                              <h3 className="text-lg font-bold text-gray-900 mb-2">Channel Monetization</h3>
                              <p className="text-gray-600">
                                {subscriptionTiers?.length > 0
                                  ? `${subscriptionTiers?.length} subscription tiers available`
                                  : 'Set up premium subscriptions for your channel'}
                              </p>
                            </div>
                            <button
                              onClick={handleManageMonetization}
                              className="bg-green-600 text-white px-6 py-3 rounded-lg font-medium hover:bg-green-700 flex items-center gap-2"
                            >
                              <Icon name="DollarSign" size={20} />
                              <span>Manage Monetization</span>
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  )}

                  {activeTab === 'broadcast' && (
                    <div>
                      <h3 className="font-semibold text-gray-900 mb-4">Send Broadcast Message</h3>
                      <form onSubmit={handleSendMessage} className="space-y-4">
                        <textarea
                          value={messageText}
                          onChange={(e) => setMessageText(e?.target?.value)}
                          placeholder="Write your broadcast message..."
                          rows={6}
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        />
                        <div className="flex justify-end">
                          <Button
                            type="submit"
                            disabled={sendingMessage || !messageText?.trim()}
                            className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 disabled:opacity-50 flex items-center gap-2"
                          >
                            {sendingMessage ? (
                              <>
                                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                                Sending...
                              </>
                            ) : (
                              <>
                                <Send className="w-5 h-5" />
                                Send Broadcast
                              </>
                            )}
                          </Button>
                        </div>
                      </form>

                      <div className="mt-8">
                        <h4 className="font-semibold text-gray-900 mb-3">All Messages</h4>
                        {channelMessages?.length === 0 ? (
                          <div className="text-center py-8 text-gray-500">
                            <MessageSquare className="w-12 h-12 mx-auto mb-2 text-gray-300" />
                            <p>No messages sent yet</p>
                          </div>
                        ) : (
                          <div className="space-y-3 max-h-96 overflow-y-auto">
                            {channelMessages?.map((message) => (
                              <div key={message?.id} className="bg-gray-50 rounded-lg p-4">
                                <div className="flex items-start justify-between">
                                  <div className="flex-1">
                                    <p className="text-gray-900">{message?.text_content}</p>
                                    <div className="flex items-center gap-4 mt-2 text-xs text-gray-500">
                                      <span>{formatDate(message?.sent_at)} at {formatTime(message?.sent_at)}</span>
                                      <span>{message?.views_count || 0} views</span>
                                    </div>
                                  </div>
                                  <button
                                    onClick={() => handleDeleteMessage(message?.id)}
                                    className="text-red-600 hover:text-red-700 p-1"
                                  >
                                    <Trash2 className="w-4 h-4" />
                                  </button>
                                </div>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}