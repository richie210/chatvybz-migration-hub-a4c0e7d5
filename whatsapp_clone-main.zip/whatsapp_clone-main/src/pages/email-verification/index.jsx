import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Mail, RefreshCw, ArrowLeft, Check, AlertCircle, Copy, Clock } from 'lucide-react';
import registrationService from '../../services/registrationService';
import { supabase } from '../../lib/supabase';

const EmailVerification = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const email = location?.state?.email || '';
  const fullName = location?.state?.fullName || '';
  const profileData = location?.state?.profileData || {};

  // State management
  const [activeTab, setActiveTab] = useState('magic-link'); // 'magic-link' or 'code'
  const [verificationCode, setVerificationCode] = useState(['', '', '', '', '', '']);
  const [isLoading, setIsLoading] = useState(false);
  const [isSending, setIsSending] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [resendTimer, setResendTimer] = useState(60);
  const [canResend, setCanResend] = useState(false);
  const [magicLinkSent, setMagicLinkSent] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editedEmail, setEditedEmail] = useState(email);

  // Refs for code inputs
  const codeInputRefs = useRef([]);

  // Countdown timer effect
  useEffect(() => {
    if (resendTimer > 0) {
      const timer = setTimeout(() => setResendTimer(resendTimer - 1), 1000);
      return () => clearTimeout(timer);
    } else {
      setCanResend(true);
    }
  }, [resendTimer]);

  // Auto-send magic link on mount if email is provided
  useEffect(() => {
    if (email && !magicLinkSent && activeTab === 'magic-link') {
      handleSendMagicLink();
    }
  }, []);

  // Listen for auth state changes (magic link verification)
  useEffect(() => {
    const { data: authListener } = supabase?.auth?.onAuthStateChange(async (event, session) => {
      if (event === 'SIGNED_IN' && session?.user?.email === email) {
        setSuccess('Email verified successfully! Redirecting...');
        setTimeout(() => {
          navigate('/profile-setup', {
            state: {
              userId: session?.user?.id,
              email: session?.user?.email,
              fullName,
              ...profileData
            }
          });
        }, 1500);
      }
    });

    return () => {
      authListener?.subscription?.unsubscribe();
    };
  }, [email, fullName, profileData, navigate]);

  // Handle magic link sending
  const handleSendMagicLink = async () => {
    if (!email) {
      setError('Please provide an email address');
      return;
    }

    setIsSending(true);
    setError('');
    setSuccess('');

    try {
      const { error: sendError } = await supabase?.auth?.signInWithOtp({
        email: email,
        options: {
          shouldCreateUser: true,
          emailRedirectTo: `${window?.location?.origin}/email-verification`
        }
      });

      if (sendError) throw sendError;

      setMagicLinkSent(true);
      setSuccess('Magic link sent! Check your email inbox.');
      setResendTimer(60);
      setCanResend(false);
    } catch (err) {
      console.error('Magic link error:', err);
      setError(err?.message || 'Failed to send magic link. Please try again.');
    } finally {
      setIsSending(false);
    }
  };

  // Handle verification code sending
  const handleSendVerificationCode = async () => {
    if (!email) {
      setError('Please provide an email address');
      return;
    }

    setIsSending(true);
    setError('');
    setSuccess('');

    try {
      await registrationService?.sendVerificationCode('email', email);
      setSuccess('Verification code sent! Check your email.');
      setResendTimer(60);
      setCanResend(false);
    } catch (err) {
      console.error('Send code error:', err);
      setError(err?.message || 'Failed to send verification code. Please try again.');
    } finally {
      setIsSending(false);
    }
  };

  // Handle code input change
  const handleCodeChange = (index, value) => {
    if (!/^\d*$/?.test(value)) return; // Only allow numbers

    const newCode = [...verificationCode];
    newCode[index] = value?.slice(-1); // Only take last character
    setVerificationCode(newCode);

    // Auto-focus next input
    if (value && index < 5) {
      codeInputRefs?.current?.[index + 1]?.focus();
    }

    // Auto-verify when all 6 digits are entered
    if (index === 5 && value && newCode?.every(digit => digit)) {
      handleVerifyCode(newCode?.join(''));
    }
  };

  // Handle code verification
  const handleVerifyCode = async (code) => {
    const finalCode = code || verificationCode?.join('');
    
    if (finalCode?.length !== 6) {
      setError('Please enter all 6 digits');
      return;
    }

    setIsLoading(true);
    setError('');
    setSuccess('');

    try {
      const result = await registrationService?.verifyCode('email', email, finalCode);

      if (result?.success) {
        setSuccess('Email verified successfully! Redirecting...');
        setTimeout(() => {
          navigate('/profile-setup', {
            state: {
              userId: result?.user?.id,
              email: result?.user?.email,
              fullName,
              ...profileData
            }
          });
        }, 1500);
      }
    } catch (err) {
      console.error('Verification error:', err);
      setError(err?.message || 'Invalid verification code. Please try again.');
      setVerificationCode(['', '', '', '', '', '']);
      codeInputRefs?.current?.[0]?.focus();
    } finally {
      setIsLoading(false);
    }
  };

  // Handle paste event for verification code
  const handlePaste = (e) => {
    e?.preventDefault();
    const pastedData = e?.clipboardData?.getData('text')?.trim();
    
    if (/^\d{6}$/?.test(pastedData)) {
      const digits = pastedData?.split('');
      setVerificationCode(digits);
      codeInputRefs?.current?.[5]?.focus();
      // Auto-verify pasted code
      handleVerifyCode(pastedData);
    }
  };

  // Handle email editing
  const handleEditEmail = () => {
    setIsEditing(true);
    setEditedEmail(email);
  };

  const handleSaveEmail = () => {
    if (editedEmail && editedEmail !== email) {
      navigate('/register', {
        state: {
          email: editedEmail,
          fullName,
          ...profileData
        }
      });
    } else {
      setIsEditing(false);
    }
  };

  // Handle resend
  const handleResend = () => {
    if (canResend) {
      if (activeTab === 'magic-link') {
        handleSendMagicLink();
      } else {
        handleSendVerificationCode();
      }
    }
  };

  // Handle tab switch
  const handleTabSwitch = (tab) => {
    setActiveTab(tab);
    setError('');
    setSuccess('');
    setVerificationCode(['', '', '', '', '', '']);
    
    // Auto-send based on active tab
    if (tab === 'magic-link' && !magicLinkSent) {
      handleSendMagicLink();
    } else if (tab === 'code') {
      handleSendVerificationCode();
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-green-50 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Back Button */}
        <button
          onClick={() => navigate('/register')}
          className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-6 transition-colors"
        >
          <ArrowLeft size={20} />
          <span className="text-sm font-medium">Back to Registration</span>
        </button>

        {/* Main Card */}
        <div className="bg-white rounded-2xl shadow-xl p-8 space-y-6">
          {/* Header */}
          <div className="text-center">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Mail className="w-8 h-8 text-green-600" />
            </div>
            <h1 className="text-2xl font-bold text-gray-900 mb-2">Verify Your Email</h1>
            <p className="text-gray-600 text-sm">
              We need to verify your email address to complete registration
            </p>
          </div>

          {/* Email Display/Edit */}
          <div className="bg-gray-50 rounded-lg p-4">
            {isEditing ? (
              <div className="space-y-3">
                <input
                  type="email"
                  value={editedEmail}
                  onChange={(e) => setEditedEmail(e?.target?.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
                  autoFocus
                />
                <div className="flex gap-2">
                  <button
                    onClick={handleSaveEmail}
                    className="flex-1 bg-green-500 hover:bg-green-600 text-white py-2 rounded-lg font-medium transition-colors"
                  >
                    Save
                  </button>
                  <button
                    onClick={() => setIsEditing(false)}
                    className="flex-1 bg-gray-200 hover:bg-gray-300 text-gray-700 py-2 rounded-lg font-medium transition-colors"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <p className="text-xs text-gray-500 mb-1">Sending to:</p>
                  <p className="text-sm font-medium text-gray-900 break-all">{email}</p>
                </div>
                <button
                  onClick={handleEditEmail}
                  className="text-green-600 hover:text-green-700 text-sm font-medium ml-4"
                >
                  Edit
                </button>
              </div>
            )}
          </div>

          {/* Tab Navigation */}
          <div className="flex gap-2 border-b border-gray-200">
            <button
              onClick={() => handleTabSwitch('magic-link')}
              className={`flex-1 py-3 px-4 text-sm font-medium transition-all relative ${
                activeTab === 'magic-link' ?'text-green-600' :'text-gray-600 hover:text-gray-900'
              }`}
            >
              Magic Link
              {activeTab === 'magic-link' && (
                <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-green-600" />
              )}
            </button>
            <button
              onClick={() => handleTabSwitch('code')}
              className={`flex-1 py-3 px-4 text-sm font-medium transition-all relative ${
                activeTab === 'code' ?'text-green-600' :'text-gray-600 hover:text-gray-900'
              }`}
            >
              Verification Code
              {activeTab === 'code' && (
                <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-green-600" />
              )}
            </button>
          </div>

          {/* Magic Link Tab Content */}
          {activeTab === 'magic-link' && (
            <div className="space-y-4">
              <div className="text-center space-y-3">
                <p className="text-sm text-gray-700">
                  Click the button below to send a magic link to your email
                </p>
                
                <button
                  onClick={handleSendMagicLink}
                  disabled={isSending || !canResend && magicLinkSent}
                  className="w-full bg-green-500 hover:bg-green-600 disabled:bg-gray-300 disabled:cursor-not-allowed text-white font-bold py-3 px-4 rounded-lg transition-colors flex items-center justify-center gap-2"
                >
                  {isSending ? (
                    <>
                      <RefreshCw className="w-5 h-5 animate-spin" />
                      Sending Magic Link...
                    </>
                  ) : magicLinkSent ? (
                    <>
                      <Check className="w-5 h-5" />
                      Magic Link Sent
                    </>
                  ) : (
                    <>
                      <Mail className="w-5 h-5" />
                      Send Magic Link
                    </>
                  )}
                </button>

                {magicLinkSent && (
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 space-y-2">
                    <p className="text-sm font-medium text-blue-900">📧 Check your email!</p>
                    <ul className="text-xs text-blue-800 space-y-1 text-left pl-4">
                      <li>• Click the magic link in your email to verify</li>
                      <li>• Link will automatically verify your account</li>
                      <li>• Check spam folder if you don't see it</li>
                      <li>• Link expires in 1 hour</li>
                    </ul>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Verification Code Tab Content */}
          {activeTab === 'code' && (
            <div className="space-y-4">
              <div className="text-center">
                <p className="text-sm text-gray-700 mb-4">
                  Enter the 6-digit code sent to your email
                </p>

                {/* Code Input Fields */}
                <div className="flex gap-2 justify-center mb-4">
                  {verificationCode?.map((digit, index) => (
                    <input
                      key={index}
                      ref={(el) => (codeInputRefs.current[index] = el)}
                      type="text"
                      inputMode="numeric"
                      maxLength={1}
                      value={digit}
                      onChange={(e) => handleCodeChange(index, e?.target?.value)}
                      onKeyDown={(e) => {
                        if (e?.key === 'Backspace' && !digit && index > 0) {
                          codeInputRefs?.current?.[index - 1]?.focus();
                        }
                      }}
                      onPaste={index === 0 ? handlePaste : undefined}
                      className={`w-12 h-14 text-center text-xl font-bold border-2 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 transition-all ${
                        error ? 'border-red-500' : digit ? 'border-green-500' : 'border-gray-300'
                      }`}
                      disabled={isLoading}
                    />
                  ))}
                </div>

                <button
                  onClick={() => handleVerifyCode()}
                  disabled={isLoading || verificationCode?.join('')?.length !== 6}
                  className="w-full bg-green-500 hover:bg-green-600 disabled:bg-gray-300 disabled:cursor-not-allowed text-white font-bold py-3 px-4 rounded-lg transition-colors flex items-center justify-center gap-2"
                >
                  {isLoading ? (
                    <>
                      <RefreshCw className="w-5 h-5 animate-spin" />
                      Verifying...
                    </>
                  ) : (
                    <>
                      <Check className="w-5 h-5" />
                      Verify Code
                    </>
                  )}
                </button>

                <div className="mt-4 bg-gray-50 rounded-lg p-3">
                  <p className="text-xs text-gray-600">💡 Pro tip: You can paste the code directly</p>
                </div>
              </div>
            </div>
          )}

          {/* Success Message */}
          {success && (
            <div className="bg-green-50 border border-green-200 rounded-lg p-4 flex items-start gap-3">
              <Check className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
              <p className="text-sm text-green-800 font-medium">{success}</p>
            </div>
          )}

          {/* Error Message */}
          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
              <div className="flex items-start gap-3 mb-2">
                <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                <div className="flex-1">
                  <p className="text-sm text-red-800 font-medium mb-2">{error}</p>
                  <button
                    onClick={() => {
                      navigator?.clipboard?.writeText(error);
                      setSuccess('Error copied to clipboard');
                      setTimeout(() => setSuccess(''), 2000);
                    }}
                    className="flex items-center gap-1 text-xs text-red-700 hover:text-red-900"
                  >
                    <Copy size={12} />
                    Copy error details
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Resend Timer */}
          <div className="text-center space-y-2">
            {!canResend ? (
              <div className="flex items-center justify-center gap-2 text-sm text-gray-600">
                <Clock size={16} />
                <span>Resend available in {resendTimer}s</span>
              </div>
            ) : (
              <button
                onClick={handleResend}
                className="text-green-600 hover:text-green-700 text-sm font-medium flex items-center gap-2 mx-auto"
              >
                <RefreshCw size={16} />
                Resend {activeTab === 'magic-link' ? 'Magic Link' : 'Code'}
              </button>
            )}
          </div>

          {/* Help Text */}
          <div className="text-center pt-4 border-t border-gray-200">
            <p className="text-xs text-gray-500">
              Didn't receive anything? Check your spam folder or try the other verification method
            </p>
          </div>
        </div>

        {/* Additional Help */}
        <div className="mt-6 text-center">
          <p className="text-sm text-gray-600">
            Need help?{' '}
            <a href="#" className="text-green-600 hover:underline font-medium">
              Contact Support
            </a>
          </p>
        </div>
      </div>
    </div>
  );
};

export default EmailVerification;