import React, { useState, useEffect, useRef } from 'react';
import { Video, Users, Settings } from 'lucide-react';
import Button from '../../components/ui/Button';
import ParticipantGrid from './components/ParticipantGrid';
import TranscriptionPanel from './components/TranscriptionPanel';
import EncryptionIndicator from './components/EncryptionIndicator';
import ControlPanel from './components/ControlPanel';
import SettingsModal from './components/SettingsModal';
import { useAuth } from '../../contexts/AuthContext';

const EnhancedMultiParticipantVideoConference = () => {
  const { user } = useAuth();
  const [isVideoEnabled, setIsVideoEnabled] = useState(true);
  const [isAudioEnabled, setIsAudioEnabled] = useState(true);
  const [isScreenSharing, setIsScreenSharing] = useState(false);
  const [isTranscriptionEnabled, setIsTranscriptionEnabled] = useState(false);
  const [showTranscriptionPanel, setShowTranscriptionPanel] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [participants, setParticipants] = useState([]);
  const [transcripts, setTranscripts] = useState([]);
  const [isRecording, setIsRecording] = useState(false);
  const [encryptionStatus, setEncryptionStatus] = useState({
    enabled: true,
    level: 'E2EE',
    verified: true
  });
  const [connectionQuality, setConnectionQuality] = useState('excellent');
  const localVideoRef = useRef(null);
  const localStreamRef = useRef(null);

  useEffect(() => {
    initializeMediaDevices();
    simulateParticipants();
    return () => {
      cleanup();
    };
  }, []);

  const initializeMediaDevices = async () => {
    try {
      const stream = await navigator.mediaDevices?.getUserMedia({
        video: { width: 1280, height: 720 },
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true
        }
      });
      localStreamRef.current = stream;
      if (localVideoRef?.current) {
        localVideoRef.current.srcObject = stream;
      }
    } catch (error) {
      console.error('Error accessing media devices:', error);
    }
  };

  const simulateParticipants = () => {
    const mockParticipants = [
      { id: '1', name: 'Sarah Johnson', isVideoOn: true, isAudioOn: true, encryptionVerified: true, connectionQuality: 'excellent' },
      { id: '2', name: 'Michael Chen', isVideoOn: true, isAudioOn: true, encryptionVerified: true, connectionQuality: 'good' },
      { id: '3', name: 'Emma Williams', isVideoOn: false, isAudioOn: true, encryptionVerified: true, connectionQuality: 'excellent' },
      { id: '4', name: 'James Brown', isVideoOn: true, isAudioOn: false, encryptionVerified: true, connectionQuality: 'fair' }
    ];
    setParticipants(mockParticipants);
  };

  const cleanup = () => {
    if (localStreamRef?.current) {
      localStreamRef?.current?.getTracks()?.forEach(track => track?.stop());
    }
  };

  const toggleVideo = () => {
    if (localStreamRef?.current) {
      const videoTrack = localStreamRef?.current?.getVideoTracks()?.[0];
      if (videoTrack) {
        videoTrack.enabled = !videoTrack?.enabled;
        setIsVideoEnabled(videoTrack?.enabled);
      }
    }
  };

  const toggleAudio = () => {
    if (localStreamRef?.current) {
      const audioTrack = localStreamRef?.current?.getAudioTracks()?.[0];
      if (audioTrack) {
        audioTrack.enabled = !audioTrack?.enabled;
        setIsAudioEnabled(audioTrack?.enabled);
      }
    }
  };

  const toggleScreenShare = async () => {
    try {
      if (!isScreenSharing) {
        const screenStream = await navigator.mediaDevices?.getDisplayMedia({
          video: { cursor: 'always' },
          audio: false
        });
        setIsScreenSharing(true);
        screenStream?.getVideoTracks()?.[0]?.addEventListener('ended', () => {
          setIsScreenSharing(false);
        });
      } else {
        setIsScreenSharing(false);
      }
    } catch (error) {
      console.error('Error sharing screen:', error);
    }
  };

  const toggleTranscription = () => {
    setIsTranscriptionEnabled(!isTranscriptionEnabled);
    setShowTranscriptionPanel(!isTranscriptionEnabled);
    
    if (!isTranscriptionEnabled) {
      const mockTranscript = {
        id: Date.now(),
        speaker: user?.email || 'You',
        text: 'Real-time transcription enabled. Your speech will be converted to text using OpenAI Whisper.',
        timestamp: new Date()?.toISOString(),
        confidence: 0.95,
        language: 'en'
      };
      setTranscripts(prev => [...prev, mockTranscript]);
    }
  };

  const endCall = () => {
    cleanup();
    window.history?.back();
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      {/* Header with Encryption Status */}
      <div className="bg-gray-800 border-b border-gray-700 px-6 py-3">
        <div className="flex items-center justify-between max-w-7xl mx-auto">
          <div className="flex items-center gap-4">
            <h1 className="text-xl font-semibold">Video Conference</h1>
            <div className="flex items-center gap-2">
              <Users className="w-5 h-5 text-blue-400" />
              <span className="text-sm text-gray-400">{participants?.length + 1} participants</span>
            </div>
          </div>
          
          <EncryptionIndicator status={encryptionStatus} />
          
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setShowSettings(true)}
            className="text-gray-400 hover:text-white"
          >
            <Settings className="w-5 h-5" />
          </Button>
        </div>
      </div>
      {/* Main Content */}
      <div className="flex h-[calc(100vh-72px)]">
        {/* Video Grid */}
        <div className={`flex-1 transition-all duration-300 ${showTranscriptionPanel ? 'mr-96' : ''}`}>
          <ParticipantGrid
            participants={participants}
            localVideoRef={localVideoRef}
            isLocalVideoEnabled={isVideoEnabled}
            isLocalAudioEnabled={isAudioEnabled}
            encryptionEnabled={encryptionStatus?.enabled}
          />
        </div>

        {/* Transcription Panel */}
        {showTranscriptionPanel && (
          <TranscriptionPanel
            transcripts={transcripts}
            isEnabled={isTranscriptionEnabled}
            onClose={() => setShowTranscriptionPanel(false)}
            onExport={(format) => {
              console.log(`Exporting transcripts as ${format}`);
            }}
          />
        )}
      </div>
      {/* Control Panel */}
      <ControlPanel
        isVideoEnabled={isVideoEnabled}
        isAudioEnabled={isAudioEnabled}
        isScreenSharing={isScreenSharing}
        isTranscriptionEnabled={isTranscriptionEnabled}
        isRecording={isRecording}
        onToggleVideo={toggleVideo}
        onToggleAudio={toggleAudio}
        onToggleScreenShare={toggleScreenShare}
        onToggleTranscription={toggleTranscription}
        onToggleRecording={() => setIsRecording(!isRecording)}
        onEndCall={endCall}
        encryptionStatus={encryptionStatus}
      />
      {/* Settings Modal */}
      {showSettings && (
        <SettingsModal
          onClose={() => setShowSettings(false)}
          encryptionStatus={encryptionStatus}
          onEncryptionChange={setEncryptionStatus}
        />
      )}
    </div>
  );
};

export default EnhancedMultiParticipantVideoConference;