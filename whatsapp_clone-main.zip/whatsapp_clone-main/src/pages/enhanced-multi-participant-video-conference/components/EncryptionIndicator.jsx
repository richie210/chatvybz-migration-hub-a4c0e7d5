import React, { useState } from 'react';
import { Shield, ShieldCheck, ShieldAlert, Info, Lock } from 'lucide-react';

const EncryptionIndicator = ({ status }) => {
  const [showDetails, setShowDetails] = useState(false);

  const getStatusIcon = () => {
    if (!status?.enabled) return <ShieldAlert className="w-5 h-5 text-red-400" />;
    if (status?.verified) return <ShieldCheck className="w-5 h-5 text-green-400" />;
    return <Shield className="w-5 h-5 text-yellow-400" />;
  };

  const getStatusColor = () => {
    if (!status?.enabled) return 'bg-red-500/20 border-red-500/50 text-red-400';
    if (status?.verified) return 'bg-green-500/20 border-green-500/50 text-green-400';
    return 'bg-yellow-500/20 border-yellow-500/50 text-yellow-400';
  };

  const getStatusText = () => {
    if (!status?.enabled) return 'Encryption Disabled';
    if (status?.verified) return 'E2EE Verified';
    return 'E2EE Active';
  };

  return (
    <div className="relative">
      <button
        onClick={() => setShowDetails(!showDetails)}
        className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border transition-colors ${getStatusColor()}`}
      >
        {getStatusIcon()}
        <span className="text-sm font-medium">{getStatusText()}</span>
        <Info className="w-4 h-4 opacity-60" />
      </button>
      {showDetails && (
        <div className="absolute top-full right-0 mt-2 w-80 bg-gray-800 border border-gray-700 rounded-lg shadow-xl p-4 z-50">
          <div className="flex items-start gap-3 mb-3">
            <div className={`p-2 rounded-lg ${status?.enabled ? 'bg-green-500/20' : 'bg-red-500/20'}`}>
              <Lock className={`w-5 h-5 ${status?.enabled ? 'text-green-400' : 'text-red-400'}`} />
            </div>
            <div className="flex-1">
              <h3 className="text-sm font-semibold text-white mb-1">
                End-to-End Encryption {status?.enabled ? 'Active' : 'Disabled'}
              </h3>
              <p className="text-xs text-gray-400 leading-relaxed">
                {status?.enabled
                  ? 'Your video call is protected with military-grade end-to-end encryption. Only participants can access the content.' :'Encryption is currently disabled. Consider enabling E2EE for enhanced security.'}
              </p>
            </div>
          </div>

          <div className="space-y-2 mb-3">
            <div className="flex items-center justify-between text-xs">
              <span className="text-gray-400">Encryption Level:</span>
              <span className="text-white font-medium">{status?.level || 'AES-256'}</span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-gray-400">Key Exchange:</span>
              <span className="text-white font-medium">ECDHE</span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="text-gray-400">Identity Verified:</span>
              <span className={`font-medium ${status?.verified ? 'text-green-400' : 'text-yellow-400'}`}>
                {status?.verified ? 'Yes' : 'Pending'}
              </span>
            </div>
          </div>

          <div className="bg-gray-700/50 rounded-lg p-2">
            <div className="flex items-start gap-2">
              <Info className="w-4 h-4 text-blue-400 mt-0.5 flex-shrink-0" />
              <p className="text-xs text-gray-300 leading-relaxed">
                All media streams, transcriptions, and data channels are encrypted end-to-end. 
                Even the server cannot access your conversation.
              </p>
            </div>
          </div>

          <button
            onClick={() => setShowDetails(false)}
            className="w-full mt-3 px-3 py-1.5 bg-gray-700 hover:bg-gray-600 rounded text-xs text-gray-300 transition-colors"
          >
            Close
          </button>
        </div>
      )}
    </div>
  );
};

export default EncryptionIndicator;