import React, { useState } from 'react';
import { X, Mic, Video, Speaker, Shield, Sliders } from 'lucide-react';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';
import Icon from '../../../components/AppIcon';


const SettingsModal = ({ onClose, encryptionStatus, onEncryptionChange }) => {
  const [activeTab, setActiveTab] = useState('devices');
  const [selectedMic, setSelectedMic] = useState('default');
  const [selectedCamera, setSelectedCamera] = useState('default');
  const [selectedSpeaker, setSelectedSpeaker] = useState('default');

  const tabs = [
    { id: 'devices', label: 'Devices', icon: Sliders },
    { id: 'video', label: 'Video', icon: Video },
    { id: 'audio', label: 'Audio', icon: Mic },
    { id: 'security', label: 'Security', icon: Shield }
  ];

  const micOptions = [
    { value: 'default', label: 'Default Microphone' },
    { value: 'mic1', label: 'Built-in Microphone' },
    { value: 'mic2', label: 'External Microphone' }
  ];

  const cameraOptions = [
    { value: 'default', label: 'Default Camera' },
    { value: 'cam1', label: 'Built-in Camera' },
    { value: 'cam2', label: 'External Camera' }
  ];

  const speakerOptions = [
    { value: 'default', label: 'Default Speaker' },
    { value: 'speaker1', label: 'Built-in Speakers' },
    { value: 'speaker2', label: 'External Speakers' }
  ];

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-gray-800 rounded-lg w-full max-w-2xl max-h-[80vh] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-700">
          <h2 className="text-xl font-semibold text-white">Conference Settings</h2>
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="text-gray-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </Button>
        </div>

        <div className="flex flex-1 overflow-hidden">
          {/* Tabs */}
          <div className="w-48 bg-gray-900 border-r border-gray-700 p-4">
            {tabs?.map((tab) => {
              const Icon = tab?.icon;
              return (
                <button
                  key={tab?.id}
                  onClick={() => setActiveTab(tab?.id)}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg mb-2 transition-colors ${
                    activeTab === tab?.id
                      ? 'bg-blue-500 text-white' :'text-gray-400 hover:bg-gray-800 hover:text-white'
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span className="text-sm font-medium">{tab?.label}</span>
                </button>
              );
            })}
          </div>

          {/* Content */}
          <div className="flex-1 p-6 overflow-y-auto">
            {activeTab === 'devices' && (
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-white mb-2">
                    <Mic className="w-4 h-4 inline mr-2" />
                    Microphone
                  </label>
                  <Select
                    options={micOptions}
                    value={selectedMic}
                    onChange={(e) => setSelectedMic(e?.target?.value)}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-white mb-2">
                    <Video className="w-4 h-4 inline mr-2" />
                    Camera
                  </label>
                  <Select
                    options={cameraOptions}
                    value={selectedCamera}
                    onChange={(e) => setSelectedCamera(e?.target?.value)}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-white mb-2">
                    <Speaker className="w-4 h-4 inline mr-2" />
                    Speaker
                  </label>
                  <Select
                    options={speakerOptions}
                    value={selectedSpeaker}
                    onChange={(e) => setSelectedSpeaker(e?.target?.value)}
                  />
                </div>
              </div>
            )}

            {activeTab === 'video' && (
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-white mb-2">Video Quality</label>
                  <Select
                    options={[
                      { value: 'auto', label: 'Auto' },
                      { value: '720p', label: '720p HD' },
                      { value: '1080p', label: '1080p Full HD' }
                    ]}
                    value="auto"
                    onChange={() => {}}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-white">Mirror Video</p>
                    <p className="text-xs text-gray-400">Flip your video horizontally</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input type="checkbox" className="sr-only peer" defaultChecked />
                    <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-blue-500 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-500"></div>
                  </label>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-white">HD Video</p>
                    <p className="text-xs text-gray-400">Use high-definition video quality</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input type="checkbox" className="sr-only peer" defaultChecked />
                    <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-blue-500 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-500"></div>
                  </label>
                </div>
              </div>
            )}

            {activeTab === 'audio' && (
              <div className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-white">Echo Cancellation</p>
                    <p className="text-xs text-gray-400">Reduce audio feedback</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input type="checkbox" className="sr-only peer" defaultChecked />
                    <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-blue-500 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-500"></div>
                  </label>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-white">Noise Suppression</p>
                    <p className="text-xs text-gray-400">Filter background noise</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input type="checkbox" className="sr-only peer" defaultChecked />
                    <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-blue-500 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-500"></div>
                  </label>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-white">Auto Gain Control</p>
                    <p className="text-xs text-gray-400">Automatically adjust volume</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input type="checkbox" className="sr-only peer" defaultChecked />
                    <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-blue-500 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-500"></div>
                  </label>
                </div>
              </div>
            )}

            {activeTab === 'security' && (
              <div className="space-y-6">
                <div className="bg-green-500/10 border border-green-500/30 rounded-lg p-4">
                  <div className="flex items-center gap-3 mb-2">
                    <Shield className="w-5 h-5 text-green-400" />
                    <h3 className="text-sm font-semibold text-green-400">
                      End-to-End Encryption Active
                    </h3>
                  </div>
                  <p className="text-xs text-gray-300 leading-relaxed">
                    All video, audio, and data in this conference is encrypted end-to-end using AES-256 encryption. 
                    Only participants in this call can decrypt and view the content.
                  </p>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-300">Encryption Protocol</span>
                    <span className="text-sm text-white font-medium">AES-256-GCM</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-300">Key Exchange</span>
                    <span className="text-sm text-white font-medium">ECDHE</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-300">Perfect Forward Secrecy</span>
                    <span className="text-sm text-green-400 font-medium">Enabled</span>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-4 border-t border-gray-700">
                  <div>
                    <p className="text-sm font-medium text-white">Encrypt Transcripts</p>
                    <p className="text-xs text-gray-400">Apply E2EE to all transcriptions</p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input type="checkbox" className="sr-only peer" defaultChecked />
                    <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-blue-500 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-500"></div>
                  </label>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end gap-3 p-6 border-t border-gray-700">
          <Button variant="secondary" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={onClose}>
            Save Changes
          </Button>
        </div>
      </div>
    </div>
  );
};

export default SettingsModal;