import React from 'react';
import { Video, VideoOff, Mic, MicOff, Shield, ShieldCheck, Wifi } from 'lucide-react';

const ParticipantGrid = ({ participants, localVideoRef, isLocalVideoEnabled, isLocalAudioEnabled, encryptionEnabled }) => {
  const allParticipants = [
    {
      id: 'local',
      name: 'You',
      isVideoOn: isLocalVideoEnabled,
      isAudioOn: isLocalAudioEnabled,
      isLocal: true,
      encryptionVerified: true,
      connectionQuality: 'excellent'
    },
    ...participants
  ];

  const getGridClass = (count) => {
    if (count === 1) return 'grid-cols-1';
    if (count === 2) return 'grid-cols-2';
    if (count <= 4) return 'grid-cols-2';
    if (count <= 9) return 'grid-cols-3';
    if (count <= 16) return 'grid-cols-4';
    return 'grid-cols-5';
  };

  const getConnectionColor = (quality) => {
    switch (quality) {
      case 'excellent': return 'text-green-400';
      case 'good': return 'text-blue-400';
      case 'fair': return 'text-yellow-400';
      case 'poor': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  return (
    <div className="h-full p-4 overflow-auto">
      <div className={`grid ${getGridClass(allParticipants?.length)} gap-4 auto-rows-fr`}>
        {allParticipants?.map((participant) => (
          <div
            key={participant?.id}
            className="relative bg-gray-800 rounded-lg overflow-hidden aspect-video flex items-center justify-center group"
          >
            {/* Video Stream */}
            {participant?.isLocal && participant?.isVideoOn ? (
              <video
                ref={localVideoRef}
                autoPlay
                muted
                playsInline
                className="w-full h-full object-cover"
              />
            ) : participant?.isVideoOn ? (
              <div className="w-full h-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
                <div className="text-6xl font-bold text-white opacity-50">
                  {participant?.name?.charAt(0)?.toUpperCase()}
                </div>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center gap-3">
                <div className="w-20 h-20 rounded-full bg-gray-700 flex items-center justify-center">
                  <span className="text-3xl font-bold text-gray-300">
                    {participant?.name?.charAt(0)?.toUpperCase()}
                  </span>
                </div>
                <VideoOff className="w-6 h-6 text-gray-500" />
              </div>
            )}

            {/* Participant Info Overlay */}
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium">{participant?.name}</span>
                  {participant?.isLocal && (
                    <span className="px-2 py-0.5 bg-blue-500/30 text-blue-300 text-xs rounded">
                      You
                    </span>
                  )}
                </div>
                
                <div className="flex items-center gap-2">
                  {/* Encryption Indicator */}
                  {encryptionEnabled && participant?.encryptionVerified && (
                    <ShieldCheck className="w-4 h-4 text-green-400" title="E2EE Verified" />
                  )}
                  
                  {/* Connection Quality */}
                  <Wifi className={`w-4 h-4 ${getConnectionColor(participant?.connectionQuality)}`} />
                  
                  {/* Audio Status */}
                  {participant?.isAudioOn ? (
                    <Mic className="w-4 h-4 text-green-400" />
                  ) : (
                    <MicOff className="w-4 h-4 text-red-400" />
                  )}
                </div>
              </div>
            </div>

            {/* Speaking Indicator */}
            {participant?.isAudioOn && (
              <div className="absolute top-2 left-2 right-2">
                <div className="h-1 bg-green-400/30 rounded-full overflow-hidden">
                  <div className="h-full bg-green-400 w-0 animate-pulse"></div>
                </div>
              </div>
            )}

            {/* Encryption Badge */}
            {encryptionEnabled && (
              <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                <div className="bg-black/60 backdrop-blur-sm px-2 py-1 rounded flex items-center gap-1">
                  <Shield className="w-3 h-3 text-green-400" />
                  <span className="text-xs text-green-400 font-medium">E2EE</span>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default ParticipantGrid;