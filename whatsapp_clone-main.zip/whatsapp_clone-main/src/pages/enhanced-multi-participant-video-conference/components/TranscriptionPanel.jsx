import React, { useState, useRef, useEffect } from 'react';
import { X, Download, Search, Edit2, Globe, Sparkles, ChevronDown } from 'lucide-react';
import Button from '../../../components/ui/Button';


const TranscriptionPanel = ({ transcripts, isEnabled, onClose, onExport }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedLanguage, setSelectedLanguage] = useState('en');
  const [showLanguages, setShowLanguages] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [editText, setEditText] = useState('');
  const transcriptEndRef = useRef(null);

  const languages = [
    { code: 'en', name: 'English', flag: '🇺🇸' },
    { code: 'es', name: 'Spanish', flag: '🇪🇸' },
    { code: 'fr', name: 'French', flag: '🇫🇷' },
    { code: 'de', name: 'German', flag: '🇩🇪' },
    { code: 'it', name: 'Italian', flag: '🇮🇹' },
    { code: 'pt', name: 'Portuguese', flag: '🇵🇹' },
    { code: 'ru', name: 'Russian', flag: '🇷🇺' },
    { code: 'ja', name: 'Japanese', flag: '🇯🇵' },
    { code: 'zh', name: 'Chinese', flag: '🇨🇳' },
    { code: 'ko', name: 'Korean', flag: '🇰🇷' }
  ];

  useEffect(() => {
    transcriptEndRef?.current?.scrollIntoView({ behavior: 'smooth' });
  }, [transcripts]);

  const filteredTranscripts = transcripts?.filter(t =>
    t?.text?.toLowerCase()?.includes(searchQuery?.toLowerCase()) ||
    t?.speaker?.toLowerCase()?.includes(searchQuery?.toLowerCase())
  );

  const getConfidenceColor = (confidence) => {
    if (confidence >= 0.9) return 'text-green-400';
    if (confidence >= 0.7) return 'text-yellow-400';
    return 'text-red-400';
  };

  const formatTime = (timestamp) => {
    const date = new Date(timestamp);
    return date?.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  };

  const handleEdit = (transcript) => {
    setEditingId(transcript?.id);
    setEditText(transcript?.text);
  };

  const handleSaveEdit = (id) => {
    console.log(`Saving edited transcript ${id}: ${editText}`);
    setEditingId(null);
    setEditText('');
  };

  const exportFormats = [
    { value: 'txt', label: 'Plain Text (.txt)' },
    { value: 'json', label: 'JSON (.json)' },
    { value: 'srt', label: 'Subtitles (.srt)' },
    { value: 'vtt', label: 'WebVTT (.vtt)' },
    { value: 'docx', label: 'Word Document (.docx)' }
  ];

  return (
    <div className="absolute right-0 top-0 bottom-0 w-96 bg-gray-800 border-l border-gray-700 flex flex-col shadow-2xl">
      {/* Header */}
      <div className="bg-gray-900 border-b border-gray-700 p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-blue-400" />
            <h2 className="text-lg font-semibold">Live Transcription</h2>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="text-gray-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </Button>
        </div>

        {/* Status Indicator */}
        <div className="flex items-center gap-2 mb-3">
          <div className={`w-2 h-2 rounded-full ${isEnabled ? 'bg-green-400 animate-pulse' : 'bg-gray-500'}`}></div>
          <span className="text-sm text-gray-400">
            {isEnabled ? 'Active - OpenAI Whisper' : 'Inactive'}
          </span>
        </div>

        {/* Language Selector */}
        <div className="relative">
          <button
            onClick={() => setShowLanguages(!showLanguages)}
            className="w-full bg-gray-700 hover:bg-gray-600 rounded-lg px-3 py-2 flex items-center justify-between text-sm transition-colors"
          >
            <div className="flex items-center gap-2">
              <Globe className="w-4 h-4 text-blue-400" />
              <span>{languages?.find(l => l?.code === selectedLanguage)?.flag}</span>
              <span>{languages?.find(l => l?.code === selectedLanguage)?.name}</span>
            </div>
            <ChevronDown className={`w-4 h-4 transition-transform ${showLanguages ? 'rotate-180' : ''}`} />
          </button>

          {showLanguages && (
            <div className="absolute top-full left-0 right-0 mt-1 bg-gray-700 rounded-lg shadow-lg max-h-60 overflow-auto z-10">
              {languages?.map((lang) => (
                <button
                  key={lang?.code}
                  onClick={() => {
                    setSelectedLanguage(lang?.code);
                    setShowLanguages(false);
                  }}
                  className="w-full px-3 py-2 hover:bg-gray-600 flex items-center gap-2 text-sm transition-colors"
                >
                  <span>{lang?.flag}</span>
                  <span>{lang?.name}</span>
                  {selectedLanguage === lang?.code && (
                    <span className="ml-auto text-blue-400">✓</span>
                  )}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Search */}
        <div className="mt-3 relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            type="text"
            placeholder="Search transcripts..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e?.target?.value)}
            className="w-full bg-gray-700 rounded-lg pl-10 pr-3 py-2 text-sm text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
        </div>
      </div>
      {/* Transcripts List */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {filteredTranscripts?.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-gray-400">
            <Sparkles className="w-12 h-12 mb-3 opacity-50" />
            <p className="text-sm text-center">
              {isEnabled
                ? 'Waiting for speech...'
                : 'Enable transcription to start capturing speech'}
            </p>
          </div>
        ) : (
          filteredTranscripts?.map((transcript) => (
            <div
              key={transcript?.id}
              className="bg-gray-700 rounded-lg p-3 hover:bg-gray-600 transition-colors group"
            >
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center text-sm font-medium">
                    {transcript?.speaker?.charAt(0)?.toUpperCase()}
                  </div>
                  <div>
                    <p className="text-sm font-medium">{transcript?.speaker}</p>
                    <p className="text-xs text-gray-400">{formatTime(transcript?.timestamp)}</p>
                  </div>
                </div>
                
                <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleEdit(transcript)}
                    className="text-gray-400 hover:text-white"
                  >
                    <Edit2 className="w-3 h-3" />
                  </Button>
                  <span className={`text-xs ${getConfidenceColor(transcript?.confidence)}`}>
                    {Math.round(transcript?.confidence * 100)}%
                  </span>
                </div>
              </div>

              {editingId === transcript?.id ? (
                <div className="space-y-2">
                  <textarea
                    value={editText}
                    onChange={(e) => setEditText(e?.target?.value)}
                    className="w-full bg-gray-800 rounded px-2 py-1 text-sm text-white resize-none focus:outline-none focus:ring-2 focus:ring-blue-500"
                    rows={3}
                  />
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      onClick={() => handleSaveEdit(transcript?.id)}
                      className="flex-1"
                    >
                      Save
                    </Button>
                    <Button
                      variant="secondary"
                      size="sm"
                      onClick={() => {
                        setEditingId(null);
                        setEditText('');
                      }}
                      className="flex-1"
                    >
                      Cancel
                    </Button>
                  </div>
                </div>
              ) : (
                <p className="text-sm text-gray-200 leading-relaxed">{transcript?.text}</p>
              )}
            </div>
          ))
        )}
        <div ref={transcriptEndRef} />
      </div>
      {/* Export Options */}
      <div className="bg-gray-900 border-t border-gray-700 p-4">
        <p className="text-xs text-gray-400 mb-2">Export transcript as:</p>
        <div className="grid grid-cols-2 gap-2">
          {exportFormats?.slice(0, 4)?.map((format) => (
            <Button
              key={format?.value}
              variant="secondary"
              size="sm"
              onClick={() => onExport(format?.value)}
              className="text-xs"
            >
              <Download className="w-3 h-3 mr-1" />
              {format?.value?.toUpperCase()}
            </Button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default TranscriptionPanel;