import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import ProfileSettingsTrigger from '../../components/ui/ProfileSettingsDropdown';

import PrivacySettings from './components/PrivacySettings';
import NotificationSettings from './components/NotificationSettings';
import SecuritySettings from './components/SecuritySettings';
import AppearanceSettings from './components/AppearanceSettings';
import DataSettings from './components/DataSettings';
import BackupRestoreSettings from './components/BackupRestoreSettings';
import { appearanceService } from '../../services/appearanceService';
import SettingsSection from './components/SettingsSection';
import SettingItem from './components/SettingItem';
import { useAuth } from '../../contexts/AuthContext';
import TranslationSettings from './components/TranslationSettings';

export default function UserProfileSettings() {
  const navigate = useNavigate();
  const { user, loading: authLoading, isAuthenticated } = useAuth();

  const [settings, setSettings] = useState({
    theme: 'system',
    font_size: 'medium',
    wallpaper_url: null,
    wallpaper_type: 'default',
    language: 'en',
    compactMode: false,
    showAnimations: true
  });

  const [userProfile, setUserProfile] = useState({
    name: 'Alex Morgan',
    status: 'Hey there! I am using ChatVybz',
    phone: '+1 (555) 123-4567',
    phoneVerified: true,
    avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_14e9c5480-1765308576801.png"
  });

  const [profile, setProfile] = useState({
    fullName: 'Alex Morgan',
    email: 'alex.morgan@example.com',
    countryCode: 'US'
  });

  const [privacySettings, setPrivacySettings] = useState({
    showOnlineStatus: true,
    profilePhotoVisibility: 'everyone',
    lastSeenVisibility: 'contacts',
    readReceipts: true,
    statusVisibility: 'contacts',
    groupsVisibility: 'contacts'
  });

  const [notificationSettings, setNotificationSettings] = useState({
    messageNotifications: true,
    notificationSound: 'default',
    desktopNotifications: true,
    groupNotifications: true,
    showPreview: true,
    vibrate: true
  });

  const [securitySettings, setSecuritySettings] = useState({
    twoFactorEnabled: false
  });

  const [appearanceSettings, setAppearanceSettings] = useState({
    theme: 'system',
    language: 'en',
    compactMode: false,
    showAnimations: true
  });

  const [dataSettings, setDataSettings] = useState({
    autoBackup: true,
    includeMediaInBackup: true,
    mediaAutoDownload: true,
    lowDataMode: false
  });

  const [translationSettings, setTranslationSettings] = useState({
    autoTranslateEnabled: false,
    translationPreference: 'ask_before',
    doNotTranslateLanguages: [],
    preferredTranslationLanguage: 'en',
    translateEntireChats: false
  });

  const [activeSection, setActiveSection] = useState('profile');

  const handleUpdateProfile = (updates) => {
    setUserProfile((prev) => ({ ...prev, ...updates }));
    setProfile((prev) => ({ ...prev, ...updates }));
  };

  const handleUpdatePrivacy = (updates) => {
    setPrivacySettings((prev) => ({ ...prev, ...updates }));
  };

  const handleUpdateNotifications = (updates) => {
    setNotificationSettings((prev) => ({ ...prev, ...updates }));
  };

  const handleUpdateSecurity = (updates) => {
    setSecuritySettings((prev) => ({ ...prev, ...updates }));
  };

  const handleUpdateAppearance = (updates) => {
    setAppearanceSettings((prev) => ({ ...prev, ...updates }));
  };

  const handleUpdateData = (updates) => {
    setDataSettings((prev) => ({ ...prev, ...updates }));
  };

  const handleUpdateTranslation = (updates) => {
    setTranslationSettings((prev) => ({ ...prev, ...updates }));
  };

  useEffect(() => {
    // Redirect to login if not authenticated
    if (!authLoading && !isAuthenticated) {
      navigate('/login');
      return;
    }

    const loadSettings = async () => {
      if (!user?.id) return;

      try {
        // Load appearance settings
        const appearanceData = await appearanceService?.getAppearanceSettings(user?.id);
        setSettings((prev) => ({
          ...prev,
          theme: appearanceData?.theme,
          font_size: appearanceData?.font_size,
          wallpaper_url: appearanceData?.wallpaper_url,
          wallpaper_type: appearanceData?.wallpaper_type,
          language: appearanceData?.language,
          compactMode: appearanceData?.compact_mode,
          showAnimations: appearanceData?.show_animations
        }));

        // Apply settings on load
        appearanceService?.applyTheme(appearanceData?.theme);
        appearanceService?.applyFontSize(appearanceData?.font_size);

        // Load translation settings
        const { getTranslationSettings } = await import('../../services/translationService');
        const translationData = await getTranslationSettings(user?.id);
        setTranslationSettings(translationData);
      } catch (error) {
        console.error('Failed to load settings:', error);
      }
    };

    loadSettings();
  }, [user?.id, authLoading, isAuthenticated, navigate]);

  const handleUpdateSettings = async (newSettings) => {
    const updatedSettings = { ...settings, ...newSettings };
    setSettings(updatedSettings);

    if (!user?.id) return;

    try {
      // Update appearance settings in database
      await appearanceService?.updateAppearanceSettings(user?.id, {
        theme: updatedSettings?.theme,
        font_size: updatedSettings?.font_size,
        wallpaper_url: updatedSettings?.wallpaper_url,
        wallpaper_type: updatedSettings?.wallpaper_type,
        language: updatedSettings?.language,
        compact_mode: updatedSettings?.compactMode,
        show_animations: updatedSettings?.showAnimations
      });

      // Update translation settings if changed
      if (newSettings?.autoTranslateEnabled !== undefined ||
      newSettings?.translationPreference !== undefined ||
      newSettings?.doNotTranslateLanguages !== undefined ||
      newSettings?.preferredTranslationLanguage !== undefined ||
      newSettings?.translateEntireChats !== undefined) {
        const { updateTranslationSettings } = await import('../../services/translationService');
        await updateTranslationSettings(user?.id, {
          ...translationSettings,
          ...newSettings
        });
      }
    } catch (error) {
      console.error('Failed to update settings:', error);
    }
  };

  const sections = [
  { id: 'profile', label: 'Profile', icon: 'User' },
  { id: 'privacy', label: 'Privacy', icon: 'Lock' },
  { id: 'notifications', label: 'Notifications', icon: 'Bell' },
  { id: 'security', label: 'Security', icon: 'Shield' },
  { id: 'appearance', label: 'Appearance', icon: 'Palette' },
  { id: 'data', label: 'Data & Storage', icon: 'Database' }];


  // Show loading state while authenticating
  if (authLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading...</p>
        </div>
      </div>);

  }

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-card border-b border-border">
        <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 md:h-20">
            <div className="flex items-center gap-3 md:gap-4">
              <button
                onClick={() => navigate('/main-chat-interface')}
                className="p-2 rounded-lg hover:bg-muted transition-colors focus-ring"
                aria-label="Back to chats">

                <Icon name="ArrowLeft" size={24} color="var(--color-foreground)" />
              </button>
              <div>
                <h1 className="text-lg md:text-xl lg:text-2xl font-bold text-foreground">
                  Settings
                </h1>
                <p className="text-xs md:text-sm text-muted-foreground hidden md:block">
                  Manage your account preferences
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 md:gap-3">
              <Button
                variant="outline"
                size="sm"
                iconName="Save"
                iconPosition="left"
                onClick={() => console.log('Settings saved')}
                className="hidden md:flex">

                Save Changes
              </Button>
              <ProfileSettingsTrigger />
            </div>
          </div>
        </div>
      </header>

      {/* Settings sections */}
      <div className="max-w-4xl mx-auto px-4 py-6 space-y-6">
        {/* Account Settings */}
        <SettingsSection
          title="Account"
          description="Manage your account information"
          icon={<svg className="w-5 h-5 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>}>
          <SettingItem
            icon={<svg className="w-5 h-5 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>}
            label="Name"
            title="Name"
            description="Your display name"
            value={profile?.fullName}
            onChange={(value) => handleUpdateProfile({ fullName: value })} />

          <SettingItem
            icon={<svg className="w-5 h-5 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>}
            label="Email"
            title="Email"
            description="Your email address"
            value={profile?.email}
            type="email"
            disabled
            onChange={() => {}} />

          <SettingItem
            icon={<svg className="w-5 h-5 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>}
            label="Country / Timezone"
            title="Country / Timezone"
            description="Your country and local timezone"
            value={profile?.countryCode}
            type="country"
            onChange={(value) => handleUpdateProfile({ countryCode: value })} />

        </SettingsSection>

        {/* Privacy Settings */}
        <PrivacySettings
          settings={privacySettings}
          onUpdateSettings={handleUpdatePrivacy} />

        {/* Notifications Settings */}
        <NotificationSettings
          settings={notificationSettings}
          onUpdateSettings={handleUpdateNotifications} />

        {/* Security Settings */}
        <SecuritySettings
          settings={securitySettings}
          onUpdateSettings={handleUpdateSecurity} />

        {/* Appearance Settings */}
        <AppearanceSettings
          settings={appearanceSettings}
          onUpdateSettings={handleUpdateAppearance} />

        {/* Translation Settings */}
        <TranslationSettings
          settings={translationSettings}
          onUpdateSettings={(updates) => {
            handleUpdateTranslation(updates);
            handleUpdateSettings(updates);
          }} />

        {/* Data Settings */}
        <DataSettings
          settings={dataSettings}
          onUpdateSettings={handleUpdateData} />

        {/* Backup & Restore */}
        {activeSection === 'data' &&
        <div className="border-t border-border pt-6">
            <BackupRestoreSettings userId={user?.id} />
          </div>
        }
      </div>

      {/* Footer */}
      <footer className="bg-card border-t border-border mt-12 md:mt-16 lg:mt-20">
        <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8 py-6 md:py-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="text-center md:text-left">
              <p className="text-sm md:text-base text-muted-foreground">
                © {new Date()?.getFullYear()} ChatVybz. All rights reserved.
              </p>
            </div>
            <div className="flex items-center gap-4 md:gap-6">
              <button
                onClick={() => navigate('/main-chat-interface')}
                className="text-sm md:text-base text-muted-foreground hover:text-foreground transition-colors">

                Help Center
              </button>
              <button
                onClick={() => navigate('/main-chat-interface')}
                className="text-sm md:text-base text-muted-foreground hover:text-foreground transition-colors">

                Privacy Policy
              </button>
              <button
                onClick={() => navigate('/main-chat-interface')}
                className="text-sm md:text-base text-muted-foreground hover:text-foreground transition-colors">

                Terms of Service
              </button>
            </div>
          </div>
        </div>
      </footer>
    </div>);

}