import React, { useState, useEffect, useRef } from 'react';
import { chatBackupService } from '../../../services/chatBackupService';
import Button from '../../../components/ui/Button';

import { Download, Upload, Trash2, HardDrive, AlertCircle, CheckCircle, Clock } from 'lucide-react';

export default function BackupRestoreSettings({ userId }) {
  const [backups, setBackups] = useState([]);
  const [loading, setLoading] = useState(false);
  const [creating, setCreating] = useState(false);
  const [restoring, setRestoring] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  const fileInputRef = React.useRef(null);

  useEffect(() => {
    if (userId) {
      loadBackups();
    }
  }, [userId]);

  const loadBackups = async () => {
    try {
      setLoading(true);
      const backupList = await chatBackupService?.listBackups(userId);
      setBackups(backupList);
    } catch (err) {
      console.error('Error loading backups:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateBackup = async () => {
    try {
      setCreating(true);
      setError(null);
      setSuccess(null);

      const result = await chatBackupService?.createChatBackup(userId);
      
      setSuccess(`Backup created successfully! ${result?.messageCount} messages backed up.`);
      await loadBackups();
    } catch (err) {
      setError(err?.message || 'Failed to create backup');
    } finally {
      setCreating(false);
    }
  };

  const handleRestoreBackup = async (event) => {
    const file = event?.target?.files?.[0];
    if (!file) return;

    try {
      setRestoring(true);
      setError(null);
      setSuccess(null);

      const result = await chatBackupService?.restoreChatBackup(userId, file);
      
      setSuccess(
        `Restore completed! ${result?.restoredCount} messages restored, ${result?.skippedCount} skipped.`
      );
    } catch (err) {
      setError(err?.message || 'Failed to restore backup');
    } finally {
      setRestoring(false);
      if (fileInputRef?.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const handleDeleteBackup = async (backupId) => {
    if (!confirm('Are you sure you want to delete this backup?')) return;

    try {
      await chatBackupService?.deleteBackup(backupId, userId);
      setSuccess('Backup deleted successfully');
      await loadBackups();
    } catch (err) {
      setError(err?.message || 'Failed to delete backup');
    }
  };

  const formatFileSize = (bytes) => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024)?.toFixed(2) + ' KB';
    return (bytes / (1024 * 1024))?.toFixed(2) + ' MB';
  };

  const formatDate = (dateString) => {
    return new Date(dateString)?.toLocaleString();
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h3 className="text-lg font-semibold text-foreground mb-2 flex items-center gap-2">
          <HardDrive size={20} />
          Chat Backup & Restore
        </h3>
        <p className="text-sm text-muted-foreground">
          Create backups of your chat history and restore them when needed
        </p>
      </div>
      {/* Error/Success Messages */}
      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-start gap-3">
          <AlertCircle size={20} className="text-red-600 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-semibold text-red-800">Error</p>
            <p className="text-sm text-red-600">{error}</p>
          </div>
        </div>
      )}
      {success && (
        <div className="bg-green-50 border border-green-200 rounded-lg p-4 flex items-start gap-3">
          <CheckCircle size={20} className="text-green-600 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-semibold text-green-800">Success</p>
            <p className="text-sm text-green-600">{success}</p>
          </div>
        </div>
      )}
      {/* Action Buttons */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Button
          onClick={handleCreateBackup}
          loading={creating}
          disabled={creating}
          iconName="Download"
          iconPosition="left"
          fullWidth
        >
          {creating ? 'Creating Backup...' : 'Create Backup'}
        </Button>

        <div>
          <input
            ref={fileInputRef}
            type="file"
            accept=".json"
            onChange={handleRestoreBackup}
            className="hidden"
            id="restore-backup-input"
          />
          <Button
            onClick={() => fileInputRef?.current?.click()}
            loading={restoring}
            disabled={restoring}
            variant="outline"
            iconName="Upload"
            iconPosition="left"
            fullWidth
          >
            {restoring ? 'Restoring...' : 'Restore from File'}
          </Button>
        </div>
      </div>
      {/* Backup List */}
      <div>
        <h4 className="font-semibold text-foreground mb-3 flex items-center gap-2">
          <Clock size={18} />
          Recent Backups
        </h4>

        {loading ? (
          <div className="text-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
            <p className="text-sm text-muted-foreground mt-2">Loading backups...</p>
          </div>
        ) : backups?.length === 0 ? (
          <div className="text-center py-8 bg-muted/50 rounded-lg">
            <HardDrive size={48} className="text-muted-foreground mx-auto mb-3" />
            <p className="text-sm text-muted-foreground">No backups found</p>
            <p className="text-xs text-muted-foreground mt-1">
              Create your first backup to get started
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {backups?.map((backup) => (
              <div
                key={backup?.id}
                className="p-4 border border-border rounded-lg bg-card hover:border-primary transition-colors"
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <HardDrive size={16} className="text-primary flex-shrink-0" />
                      <h5 className="font-semibold text-foreground text-sm truncate">
                        {backup?.file_name}
                      </h5>
                    </div>
                    <div className="space-y-1">
                      <p className="text-xs text-muted-foreground">
                        {backup?.message_count} messages • {formatFileSize(backup?.file_size)}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        Created: {formatDate(backup?.created_at)}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {backup?.file_url && (
                      <a
                        href={backup?.file_url}
                        download={backup?.file_name}
                        className="p-2 rounded-lg hover:bg-muted transition-colors"
                        title="Download backup"
                      >
                        <Download size={18} className="text-primary" />
                      </a>
                    )}
                    <button
                      onClick={() => handleDeleteBackup(backup?.id)}
                      className="p-2 rounded-lg hover:bg-red-50 transition-colors"
                      title="Delete backup"
                    >
                      <Trash2 size={18} className="text-red-600" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      {/* Info Box */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <h4 className="text-sm font-semibold text-blue-900 mb-2">
          About Chat Backups
        </h4>
        <ul className="space-y-1 text-xs text-blue-700">
          <li className="flex items-start gap-2">
            <span className="text-blue-500 mt-0.5">•</span>
            <span>Backups include all your messages, attachments, and reactions</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-blue-500 mt-0.5">•</span>
            <span>Encrypted messages remain encrypted in backups</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-blue-500 mt-0.5">•</span>
            <span>Backups are stored securely in cloud storage</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-blue-500 mt-0.5">•</span>
            <span>You can download backups for offline storage</span>
          </li>
        </ul>
      </div>
    </div>
  );
}
