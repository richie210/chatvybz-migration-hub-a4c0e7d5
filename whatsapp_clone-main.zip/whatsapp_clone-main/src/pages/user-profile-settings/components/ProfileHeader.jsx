import React, { useState, useRef, useEffect } from 'react';
import Icon from '../../../components/AppIcon';


import { COUNTRY_NAMES, getCurrentTimeInTimezone, getTimezoneForCountry } from '../../../utils/timezoneUtils';

function ProfileHeader({ profile, onEdit }) {
  const [isEditing, setIsEditing] = useState(false);
  const [editedName, setEditedName] = useState(profile?.name);
  const [editedStatus, setEditedStatus] = useState(profile?.status);
  const [currentTime, setCurrentTime] = useState('');

  const fileInputRef = useRef(null);

  // Update current time every minute
  useEffect(() => {
    if (!profile?.countryCode) return;

    const updateTime = () => {
      const timezone = getTimezoneForCountry(profile?.countryCode);
      setCurrentTime(getCurrentTimeInTimezone(timezone));
    };

    updateTime();
    const interval = setInterval(updateTime, 60000); // Update every minute

    return () => clearInterval(interval);
  }, [profile?.countryCode]);

  const handleSave = () => {
    onEdit({
      name: editedName,
      status: editedStatus
    });
    setIsEditing(false);
  };

  const handleCancel = () => {
    setEditedName(profile?.name);
    setEditedStatus(profile?.status);
    setIsEditing(false);
  };

  const handlePhotoUpload = (event) => {
    const file = event?.target?.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        onEdit({ avatar: reader?.result });
      };
      reader?.readAsDataURL(file);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-start gap-6">
        {/* Avatar */}
        <img
          src={profile?.avatarUrl || '/default-avatar.png'}
          alt={profile?.fullName}
          className="w-24 h-24 rounded-full object-cover"
        />

        {/* Profile info */}
        <div className="flex-1">
          <div className="flex items-center justify-between mb-2">
            <h2 className="text-2xl font-bold text-gray-900">{profile?.fullName}</h2>
            <button
              onClick={onEdit}
              className="px-4 py-2 text-sm bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
            >
              Edit Profile
            </button>
          </div>

          <p className="text-gray-600 mb-4">{profile?.email}</p>

          {/* Country and timezone info */}
          {profile?.countryCode && (
            <div className="flex items-center gap-4 text-sm">
              <div className="flex items-center gap-2">
                <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <span className="text-gray-700 font-medium">
                  {COUNTRY_NAMES?.[profile?.countryCode] || profile?.countryCode}
                </span>
              </div>

              {currentTime && (
                <div className="flex items-center gap-2">
                  <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  <span className="text-gray-700 font-medium">Local time: {currentTime}</span>
                </div>
              )}
            </div>
          )}

          {/* Profile stats */}
          <div className="mt-4 space-y-2">
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <Icon name="Phone" size={16} color="var(--color-muted-foreground)" />
              <span className="font-mono">{profile?.phone}</span>
              {profile?.phoneVerified && (
                <div className="flex items-center gap-1 text-success">
                  <Icon name="CheckCircle" size={16} color="var(--color-success)" />
                  <span className="text-xs">Verified</span>
                </div>
              )}
            </div>
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <Icon name="Calendar" size={16} color="var(--color-muted-foreground)" />
              <span>{profile?.birthDate ? new Date(profile.birthDate)?.toLocaleDateString() : 'N/A'}</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <Icon name="Location" size={16} color="var(--color-muted-foreground)" />
              <span>{profile?.location || 'N/A'}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ProfileHeader;