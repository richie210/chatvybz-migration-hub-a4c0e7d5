import React from 'react';
import SettingsSection from './SettingsSection';
import SettingItem from './SettingItem';

const NotificationSettings = ({ settings, onUpdateSettings }) => {
  const soundOptions = [
    { value: 'default', label: 'Default' },
    { value: 'chime', label: 'Chime' },
    { value: 'bell', label: 'Bell' },
    { value: 'ping', label: 'Ping' },
    { value: 'none', label: 'None' }
  ];

  return (
    <SettingsSection
      title="Notifications"
      description="Manage how you receive notifications"
      icon="Bell"
    >
      <SettingItem
        label="Message Notifications"
        description="Show notifications for new messages"
        value={settings?.messageNotifications}
        type="toggle"
        onChange={(value) => onUpdateSettings({ messageNotifications: value })}
        icon="MessageSquare"
      />
      <SettingItem
        label="Notification Sound"
        description="Choose notification sound"
        value={settings?.notificationSound}
        type="select"
        options={soundOptions}
        onChange={(value) => onUpdateSettings({ notificationSound: value })}
        icon="Volume2"
      />
      <SettingItem
        label="Desktop Notifications"
        description="Show notifications on desktop"
        value={settings?.desktopNotifications}
        type="toggle"
        onChange={(value) => onUpdateSettings({ desktopNotifications: value })}
        icon="Monitor"
      />
      <SettingItem
        label="Group Notifications"
        description="Receive notifications from groups"
        value={settings?.groupNotifications}
        type="toggle"
        onChange={(value) => onUpdateSettings({ groupNotifications: value })}
        icon="Users"
      />
      <SettingItem
        label="Show Preview"
        description="Show message preview in notifications"
        value={settings?.showPreview}
        type="toggle"
        onChange={(value) => onUpdateSettings({ showPreview: value })}
        icon="Eye"
      />
      <SettingItem
        label="Vibrate"
        description="Vibrate on new messages (mobile only)"
        value={settings?.vibrate}
        type="toggle"
        onChange={(value) => onUpdateSettings({ vibrate: value })}
        icon="Smartphone"
      />
    </SettingsSection>
  );
};

export default NotificationSettings;