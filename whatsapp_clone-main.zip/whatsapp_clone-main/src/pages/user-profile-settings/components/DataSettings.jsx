import React, { useState } from 'react';
import SettingsSection from './SettingsSection';
import SettingItem from './SettingItem';
import Button from '../../../components/ui/Button';
import Icon from '../../../components/AppIcon';

const DataSettings = ({ settings, onUpdateSettings }) => {
  const [backupStatus, setBackupStatus] = useState({
    lastBackup: '2025-12-20 14:30:00',
    size: '2.4 GB',
    status: 'completed'
  });

  const handleBackupNow = () => {
    setBackupStatus({
      ...backupStatus,
      status: 'in-progress'
    });
    
    setTimeout(() => {
      setBackupStatus({
        lastBackup: new Date()?.toISOString(),
        size: '2.5 GB',
        status: 'completed'
      });
    }, 3000);
  };

  const handleExportData = () => {
    console.log('Exporting chat data...');
  };

  const handleRestoreBackup = () => {
    console.log('Restoring from backup...');
  };

  return (
    <SettingsSection
      title="Data & Storage"
      description="Manage your chat backups and data"
      icon="Database"
    >
      <SettingItem
        label="Auto Backup"
        description="Automatically backup your chats"
        value={settings?.autoBackup}
        type="toggle"
        onChange={(value) => onUpdateSettings({ autoBackup: value })}
        icon="CloudUpload"
      />
      <div className="py-3 md:py-4 border-b border-border">
        <div className="flex items-start gap-3 mb-4">
          <Icon name="HardDrive" size={20} color="var(--color-muted-foreground)" />
          <div className="flex-1 min-w-0">
            <div className="text-sm md:text-base font-medium text-foreground mb-1">
              Backup Status
            </div>
            <div className="text-xs md:text-sm text-muted-foreground space-y-1">
              <div>Last backup: {new Date(backupStatus.lastBackup)?.toLocaleString()}</div>
              <div>Backup size: {backupStatus?.size}</div>
              <div className="flex items-center gap-2 mt-2">
                {backupStatus?.status === 'completed' && (
                  <>
                    <Icon name="CheckCircle" size={16} color="var(--color-success)" />
                    <span className="text-success">Backup completed</span>
                  </>
                )}
                {backupStatus?.status === 'in-progress' && (
                  <>
                    <Icon name="Loader" size={16} color="var(--color-primary)" className="animate-spin" />
                    <span className="text-primary">Backup in progress...</span>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
        <div className="flex flex-wrap gap-2 md:gap-3">
          <Button
            variant="default"
            size="sm"
            iconName="CloudUpload"
            iconPosition="left"
            onClick={handleBackupNow}
            disabled={backupStatus?.status === 'in-progress'}
          >
            Backup Now
          </Button>
          <Button
            variant="outline"
            size="sm"
            iconName="CloudDownload"
            iconPosition="left"
            onClick={handleRestoreBackup}
          >
            Restore
          </Button>
        </div>
      </div>
      <SettingItem
        label="Include Media in Backup"
        description="Backup photos, videos, and files"
        value={settings?.includeMediaInBackup}
        type="toggle"
        onChange={(value) => onUpdateSettings({ includeMediaInBackup: value })}
        icon="Image"
      />
      <div className="py-3 md:py-4 border-b border-border last:border-b-0">
        <div className="flex items-start gap-3 mb-4">
          <Icon name="Download" size={20} color="var(--color-muted-foreground)" />
          <div className="flex-1 min-w-0">
            <div className="text-sm md:text-base font-medium text-foreground mb-1">
              Export Chat Data
            </div>
            <div className="text-xs md:text-sm text-muted-foreground">
              Download all your chat history and media files
            </div>
          </div>
        </div>
        <Button
          variant="outline"
          size="sm"
          iconName="FileDown"
          iconPosition="left"
          onClick={handleExportData}
        >
          Export Data
        </Button>
      </div>
      <SettingItem
        label="Media Auto-Download"
        description="Automatically download media files"
        value={settings?.mediaAutoDownload}
        type="toggle"
        onChange={(value) => onUpdateSettings({ mediaAutoDownload: value })}
        icon="Download"
      />
      <SettingItem
        label="Low Data Mode"
        description="Reduce data usage"
        value={settings?.lowDataMode}
        type="toggle"
        onChange={(value) => onUpdateSettings({ lowDataMode: value })}
        icon="Wifi"
      />
    </SettingsSection>
  );
};

export default DataSettings;