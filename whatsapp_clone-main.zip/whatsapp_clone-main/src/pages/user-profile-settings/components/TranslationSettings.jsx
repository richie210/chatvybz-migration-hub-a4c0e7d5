import React from 'react';
import SettingsSection from './SettingsSection';
import SettingItem from './SettingItem';

export default function TranslationSettings({ settings, onUpdateSettings }) {
  return (
    <SettingsSection 
      title="Chat Translation" 
      description="Automatic message translation settings"
      icon={
        <svg className="w-5 h-5 text-purple-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5h12M9 3v2m1.048 9.5A18.022 18.022 0 016.412 9m6.088 9h7M11 21l5-10 5 10M12.751 5C11.783 10.77 8.07 15.61 3 18.129" />
        </svg>
      }
    >
      <SettingItem
        icon={
          <svg className="w-5 h-5 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
        }
        label="Message Translation"
        title="Message Translation"
        description="Automatically translate incoming messages to your preferred language"
        type="toggle"
        value={settings?.autoTranslateEnabled}
        onChange={(value) => onUpdateSettings({ autoTranslateEnabled: value })}
      />

      <SettingItem
        icon={
          <svg className="w-5 h-5 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
          </svg>
        }
        label="Translation Preference"
        title="Translate Entire Chats"
        description="Choose how translation works across all conversations"
        type="select"
        value={settings?.translationPreference}
        options={[
          { value: 'auto_all', label: 'Auto-translate All Messages' },
          { value: 'ask_before', label: 'Ask Me Before Translating' },
          { value: 'never', label: 'Never Translate' }
        ]}
        onChange={(value) => onUpdateSettings({ translationPreference: value })}
      />

      <SettingItem
        icon={
          <svg className="w-5 h-5 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9" />
          </svg>
        }
        label="Preferred Language"
        title="Preferred Translation Language"
        description="Language to translate messages into"
        type="select"
        value={settings?.preferredTranslationLanguage}
        options={[
          { value: 'en', label: 'English' },
          { value: 'es', label: 'Spanish (Español)' },
          { value: 'fr', label: 'French (Français)' },
          { value: 'de', label: 'German (Deutsch)' },
          { value: 'it', label: 'Italian (Italiano)' },
          { value: 'pt', label: 'Portuguese (Português)' },
          { value: 'ru', label: 'Russian (Русский)' },
          { value: 'zh', label: 'Chinese (中文)' },
          { value: 'ja', label: 'Japanese (日本語)' },
          { value: 'ko', label: 'Korean (한국어)' },
          { value: 'ar', label: 'Arabic (العربية)' },
          { value: 'hi', label: 'Hindi (हिन्दी)' }
        ]}
        onChange={(value) => onUpdateSettings({ preferredTranslationLanguage: value })}
      />

      <SettingItem
        icon={
          <svg className="w-5 h-5 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636" />
          </svg>
        }
        label="Do Not Translate"
        title="Do Not Translate"
        description="Select languages that should not show the Translate button"
        type="multiselect"
        value={settings?.doNotTranslateLanguages || []}
        options={[
          { value: 'en', label: 'English' },
          { value: 'es', label: 'Spanish' },
          { value: 'fr', label: 'French' },
          { value: 'de', label: 'German' },
          { value: 'it', label: 'Italian' },
          { value: 'pt', label: 'Portuguese' },
          { value: 'ru', label: 'Russian' },
          { value: 'zh', label: 'Chinese' },
          { value: 'ja', label: 'Japanese' },
          { value: 'ko', label: 'Korean' }
        ]}
        onChange={(value) => onUpdateSettings({ doNotTranslateLanguages: value })}
      />

      <SettingItem
        icon={
          <svg className="w-5 h-5 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
          </svg>
        }
        label="Translate Entire Chats"
        title="Translate Entire Chats"
        description="Automatically translate all messages in open conversations"
        type="toggle"
        value={settings?.translateEntireChats}
        onChange={(value) => onUpdateSettings({ translateEntireChats: value })}
      />

      <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
        <div className="flex gap-3">
          <svg className="w-5 h-5 text-blue-500 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          <div>
            <p className="text-sm font-medium text-blue-900 mb-1">How Translation Works</p>
            <ul className="text-xs text-blue-700 space-y-1">
              <li>• <strong>Auto-translate All Messages:</strong> Incoming messages are automatically translated</li>
              <li>• <strong>Ask Me Before Translating:</strong> A translate button appears for messages in other languages</li>
              <li>• <strong>Never Translate:</strong> Translation button is hidden for all messages</li>
              <li>• <strong>Do Not Translate:</strong> Selected languages will not trigger translation</li>
            </ul>
          </div>
        </div>
      </div>
    </SettingsSection>
  );
}