import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import { COUNTRY_NAMES, COUNTRY_TIMEZONES } from '../../../utils/timezoneUtils';
import { supabase } from '../../../lib/supabase';

export default function SettingItem({
  icon,
  label,
  title,
  description,
  value,
  onChange,
  type = 'text',
  options = [],
  disabled = false,
  placeholder
}) {
  const [countryCode, setCountryCode] = useState(value || 'US');

  // Handle country code change
  const handleCountryChange = async (newCode) => {
    setCountryCode(newCode);
    
    if (onChange) {
      onChange(newCode);
    }

    // Update timezone based on country
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (user) {
        const timezone = COUNTRY_TIMEZONES?.[newCode] || 'UTC';
        await supabase?.from('profiles')?.update({ 
            country_code: newCode,
            timezone: timezone
          })?.eq('id', user?.id);
      }
    } catch (error) {
      console.error('Error updating country/timezone:', error);
    }
  };

  const renderInput = () => {
    switch (type) {
      case 'toggle':
        return (
          <button
            onClick={() => onChange(!value)}
            className={`relative w-12 h-6 md:w-14 md:h-7 rounded-full transition-colors focus-ring ${
              value ? 'bg-primary' : 'bg-muted'
            }`}
            aria-label={`Toggle ${label}`}
            role="switch"
            aria-checked={value}
          >
            <div
              className={`absolute top-1 w-4 h-4 md:w-5 md:h-5 rounded-full bg-white shadow-md transition-transform ${
                value ? 'translate-x-7 md:translate-x-8' : 'translate-x-1'
              }`}
            />
          </button>
        );
      
      case 'select':
        return (
          <select
            value={value}
            onChange={(e) => onChange(e?.target?.value)}
            className="px-3 py-2 md:px-4 md:py-2 text-sm md:text-base bg-background border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary min-w-[120px] md:min-w-[150px]"
          >
            {options?.map((option) => (
              <option key={option?.value} value={option?.value}>
                {option?.label}
              </option>
            ))}
          </select>
        );
      
      case 'button':
        return (
          <button
            onClick={onChange}
            className={`px-4 py-2 md:px-6 md:py-2 text-sm md:text-base rounded-lg font-medium transition-colors focus-ring ${
              disabled
                ? 'bg-muted text-muted-foreground cursor-not-allowed'
                : 'bg-primary text-primary-foreground hover:bg-primary/90'
            }`}
          >
            {value}
          </button>
        );
      
      case 'multiselect':
        return (
          <div className="relative">
            <div className="flex flex-wrap gap-2 mb-2">
              {(value || [])?.map((selectedValue) => {
                const option = options?.find(opt => opt?.value === selectedValue);
                return option ? (
                  <span
                    key={selectedValue}
                    className="inline-flex items-center gap-1 px-3 py-1 bg-primary/10 text-primary rounded-full text-sm"
                  >
                    {option?.label}
                    <button
                      onClick={() => {
                        const newValue = (value || [])?.filter(v => v !== selectedValue);
                        onChange(newValue);
                      }}
                      className="hover:bg-primary/20 rounded-full p-0.5"
                      aria-label={`Remove ${option?.label}`}
                    >
                      <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                      </svg>
                    </button>
                  </span>
                ) : null;
              })}
            </div>
            <select
              value=""
              onChange={(e) => {
                if (e?.target?.value && !(value || [])?.includes(e?.target?.value)) {
                  onChange([...(value || []), e?.target?.value]);
                }
              }}
              className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent disabled:bg-gray-100 disabled:cursor-not-allowed"
              disabled={disabled}
            >
              <option value="">Select language to add...</option>
              {options
                ?.filter(option => !(value || [])?.includes(option?.value))
                ?.map((option) => (
                  <option key={option?.value} value={option?.value}>
                    {option?.label}
                  </option>
                ))}
            </select>
          </div>
        );
      
      default:
        return null;
    }
  };

  // Add country selector type
  if (type === 'country') {
    return (
      <div className="flex items-center justify-between p-4 hover:bg-gray-50 rounded-lg transition-colors">
        <div className="flex items-center gap-4">
          <div className="p-2 bg-blue-50 rounded-lg">
            {icon}
          </div>
          <div>
            <h3 className="font-medium text-gray-900">{label}</h3>
            {description && <p className="text-sm text-gray-500">{description}</p>}
          </div>
        </div>
        <select
          value={countryCode}
          onChange={(e) => handleCountryChange(e?.target?.value)}
          className="px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
          {Object.entries(COUNTRY_NAMES)?.map(([code, name]) => (
            <option key={code} value={code}>
              {name}
            </option>
          ))}
        </select>
      </div>
    );
  }

  return (
    <div className="flex items-center justify-between gap-4 py-3 md:py-4 border-b border-border last:border-b-0">
      <div className="flex items-start gap-3 flex-1 min-w-0">
        {icon && (
          <div className="flex-shrink-0 mt-1">
            <Icon name={icon} size={20} color="var(--color-muted-foreground)" />
          </div>
        )}
        <div className="flex-1 min-w-0">
          <div className={`text-sm md:text-base font-medium ${disabled ? 'text-muted-foreground' : 'text-foreground'}`}>
            {label}
          </div>
          {description && (
            <div className="text-xs md:text-sm text-muted-foreground mt-1">
              {description}
            </div>
          )}
        </div>
      </div>
      <div className="flex-shrink-0">
        {renderInput()}
      </div>
    </div>
  );
}