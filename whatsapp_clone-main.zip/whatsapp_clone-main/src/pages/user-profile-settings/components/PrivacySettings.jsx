import React from 'react';
import SettingsSection from './SettingsSection';
import SettingItem from './SettingItem';

const PrivacySettings = ({ settings, onUpdateSettings }) => {
  const visibilityOptions = [
    { value: 'everyone', label: 'Everyone' },
    { value: 'contacts', label: 'My Contacts' },
    { value: 'nobody', label: 'Nobody' }
  ];

  return (
    <SettingsSection
      title="Privacy"
      description="Control who can see your information and activity"
      icon="Lock"
    >
      <SettingItem
        label="Online Status"
        description="Show when you're online"
        value={settings?.showOnlineStatus}
        type="toggle"
        onChange={(value) => onUpdateSettings({ showOnlineStatus: value })}
        icon="Eye"
      />
      <SettingItem
        label="Profile Photo Visibility"
        description="Choose who can see your profile photo"
        value={settings?.profilePhotoVisibility}
        type="select"
        options={visibilityOptions}
        onChange={(value) => onUpdateSettings({ profilePhotoVisibility: value })}
        icon="Image"
      />
      <SettingItem
        label="Last Seen"
        description="Choose who can see when you were last online"
        value={settings?.lastSeenVisibility}
        type="select"
        options={visibilityOptions}
        onChange={(value) => onUpdateSettings({ lastSeenVisibility: value })}
        icon="Clock"
      />
      <SettingItem
        label="Read Receipts"
        description="Send and receive read receipts (blue ticks)"
        value={settings?.readReceipts}
        type="toggle"
        onChange={(value) => onUpdateSettings({ readReceipts: value })}
        icon="CheckCheck"
      />
      <SettingItem
        label="Status Updates Visibility"
        description="Choose who can see your status updates"
        value={settings?.statusVisibility}
        type="select"
        options={visibilityOptions}
        onChange={(value) => onUpdateSettings({ statusVisibility: value })}
        icon="Radio"
      />
      <SettingItem
        label="Groups"
        description="Choose who can add you to groups"
        value={settings?.groupsVisibility}
        type="select"
        options={visibilityOptions}
        onChange={(value) => onUpdateSettings({ groupsVisibility: value })}
        icon="Users"
      />
    </SettingsSection>
  );
};

export default PrivacySettings;