import React, { useState, useRef, useEffect } from 'react';
import SettingsSection from './SettingsSection';
import SettingItem from './SettingItem';
import { Upload, X, Image as ImageIcon } from 'lucide-react';
import { appearanceService } from '../../../services/appearanceService';
import { useAuth } from '../../../contexts/AuthContext';
import { trackFeatureAdoption } from '../../../utils/analytics';
import { translationService } from '../../../services/translationService';
import Select from '../../../components/ui/Select';


export default function AppearanceSettings() {
  const { user } = useAuth();
  const fileInputRef = useRef(null);
  const [uploading, setUploading] = useState(false);
  const [wallpaperPreview, setWallpaperPreview] = useState('');
  const [selectedLanguage, setSelectedLanguage] = useState('en');
  const [availableLanguages, setAvailableLanguages] = useState([]);
  const [settings, setSettings] = useState({
    theme: 'light',
    font_size: 'medium',
    wallpaper_type: 'default',
    wallpaper_url: null,
    language: 'en',
    compact_mode: false,
    show_animations: true
  });

  const onUpdateSettings = (updates) => {
    setSettings(prev => ({ ...prev, ...updates }));
  };

  useEffect(() => {
    loadSettings();
    loadAvailableLanguages();
  }, []);

  const loadAvailableLanguages = () => {
    const languages = translationService?.getSupportedLanguages();
    setAvailableLanguages(languages);
  };

  const loadSettings = () => {
    // Load settings from localStorage or API
    const savedSettings = localStorage.getItem('appearanceSettings');
    if (savedSettings) {
      const parsedSettings = JSON.parse(savedSettings);
      setSettings(parsedSettings);
      setWallpaperPreview(parsedSettings?.wallpaper_url || '');
      setSelectedLanguage(parsedSettings?.language || 'en');
    }
  };

  const handleSave = () => {
    // Save settings to localStorage or API
    const updatedSettings = {
      ...settings,
      wallpaper_url: wallpaperPreview,
      language: selectedLanguage
    };
    
    localStorage.setItem('appearanceSettings', JSON.stringify(updatedSettings));
    
    // Update appearance service
    appearanceService?.applyTheme(updatedSettings?.theme || 'light');
    appearanceService?.applyFontSize(updatedSettings?.font_size || 'medium');
    appearanceService?.applyWallpaper(updatedSettings?.wallpaper_url || null);
    
    // Track feature adoption
    trackFeatureAdoption?.settingsChanged('language', selectedLanguage);
  };

  const themeOptions = [
    { value: 'light', label: 'Light' },
    { value: 'dark', label: 'Dark' },
    { value: 'system', label: 'System Default' }
  ];

  const fontSizeOptions = [
    { value: 'small', label: 'Small' },
    { value: 'medium', label: 'Medium' },
    { value: 'large', label: 'Large' },
    { value: 'extra-large', label: 'Extra Large' }
  ];

  const wallpaperOptions = [
    { value: 'default', label: 'Default' },
    { value: 'color', label: 'Solid Color' },
    { value: 'custom', label: 'Custom Image' }
  ];

  const languageOptions = [
    { value: 'en', label: 'English' },
    { value: 'es', label: 'Español' },
    { value: 'fr', label: 'Français' },
    { value: 'de', label: 'Deutsch' },
    { value: 'it', label: 'Italiano' },
    { value: 'pt', label: 'Português' },
    { value: 'ru', label: 'Русский' },
    { value: 'zh', label: '中文' },
    { value: 'ja', label: '日本語' },
    { value: 'ko', label: '한국어' },
    { value: 'ar', label: 'العربية' },
    { value: 'hi', label: 'हिन्दी' }
  ];

  const handleThemeChange = (value) => {
    onUpdateSettings({ theme: value });
    appearanceService?.applyTheme(value);
    trackFeatureAdoption?.settingsChanged('theme', value);
  };

  const handleFontSizeChange = (value) => {
    onUpdateSettings({ font_size: value });
    appearanceService?.applyFontSize(value);
    trackFeatureAdoption?.settingsChanged('font_size', value);
  };

  const handleWallpaperTypeChange = (value) => {
    onUpdateSettings({ wallpaper_type: value });
    
    if (value === 'default') {
      setWallpaperPreview(null);
      onUpdateSettings({ wallpaper_url: null });
    }
    trackFeatureAdoption?.settingsChanged('wallpaper_type', value);
  };

  const handleWallpaperUpload = async (event) => {
    const file = event?.target?.files?.[0];
    if (!file || !user?.id) return;

    // Validate file type
    if (!file?.type?.startsWith('image/')) {
      alert('Please select an image file');
      return;
    }

    // Validate file size (max 5MB)
    if (file?.size > 5 * 1024 * 1024) {
      alert('File size must be less than 5MB');
      return;
    }

    try {
      setUploading(true);

      // Delete old wallpaper if exists
      if (settings?.wallpaper_url && settings?.wallpaper_url?.includes('chat-wallpapers')) {
        const oldPath = settings?.wallpaper_url?.split('chat-wallpapers/')?.[1]?.split('?')?.[0];
        if (oldPath) {
          await appearanceService?.deleteWallpaper(oldPath);
        }
      }

      // Upload new wallpaper
      const { url } = await appearanceService?.uploadWallpaper(user?.id, file);
      
      setWallpaperPreview(url);
      onUpdateSettings({ 
        wallpaper_url: url,
        wallpaper_type: 'custom'
      });
      
      trackFeatureAdoption?.featureUsed('custom_wallpaper_upload');
    } catch (error) {
      console.error('Failed to upload wallpaper:', error);
      alert('Failed to upload wallpaper. Please try again.');
    } finally {
      setUploading(false);
    }
  };

  const handleRemoveWallpaper = async () => {
    if (!settings?.wallpaper_url) return;

    try {
      const filePath = settings?.wallpaper_url?.split('chat-wallpapers/')?.[1]?.split('?')?.[0];
      if (filePath) {
        await appearanceService?.deleteWallpaper(filePath);
      }

      setWallpaperPreview(null);
      onUpdateSettings({ 
        wallpaper_url: null,
        wallpaper_type: 'default'
      });
      
      trackFeatureAdoption?.featureUsed('wallpaper_removed');
    } catch (error) {
      console.error('Failed to remove wallpaper:', error);
    }
  };

  return (
    <div className="space-y-6">
      <SettingsSection
        title="Appearance"
        description="Customize the look and feel of the application"
        icon="Palette"
      >
        <SettingItem
          label="Theme"
          description="Choose your preferred color theme"
          value={settings?.theme}
          type="select"
          options={themeOptions}
          onChange={handleThemeChange}
          icon="Moon"
        />
        <SettingItem
          label="Font Size"
          description="Adjust text size for better readability"
          value={settings?.font_size}
          type="select"
          options={fontSizeOptions}
          onChange={handleFontSizeChange}
          icon="Type"
        />
        <SettingItem
          label="Language"
          description="Select your preferred language"
          value={settings?.language}
          type="select"
          options={languageOptions}
          onChange={(value) => {
            onUpdateSettings({ language: value });
            trackFeatureAdoption?.settingsChanged('language', value);
          }}
          icon="Globe"
        />
        {/* Wallpaper Settings */}
        <div className="space-y-4 p-4 bg-gray-50 dark:bg-gray-800/50 rounded-lg">
          <div className="flex items-center gap-2 text-sm font-medium text-gray-900 dark:text-white">
            <ImageIcon className="w-5 h-5" />
            <span>Chat Wallpaper</span>
          </div>

          <SettingItem
            label="Wallpaper Type"
            description="Choose wallpaper style"
            value={settings?.wallpaper_type}
            type="select"
            options={wallpaperOptions}
            onChange={handleWallpaperTypeChange}
            icon="Image"
          />

          {settings?.wallpaper_type === 'custom' && (
            <div className="space-y-3">
              {wallpaperPreview ? (
                <div className="relative">
                  <img
                    src={wallpaperPreview}
                    alt="Wallpaper preview"
                    className="w-full h-32 object-cover rounded-lg"
                  />
                  <button
                    onClick={handleRemoveWallpaper}
                    className="absolute top-2 right-2 p-1 bg-red-500 text-white rounded-full hover:bg-red-600 transition-colors"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => fileInputRef?.current?.click()}
                  disabled={uploading}
                  className="w-full h-32 border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg flex flex-col items-center justify-center gap-2 hover:border-blue-500 dark:hover:border-blue-400 transition-colors disabled:opacity-50"
                >
                  {uploading ? (
                    <>
                      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500"></div>
                      <span className="text-sm text-gray-600 dark:text-gray-400">Uploading...</span>
                    </>
                  ) : (
                    <>
                      <Upload className="w-8 h-8 text-gray-400" />
                      <span className="text-sm text-gray-600 dark:text-gray-400">
                        Click to upload wallpaper
                      </span>
                      <span className="text-xs text-gray-500 dark:text-gray-500">
                        Max 5MB • JPG, PNG, WEBP
                      </span>
                    </>
                  )}
                </button>
              )}
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleWallpaperUpload}
                className="hidden"
              />
            </div>
          )}
        </div>
        <SettingItem
          label="Compact Mode"
          description="Reduce spacing for more content"
          value={settings?.compact_mode}
          type="toggle"
          onChange={(value) => {
            onUpdateSettings({ compact_mode: value });
            trackFeatureAdoption?.settingsChanged('compact_mode', value);
          }}
          icon="Minimize2"
        />
        <SettingItem
          label="Show Animations"
          description="Enable smooth animations and transitions"
          value={settings?.show_animations}
          type="toggle"
          onChange={(value) => {
            onUpdateSettings({ show_animations: value });
            trackFeatureAdoption?.settingsChanged('show_animations', value);
          }}
          icon="Zap"
        />
      </SettingsSection>

      {/* Language Settings */}
      <div className="space-y-3">
        <h3 className="text-lg font-semibold">App Language</h3>
        <p className="text-sm text-muted-foreground">
          Select your preferred language for the app interface
        </p>
        <Select
          value={selectedLanguage}
          onValueChange={setSelectedLanguage}
          options={availableLanguages?.map(lang => ({
            value: lang?.code,
            label: lang?.name
          }))}
          placeholder="Select language"
        />
        <p className="text-xs text-muted-foreground mt-2">
          Messages can be translated on-demand by tapping the translate button on any message
        </p>
      </div>

      <button
        onClick={handleSave}
        className="w-full py-3 px-4 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition-colors"
      >
        Save Settings
      </button>
    </div>
  );
}