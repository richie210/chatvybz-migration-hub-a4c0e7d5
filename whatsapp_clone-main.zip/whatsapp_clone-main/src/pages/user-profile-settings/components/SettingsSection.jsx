import React from 'react';
import Icon from '../../../components/AppIcon';

const SettingsSection = ({ title, description, icon, children, className = '' }) => {
  return (
    <div className={`bg-card border border-border rounded-xl p-4 md:p-6 lg:p-8 ${className}`}>
      <div className="flex items-start gap-3 md:gap-4 mb-4 md:mb-6">
        <div className="w-10 h-10 md:w-12 md:h-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
          <Icon name={icon} size={24} color="var(--color-primary)" />
        </div>
        <div className="flex-1 min-w-0">
          <h2 className="text-lg md:text-xl lg:text-2xl font-semibold text-foreground mb-1 md:mb-2">
            {title}
          </h2>
          {description && (
            <p className="text-sm md:text-base text-muted-foreground">{description}</p>
          )}
        </div>
      </div>
      <div className="space-y-3 md:space-y-4">
        {children}
      </div>
    </div>
  );
};

export default SettingsSection;