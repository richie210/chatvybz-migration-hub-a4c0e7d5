import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import SettingsSection from './SettingsSection';
import SettingItem from './SettingItem';
import Button from '../../../components/ui/Button';
import Icon from '../../../components/AppIcon';

const SecuritySettings = ({ settings, onUpdateSettings }) => {
  const navigate = useNavigate();
  const [showSessions, setShowSessions] = useState(false);

  const activeSessions = [
    {
      id: 1,
      device: 'Chrome on Windows',
      location: 'New York, USA',
      lastActive: '2025-12-21 17:30:00',
      current: true
    },
    {
      id: 2,
      device: 'Safari on iPhone',
      location: 'New York, USA',
      lastActive: '2025-12-21 15:20:00',
      current: false
    },
    {
      id: 3,
      device: 'Firefox on MacBook',
      location: 'Boston, USA',
      lastActive: '2025-12-20 22:15:00',
      current: false
    }
  ];

  const handleTerminateSession = (sessionId) => {
    console.log('Terminating session:', sessionId);
  };

  return (
    <SettingsSection
      title="Security"
      description="Manage your account security and active sessions"
      icon="Shield"
    >
      <SettingItem
        label="Two-Factor Authentication"
        description="Add an extra layer of security to your account"
        value={settings?.twoFactorEnabled}
        type="toggle"
        onChange={(value) => onUpdateSettings({ twoFactorEnabled: value })}
        icon="Lock"
      />
      <div className="py-3 md:py-4 border-b border-border">
        <button
          onClick={() => navigate('/enhanced-session-security-dashboard')}
          className="flex items-center justify-between w-full text-left focus-ring rounded-lg p-2 -m-2 hover:bg-muted transition-colors"
        >
          <div className="flex items-start gap-3">
            <Icon name="Monitor" size={20} color="var(--color-muted-foreground)" />
            <div>
              <div className="text-sm md:text-base font-medium text-foreground">
                Session Security Dashboard
              </div>
              <div className="text-xs md:text-sm text-muted-foreground mt-1">
                View detailed session tracking, device info, and login history
              </div>
            </div>
          </div>
          <Icon
            name="ChevronRight"
            size={20}
            color="var(--color-muted-foreground)"
          />
        </button>
      </div>
      <div className="py-3 md:py-4 border-b border-border">
        <button
          onClick={() => setShowSessions(!showSessions)}
          className="flex items-center justify-between w-full text-left focus-ring rounded-lg p-2 -m-2 hover:bg-muted transition-colors"
        >
          <div className="flex items-start gap-3">
            <Icon name="Monitor" size={20} color="var(--color-muted-foreground)" />
            <div>
              <div className="text-sm md:text-base font-medium text-foreground">
                Active Sessions (Quick View)
              </div>
              <div className="text-xs md:text-sm text-muted-foreground mt-1">
                Manage devices where you're logged in
              </div>
            </div>
          </div>
          <Icon
            name={showSessions ? 'ChevronUp' : 'ChevronDown'}
            size={20}
            color="var(--color-muted-foreground)"
          />
        </button>

        {showSessions && (
          <div className="mt-4 space-y-3">
            {activeSessions?.map((session) => (
              <div
                key={session?.id}
                className="p-3 md:p-4 bg-muted rounded-lg"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-sm md:text-base font-medium text-foreground">
                        {session?.device}
                      </span>
                      {session?.current && (
                        <span className="px-2 py-1 text-xs bg-success/10 text-success rounded-md font-medium">
                          Current
                        </span>
                      )}
                    </div>
                    <div className="text-xs md:text-sm text-muted-foreground space-y-1">
                      <div className="flex items-center gap-2">
                        <Icon name="MapPin" size={14} color="var(--color-muted-foreground)" />
                        <span>{session?.location}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Icon name="Clock" size={14} color="var(--color-muted-foreground)" />
                        <span>Last active: {new Date(session.lastActive)?.toLocaleString()}</span>
                      </div>
                    </div>
                  </div>
                  {!session?.current && (
                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => handleTerminateSession(session?.id)}
                    >
                      Terminate
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      <SettingItem
        label="Change Password"
        description="Update your account password"
        value="Change"
        type="button"
        onChange={() => console.log('Change password clicked')}
        icon="Key"
      />
      <SettingItem
        label="Delete Account"
        description="Permanently delete your account and all data"
        value="Delete Account"
        type="button"
        onChange={() => console.log('Delete account clicked')}
        icon="Trash2"
        danger
      />
    </SettingsSection>
  );
};

export default SecuritySettings;