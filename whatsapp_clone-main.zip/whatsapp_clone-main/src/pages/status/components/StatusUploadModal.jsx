import React, { useState, useRef } from 'react';
import { X, Image, Video, Send } from 'lucide-react';
import { statusService } from '../../../services/statusService';

function StatusUploadModal({ onClose, onSuccess }) {
  const [selectedFile, setSelectedFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState(null);
  const [caption, setCaption] = useState('');
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState(null);
  const fileInputRef = useRef(null);

  const handleFileSelect = (e) => {
    const file = e?.target?.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file?.type?.startsWith('image/') && !file?.type?.startsWith('video/')) {
      setError('Please select an image or video file');
      return;
    }

    // Validate file size (max 10MB)
    if (file?.size > 10 * 1024 * 1024) {
      setError('File size must be less than 10MB');
      return;
    }

    setSelectedFile(file);
    setPreviewUrl(URL.createObjectURL(file));
    setError(null);
  };

  const handleUpload = async () => {
    if (!selectedFile) {
      setError('Please select a file');
      return;
    }

    try {
      setUploading(true);
      setError(null);

      await statusService?.createStatus(selectedFile, caption);
      onSuccess();
    } catch (err) {
      console.error('Error uploading status:', err);
      setError(err?.message);
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-90 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-lg w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="sticky top-0 bg-white border-b border-gray-200 p-4 flex items-center justify-between">
          <h2 className="text-lg font-semibold text-gray-900">Add Status</h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4">
          {/* File preview */}
          {previewUrl ? (
            <div className="relative mb-4 rounded-lg overflow-hidden bg-gray-100">
              {selectedFile?.type?.startsWith('image/') ? (
                <img
                  src={previewUrl}
                  alt="Preview"
                  className="w-full h-96 object-contain"
                />
              ) : (
                <video
                  src={previewUrl}
                  controls
                  className="w-full h-96 object-contain"
                />
              )}
              
              <button
                onClick={() => {
                  setSelectedFile(null);
                  setPreviewUrl(null);
                }}
                className="absolute top-2 right-2 bg-black/50 text-white rounded-full p-2 hover:bg-black/70"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          ) : (
            <div
              onClick={() => fileInputRef?.current?.click()}
              className="border-2 border-dashed border-gray-300 rounded-lg p-12 text-center cursor-pointer hover:border-sky-500 transition-colors"
            >
              <div className="flex justify-center gap-4 mb-4">
                <Image className="w-12 h-12 text-gray-400" />
                <Video className="w-12 h-12 text-gray-400" />
              </div>
              <p className="text-gray-600 mb-2">Click to upload photo or video</p>
              <p className="text-sm text-gray-500">Max size: 10MB</p>
            </div>
          )}

          {/* Hidden file input */}
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*,video/*"
            onChange={handleFileSelect}
            className="hidden"
          />

          {/* Caption input */}
          <textarea
            value={caption}
            onChange={(e) => setCaption(e?.target?.value)}
            placeholder="Add a caption... (optional)"
            maxLength={200}
            className="w-full p-3 border border-gray-300 rounded-lg resize-none focus:outline-none focus:ring-2 focus:ring-sky-500"
            rows={3}
          />
          <p className="text-xs text-gray-500 text-right mt-1">
            {caption?.length}/200
          </p>

          {/* Error message */}
          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-3 mt-4">
              <p className="text-red-600 text-sm">{error}</p>
            </div>
          )}

          {/* Upload button */}
          <button
            onClick={handleUpload}
            disabled={!selectedFile || uploading}
            className="w-full bg-sky-500 text-white py-3 rounded-lg mt-4 flex items-center justify-center gap-2 hover:bg-sky-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {uploading ? (
              <>
                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                <span>Uploading...</span>
              </>
            ) : (
              <>
                <Send className="w-5 h-5" />
                <span>Share Status</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}

export default StatusUploadModal;