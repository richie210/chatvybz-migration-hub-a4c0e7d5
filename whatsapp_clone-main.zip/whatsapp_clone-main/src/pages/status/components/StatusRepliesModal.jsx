import React, { useState, useEffect } from 'react';
import { X, Send } from 'lucide-react';
import { statusService } from '../../../services/statusService';
import { useAuth } from '../../../contexts/AuthContext';
import { format } from 'date-fns';

function StatusRepliesModal({ status, onClose }) {
  const { user } = useAuth();
  const [replies, setReplies] = useState([]);
  const [replyText, setReplyText] = useState('');
  const [sending, setSending] = useState(false);
  const [loading, setLoading] = useState(true);
  const isOwnStatus = status?.user_id === user?.id;

  useEffect(() => {
    fetchReplies();
    setupRealtimeSubscription();
  }, [status?.id]);

  const fetchReplies = async () => {
    try {
      setLoading(true);
      const data = await statusService?.getStatusReplies(status?.id);
      setReplies(data);
    } catch (err) {
      console.error('Error fetching replies:', err);
    } finally {
      setLoading(false);
    }
  };

  const setupRealtimeSubscription = () => {
    const subscription = statusService?.subscribeToStatusReplies(status?.id, (payload) => {
      if (payload?.eventType === 'INSERT') {
        setReplies(prev => [payload?.new, ...prev]);
      }
    });

    return () => {
      subscription?.unsubscribe();
    };
  };

  const handleSendReply = async () => {
    if (!replyText?.trim()) return;

    try {
      setSending(true);
      const newReply = await statusService?.replyToStatus(status?.id, replyText);
      setReplies(prev => [newReply, ...prev]);
      setReplyText('');
    } catch (err) {
      console.error('Error sending reply:', err);
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl max-w-lg w-full max-h-[80vh] flex flex-col">
        {/* Header */}
        <div className="border-b border-gray-200 p-4 flex items-center justify-between">
          <h2 className="text-lg font-semibold text-gray-900">Replies</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Status preview */}
        <div className="border-b border-gray-200 p-4 flex items-center gap-3">
          <img
            src={status?.user?.avatar_url || user?.avatar_url || '/assets/images/no_image.png'}
            alt="User"
            className="w-12 h-12 rounded-full object-cover"
          />
          <div className="flex-1">
            <p className="font-semibold text-gray-900">
              {isOwnStatus ? 'Your Status' : status?.user?.full_name || 'Unknown'}
            </p>
            {status?.caption && (
              <p className="text-sm text-gray-600 truncate">{status?.caption}</p>
            )}
          </div>
          <img
            src={status?.media_signed_url}
            alt="Status"
            className="w-16 h-16 rounded-lg object-cover"
          />
        </div>

        {/* Replies list */}
        <div className="flex-1 overflow-y-auto p-4">
          {loading ? (
            <div className="flex justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-sky-500"></div>
            </div>
          ) : replies?.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-gray-500">No replies yet</p>
              <p className="text-sm text-gray-400 mt-1">Be the first to reply</p>
            </div>
          ) : (
            <div className="space-y-4">
              {replies?.map((reply) => (
                <div key={reply?.id} className="flex gap-3">
                  <img
                    src={reply?.user?.avatar_url || '/assets/images/no_image.png'}
                    alt={reply?.user?.full_name || 'User'}
                    className="w-10 h-10 rounded-full object-cover flex-shrink-0"
                  />
                  <div className="flex-1">
                    <div className="bg-gray-100 rounded-lg p-3">
                      <p className="font-semibold text-sm text-gray-900 mb-1">
                        {reply?.user_id === user?.id ? 'You' : reply?.user?.full_name || 'Unknown'}
                      </p>
                      <p className="text-gray-800">{reply?.reply_text}</p>
                    </div>
                    <p className="text-xs text-gray-500 mt-1 ml-3">
                      {format(new Date(reply.created_at), 'MMM d, h:mm a')}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Reply input */}
        {!isOwnStatus && (
          <div className="border-t border-gray-200 p-4">
            <div className="flex gap-2">
              <input
                type="text"
                value={replyText}
                onChange={(e) => setReplyText(e?.target?.value)}
                placeholder="Write a reply..."
                className="flex-1 px-4 py-2 border border-gray-300 rounded-full focus:outline-none focus:ring-2 focus:ring-sky-500"
                onKeyPress={(e) => e?.key === 'Enter' && handleSendReply()}
              />
              <button
                onClick={handleSendReply}
                disabled={!replyText?.trim() || sending}
                className="bg-sky-500 text-white rounded-full p-2 hover:bg-sky-600 transition-colors disabled:opacity-50"
              >
                {sending ? (
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                ) : (
                  <Send className="w-5 h-5" />
                )}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default StatusRepliesModal;