import React, { useState, useEffect, useRef } from 'react';
import { Eye, X, Pause, ChevronLeft, ChevronRight } from 'lucide-react';

import { realtimeService } from '../../../services/realtimeService';
import { useAuth } from '../../../contexts/AuthContext';
import { format } from 'date-fns';

export default function StatusViewModal({ statusGroup, onClose, onRefresh }) {
  const { user } = useAuth();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [progress, setProgress] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [viewCount, setViewCount] = useState(0);
  const [showReplies, setShowReplies] = useState(false);
  const progressInterval = useRef(null);

  const currentStatus = statusGroup?.statuses?.[currentIndex];
  const isMyStatus = statusGroup?.user?.id === user?.id;

  useEffect(() => {
    if (!currentStatus) return;

    // Mark status as viewed (only if not my status)
    if (!isMyStatus) {
      markStatusAsViewed(currentStatus?.id);
    }

    // Subscribe to real-time view count updates
    const channelName = realtimeService?.subscribeToStatusViews(
      currentStatus?.id,
      (newView) => {
        setViewCount(prev => prev + 1);
      }
    );

    // Initialize view count
    setViewCount(currentStatus?.views?.length || 0);

    return () => {
      realtimeService?.unsubscribe(channelName);
    };
  }, [currentStatus, isMyStatus]);

  useEffect(() => {
    if (isPaused) return;

    progressInterval.current = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          handleNext();
          return 0;
        }
        return prev + 1;
      });
    }, 50); // 5 seconds per status (100 * 50ms)

    return () => {
      if (progressInterval?.current) {
        clearInterval(progressInterval?.current);
      }
    };
  }, [currentIndex, isPaused]);

  const handleNext = () => {
    if (currentIndex < statusGroup?.statuses?.length - 1) {
      setCurrentIndex(currentIndex + 1);
      setProgress(0);
    }
  };

  const handlePrevious = () => {
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1);
      setProgress(0);
    }
  };

  const handlePause = () => {
    setIsPaused(!isPaused);
  };

  const getTimeAgo = (timestamp) => {
    const now = new Date();
    const posted = new Date(timestamp);
    const diffMs = now - posted;
    const diffMins = Math.floor(diffMs / (1000 * 60));
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));

    if (diffHours > 0) {
      return `${diffHours}h ago`;
    } else if (diffMins > 0) {
      return `${diffMins}m ago`;
    }
    return 'Just now';
  };

  const getTimeRemaining = (expiresAt) => {
    const now = new Date();
    const expiry = new Date(expiresAt);
    const diffMs = expiry - now;
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffMinutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));

    if (diffHours > 0) {
      return `${diffHours}h`;
    } else if (diffMinutes > 0) {
      return `${diffMinutes}m`;
    }
    return '&lt;1m';
  };

  const markStatusAsViewed = async (statusId) => {
    try {
      // Implementation for marking status as viewed
      await realtimeService?.markStatusViewed?.(statusId, user?.id);
    } catch (error) {
      console.error('Error marking status as viewed:', error);
    }
  };

  if (!currentStatus) {
    return null;
  }

  return (
    <div className="fixed inset-0 bg-black z-50 flex items-center justify-center">
      {/* Progress Bars */}
      <div className="absolute top-4 left-4 right-4 flex gap-1 z-10">
        {statusGroup?.statuses?.map((_, idx) => (
          <div key={idx} className="flex-1 h-1 bg-gray-600 rounded-full overflow-hidden">
            <div
              className="h-full bg-white transition-all duration-100"
              style={{
                width: idx < currentIndex ? '100%' : idx === currentIndex ? `${progress}%` : '0%'
              }}
            />
          </div>
        ))}
      </div>
      {/* Header */}
      <div className="absolute top-8 left-4 right-4 flex items-center justify-between z-10">
        <div className="flex items-center gap-3">
          <img
            src={statusGroup?.user?.avatar_url || '/assets/images/no_image.png'}
            alt={statusGroup?.user?.username || 'User'}
            className="w-10 h-10 rounded-full border-2 border-white"
          />
          <div>
            <p className="text-white font-medium">{statusGroup?.user?.username || 'Unknown'}</p>
            <p className="text-white/80 text-sm">
              {getTimeAgo(currentStatus?.created_at)} • {getTimeRemaining(currentStatus?.expires_at)} left
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {isMyStatus && (
            <button className="text-white/90 hover:text-white flex items-center gap-1">
              <Eye className="w-5 h-5" />
              <span className="text-sm font-medium">{viewCount}</span>
            </button>
          )}
          <button
            onClick={onClose}
            className="text-white/90 hover:text-white transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>
      </div>
      {/* Status Content */}
      <div
        className="w-full h-full flex items-center justify-center"
        onClick={(e) => {
          const rect = e?.currentTarget?.getBoundingClientRect();
          const clickX = e?.clientX - rect?.left;
          if (clickX < rect?.width / 2) {
            handlePrevious();
          } else {
            handleNext();
          }
        }}
      >
        {currentStatus?.media_type === 'video' ? (
          <video
            src={currentStatus?.media_url}
            className="max-w-full max-h-full object-contain"
            autoPlay
            loop
            playsInline
          />
        ) : (
          <img
            src={currentStatus?.media_url}
            alt="Status"
            className="max-w-full max-h-full object-contain"
          />
        )}
      </div>
      {/* Caption */}
      {currentStatus?.decrypted_caption && (
        <div className="absolute bottom-20 left-4 right-4 bg-black/50 backdrop-blur-sm rounded-lg p-4 z-10">
          <p className="text-white">{currentStatus?.decrypted_caption}</p>
        </div>
      )}
      {/* Footer */}
      <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between z-10">
        <div className="flex items-center gap-2">
          <button
            onClick={handlePause}
            className="flex items-center gap-1 text-white/90 hover:text-white"
          >
            <Pause className="w-5 h-5" />
            <span className="text-sm">{isPaused ? 'Resume' : 'Pause'}</span>
          </button>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handlePrevious}
            disabled={currentIndex === 0}
            className="flex items-center gap-1 text-white/90 hover:text-white disabled:opacity-50"
          >
            <ChevronLeft className="w-5 h-5" />
            <span className="text-sm">Previous</span>
          </button>

          <button
            onClick={handleNext}
            disabled={currentIndex >= statusGroup?.statuses?.length - 1}
            className="flex items-center gap-1 text-white/90 hover:text-white disabled:opacity-50"
          >
            <span className="text-sm">Next</span>
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      </div>
      {/* Reply section */}
      {showReplies && (
        <div className="absolute bottom-16 left-4 right-4 bg-black/80 backdrop-blur-sm rounded-lg p-4 z-10">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-white font-medium">Replies</h3>
            <button
              onClick={() => setShowReplies(false)}
              className="text-white/90 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="space-y-2 max-h-40 overflow-y-auto">
            {currentStatus?.replies?.map((reply) => (
              <div key={reply?.id} className="bg-white/10 rounded-lg p-3">
                <div className="flex items-center gap-2 mb-1">
                  <img
                    src={reply?.user?.avatar_url || '/assets/images/no_image.png'}
                    alt={reply?.user?.username || 'User'}
                    className="w-6 h-6 rounded-full object-cover"
                  />
                  <div className="flex-1">
                    <p className="text-white font-medium">{reply?.user?.username}</p>
                    <p className="text-xs text-gray-300">{reply?.text}</p>
                  </div>
                </div>
                <p className="text-xs text-gray-400">
                  {format(new Date(reply.created_at), 'MMM d, h:mm a')}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}