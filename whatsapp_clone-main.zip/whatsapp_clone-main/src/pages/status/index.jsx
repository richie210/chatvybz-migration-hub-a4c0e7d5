import React, { useState, useEffect } from 'react';
import { Camera, Plus, Eye, Clock, Trash2 } from 'lucide-react';
import StatusUploadModal from './components/StatusUploadModal';
import StatusViewModal from './components/StatusViewModal';
import { createStatus, getContactStatuses, getMyStatuses, deleteStatus } from '../../services/statusService';
import { realtimeService } from '../../services/realtimeService';
import { useAuth } from '../../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import Button from '../../components/ui/Button';


export default function Status() {
  const { user, loading: authLoading, isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [showViewModal, setShowViewModal] = useState(false);
  const [selectedStatus, setSelectedStatus] = useState(null);
  const [myStatuses, setMyStatuses] = useState([]);
  const [contactStatuses, setContactStatuses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Load statuses on mount
  useEffect(() => {
    // Wait for auth to be established before loading statuses
    if (authLoading) return;

    // Redirect to login if not authenticated
    if (!isAuthenticated) {
      navigate('/login');
      return;
    }

    loadStatuses();
    
    // Subscribe to real-time status updates
    const channelName = realtimeService?.subscribeToStatusUpdates((newStatus) => {
      // Reload statuses when new status is posted
      loadStatuses();
    });

    return () => {
      realtimeService?.unsubscribe(channelName);
    };
  }, [authLoading, isAuthenticated, navigate]);

  const loadStatuses = async () => {
    // Double-check authentication before making service calls
    if (!isAuthenticated) {
      setError('Please log in to view statuses');
      return;
    }

    try {
      setLoading(true);
      setError(null);

      const [myStatusesResult, contactStatusesResult] = await Promise.all([
        getMyStatuses(),
        getContactStatuses()
      ]);

      if (myStatusesResult?.error) throw myStatusesResult?.error;
      if (contactStatusesResult?.error) throw contactStatusesResult?.error;

      setMyStatuses(myStatusesResult?.data || []);
      setContactStatuses(contactStatusesResult?.data || []);
    } catch (err) {
      console.error('Error loading statuses:', err);
      setError(err?.message);
    } finally {
      setLoading(false);
    }
  };

  const handleStatusUpload = async (statusData) => {
    try {
      const result = await createStatus(statusData);
      if (result?.error) throw result?.error;

      setShowUploadModal(false);
      await loadStatuses();
    } catch (err) {
      console.error('Error uploading status:', err);
      setError(err?.message);
    }
  };

  const handleManageMyStatus = () => {
    navigate('/status-stories-creation-management');
  };

  const handleDeleteStatus = async (statusId) => {
    if (!window.confirm('Delete this status?')) return;

    try {
      const result = await deleteStatus(statusId);
      if (result?.error) throw result?.error;

      await loadStatuses();
    } catch (err) {
      console.error('Error deleting status:', err);
      setError(err?.message);
    }
  };

  const handleViewStatus = (statusGroup) => {
    navigate('/status-stories-viewer-interface', { state: { statusGroup } });
  };

  const getTimeRemaining = (expiresAt) => {
    const now = new Date();
    const expiry = new Date(expiresAt);
    const diffMs = expiry - now;
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffMinutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));

    if (diffHours > 0) {
      return `${diffHours}h remaining`;
    } else if (diffMinutes > 0) {
      return `${diffMinutes}m remaining`;
    }
    return 'Expiring soon';
  };

  // Show loading during authentication check
  if (authLoading || loading) {
    return (
      <div className="flex items-center justify-center h-screen bg-gray-50">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading statuses...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white p-6 shadow-lg">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-2xl font-bold mb-2">Status Updates</h1>
          <p className="text-blue-100">Share photos and videos that disappear after 24 hours</p>
        </div>
      </div>
      <div className="max-w-6xl mx-auto p-6">
        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-6">
            <p className="font-medium">Error</p>
            <p className="text-sm">{error}</p>
          </div>
        )}

        {/* My Status Section */}
        <div className="bg-white rounded-lg shadow-md p-6 mb-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-semibold text-foreground">My Status</h2>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                iconName="Settings"
                iconPosition="left"
                onClick={handleManageMyStatus}
              >
                Manage
              </Button>
              <Button
                variant="default"
                size="sm"
                iconName="Plus"
                iconPosition="left"
                onClick={() => setShowUploadModal(true)}
              >
                Add Status
              </Button>
            </div>
          </div>

          <div className="flex items-center gap-4 overflow-x-auto pb-4">
            {/* My Statuses */}
            {myStatuses?.map((status) => (
              <div key={status?.id} className="flex-shrink-0 text-center">
                <div className="relative">
                  <button
                    onClick={() => handleViewStatus({ user: { ...user, id: user?.id }, statuses: [status] })}
                    className="w-20 h-20 rounded-full border-4 border-blue-500 overflow-hidden hover:border-blue-600 transition-all"
                  >
                    {status?.media_type === 'video' ? (
                      <video src={status?.media_url} className="w-full h-full object-cover" />
                    ) : (
                      <img src={status?.media_url} alt="Status" className="w-full h-full object-cover" />
                    )}
                  </button>
                  <button
                    onClick={() => handleDeleteStatus(status?.id)}
                    className="absolute -top-1 -right-1 w-6 h-6 bg-red-500 rounded-full flex items-center justify-center text-white hover:bg-red-600 transition-colors"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                </div>
                <div className="mt-2 text-xs text-gray-600 flex items-center gap-1 justify-center">
                  <Eye className="w-3 h-3" />
                  <span>{status?.views?.length || 0}</span>
                </div>
                <div className="text-xs text-gray-500 flex items-center gap-1 justify-center mt-1">
                  <Clock className="w-3 h-3" />
                  <span>{getTimeRemaining(status?.expires_at)}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Contact Statuses Section */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <h2 className="text-lg font-semibold mb-4">Recent Updates</h2>

          {contactStatuses?.length === 0 ? (
            <div className="text-center py-12 text-gray-500">
              <Camera className="w-16 h-16 mx-auto mb-4 opacity-20" />
              <p className="text-lg font-medium">No status updates yet</p>
              <p className="text-sm">Check back later for updates from your contacts</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-6">
              {contactStatuses?.map((statusGroup) => (
                <button
                  key={statusGroup?.user?.id}
                  onClick={() => handleViewStatus(statusGroup)}
                  className="text-center hover:opacity-80 transition-opacity"
                >
                  <div className="relative mb-2">
                    <div className="w-20 h-20 mx-auto rounded-full border-4 border-blue-500 overflow-hidden">
                      <img
                        src={statusGroup?.user?.avatar_url || '/assets/images/no_image.png'}
                        alt={statusGroup?.user?.username || 'User'}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    {statusGroup?.statuses?.length > 1 && (
                      <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center text-white text-xs font-bold">
                        {statusGroup?.statuses?.length}
                      </div>
                    )}
                  </div>
                  <p className="text-sm font-medium text-gray-900 truncate">
                    {statusGroup?.user?.username || 'Unknown'}
                  </p>
                  <p className="text-xs text-gray-500">
                    {new Date(statusGroup.lastStatusTime)?.toLocaleTimeString([], { 
                      hour: '2-digit', 
                      minute: '2-digit' 
                    })}
                  </p>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
      {/* Modals */}
      {showUploadModal && (
        <StatusUploadModal
          onClose={() => setShowUploadModal(false)}
          onUpload={handleStatusUpload}
        />
      )}
      {showViewModal && selectedStatus && (
        <StatusViewModal
          statusGroup={selectedStatus}
          onClose={() => {
            setShowViewModal(false);
            setSelectedStatus(null);
          }}
          onRefresh={loadStatuses}
        />
      )}
    </div>
  );
}