import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Input from '../../../components/ui/Input';
import { Checkbox } from '../../../components/ui/Checkbox';

const RecipientSelector = ({ selectedRecipients, onRecipientsChange }) => {
  const [searchQuery, setSearchQuery] = useState('');

  const conversations = [
  {
    id: 1,
    name: 'Sarah Johnson',
    type: 'individual',
    avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_151378054-1763295516123.png",
    avatarAlt: 'Professional headshot of woman with blonde hair in business attire',
    lastSeen: 'online'
  },
  {
    id: 2,
    name: 'Tech Team',
    type: 'group',
    avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_171170bd3-1764687877901.png",
    avatarAlt: 'Group of diverse professionals collaborating around laptop in modern office',
    members: 12
  },
  {
    id: 3,
    name: 'Michael Chen',
    type: 'individual',
    avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_1fd29f585-1763300949045.png",
    avatarAlt: 'Professional headshot of Asian man with glasses in navy suit',
    lastSeen: '2 hours ago'
  },
  {
    id: 4,
    name: 'Project Alpha',
    type: 'group',
    avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_1c4f86406-1764672388583.png",
    avatarAlt: 'Business team having strategy meeting in conference room with charts',
    members: 8
  },
  {
    id: 5,
    name: 'Emma Wilson',
    type: 'individual',
    avatar: "https://img.rocket.new/generatedImages/rocket_gen_img_17187f2d5-1763301571161.png",
    avatarAlt: 'Professional headshot of woman with dark hair in red blazer',
    lastSeen: 'yesterday'
  }];


  const filteredConversations = conversations?.filter((conv) =>
  conv?.name?.toLowerCase()?.includes(searchQuery?.toLowerCase())
  );

  const handleToggleRecipient = (conversationId) => {
    const newSelected = selectedRecipients?.includes(conversationId) ?
    selectedRecipients?.filter((id) => id !== conversationId) :
    [...selectedRecipients, conversationId];
    onRecipientsChange(newSelected);
  };

  return (
    <div className="bg-card border border-border rounded-xl overflow-hidden">
      <div className="p-4 md:p-6 border-b border-border">
        <h3 className="text-base md:text-lg font-semibold text-foreground mb-4">
          Send to ({selectedRecipients?.length})
        </h3>
        <Input
          type="search"
          placeholder="Search conversations..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e?.target?.value)} />

      </div>
      <div className="max-h-[300px] md:max-h-[400px] overflow-y-auto custom-scrollbar">
        {filteredConversations?.map((conversation) =>
        <div
          key={conversation?.id}
          className="flex items-center gap-3 md:gap-4 p-3 md:p-4 hover:bg-muted transition-colors cursor-pointer border-b border-border last:border-b-0"
          onClick={() => handleToggleRecipient(conversation?.id)}>

            <Checkbox
            checked={selectedRecipients?.includes(conversation?.id)}
            onChange={() => handleToggleRecipient(conversation?.id)}
            onClick={(e) => e?.stopPropagation()} />


            <div className="relative flex-shrink-0">
              <div className="w-10 h-10 md:w-12 md:h-12 rounded-full overflow-hidden">
                <Image
                src={conversation?.avatar}
                alt={conversation?.avatarAlt}
                className="w-full h-full object-cover" />

              </div>
              {conversation?.type === 'group' &&
            <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-primary flex items-center justify-center">
                  <Icon name="Users" size={12} color="#FFFFFF" />
                </div>
            }
            </div>

            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2">
                <p className="text-sm md:text-base font-medium text-foreground truncate">
                  {conversation?.name}
                </p>
                {conversation?.type === 'group' &&
              <span className="text-xs text-muted-foreground whitespace-nowrap">
                    ({conversation?.members} members)
                  </span>
              }
              </div>
              {conversation?.type === 'individual' &&
            <p className="text-xs md:text-sm text-muted-foreground">
                  {conversation?.lastSeen}
                </p>
            }
            </div>

            {selectedRecipients?.includes(conversation?.id) &&
          <Icon name="CheckCircle2" size={20} color="var(--color-primary)" />
          }
          </div>
        )}

        {filteredConversations?.length === 0 &&
        <div className="flex flex-col items-center justify-center py-12 px-4 text-center">
            <Icon name="Search" size={48} color="var(--color-muted-foreground)" />
            <p className="mt-4 text-muted-foreground">No conversations found</p>
          </div>
        }
      </div>
    </div>);

};

export default RecipientSelector;