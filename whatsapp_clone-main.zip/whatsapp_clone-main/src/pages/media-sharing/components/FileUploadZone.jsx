import React, { useCallback, useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const FileUploadZone = ({ onFilesSelected, acceptedTypes, maxSize }) => {
  const [isDragging, setIsDragging] = useState(false);

  const handleDragEnter = useCallback((e) => {
    e?.preventDefault();
    e?.stopPropagation();
    setIsDragging(true);
  }, []);

  const handleDragLeave = useCallback((e) => {
    e?.preventDefault();
    e?.stopPropagation();
    setIsDragging(false);
  }, []);

  const handleDragOver = useCallback((e) => {
    e?.preventDefault();
    e?.stopPropagation();
  }, []);

  const handleDrop = useCallback((e) => {
    e?.preventDefault();
    e?.stopPropagation();
    setIsDragging(false);

    const files = Array.from(e?.dataTransfer?.files);
    onFilesSelected(files);
  }, [onFilesSelected]);

  const handleFileInput = useCallback((e) => {
    const files = Array.from(e?.target?.files);
    onFilesSelected(files);
  }, [onFilesSelected]);

  const formatMaxSize = (bytes) => {
    return `${Math.round(bytes / (1024 * 1024))}MB`;
  };

  return (
    <div
      className={`relative border-2 border-dashed rounded-xl transition-all duration-300 ${
        isDragging
          ? 'border-primary bg-primary/5 scale-[1.02]'
          : 'border-border bg-card hover:border-primary/50'
      }`}
      onDragEnter={handleDragEnter}
      onDragLeave={handleDragLeave}
      onDragOver={handleDragOver}
      onDrop={handleDrop}
    >
      <div className="flex flex-col items-center justify-center p-8 md:p-12 lg:p-16">
        <div className={`w-16 h-16 md:w-20 md:h-20 lg:w-24 lg:h-24 rounded-full flex items-center justify-center mb-4 md:mb-6 transition-all duration-300 ${
          isDragging ? 'bg-primary/20' : 'bg-muted'
        }`}>
          <Icon
            name={isDragging ? 'Download' : 'Upload'}
            size={32}
            color={isDragging ? 'var(--color-primary)' : 'var(--color-muted-foreground)'}
          />
        </div>

        <h3 className="text-lg md:text-xl lg:text-2xl font-semibold text-foreground mb-2">
          {isDragging ? 'Drop files here' : 'Upload Media Files'}
        </h3>

        <p className="text-sm md:text-base text-muted-foreground text-center mb-4 md:mb-6 max-w-md">
          Drag and drop your files here, or click to browse
        </p>

        <input
          type="file"
          id="file-upload"
          multiple
          accept={acceptedTypes}
          onChange={handleFileInput}
          className="hidden"
        />

        <Button
          variant="default"
          size="lg"
          iconName="FolderOpen"
          iconPosition="left"
          onClick={() => document.getElementById('file-upload')?.click()}
        >
          Browse Files
        </Button>

        <div className="mt-6 md:mt-8 flex flex-wrap items-center justify-center gap-3 md:gap-4 text-xs md:text-sm text-muted-foreground">
          <div className="flex items-center gap-2">
            <Icon name="Image" size={16} color="var(--color-muted-foreground)" />
            <span>Photos</span>
          </div>
          <div className="flex items-center gap-2">
            <Icon name="Video" size={16} color="var(--color-muted-foreground)" />
            <span>Videos</span>
          </div>
          <div className="flex items-center gap-2">
            <Icon name="Music" size={16} color="var(--color-muted-foreground)" />
            <span>Audio</span>
          </div>
          <div className="flex items-center gap-2">
            <Icon name="FileText" size={16} color="var(--color-muted-foreground)" />
            <span>Documents</span>
          </div>
        </div>

        <p className="mt-4 text-xs text-muted-foreground">
          Maximum file size: {formatMaxSize(maxSize)}
        </p>
      </div>
    </div>
  );
};

export default FileUploadZone;