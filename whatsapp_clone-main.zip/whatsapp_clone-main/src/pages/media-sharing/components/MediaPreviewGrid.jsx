import React from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';


const MediaPreviewGrid = ({ files, onRemove, onEdit, onCaptionChange }) => {
  const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes?.[i];
  };

  const formatDuration = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs?.toString()?.padStart(2, '0')}`;
  };

  const getFileIcon = (type) => {
    if (type?.startsWith('image/')) return 'Image';
    if (type?.startsWith('video/')) return 'Video';
    if (type?.startsWith('audio/')) return 'Music';
    return 'FileText';
  };

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
      {files?.map((file, index) => (
        <div
          key={index}
          className="relative bg-card border border-border rounded-xl overflow-hidden group hover:shadow-lg transition-all duration-300"
        >
          {/* Preview Area */}
          <div className="relative aspect-video bg-muted">
            {file?.type?.startsWith('image/') ? (
              <Image
                src={file?.preview}
                alt={`Preview of ${file?.name} - uploaded image file`}
                className="w-full h-full object-cover"
              />
            ) : file?.type?.startsWith('video/') ? (
              <>
                <video
                  src={file?.preview}
                  className="w-full h-full object-cover"
                  muted
                />
                <div className="absolute inset-0 flex items-center justify-center bg-black/30">
                  <div className="w-12 h-12 md:w-16 md:h-16 rounded-full bg-white/90 flex items-center justify-center">
                    <Icon name="Play" size={24} color="#000000" />
                  </div>
                </div>
                {file?.duration && (
                  <div className="absolute bottom-2 right-2 px-2 py-1 bg-black/70 text-white text-xs rounded">
                    {formatDuration(file?.duration)}
                  </div>
                )}
              </>
            ) : file?.type?.startsWith('audio/') ? (
              <div className="w-full h-full flex flex-col items-center justify-center">
                <Icon name="Music" size={48} color="var(--color-muted-foreground)" />
                <div className="mt-4 w-full px-4">
                  <div className="h-16 bg-primary/10 rounded flex items-center justify-center">
                    <div className="flex gap-1">
                      {[...Array(20)]?.map((_, i) => (
                        <div
                          key={i}
                          className="w-1 bg-primary rounded-full"
                          style={{ height: `${Math.random() * 40 + 20}px` }}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="w-full h-full flex flex-col items-center justify-center">
                <Icon name={getFileIcon(file?.type)} size={48} color="var(--color-muted-foreground)" />
                <p className="mt-2 text-sm text-muted-foreground">Document</p>
              </div>
            )}

            {/* Action Buttons Overlay */}
            <div className="absolute top-2 right-2 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
              {file?.type?.startsWith('image/') && (
                <button
                  onClick={() => onEdit(index)}
                  className="w-8 h-8 rounded-full bg-white/90 hover:bg-white flex items-center justify-center shadow-lg transition-colors focus-ring"
                  aria-label="Edit image"
                >
                  <Icon name="Edit2" size={16} color="#000000" />
                </button>
              )}
              <button
                onClick={() => onRemove(index)}
                className="w-8 h-8 rounded-full bg-destructive hover:bg-destructive/90 flex items-center justify-center shadow-lg transition-colors focus-ring"
                aria-label="Remove file"
              >
                <Icon name="Trash2" size={16} color="#FFFFFF" />
              </button>
            </div>

            {/* Upload Progress */}
            {file?.uploadProgress !== undefined && file?.uploadProgress < 100 && (
              <div className="absolute bottom-0 left-0 right-0 h-1 bg-black/30">
                <div
                  className="h-full bg-primary transition-all duration-300"
                  style={{ width: `${file?.uploadProgress}%` }}
                />
              </div>
            )}
          </div>

          {/* File Info */}
          <div className="p-3 md:p-4">
            <div className="flex items-start justify-between gap-2 mb-2">
              <p className="text-sm font-medium text-foreground truncate flex-1">
                {file?.name}
              </p>
              <span className="text-xs text-muted-foreground whitespace-nowrap">
                {formatFileSize(file?.size)}
              </span>
            </div>

            {/* Caption Input */}
            <input
              type="text"
              placeholder="Add a caption..."
              value={file?.caption || ''}
              onChange={(e) => onCaptionChange(index, e?.target?.value)}
              className="w-full px-3 py-2 text-sm bg-muted border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-primary transition-all"
            />

            {/* Upload Status */}
            {file?.uploadProgress !== undefined && (
              <div className="mt-2 flex items-center gap-2">
                {file?.uploadProgress < 100 ? (
                  <>
                    <Icon name="Loader2" size={14} color="var(--color-primary)" className="animate-spin" />
                    <span className="text-xs text-muted-foreground">
                      Uploading... {file?.uploadProgress}%
                    </span>
                  </>
                ) : (
                  <>
                    <Icon name="CheckCircle2" size={14} color="var(--color-success)" />
                    <span className="text-xs text-success">Uploaded</span>
                  </>
                )}
              </div>
            )}
          </div>
        </div>
      ))}
    </div>
  );
};

export default MediaPreviewGrid;