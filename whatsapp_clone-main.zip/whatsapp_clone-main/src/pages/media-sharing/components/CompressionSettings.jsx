import React from 'react';
import Icon from '../../../components/AppIcon';
import { Checkbox } from '../../../components/ui/Checkbox';

const CompressionSettings = ({ settings, onSettingsChange }) => {
  const qualityOptions = [
    { value: 'high', label: 'High Quality', description: 'Best quality, larger file size' },
    { value: 'medium', label: 'Medium Quality', description: 'Balanced quality and size' },
    { value: 'low', label: 'Low Quality', description: 'Smaller file size, reduced quality' }
  ];

  return (
    <div className="bg-card border border-border rounded-xl p-4 md:p-6">
      <div className="flex items-center gap-3 mb-4 md:mb-6">
        <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
          <Icon name="Settings" size={20} color="var(--color-primary)" />
        </div>
        <div>
          <h3 className="text-base md:text-lg font-semibold text-foreground">
            Compression Settings
          </h3>
          <p className="text-xs md:text-sm text-muted-foreground">
            Optimize file size for faster uploads
          </p>
        </div>
      </div>
      <div className="space-y-4 md:space-y-6">
        {/* Enable Compression */}
        <Checkbox
          label="Enable compression"
          description="Reduce file size while maintaining quality"
          checked={settings?.enabled}
          onChange={(e) => onSettingsChange({ ...settings, enabled: e?.target?.checked })}
        />

        {/* Quality Selection */}
        {settings?.enabled && (
          <div className="pl-0 md:pl-8 space-y-3">
            <label className="text-sm font-medium text-foreground block">
              Compression Quality
            </label>
            <div className="space-y-2">
              {qualityOptions?.map((option) => (
                <div
                  key={option?.value}
                  className={`p-3 md:p-4 rounded-lg border-2 cursor-pointer transition-all ${
                    settings?.quality === option?.value
                      ? 'border-primary bg-primary/5' :'border-border hover:border-primary/50'
                  }`}
                  onClick={() => onSettingsChange({ ...settings, quality: option?.value })}
                >
                  <div className="flex items-start gap-3">
                    <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center mt-0.5 ${
                      settings?.quality === option?.value
                        ? 'border-primary bg-primary' :'border-border'
                    }`}>
                      {settings?.quality === option?.value && (
                        <div className="w-2 h-2 rounded-full bg-white" />
                      )}
                    </div>
                    <div className="flex-1">
                      <p className="text-sm md:text-base font-medium text-foreground">
                        {option?.label}
                      </p>
                      <p className="text-xs md:text-sm text-muted-foreground mt-1">
                        {option?.description}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Additional Options */}
        {settings?.enabled && (
          <div className="pl-0 md:pl-8 space-y-3">
            <Checkbox
              label="Preserve metadata"
              description="Keep EXIF data and location information"
              checked={settings?.preserveMetadata}
              onChange={(e) => onSettingsChange({ ...settings, preserveMetadata: e?.target?.checked })}
            />
            <Checkbox
              label="Auto-resize large images"
              description="Automatically resize images larger than 4K resolution"
              checked={settings?.autoResize}
              onChange={(e) => onSettingsChange({ ...settings, autoResize: e?.target?.checked })}
            />
          </div>
        )}

        {/* Estimated Savings */}
        {settings?.enabled && (
          <div className="mt-4 p-3 md:p-4 bg-success/10 border border-success/20 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <Icon name="TrendingDown" size={16} color="var(--color-success)" />
              <span className="text-sm font-medium text-success">Estimated Savings</span>
            </div>
            <p className="text-xs md:text-sm text-muted-foreground">
              Files will be approximately 40-60% smaller with {settings?.quality} quality compression
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default CompressionSettings;