import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Image from '../../../components/AppImage';
import Button from '../../../components/ui/Button';

const ImageEditorModal = ({ isOpen, onClose, image, onSave }) => {
  const [rotation, setRotation] = useState(0);
  const [filter, setFilter] = useState('none');
  const [brightness, setBrightness] = useState(100);
  const [contrast, setContrast] = useState(100);

  if (!isOpen) return null;

  const filters = [
    { name: 'None', value: 'none' },
    { name: 'Grayscale', value: 'grayscale(100%)' },
    { name: 'Sepia', value: 'sepia(100%)' },
    { name: 'Vintage', value: 'sepia(50%) contrast(120%)' },
    { name: 'Cool', value: 'hue-rotate(180deg)' },
    { name: 'Warm', value: 'hue-rotate(30deg) saturate(150%)' }
  ];

  const handleRotate = (degrees) => {
    setRotation((prev) => (prev + degrees) % 360);
  };

  const handleSave = () => {
    onSave({
      rotation,
      filter,
      brightness,
      contrast
    });
    onClose();
  };

  const handleReset = () => {
    setRotation(0);
    setFilter('none');
    setBrightness(100);
    setContrast(100);
  };

  return (
    <div className="fixed inset-0 bg-black/80 z-[300] flex items-center justify-center p-4">
      <div className="bg-card rounded-xl w-full max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 md:p-6 border-b border-border">
          <h2 className="text-lg md:text-xl font-semibold text-foreground">Edit Image</h2>
          <button
            onClick={onClose}
            className="p-2 rounded-lg hover:bg-muted transition-colors focus-ring"
            aria-label="Close editor"
          >
            <Icon name="X" size={24} color="var(--color-foreground)" />
          </button>
        </div>

        {/* Preview Area */}
        <div className="flex-1 overflow-auto p-4 md:p-6 bg-muted/30">
          <div className="flex items-center justify-center min-h-[300px] md:min-h-[400px]">
            <div
              className="relative max-w-full max-h-full"
              style={{
                transform: `rotate(${rotation}deg)`,
                transition: 'transform 0.3s ease'
              }}
            >
              <Image
                src={image?.preview}
                alt="Image being edited with filters and adjustments applied"
                className="max-w-full max-h-[400px] md:max-h-[500px] object-contain rounded-lg"
                style={{
                  filter: `${filter !== 'none' ? filter : ''} brightness(${brightness}%) contrast(${contrast}%)`,
                  transition: 'filter 0.3s ease'
                }}
              />
            </div>
          </div>
        </div>

        {/* Controls */}
        <div className="p-4 md:p-6 border-t border-border space-y-4 md:space-y-6">
          {/* Rotation Controls */}
          <div>
            <label className="text-sm font-medium text-foreground mb-3 block">Rotation</label>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                iconName="RotateCcw"
                iconPosition="left"
                onClick={() => handleRotate(-90)}
              >
                Rotate Left
              </Button>
              <Button
                variant="outline"
                size="sm"
                iconName="RotateCw"
                iconPosition="left"
                onClick={() => handleRotate(90)}
              >
                Rotate Right
              </Button>
            </div>
          </div>

          {/* Filter Selection */}
          <div>
            <label className="text-sm font-medium text-foreground mb-3 block">Filters</label>
            <div className="grid grid-cols-3 md:grid-cols-6 gap-2">
              {filters?.map((f) => (
                <button
                  key={f?.name}
                  onClick={() => setFilter(f?.value)}
                  className={`p-2 md:p-3 rounded-lg border-2 transition-all text-xs md:text-sm font-medium ${
                    filter === f?.value
                      ? 'border-primary bg-primary/10 text-primary' :'border-border bg-card text-foreground hover:border-primary/50'
                  }`}
                >
                  {f?.name}
                </button>
              ))}
            </div>
          </div>

          {/* Brightness Control */}
          <div>
            <label className="text-sm font-medium text-foreground mb-2 block">
              Brightness: {brightness}%
            </label>
            <input
              type="range"
              min="0"
              max="200"
              value={brightness}
              onChange={(e) => setBrightness(Number(e?.target?.value))}
              className="w-full h-2 bg-muted rounded-lg appearance-none cursor-pointer"
            />
          </div>

          {/* Contrast Control */}
          <div>
            <label className="text-sm font-medium text-foreground mb-2 block">
              Contrast: {contrast}%
            </label>
            <input
              type="range"
              min="0"
              max="200"
              value={contrast}
              onChange={(e) => setContrast(Number(e?.target?.value))}
              className="w-full h-2 bg-muted rounded-lg appearance-none cursor-pointer"
            />
          </div>
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-between p-4 md:p-6 border-t border-border">
          <Button variant="outline" onClick={handleReset}>
            Reset
          </Button>
          <div className="flex gap-3">
            <Button variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button variant="default" iconName="Check" iconPosition="left" onClick={handleSave}>
              Apply Changes
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ImageEditorModal;