import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';
import ChatTabNavigation from '../../components/ui/ChatTabNavigation';
import ProfileSettingsTrigger from '../../components/ui/ProfileSettingsDropdown';
import FileUploadZone from './components/FileUploadZone';
import MediaPreviewGrid from './components/MediaPreviewGrid';
import ImageEditorModal from './components/ImageEditorModal';
import RecipientSelector from './components/RecipientSelector';
import CompressionSettings from './components/CompressionSettings';

const MediaSharing = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [files, setFiles] = useState([]);
  const [message, setMessage] = useState('');
  const [selectedRecipients, setSelectedRecipients] = useState([]);
  const [isEditorOpen, setIsEditorOpen] = useState(false);
  const [editingImageIndex, setEditingImageIndex] = useState(null);
  const [compressionSettings, setCompressionSettings] = useState({
    enabled: true,
    quality: 'medium',
    preserveMetadata: false,
    autoResize: true
  });
  const [isUploading, setIsUploading] = useState(false);

  const MAX_FILE_SIZE = 100 * 1024 * 1024; // 100MB
  const ACCEPTED_TYPES = 'image/*,video/*,audio/*,.pdf,.doc,.docx,.txt';

  useEffect(() => {
    if (location?.state?.conversationId) {
      setSelectedRecipients([location?.state?.conversationId]);
    }
  }, [location?.state]);

  const validateFile = (file) => {
    if (file?.size > MAX_FILE_SIZE) {
      alert(`File "${file?.name}" exceeds maximum size of 100MB`);
      return false;
    }
    return true;
  };

  const handleFilesSelected = (selectedFiles) => {
    const validFiles = selectedFiles?.filter(validateFile);
    
    const fileObjects = validFiles?.map((file) => ({
      file,
      name: file?.name,
      size: file?.size,
      type: file?.type,
      preview: URL.createObjectURL(file),
      caption: '',
      uploadProgress: 0,
      duration: file?.type?.startsWith('video/') ? Math.floor(Math.random() * 300) + 30 : null
    }));

    setFiles((prev) => [...prev, ...fileObjects]);
  };

  const handleRemoveFile = (index) => {
    setFiles((prev) => {
      const newFiles = [...prev];
      URL.revokeObjectURL(newFiles?.[index]?.preview);
      newFiles?.splice(index, 1);
      return newFiles;
    });
  };

  const handleEditImage = (index) => {
    setEditingImageIndex(index);
    setIsEditorOpen(true);
  };

  const handleSaveEdit = (edits) => {
    console.log('Applying edits:', edits);
    setIsEditorOpen(false);
    setEditingImageIndex(null);
  };

  const handleCaptionChange = (index, caption) => {
    setFiles((prev) => {
      const newFiles = [...prev];
      newFiles[index].caption = caption;
      return newFiles;
    });
  };

  const simulateUpload = (fileIndex) => {
    return new Promise((resolve) => {
      let progress = 0;
      const interval = setInterval(() => {
        progress += Math.random() * 15;
        if (progress >= 100) {
          progress = 100;
          clearInterval(interval);
          resolve();
        }
        setFiles((prev) => {
          const newFiles = [...prev];
          if (newFiles[fileIndex]) {
            newFiles[fileIndex].uploadProgress = Math.floor(progress);
          }
          return newFiles;
        });
      }, 200);
    });
  };

  const handleSend = async () => {
    if (files?.length === 0) {
      alert('Please select at least one file to share');
      return;
    }

    if (selectedRecipients?.length === 0) {
      alert('Please select at least one recipient');
      return;
    }

    setIsUploading(true);

    try {
      for (let i = 0; i < files?.length; i++) {
        await simulateUpload(i);
      }

      setTimeout(() => {
        alert(`Successfully sent ${files?.length} file(s) to ${selectedRecipients?.length} recipient(s)`);
        navigate('/main-chat-interface');
      }, 500);
    } catch (error) {
      console.error('Upload error:', error);
      alert('Failed to upload files. Please try again.');
      setIsUploading(false);
    }
  };

  const handleCancel = () => {
    files?.forEach(file => URL.revokeObjectURL(file?.preview));
    navigate(-1);
  };

  const getTotalSize = () => {
    return files?.reduce((total, file) => total + file?.size, 0);
  };

  const formatTotalSize = (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    let i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes?.[i];
  };

  return (
    <div className="min-h-screen bg-background">
      <ChatTabNavigation />
      {/* Main Content */}
      <div className="lg:ml-[320px] min-h-screen">
        {/* Header */}
        <header className="sticky top-0 z-50 bg-card border-b border-border">
          <div className="flex items-center justify-between px-4 md:px-6 lg:px-8 h-16 md:h-20">
            <div className="flex items-center gap-3 md:gap-4">
              <button
                onClick={handleCancel}
                className="p-2 rounded-lg hover:bg-muted transition-colors focus-ring lg:hidden"
                aria-label="Go back"
              >
                <Icon name="ArrowLeft" size={24} color="var(--color-foreground)" />
              </button>
              <div>
                <h1 className="text-lg md:text-xl lg:text-2xl font-bold text-foreground">
                  Share Media
                </h1>
                <p className="text-xs md:text-sm text-muted-foreground">
                  Upload and share files with your contacts
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 md:gap-3">
              {files?.length > 0 && (
                <div className="hidden md:flex items-center gap-2 px-3 py-1.5 bg-muted rounded-lg">
                  <Icon name="Files" size={16} color="var(--color-foreground)" />
                  <span className="text-sm font-medium text-foreground">
                    {files?.length} file{files?.length !== 1 ? 's' : ''}
                  </span>
                  <span className="text-xs text-muted-foreground">
                    ({formatTotalSize(getTotalSize())})
                  </span>
                </div>
              )}
              <ProfileSettingsTrigger />
            </div>
          </div>
        </header>

        {/* Content Area */}
        <main className="p-4 md:p-6 lg:p-8 pb-24 lg:pb-8">
          <div className="max-w-7xl mx-auto space-y-6 md:space-y-8">
            {/* Upload Zone */}
            {files?.length === 0 && (
              <FileUploadZone
                onFilesSelected={handleFilesSelected}
                acceptedTypes={ACCEPTED_TYPES}
                maxSize={MAX_FILE_SIZE}
              />
            )}

            {/* Media Preview Grid */}
            {files?.length > 0 && (
              <div className="space-y-4 md:space-y-6">
                <div className="flex items-center justify-between">
                  <h2 className="text-base md:text-lg font-semibold text-foreground">
                    Selected Files ({files?.length})
                  </h2>
                  <Button
                    variant="outline"
                    size="sm"
                    iconName="Plus"
                    iconPosition="left"
                    onClick={() => document.getElementById('additional-files')?.click()}
                  >
                    Add More
                  </Button>
                  <input
                    id="additional-files"
                    type="file"
                    multiple
                    accept={ACCEPTED_TYPES}
                    onChange={(e) => handleFilesSelected(Array.from(e?.target?.files))}
                    className="hidden"
                  />
                </div>

                <MediaPreviewGrid
                  files={files}
                  onRemove={handleRemoveFile}
                  onEdit={handleEditImage}
                  onCaptionChange={handleCaptionChange}
                />
              </div>
            )}

            {/* Message Input */}
            {files?.length > 0 && (
              <div className="bg-card border border-border rounded-xl p-4 md:p-6">
                <Input
                  label="Message (Optional)"
                  type="text"
                  placeholder="Add a message to your files..."
                  value={message}
                  onChange={(e) => setMessage(e?.target?.value)}
                  description="This message will be sent with all files"
                />
              </div>
            )}

            {/* Two Column Layout for Recipients and Settings */}
            {files?.length > 0 && (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 md:gap-8">
                <RecipientSelector
                  selectedRecipients={selectedRecipients}
                  onRecipientsChange={setSelectedRecipients}
                />

                <CompressionSettings
                  settings={compressionSettings}
                  onSettingsChange={setCompressionSettings}
                />
              </div>
            )}

            {/* Action Buttons */}
            {files?.length > 0 && (
              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 md:gap-4">
                <Button
                  variant="outline"
                  fullWidth
                  onClick={handleCancel}
                  disabled={isUploading}
                >
                  Cancel
                </Button>
                <Button
                  variant="default"
                  fullWidth
                  iconName="Send"
                  iconPosition="right"
                  onClick={handleSend}
                  loading={isUploading}
                  disabled={selectedRecipients?.length === 0}
                >
                  Send to {selectedRecipients?.length} recipient{selectedRecipients?.length !== 1 ? 's' : ''}
                </Button>
              </div>
            )}
          </div>
        </main>
      </div>
      {/* Image Editor Modal */}
      <ImageEditorModal
        isOpen={isEditorOpen}
        onClose={() => {
          setIsEditorOpen(false);
          setEditingImageIndex(null);
        }}
        image={editingImageIndex !== null ? files?.[editingImageIndex] : null}
        onSave={handleSaveEdit}
      />
    </div>
  );
};

export default MediaSharing;