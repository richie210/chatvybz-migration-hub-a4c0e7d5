import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { Store, Package, CreditCard, Users, Plus, Edit2, Loader2, X, DollarSign, ShoppingCart, BarChart3 } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { businessProfileService } from '../../services/businessProfileService';
import Button from '../../components/ui/Button';
import Input from '../../components/ui/Input';

function BusinessProfileCatalogManagement() {
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [activeTab, setActiveTab] = useState('profile');
  
  const [businessProfile, setBusinessProfile] = useState(null);
  const [products, setProducts] = useState([]);
  const [paymentMethods, setPaymentMethods] = useState([]);
  const [analytics, setAnalytics] = useState([]);
  const [transactions, setTransactions] = useState([]);
  
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [showProductModal, setShowProductModal] = useState(false);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null);

  useEffect(() => {
    if (!authLoading && !user) {
      navigate('/login');
    }
  }, [user, authLoading, navigate]);

  useEffect(() => {
    if (!authLoading && user) {
      loadBusinessData();
    }
  }, [authLoading, user]);

  const loadBusinessData = async () => {
    try {
      setLoading(true);
      setError('');
      
      const profile = await businessProfileService?.getProfile();
      setBusinessProfile(profile);
      
      if (profile) {
        const [productsData, paymentsData, analyticsData, transactionsData] = await Promise.all([
          businessProfileService?.getProducts(profile?.id),
          businessProfileService?.getPaymentMethods(profile?.id),
          businessProfileService?.getAnalytics(profile?.id),
          businessProfileService?.getTransactions(profile?.id)
        ]);
        
        setProducts(productsData);
        setPaymentMethods(paymentsData);
        setAnalytics(analyticsData);
        setTransactions(transactionsData);
      }
    } catch (err) {
      setError(err?.message || 'Failed to load business data');
    } finally {
      setLoading(false);
    }
  };

  const handleCreateProfile = async (e) => {
    e?.preventDefault();
    const formData = new FormData(e?.target);
    
    try {
      await businessProfileService?.createProfile({
        businessName: formData?.get('businessName'),
        businessDescription: formData?.get('businessDescription'),
        businessCategory: formData?.get('businessCategory'),
        businessEmail: formData?.get('businessEmail'),
        businessPhone: formData?.get('businessPhone'),
        businessAddress: formData?.get('businessAddress'),
        businessWebsite: formData?.get('businessWebsite')
      });
      
      setShowProfileModal(false);
      await loadBusinessData();
    } catch (err) {
      setError(err?.message || 'Failed to create business profile');
    }
  };

  const handleAddProduct = async (e) => {
    e?.preventDefault();
    const formData = new FormData(e?.target);
    
    try {
      if (editingProduct) {
        await businessProfileService?.updateProduct(editingProduct?.id, {
          product_name: formData?.get('productName'),
          product_description: formData?.get('productDescription'),
          product_category: formData?.get('productCategory'),
          price: parseFloat(formData?.get('price')),
          stock_quantity: parseInt(formData?.get('stockQuantity')),
          is_available: formData?.get('isAvailable') === 'true'
        });
      } else {
        await businessProfileService?.addProduct(businessProfile?.id, {
          productName: formData?.get('productName'),
          productDescription: formData?.get('productDescription'),
          productCategory: formData?.get('productCategory'),
          price: parseFloat(formData?.get('price')),
          stockQuantity: parseInt(formData?.get('stockQuantity')),
          isAvailable: formData?.get('isAvailable') === 'true'
        });
      }
      
      setShowProductModal(false);
      setEditingProduct(null);
      await loadBusinessData();
    } catch (err) {
      setError(err?.message || 'Failed to save product');
    }
  };

  const handleDeleteProduct = async (productId) => {
    if (!window.confirm('Are you sure you want to delete this product?')) return;
    
    try {
      await businessProfileService?.deleteProduct(productId);
      await loadBusinessData();
    } catch (err) {
      setError(err?.message || 'Failed to delete product');
    }
  };

  const handleAddPaymentMethod = async (e) => {
    e?.preventDefault();
    const formData = new FormData(e?.target);
    
    try {
      await businessProfileService?.addPaymentMethod(businessProfile?.id, {
        methodType: formData?.get('methodType'),
        provider: formData?.get('provider'),
        isActive: true
      });
      
      setShowPaymentModal(false);
      await loadBusinessData();
    } catch (err) {
      setError(err?.message || 'Failed to add payment method');
    }
  };

  if (authLoading || loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-50">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Business Profile & Catalog Management</title>
        <meta name="description" content="Manage your business profile, product catalog, and payment integration" />
      </Helmet>
      <div className="min-h-screen bg-gray-50">
        <div className="bg-white border-b border-gray-200 shadow-sm">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-gradient-to-br from-purple-500 to-pink-600 rounded-lg">
                  <Store className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-gray-900">Business Management</h1>
                  <p className="text-sm text-gray-600">Manage your business profile and catalog</p>
                </div>
              </div>
              <button
                onClick={() => navigate('/chat')}
                className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Back to Chat
              </button>
            </div>
          </div>
        </div>

        {error && (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-4">
            <div className="p-4 bg-red-50 border border-red-200 rounded-lg flex items-center justify-between">
              <p className="text-sm text-red-800">{error}</p>
              <button onClick={() => setError('')} className="text-red-600 hover:text-red-800">
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>
        )}

        {!businessProfile ? (
          <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8 text-center">
              <Store className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Create Your Business Profile</h2>
              <p className="text-gray-600 mb-6">Set up your business account to start selling products and accepting payments</p>
              <Button onClick={() => setShowProfileModal(true)} className="flex items-center gap-2 mx-auto">
                <Plus className="w-4 h-4" />
                Create Business Profile
              </Button>
            </div>
          </div>
        ) : (
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <div className="flex space-x-1 mb-6 bg-white rounded-lg p-1 border border-gray-200">
              {[
                { id: 'profile', label: 'Profile', icon: Store },
                { id: 'catalog', label: 'Product Catalog', icon: Package },
                { id: 'payments', label: 'Payments', icon: CreditCard },
                { id: 'analytics', label: 'Analytics', icon: BarChart3 }
              ]?.map(tab => (
                <button
                  key={tab?.id}
                  onClick={() => setActiveTab(tab?.id)}
                  className={`flex-1 flex items-center justify-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                    activeTab === tab?.id
                      ? 'bg-blue-600 text-white' :'text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  <tab.icon className="w-4 h-4" />
                  {tab?.label}
                </button>
              ))}
            </div>

            {activeTab === 'profile' && (
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold text-gray-900">Business Profile</h2>
                  <Button onClick={() => setShowProfileModal(true)} variant="outline" size="sm">
                    <Edit2 className="w-4 h-4 mr-2" />
                    Edit Profile
                  </Button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="text-sm font-medium text-gray-700">Business Name</label>
                    <p className="text-gray-900 mt-1">{businessProfile?.business_name}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-700">Category</label>
                    <p className="text-gray-900 mt-1">{businessProfile?.business_category || 'Not specified'}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-700">Email</label>
                    <p className="text-gray-900 mt-1">{businessProfile?.business_email || 'Not specified'}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-700">Phone</label>
                    <p className="text-gray-900 mt-1">{businessProfile?.business_phone || 'Not specified'}</p>
                  </div>
                  <div className="md:col-span-2">
                    <label className="text-sm font-medium text-gray-700">Description</label>
                    <p className="text-gray-900 mt-1">{businessProfile?.business_description || 'No description provided'}</p>
                  </div>
                  <div className="md:col-span-2">
                    <label className="text-sm font-medium text-gray-700">Address</label>
                    <p className="text-gray-900 mt-1">{businessProfile?.business_address || 'Not specified'}</p>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'catalog' && (
              <div>
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold text-gray-900">Product Catalog</h2>
                  <Button onClick={() => { setEditingProduct(null); setShowProductModal(true); }} className="flex items-center gap-2">
                    <Plus className="w-4 h-4" />
                    Add Product
                  </Button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {products?.map(product => (
                    <div key={product?.id} className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                      <div className="h-48 bg-gradient-to-br from-blue-100 to-purple-100 flex items-center justify-center">
                        <Package className="w-16 h-16 text-gray-400" />
                      </div>
                      <div className="p-4">
                        <h3 className="font-semibold text-gray-900 mb-1">{product?.product_name}</h3>
                        <p className="text-sm text-gray-600 mb-2 line-clamp-2">{product?.product_description}</p>
                        <div className="flex items-center justify-between mb-3">
                          <span className="text-lg font-bold text-blue-600">${product?.price}</span>
                          <span className={`px-2 py-1 text-xs rounded-full ${
                            product?.is_available ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
                          }`}>
                            {product?.is_available ? 'Available' : 'Out of Stock'}
                          </span>
                        </div>
                        <div className="flex gap-2">
                          <button
                            onClick={() => { setEditingProduct(product); setShowProductModal(true); }}
                            className="flex-1 px-3 py-2 text-sm font-medium text-blue-600 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors"
                          >
                            Edit
                          </button>
                          <button
                            onClick={() => handleDeleteProduct(product?.id)}
                            className="flex-1 px-3 py-2 text-sm font-medium text-red-600 bg-red-50 rounded-lg hover:bg-red-100 transition-colors"
                          >
                            Delete
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                {products?.length === 0 && (
                  <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-12 text-center">
                    <Package className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-600">No products yet. Add your first product to get started.</p>
                  </div>
                )}
              </div>
            )}

            {activeTab === 'payments' && (
              <div>
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold text-gray-900">Payment Methods</h2>
                  <Button onClick={() => setShowPaymentModal(true)} className="flex items-center gap-2">
                    <Plus className="w-4 h-4" />
                    Add Payment Method
                  </Button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                  {paymentMethods?.map(method => (
                    <div key={method?.id} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center gap-3">
                          <div className="p-2 bg-green-100 rounded-lg">
                            <CreditCard className="w-5 h-5 text-green-600" />
                          </div>
                          <div>
                            <h3 className="font-semibold text-gray-900">{method?.provider}</h3>
                            <p className="text-sm text-gray-600">{method?.method_type}</p>
                          </div>
                        </div>
                        <span className={`px-2 py-1 text-xs rounded-full ${
                          method?.is_active ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'
                        }`}>
                          {method?.is_active ? 'Active' : 'Inactive'}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
                {paymentMethods?.length === 0 && (
                  <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-12 text-center">
                    <CreditCard className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-600">No payment methods configured. Add a payment method to start accepting payments.</p>
                  </div>
                )}

                <h3 className="text-lg font-bold text-gray-900 mb-4">Recent Transactions</h3>
                <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full">
                      <thead className="bg-gray-50 border-b border-gray-200">
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Customer</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Amount</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-200">
                        {transactions?.slice(0, 10)?.map(transaction => (
                          <tr key={transaction?.id}>
                            <td className="px-6 py-4 text-sm text-gray-900">
                              {new Date(transaction?.created_at)?.toLocaleDateString()}
                            </td>
                            <td className="px-6 py-4 text-sm text-gray-900">
                              {transaction?.customer?.full_name || 'Guest'}
                            </td>
                            <td className="px-6 py-4 text-sm font-medium text-gray-900">
                              ${transaction?.amount}
                            </td>
                            <td className="px-6 py-4 text-sm">
                              <span className={`px-2 py-1 text-xs rounded-full ${
                                transaction?.status === 'completed' ? 'bg-green-100 text-green-700' :
                                transaction?.status === 'pending'? 'bg-yellow-100 text-yellow-700' : 'bg-red-100 text-red-700'
                              }`}>
                                {transaction?.status}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  {transactions?.length === 0 && (
                    <div className="p-12 text-center">
                      <ShoppingCart className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-600">No transactions yet.</p>
                    </div>
                  )}
                </div>
              </div>
            )}

            {activeTab === 'analytics' && (
              <div>
                <h2 className="text-xl font-bold text-gray-900 mb-6">Business Analytics</h2>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                  <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className="p-2 bg-blue-100 rounded-lg">
                        <DollarSign className="w-5 h-5 text-blue-600" />
                      </div>
                    </div>
                    <h3 className="text-sm font-medium text-gray-600 mb-1">Total Sales</h3>
                    <p className="text-3xl font-bold text-gray-900">$0</p>
                  </div>
                  <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className="p-2 bg-green-100 rounded-lg">
                        <ShoppingCart className="w-5 h-5 text-green-600" />
                      </div>
                    </div>
                    <h3 className="text-sm font-medium text-gray-600 mb-1">Total Orders</h3>
                    <p className="text-3xl font-bold text-gray-900">0</p>
                  </div>
                  <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div className="p-2 bg-purple-100 rounded-lg">
                        <Users className="w-5 h-5 text-purple-600" />
                      </div>
                    </div>
                    <h3 className="text-sm font-medium text-gray-600 mb-1">Total Customers</h3>
                    <p className="text-3xl font-bold text-gray-900">0</p>
                  </div>
                </div>
                <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-12 text-center">
                  <BarChart3 className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600">Analytics data will appear here as you make sales.</p>
                </div>
              </div>
            )}
          </div>
        )}

        {showProfileModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
              <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
                <h2 className="text-xl font-bold text-gray-900">
                  {businessProfile ? 'Edit Business Profile' : 'Create Business Profile'}
                </h2>
                <button onClick={() => setShowProfileModal(false)} className="text-gray-500 hover:text-gray-700">
                  <X className="w-6 h-6" />
                </button>
              </div>
              <form onSubmit={handleCreateProfile} className="p-6 space-y-4">
                <Input name="businessName" label="Business Name" required defaultValue={businessProfile?.business_name} />
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                  <textarea
                    name="businessDescription"
                    rows={3}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    defaultValue={businessProfile?.business_description}
                  />
                </div>
                <Input name="businessCategory" label="Category" defaultValue={businessProfile?.business_category} />
                <Input name="businessEmail" label="Email" type="email" defaultValue={businessProfile?.business_email} />
                <Input name="businessPhone" label="Phone" defaultValue={businessProfile?.business_phone} />
                <Input name="businessAddress" label="Address" defaultValue={businessProfile?.business_address} />
                <Input name="businessWebsite" label="Website" defaultValue={businessProfile?.business_website} />
                <div className="flex gap-3 pt-4">
                  <Button type="submit" className="flex-1">Save Profile</Button>
                  <Button type="button" variant="outline" onClick={() => setShowProfileModal(false)} className="flex-1">
                    Cancel
                  </Button>
                </div>
              </form>
            </div>
          </div>
        )}

        {showProductModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
              <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
                <h2 className="text-xl font-bold text-gray-900">
                  {editingProduct ? 'Edit Product' : 'Add Product'}
                </h2>
                <button onClick={() => { setShowProductModal(false); setEditingProduct(null); }} className="text-gray-500 hover:text-gray-700">
                  <X className="w-6 h-6" />
                </button>
              </div>
              <form onSubmit={handleAddProduct} className="p-6 space-y-4">
                <Input name="productName" label="Product Name" required defaultValue={editingProduct?.product_name} />
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                  <textarea
                    name="productDescription"
                    rows={3}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    defaultValue={editingProduct?.product_description}
                  />
                </div>
                <Input name="productCategory" label="Category" defaultValue={editingProduct?.product_category} />
                <Input name="price" label="Price" type="number" step="0.01" required defaultValue={editingProduct?.price} />
                <Input name="stockQuantity" label="Stock Quantity" type="number" defaultValue={editingProduct?.stock_quantity || 0} />
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Availability</label>
                  <select
                    name="isAvailable"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    defaultValue={editingProduct?.is_available !== false ? 'true' : 'false'}
                  >
                    <option value="true">Available</option>
                    <option value="false">Out of Stock</option>
                  </select>
                </div>
                <div className="flex gap-3 pt-4">
                  <Button type="submit" className="flex-1">Save Product</Button>
                  <Button type="button" variant="outline" onClick={() => { setShowProductModal(false); setEditingProduct(null); }} className="flex-1">
                    Cancel
                  </Button>
                </div>
              </form>
            </div>
          </div>
        )}

        {showPaymentModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-xl shadow-2xl w-full max-w-md">
              <div className="border-b border-gray-200 px-6 py-4 flex items-center justify-between">
                <h2 className="text-xl font-bold text-gray-900">Add Payment Method</h2>
                <button onClick={() => setShowPaymentModal(false)} className="text-gray-500 hover:text-gray-700">
                  <X className="w-6 h-6" />
                </button>
              </div>
              <form onSubmit={handleAddPaymentMethod} className="p-6 space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Payment Provider</label>
                  <select
                    name="provider"
                    required
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="">Select Provider</option>
                    <option value="stripe">Stripe</option>
                    <option value="paypal">PayPal</option>
                    <option value="square">Square</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Method Type</label>
                  <select
                    name="methodType"
                    required
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="">Select Type</option>
                    <option value="credit_card">Credit Card</option>
                    <option value="digital_wallet">Digital Wallet</option>
                    <option value="bank_transfer">Bank Transfer</option>
                  </select>
                </div>
                <div className="flex gap-3 pt-4">
                  <Button type="submit" className="flex-1">Add Method</Button>
                  <Button type="button" variant="outline" onClick={() => setShowPaymentModal(false)} className="flex-1">
                    Cancel
                  </Button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </>
  );
}

export default BusinessProfileCatalogManagement;
