import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { Megaphone, Plus, Calendar, Target, BarChart3, Loader2, AlertCircle, Trash2, Eye } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { adminAnalyticsService } from '../../services/adminAnalyticsService';
import { adminAdService } from '../../services/adminAdService';
import Button from '../../components/ui/Button';

export default function AdminAnnouncementBroadcastingSystem() {
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();

  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [ads, setAds] = useState([]);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [error, setError] = useState('');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [selectedAd, setSelectedAd] = useState(null);
  const [showPerformanceModal, setShowPerformanceModal] = useState(false);
  const [adPerformance, setAdPerformance] = useState(null);

  // Form state
  const [formData, setFormData] = useState({
    ad_type: 'text_announcement',
    title: '',
    description: '',
    media_url: '',
    target_url: '',
    start_date: '',
    end_date: '',
    target_countries: [],
    is_active: true
  });

  useEffect(() => {
    if (!authLoading && !user) {
      navigate('/login');
    }
  }, [user, authLoading, navigate]);

  useEffect(() => {
    if (!authLoading && user) {
      checkAdminAndLoadData();
    }
  }, [authLoading, user, page]);

  const checkAdminAndLoadData = async () => {
    try {
      setLoading(true);
      setError('');

      const adminStatus = await adminAnalyticsService?.isAdmin();
      setIsAdmin(adminStatus);

      if (!adminStatus) {
        setError('Access denied. Admin privileges required.');
        setLoading(false);
        return;
      }

      await loadAds();
    } catch (err) {
      console.error('Error checking admin status:', err);
      setError(err?.message || 'Failed to load data');
    } finally {
      setLoading(false);
    }
  };

  const loadAds = async () => {
    try {
      const result = await adminAdService?.getAds({ page, limit: 10 });
      if (result?.error) throw result?.error;

      setAds(result?.data || []);
      setTotalPages(result?.totalPages || 1);
    } catch (err) {
      console.error('Error loading ads:', err);
      setError(err?.message || 'Failed to load ads');
    }
  };

  const handleCreateAd = async (e) => {
    e?.preventDefault();

    try {
      setError('');
      const result = await adminAdService?.createAd(formData);
      if (result?.error) throw result?.error;

      alert('Ad created successfully!');
      setShowCreateModal(false);
      resetForm();
      await loadAds();
    } catch (err) {
      setError(err?.message || 'Failed to create ad');
    }
  };

  const handleDeleteAd = async (adId) => {
    if (!confirm('Are you sure you want to delete this ad?')) return;

    try {
      const result = await adminAdService?.deleteAd(adId);
      if (result?.error) throw result?.error;

      alert('Ad deleted successfully');
      await loadAds();
    } catch (err) {
      alert(err?.message || 'Failed to delete ad');
    }
  };

  const handleViewPerformance = async (ad) => {
    try {
      setSelectedAd(ad);
      setShowPerformanceModal(true);

      const result = await adminAdService?.getAdPerformance(ad?.id);
      if (result?.error) throw result?.error;

      setAdPerformance(result?.data);
    } catch (err) {
      alert(err?.message || 'Failed to load performance data');
    }
  };

  const resetForm = () => {
    setFormData({
      ad_type: 'text_announcement',
      title: '',
      description: '',
      media_url: '',
      target_url: '',
      start_date: '',
      end_date: '',
      target_countries: [],
      is_active: true
    });
  };

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e?.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleCountriesChange = (e) => {
    const value = e?.target?.value;
    const countries = value?.split(',')?.map(c => c?.trim())?.filter(Boolean);
    setFormData(prev => ({ ...prev, target_countries: countries }));
  };

  if (authLoading || loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-50">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-50">
        <div className="text-center">
          <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Access Denied</h2>
          <p className="text-gray-600 mb-4">Admin privileges required to access this page.</p>
          <Button onClick={() => navigate('/chat')}>Return to Chat</Button>
        </div>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Admin Announcement Broadcasting - ChatVybz</title>
        <meta name="description" content="Create and manage system-wide announcements and advertisements" />
      </Helmet>

      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <div className="bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-lg">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Megaphone className="w-8 h-8" />
                <div>
                  <h1 className="text-2xl font-bold">Announcement Broadcasting</h1>
                  <p className="text-purple-100 text-sm">Create and manage platform announcements</p>
                </div>
              </div>
              <div className="flex gap-3">
                <Button
                  variant="outline"
                  className="bg-white text-purple-600 hover:bg-purple-50"
                  onClick={() => navigate('/chat-vybz-admin-dashboard')}
                >
                  Dashboard
                </Button>
                <Button
                  className="bg-white text-purple-600 hover:bg-purple-50"
                  onClick={() => setShowCreateModal(true)}
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Create Ad
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-6">
              <p className="text-red-800">{error}</p>
            </div>
          )}

          {/* Ads List */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200">
            <div className="px-6 py-4 border-b border-gray-200">
              <h2 className="text-lg font-semibold text-gray-900">Active Campaigns</h2>
            </div>

            <div className="divide-y divide-gray-200">
              {ads?.length === 0 ? (
                <div className="px-6 py-12 text-center text-gray-500">
                  <Megaphone className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                  <p>No ads created yet. Create your first announcement!</p>
                </div>
              ) : (
                ads?.map((ad) => (
                  <div key={ad?.id} className="px-6 py-4 hover:bg-gray-50">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h3 className="text-lg font-semibold text-gray-900">{ad?.title}</h3>
                          <span
                            className={`px-2 py-1 text-xs font-medium rounded-full ${
                              ad?.is_active
                                ? 'bg-green-100 text-green-800' :'bg-gray-100 text-gray-800'
                            }`}
                          >
                            {ad?.is_active ? 'Active' : 'Inactive'}
                          </span>
                          <span className="px-2 py-1 text-xs font-medium rounded-full bg-blue-100 text-blue-800">
                            {ad?.ad_type?.replace('_', ' ')}
                          </span>
                        </div>
                        <p className="text-sm text-gray-600 mb-3">{ad?.description}</p>
                        <div className="flex items-center gap-6 text-sm text-gray-500">
                          <div className="flex items-center gap-1">
                            <Calendar className="w-4 h-4" />
                            <span>
                              {new Date(ad?.start_date)?.toLocaleDateString()} -{' '}
                              {new Date(ad?.end_date)?.toLocaleDateString()}
                            </span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Target className="w-4 h-4" />
                            <span>
                              {ad?.target_countries?.length > 0
                                ? ad?.target_countries?.join(', ')
                                : 'All countries'}
                            </span>
                          </div>
                          <div className="flex items-center gap-1">
                            <BarChart3 className="w-4 h-4" />
                            <span>
                              {ad?.impressions_count?.toLocaleString()} impressions,{' '}
                              {ad?.clicks_count?.toLocaleString()} clicks
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="flex gap-2 ml-4">
                        <button
                          onClick={() => handleViewPerformance(ad)}
                          className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                          title="View Performance"
                        >
                          <Eye className="w-5 h-5" />
                        </button>
                        <button
                          onClick={() => handleDeleteAd(ad?.id)}
                          className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                          title="Delete"
                        >
                          <Trash2 className="w-5 h-5" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="px-6 py-4 border-t border-gray-200 flex items-center justify-between">
                <div className="text-sm text-gray-700">
                  Page {page} of {totalPages}
                </div>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setPage(Math.max(1, page - 1))}
                    disabled={page === 1}
                  >
                    Previous
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setPage(Math.min(totalPages, page + 1))}
                    disabled={page === totalPages}
                  >
                    Next
                  </Button>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Create Ad Modal */}
        {showCreateModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
              <div className="px-6 py-4 border-b border-gray-200">
                <h2 className="text-xl font-semibold text-gray-900">Create New Ad</h2>
              </div>

              <form onSubmit={handleCreateAd} className="px-6 py-4 space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Ad Type
                  </label>
                  <select
                    name="ad_type"
                    value={formData?.ad_type}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                    required
                  >
                    <option value="text_announcement">Text Announcement</option>
                    <option value="banner">Banner Image</option>
                    <option value="video_30s">Video (30s)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Title *
                  </label>
                  <input
                    type="text"
                    name="title"
                    value={formData?.title}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Description
                  </label>
                  <textarea
                    name="description"
                    value={formData?.description}
                    onChange={handleInputChange}
                    rows={3}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Media URL (for banner/video)
                  </label>
                  <input
                    type="url"
                    name="media_url"
                    value={formData?.media_url}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Target URL
                  </label>
                  <input
                    type="url"
                    name="target_url"
                    value={formData?.target_url}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Start Date *
                    </label>
                    <input
                      type="datetime-local"
                      name="start_date"
                      value={formData?.start_date}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      End Date *
                    </label>
                    <input
                      type="datetime-local"
                      name="end_date"
                      value={formData?.end_date}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Target Countries (comma-separated, leave empty for all)
                  </label>
                  <input
                    type="text"
                    placeholder="US, GB, CA, AU"
                    value={formData?.target_countries?.join(', ')}
                    onChange={handleCountriesChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  />
                </div>

                <div className="flex items-center">
                  <input
                    type="checkbox"
                    name="is_active"
                    checked={formData?.is_active}
                    onChange={handleInputChange}
                    className="w-4 h-4 text-purple-600 border-gray-300 rounded focus:ring-purple-500"
                  />
                  <label className="ml-2 text-sm text-gray-700">
                    Active (start showing immediately)
                  </label>
                </div>

                <div className="flex justify-end gap-3 pt-4 border-t border-gray-200">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      setShowCreateModal(false);
                      resetForm();
                    }}
                  >
                    Cancel
                  </Button>
                  <Button type="submit">Create Ad</Button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Performance Modal */}
        {showPerformanceModal && selectedAd && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
              <div className="px-6 py-4 border-b border-gray-200">
                <h2 className="text-xl font-semibold text-gray-900">Ad Performance</h2>
                <p className="text-sm text-gray-600">{selectedAd?.title}</p>
              </div>

              <div className="px-6 py-4 space-y-6">
                {adPerformance ? (
                  <>
                    <div className="grid grid-cols-3 gap-4">
                      <div className="bg-blue-50 rounded-lg p-4">
                        <p className="text-sm text-blue-600 font-medium">Impressions</p>
                        <p className="text-2xl font-bold text-blue-900">
                          {adPerformance?.totalImpressions?.toLocaleString()}
                        </p>
                      </div>
                      <div className="bg-green-50 rounded-lg p-4">
                        <p className="text-sm text-green-600 font-medium">Clicks</p>
                        <p className="text-2xl font-bold text-green-900">
                          {adPerformance?.totalClicks?.toLocaleString()}
                        </p>
                      </div>
                      <div className="bg-purple-50 rounded-lg p-4">
                        <p className="text-sm text-purple-600 font-medium">CTR</p>
                        <p className="text-2xl font-bold text-purple-900">{adPerformance?.ctr}%</p>
                      </div>
                    </div>
                  </>
                ) : (
                  <div className="flex items-center justify-center py-8">
                    <Loader2 className="w-8 h-8 animate-spin text-purple-600" />
                  </div>
                )}
              </div>

              <div className="px-6 py-4 border-t border-gray-200 flex justify-end">
                <Button
                  onClick={() => {
                    setShowPerformanceModal(false);
                    setSelectedAd(null);
                    setAdPerformance(null);
                  }}
                >
                  Close
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </>
  );
}