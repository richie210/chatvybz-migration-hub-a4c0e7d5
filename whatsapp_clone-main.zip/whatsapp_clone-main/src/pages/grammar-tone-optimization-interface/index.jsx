import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

import Button from '../../components/ui/Button';
import { grammarToneService } from '../../services/grammarToneService';
import { ArrowLeft, Check, X, Sparkles, AlertCircle } from 'lucide-react';

export default function GrammarToneOptimizationInterface() {
  const navigate = useNavigate();
  const [messageText, setMessageText] = useState('');
  const [selectedTone, setSelectedTone] = useState('professional');
  const [analyzing, setAnalyzing] = useState(false);
  const [grammarResults, setGrammarResults] = useState(null);
  const [toneResults, setToneResults] = useState(null);
  const [error, setError] = useState(null);
  const [activeTab, setActiveTab] = useState('grammar');

  const toneOptions = [
    { value: 'professional', label: 'Professional', icon: '💼', description: 'Business-appropriate tone' },
    { value: 'casual', label: 'Casual', icon: '😊', description: 'Relaxed and informal' },
    { value: 'friendly', label: 'Friendly', icon: '🤝', description: 'Warm and approachable' },
    { value: 'formal', label: 'Formal', icon: '🎩', description: 'Respectful and proper' },
    { value: 'enthusiastic', label: 'Enthusiastic', icon: '🎉', description: 'Energetic and excited' },
    { value: 'neutral', label: 'Neutral', icon: '⚖️', description: 'Balanced and objective' }
  ];

  const handleAnalyze = async () => {
    if (!messageText?.trim()) {
      setError('Please enter a message to analyze');
      return;
    }

    setAnalyzing(true);
    setError(null);
    setGrammarResults(null);
    setToneResults(null);

    try {
      const results = await grammarToneService?.enhanceMessage(messageText, selectedTone);
      setGrammarResults(results?.grammar);
      setToneResults(results?.tone);
    } catch (err) {
      setError(err?.message || 'Failed to analyze message');
    } finally {
      setAnalyzing(false);
    }
  };

  const handleApplySuggestion = (suggestion) => {
    setMessageText(suggestion);
    setGrammarResults(null);
    setToneResults(null);
  };

  const getErrorTypeColor = (type) => {
    const colors = {
      grammar: 'text-red-600 bg-red-50',
      spelling: 'text-orange-600 bg-orange-50',
      clarity: 'text-blue-600 bg-blue-50',
      punctuation: 'text-purple-600 bg-purple-50'
    };
    return colors?.[type] || 'text-gray-600 bg-gray-50';
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-primary text-white shadow-md">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center gap-4">
          <button
            onClick={() => navigate(-1)}
            className="p-2 hover:bg-white/10 rounded-lg transition-colors"
            aria-label="Go back"
          >
            <ArrowLeft size={24} />
          </button>
          <div className="flex-1">
            <h1 className="text-xl font-bold">Grammar & Tone Optimization</h1>
            <p className="text-sm text-white/80">AI-powered message enhancement</p>
          </div>
          <Sparkles size={24} className="text-yellow-300" />
        </div>
      </div>
      <div className="max-w-6xl mx-auto p-4 space-y-6">
        {/* Input Section */}
        <div className="bg-card border border-border rounded-xl p-6 shadow-sm">
          <label className="block text-sm font-semibold text-foreground mb-2">
            Your Message
          </label>
          <textarea
            value={messageText}
            onChange={(e) => setMessageText(e?.target?.value)}
            placeholder="Type or paste your message here..."
            className="w-full h-32 px-4 py-3 border border-border rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent resize-none text-foreground bg-background"
          />
          <div className="flex items-center justify-between mt-2">
            <span className="text-sm text-muted-foreground">
              {messageText?.length} characters
            </span>
            {messageText?.length > 0 && (
              <button
                onClick={() => setMessageText('')}
                className="text-sm text-muted-foreground hover:text-foreground transition-colors"
              >
                Clear
              </button>
            )}
          </div>
        </div>

        {/* Tone Selection */}
        <div className="bg-card border border-border rounded-xl p-6 shadow-sm">
          <label className="block text-sm font-semibold text-foreground mb-4">
            Target Tone
          </label>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {toneOptions?.map((tone) => (
              <button
                key={tone?.value}
                onClick={() => setSelectedTone(tone?.value)}
                className={`p-4 rounded-lg border-2 transition-all text-left ${
                  selectedTone === tone?.value
                    ? 'border-primary bg-primary/5' :'border-border hover:border-primary/50'
                }`}
              >
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-2xl">{tone?.icon}</span>
                  <span className="font-semibold text-foreground">{tone?.label}</span>
                </div>
                <p className="text-xs text-muted-foreground">{tone?.description}</p>
              </button>
            ))}
          </div>
        </div>

        {/* Analyze Button */}
        <Button
          onClick={handleAnalyze}
          loading={analyzing}
          disabled={!messageText?.trim() || analyzing}
          fullWidth
          size="lg"
          iconName="Sparkles"
          iconPosition="left"
        >
          {analyzing ? 'Analyzing...' : 'Analyze & Optimize'}
        </Button>

        {/* Error Message */}
        {error && (
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 flex items-start gap-3">
            <AlertCircle size={20} className="text-red-600 flex-shrink-0 mt-0.5" />
            <div>
              <p className="text-sm font-semibold text-red-800">Error</p>
              <p className="text-sm text-red-600">{error}</p>
            </div>
          </div>
        )}

        {/* Results Section */}
        {(grammarResults || toneResults) && (
          <div className="bg-card border border-border rounded-xl shadow-sm overflow-hidden">
            {/* Tabs */}
            <div className="flex border-b border-border">
              <button
                onClick={() => setActiveTab('grammar')}
                className={`flex-1 px-6 py-4 font-semibold transition-colors ${
                  activeTab === 'grammar' ?'text-primary border-b-2 border-primary bg-primary/5' :'text-muted-foreground hover:text-foreground'
                }`}
              >
                Grammar Check
                {grammarResults?.hasErrors && (
                  <span className="ml-2 px-2 py-0.5 bg-red-100 text-red-600 text-xs rounded-full">
                    {grammarResults?.corrections?.length}
                  </span>
                )}
              </button>
              <button
                onClick={() => setActiveTab('tone')}
                className={`flex-1 px-6 py-4 font-semibold transition-colors ${
                  activeTab === 'tone' ?'text-primary border-b-2 border-primary bg-primary/5' :'text-muted-foreground hover:text-foreground'
                }`}
              >
                Tone Optimization
              </button>
            </div>

            {/* Grammar Tab */}
            {activeTab === 'grammar' && grammarResults && (
              <div className="p-6 space-y-4">
                {grammarResults?.hasErrors ? (
                  <>
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <h3 className="font-semibold text-foreground">Corrections Found</h3>
                        <p className="text-sm text-muted-foreground">
                          {grammarResults?.corrections?.length} issue(s) detected
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-muted-foreground">Confidence</p>
                        <p className="text-lg font-bold text-primary">
                          {Math.round(grammarResults?.confidenceScore * 100)}%
                        </p>
                      </div>
                    </div>

                    {/* Corrections List */}
                    <div className="space-y-3">
                      {grammarResults?.corrections?.map((correction, index) => (
                        <div
                          key={index}
                          className="p-4 border border-border rounded-lg bg-background"
                        >
                          <div className="flex items-start gap-3 mb-2">
                            <span
                              className={`px-2 py-1 rounded text-xs font-semibold ${
                                getErrorTypeColor(correction?.type)
                              }`}
                            >
                              {correction?.type}
                            </span>
                          </div>
                          <div className="space-y-2">
                            <div className="flex items-center gap-2">
                              <X size={16} className="text-red-500" />
                              <span className="text-sm text-muted-foreground line-through">
                                {correction?.original}
                              </span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Check size={16} className="text-green-500" />
                              <span className="text-sm font-semibold text-foreground">
                                {correction?.corrected}
                              </span>
                            </div>
                          </div>
                          <p className="text-sm text-muted-foreground mt-2">
                            {correction?.explanation}
                          </p>
                        </div>
                      ))}
                    </div>

                    {/* Corrected Message */}
                    <div className="mt-6 p-4 bg-green-50 border border-green-200 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-semibold text-green-800">Corrected Message</h4>
                        <Button
                          size="sm"
                          onClick={() => handleApplySuggestion(grammarResults?.correctedMessage)}
                        >
                          Apply
                        </Button>
                      </div>
                      <p className="text-sm text-green-900">
                        {grammarResults?.correctedMessage}
                      </p>
                    </div>
                  </>
                ) : (
                  <div className="text-center py-8">
                    <Check size={48} className="text-green-500 mx-auto mb-3" />
                    <h3 className="font-semibold text-foreground mb-1">
                      No Grammar Issues Found
                    </h3>
                    <p className="text-sm text-muted-foreground">
                      Your message looks great!
                    </p>
                  </div>
                )}
              </div>
            )}

            {/* Tone Tab */}
            {activeTab === 'tone' && toneResults && (
              <div className="p-6 space-y-4">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="font-semibold text-foreground">Tone Analysis</h3>
                    <p className="text-sm text-muted-foreground">
                      Original tone: {toneResults?.originalTone}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-muted-foreground">Sentiment</p>
                    <p className="text-lg font-bold text-primary">
                      {toneResults?.sentimentScore > 0 ? '😊' : toneResults?.sentimentScore < 0 ? '😔' : '😐'}
                    </p>
                  </div>
                </div>

                {/* Optimized Message */}
                <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-semibold text-blue-800">Optimized Message</h4>
                    <Button
                      size="sm"
                      onClick={() => handleApplySuggestion(toneResults?.optimizedMessage)}
                    >
                      Apply
                    </Button>
                  </div>
                  <p className="text-sm text-blue-900">{toneResults?.optimizedMessage}</p>
                </div>

                {/* Alternatives */}
                <div>
                  <h4 className="font-semibold text-foreground mb-3">Alternative Phrasings</h4>
                  <div className="space-y-2">
                    {toneResults?.alternatives?.map((alt, index) => (
                      <div
                        key={index}
                        className="p-3 border border-border rounded-lg bg-background hover:border-primary transition-colors cursor-pointer"
                        onClick={() => handleApplySuggestion(alt?.text)}
                      >
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-xs font-semibold text-muted-foreground uppercase">
                            {alt?.toneStrength} tone
                          </span>
                          <Check size={16} className="text-primary" />
                        </div>
                        <p className="text-sm text-foreground">{alt?.text}</p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Key Changes */}
                <div>
                  <h4 className="font-semibold text-foreground mb-3">Key Changes Made</h4>
                  <ul className="space-y-2">
                    {toneResults?.changes?.map((change, index) => (
                      <li key={index} className="flex items-start gap-2 text-sm text-muted-foreground">
                        <span className="text-primary mt-1">•</span>
                        <span>{change}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Tips Section */}
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-6">
          <h3 className="font-semibold text-blue-900 mb-3 flex items-center gap-2">
            <Sparkles size={20} />
            Pro Tips
          </h3>
          <ul className="space-y-2 text-sm text-blue-800">
            <li className="flex items-start gap-2">
              <span className="text-blue-500 mt-1">•</span>
              <span>Use grammar check before sending important messages</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-blue-500 mt-1">•</span>
              <span>Adjust tone based on your recipient and context</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-blue-500 mt-1">•</span>
              <span>Professional tone works best for business communications</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-blue-500 mt-1">•</span>
              <span>Review AI suggestions and maintain your personal voice</span>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
}
