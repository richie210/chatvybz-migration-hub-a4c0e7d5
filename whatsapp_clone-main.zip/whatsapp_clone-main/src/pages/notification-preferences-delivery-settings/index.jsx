import React, { useState, useEffect } from 'react';
import { Bell, Mail, MessageSquare, Phone, AtSign, Clock, Moon, Settings, Check, ChevronRight, Calendar, TrendingUp, Users, DollarSign } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { enhancedNotificationService } from '../../services/enhancedNotificationService';
import { resendNotificationService } from '../../services/resendNotificationService';
import { useAuth } from '../../contexts/AuthContext';
import Icon from '../../components/AppIcon';


export default function NotificationPreferencesDeliverySettings() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [preferences, setPreferences] = useState(null);
  const [emailReports, setEmailReports] = useState({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }

    loadPreferences();
    loadEmailReports();
  }, [user, navigate]);

  const loadPreferences = async () => {
    try {
      setLoading(true);
      const prefs = await enhancedNotificationService?.getNotificationPreferences(user?.id);
      setPreferences(prefs);
    } catch (err) {
      setError(err?.message);
    } finally {
      setLoading(false);
    }
  };

  const loadEmailReports = async () => {
    try {
      const result = await resendNotificationService?.getScheduledReports(user?.id);
      if (result?.success) {
        setEmailReports(result?.data || {});
      }
    } catch (err) {
      console.error('Error loading email reports:', err);
    }
  };

  const handleToggle = async (key, value) => {
    if (!preferences) return;

    try {
      setSaving(true);
      setError('');
      
      const updatedPreferences = await enhancedNotificationService?.updateNotificationPreferences(
        user?.id,
        {
          [key]: value !== undefined ? value : !preferences?.[key],
        }
      );
      
      setPreferences(updatedPreferences);
      setSuccessMessage('Settings updated successfully');
      setTimeout(() => setSuccessMessage(''), 3000);
    } catch (err) {
      setError(err?.message);
    } finally {
      setSaving(false);
    }
  };

  const handleEmailReportToggle = async (reportType, frequency = 'weekly') => {
    try {
      setSaving(true);
      setError('');

      const currentEnabled = emailReports?.[reportType]?.enabled || false;
      
      const result = await resendNotificationService?.scheduleAnalyticsReport(
        user?.id,
        reportType,
        frequency,
        !currentEnabled
      );

      if (result?.success) {
        await loadEmailReports();
        setSuccessMessage(`Email report ${!currentEnabled ? 'enabled' : 'disabled'} successfully`);
        setTimeout(() => setSuccessMessage(''), 3000);
      } else {
        setError(result?.error || 'Failed to update email report');
      }
    } catch (err) {
      setError(err?.message);
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-teal-600 mx-auto mb-4"></div>
          <p className="text-slate-600">Loading notification settings...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <div className="bg-white border-b border-slate-200">
        <div className="max-w-4xl mx-auto px-6 py-4">
          <div className="flex items-center gap-4">
            <button
              onClick={() => navigate(-1)}
              className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
            >
              <ChevronRight className="w-6 h-6 text-slate-600 rotate-180" />
            </button>
            <div>
              <h1 className="text-2xl font-bold text-slate-900">
                Notification Preferences & Delivery
              </h1>
              <p className="text-sm text-slate-600">
                Manage push notifications, email alerts, and scheduled reports
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-6 py-8">
        {/* Success Message */}
        {successMessage && (
          <div className="mb-6 bg-green-50 border border-green-200 rounded-lg p-4 flex items-center gap-3">
            <div className="bg-green-500 rounded-full p-1">
              <Check className="w-4 h-4 text-white" />
            </div>
            <p className="text-green-800 font-medium">{successMessage}</p>
          </div>
        )}

        {/* Error Message */}
        {error && (
          <div className="mb-6 bg-red-50 border border-red-200 rounded-lg p-4">
            <p className="text-red-800">{error}</p>
          </div>
        )}

        {/* Push Notification Types */}
        <div className="bg-white rounded-lg shadow-sm border border-slate-200 mb-6">
          <div className="p-6 border-b border-slate-200">
            <div className="flex items-center gap-3">
              <div className="bg-teal-100 p-2 rounded-lg">
                <Bell className="w-5 h-5 text-teal-600" />
              </div>
              <div>
                <h2 className="text-lg font-semibold text-slate-900">Push Notification Types</h2>
                <p className="text-sm text-slate-600">Choose which events trigger notifications</p>
              </div>
            </div>
          </div>

          <div className="divide-y divide-slate-200">
            <NotificationToggle
              icon={MessageSquare}
              title="Direct Messages"
              description="Get notified when you receive new messages"
              enabled={preferences?.messageNotifications}
              onChange={() => handleToggle('messageNotifications')}
              disabled={saving}
            />
            <NotificationToggle
              icon={Phone}
              title="Incoming Calls"
              description="Receive alerts for voice and video calls"
              enabled={preferences?.callNotifications}
              onChange={() => handleToggle('callNotifications')}
              disabled={saving}
            />
            <NotificationToggle
              icon={AtSign}
              title="@Mentions"
              description="Get notified when someone mentions you"
              enabled={preferences?.replyNotifications}
              onChange={() => handleToggle('replyNotifications')}
              disabled={saving}
            />
            <NotificationToggle
              icon={Users}
              title="Group Messages"
              description="Notifications for group conversations"
              enabled={preferences?.groupNotifications}
              onChange={() => handleToggle('groupNotifications')}
              disabled={saving}
            />
          </div>
        </div>

        {/* Delivery Channels */}
        <div className="bg-white rounded-lg shadow-sm border border-slate-200 mb-6">
          <div className="p-6 border-b border-slate-200">
            <div className="flex items-center gap-3">
              <div className="bg-blue-100 p-2 rounded-lg">
                <Settings className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <h2 className="text-lg font-semibold text-slate-900">Delivery Channels</h2>
                <p className="text-sm text-slate-600">Select how you want to receive notifications</p>
              </div>
            </div>
          </div>

          <div className="divide-y divide-slate-200">
            <NotificationToggle
              icon={Bell}
              title="Push Notifications"
              description="Browser and device push notifications"
              enabled={preferences?.pushNotificationEnabled !== false}
              onChange={() => handleToggle('pushNotificationEnabled')}
              disabled={saving}
            />
            <NotificationToggle
              icon={Mail}
              title="Email Alerts"
              description="Receive notifications via email"
              enabled={preferences?.emailNotificationEnabled !== false}
              onChange={() => handleToggle('emailNotificationEnabled')}
              disabled={saving}
            />
          </div>
        </div>

        {/* Quiet Hours */}
        <div className="bg-white rounded-lg shadow-sm border border-slate-200 mb-6">
          <div className="p-6 border-b border-slate-200">
            <div className="flex items-center gap-3">
              <div className="bg-purple-100 p-2 rounded-lg">
                <Clock className="w-5 h-5 text-purple-600" />
              </div>
              <div>
                <h2 className="text-lg font-semibold text-slate-900">Quiet Hours & Do Not Disturb</h2>
                <p className="text-sm text-slate-600">Control when you receive notifications</p>
              </div>
            </div>
          </div>

          <div className="divide-y divide-slate-200">
            <NotificationToggle
              icon={Moon}
              title="Do Not Disturb"
              description="Block all notifications temporarily"
              enabled={preferences?.doNotDisturb}
              onChange={() => handleToggle('doNotDisturb')}
              disabled={saving}
            />
          </div>
        </div>

        {/* Scheduled Analytics Reports */}
        <div className="bg-white rounded-lg shadow-sm border border-slate-200">
          <div className="p-6 border-b border-slate-200">
            <div className="flex items-center gap-3">
              <div className="bg-emerald-100 p-2 rounded-lg">
                <Calendar className="w-5 h-5 text-emerald-600" />
              </div>
              <div>
                <h2 className="text-lg font-semibold text-slate-900">Scheduled Analytics Reports</h2>
                <p className="text-sm text-slate-600">Receive automated insights via email</p>
              </div>
            </div>
          </div>

          <div className="divide-y divide-slate-200">
            <EmailReportToggle
              icon={DollarSign}
              title="Creator Revenue Report"
              description="Weekly summary of subscription and ad revenue"
              reportType="creator_revenue"
              enabled={emailReports?.creator_revenue?.enabled}
              frequency={emailReports?.creator_revenue?.frequency || 'weekly'}
              onToggle={handleEmailReportToggle}
              disabled={saving}
            />
            <EmailReportToggle
              icon={Phone}
              title="Call Metrics Report"
              description="Analytics on call volume, duration, and engagement"
              reportType="call_metrics"
              enabled={emailReports?.call_metrics?.enabled}
              frequency={emailReports?.call_metrics?.frequency || 'weekly'}
              onToggle={handleEmailReportToggle}
              disabled={saving}
            />
            <EmailReportToggle
              icon={TrendingUp}
              title="Subscriber Insights Report"
              description="Growth metrics and audience engagement data"
              reportType="subscriber_insights"
              enabled={emailReports?.subscriber_insights?.enabled}
              frequency={emailReports?.subscriber_insights?.frequency || 'weekly'}
              onToggle={handleEmailReportToggle}
              disabled={saving}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

function NotificationToggle({ icon: Icon, title, description, enabled, onChange, disabled }) {
  return (
    <div className="p-6 flex items-center justify-between hover:bg-slate-50 transition-colors">
      <div className="flex items-start gap-4 flex-1">
        <div className="bg-slate-100 p-2 rounded-lg mt-1">
          <Icon className="w-5 h-5 text-slate-600" />
        </div>
        <div className="flex-1">
          <h3 className="font-medium text-slate-900 mb-1">{title}</h3>
          <p className="text-sm text-slate-600">{description}</p>
        </div>
      </div>
      <button
        onClick={onChange}
        disabled={disabled}
        className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-teal-500 focus:ring-offset-2 ${
          enabled ? 'bg-teal-600' : 'bg-slate-300'
        } ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
      >
        <span
          className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
            enabled ? 'translate-x-6' : 'translate-x-1'
          }`}
        />
      </button>
    </div>
  );
}

function EmailReportToggle({ icon: Icon, title, description, reportType, enabled, frequency, onToggle, disabled }) {
  return (
    <div className="p-6 hover:bg-slate-50 transition-colors">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-start gap-4 flex-1">
          <div className="bg-slate-100 p-2 rounded-lg mt-1">
            <Icon className="w-5 h-5 text-slate-600" />
          </div>
          <div className="flex-1">
            <h3 className="font-medium text-slate-900 mb-1">{title}</h3>
            <p className="text-sm text-slate-600">{description}</p>
          </div>
        </div>
        <button
          onClick={() => onToggle(reportType, frequency)}
          disabled={disabled}
          className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:ring-offset-2 ${
            enabled ? 'bg-emerald-600' : 'bg-slate-300'
          } ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
        >
          <span
            className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
              enabled ? 'translate-x-6' : 'translate-x-1'
            }`}
          />
        </button>
      </div>
      {enabled && (
        <div className="ml-14 flex items-center gap-2 text-sm text-slate-600">
          <Calendar className="w-4 h-4" />
          <span>Frequency: <span className="font-medium text-slate-900 capitalize">{frequency}</span></span>
        </div>
      )}
    </div>
  );
}