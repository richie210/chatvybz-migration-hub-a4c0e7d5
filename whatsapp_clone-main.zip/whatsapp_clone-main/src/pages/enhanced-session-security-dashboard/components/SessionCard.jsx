import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import { Checkbox } from '../../../components/ui/Checkbox';

export default function SessionCard({ 
  session, 
  isCurrent, 
  isSelected, 
  onSelect, 
  onRevoke, 
  disabled 
}) {
  const deviceInfo = session?.deviceInfo || {};
  const locationInfo = session?.locationInfo || {};
  
  const getDeviceIcon = () => {
    const deviceType = deviceInfo?.deviceType?.toLowerCase();
    if (deviceType?.includes('mobile') || deviceType?.includes('phone')) {
      return 'Smartphone';
    } else if (deviceType?.includes('tablet')) {
      return 'Tablet';
    }
    return 'Monitor';
  };

  const getRiskBadge = () => {
    const score = session?.riskScore || 0;
    if (score > 70) {
      return { label: 'High Risk', color: 'bg-destructive/10 text-destructive' };
    } else if (score > 40) {
      return { label: 'Medium Risk', color: 'bg-warning/10 text-warning' };
    }
    return { label: 'Trusted', color: 'bg-success/10 text-success' };
  };

  const riskBadge = getRiskBadge();

  return (
    <div className={`bg-card border rounded-lg p-4 ${
      isCurrent ? 'border-success' : 'border-border'
    }`}>
      <div className="flex items-start gap-4">
        {/* Selection Checkbox (only for non-current sessions) */}
        {!isCurrent && onSelect && (
          <div className="pt-1">
            <Checkbox
              checked={isSelected}
              onChange={onSelect}
              disabled={disabled}
            />
          </div>
        )}

        {/* Device Icon */}
        <div className="p-3 bg-muted rounded-lg">
          <Icon name={getDeviceIcon()} size={24} className="text-foreground" />
        </div>

        {/* Session Details */}
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-3 mb-3">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <h3 className="font-semibold text-foreground">
                  {deviceInfo?.browser || 'Unknown Browser'}
                </h3>
                {isCurrent && (
                  <span className="px-2 py-1 text-xs bg-success/10 text-success rounded-md font-medium">
                    Current Device
                  </span>
                )}
              </div>
              <p className="text-sm text-muted-foreground">
                {deviceInfo?.os || 'Unknown OS'} • {deviceInfo?.device || 'Desktop'}
              </p>
            </div>
            <span className={`px-2 py-1 text-xs rounded-md font-medium ${riskBadge?.color}`}>
              {riskBadge?.label}
            </span>
          </div>

          {/* Location & IP */}
          <div className="space-y-2 mb-3">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Icon name="MapPin" size={14} />
              <span>
                {locationInfo?.city || 'Unknown'}, {locationInfo?.country || 'Unknown'}
              </span>
            </div>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Icon name="Globe" size={14} />
              <span>{session?.ipAddress || 'Unknown IP'}</span>
            </div>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Icon name="Clock" size={14} />
              <span>
                Last active: {session?.lastActive 
                  ? new Date(session?.lastActive)?.toLocaleString()
                  : 'Unknown'
                }
              </span>
            </div>
          </div>

          {/* Session Metadata */}
          <div className="flex items-center gap-4 text-xs text-muted-foreground">
            <div className="flex items-center gap-1">
              <Icon name="Calendar" size={12} />
              <span>
                Created: {session?.createdAt 
                  ? new Date(session?.createdAt)?.toLocaleDateString()
                  : 'Unknown'
                }
              </span>
            </div>
            {locationInfo?.isp && (
              <div className="flex items-center gap-1">
                <Icon name="Wifi" size={12} />
                <span>{locationInfo?.isp}</span>
              </div>
            )}
          </div>
        </div>

        {/* Actions */}
        {!isCurrent && (
          <div>
            <Button
              variant="destructive"
              size="sm"
              onClick={() => onRevoke(session?.id)}
              disabled={disabled}
            >
              <Icon name="X" size={14} className="mr-1" />
              Revoke
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}