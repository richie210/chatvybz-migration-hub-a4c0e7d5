import React from 'react';
import Icon from '../../../components/AppIcon';

export default function SecurityAlerts({ alerts }) {
  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'high':
        return 'bg-destructive/10 border-destructive text-destructive';
      case 'medium':
        return 'bg-warning/10 border-warning text-warning';
      case 'low':
        return 'bg-muted border-border text-muted-foreground';
      default:
        return 'bg-muted border-border text-muted-foreground';
    }
  };

  const getSeverityIcon = (severity) => {
    switch (severity) {
      case 'high':
        return 'AlertTriangle';
      case 'medium':
        return 'AlertCircle';
      case 'low':
        return 'Info';
      default:
        return 'Info';
    }
  };

  if (!alerts || alerts?.length === 0) {
    return null;
  }

  return (
    <div className="space-y-2 mb-4">
      {alerts?.map((alert, index) => (
        <div
          key={index}
          className={`border rounded-lg p-3 flex items-start gap-3 ${getSeverityColor(alert?.severity)}`}
        >
          <Icon name={getSeverityIcon(alert?.severity)} size={20} className="flex-shrink-0 mt-0.5" />
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              <span className="font-semibold text-sm uppercase">
                {alert?.severity} Security Alert
              </span>
              <span className="text-xs opacity-75">
                {new Date(alert?.timestamp)?.toLocaleString()}
              </span>
            </div>
            <p className="text-sm">{alert?.message}</p>
          </div>
        </div>
      ))}
    </div>
  );
}