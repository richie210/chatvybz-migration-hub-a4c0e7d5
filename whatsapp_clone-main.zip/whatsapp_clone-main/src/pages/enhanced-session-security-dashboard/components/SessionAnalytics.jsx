import React from 'react';
import Icon from '../../../components/AppIcon';

export default function SessionAnalytics({ analytics }) {
  const deviceData = Object.entries(analytics?.deviceBreakdown || {});
  const browserData = Object.entries(analytics?.browserBreakdown || {});
  const locationData = Object.entries(analytics?.locationBreakdown || {});

  // Find peak login hour
  const peakHour = analytics?.loginPatternsByHour?.reduce(
    (max, count, hour) => (count > max?.count ? { hour, count } : max),
    { hour: 0, count: 0 }
  );

  return (
    <div className="space-y-6">
      {/* Overview Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-card border border-border rounded-lg p-4">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-primary/10 rounded-lg">
              <Icon name="Activity" size={20} className="text-primary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Total Logins</p>
              <p className="text-2xl font-bold">{analytics?.totalLogins || 0}</p>
            </div>
          </div>
        </div>

        <div className="bg-card border border-border rounded-lg p-4">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-success/10 rounded-lg">
              <Icon name="Monitor" size={20} className="text-success" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Unique Devices</p>
              <p className="text-2xl font-bold">{analytics?.uniqueDevices || 0}</p>
            </div>
          </div>
        </div>

        <div className="bg-card border border-border rounded-lg p-4">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-warning/10 rounded-lg">
              <Icon name="MapPin" size={20} className="text-warning" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Unique Locations</p>
              <p className="text-2xl font-bold">{analytics?.uniqueLocations || 0}</p>
            </div>
          </div>
        </div>
      </div>
      {/* Device Breakdown */}
      <div className="bg-card border border-border rounded-lg p-4">
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
          <Icon name="Smartphone" size={20} />
          Device Usage
        </h3>
        <div className="space-y-3">
          {deviceData?.map(([device, count]) => {
            const percentage = ((count / analytics?.totalLogins) * 100)?.toFixed(1);
            return (
              <div key={device}>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-medium">{device}</span>
                  <span className="text-sm text-muted-foreground">
                    {count} ({percentage}%)
                  </span>
                </div>
                <div className="w-full bg-muted rounded-full h-2">
                  <div
                    className="bg-primary h-2 rounded-full transition-all"
                    style={{ width: `${percentage}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>
      {/* Browser Breakdown */}
      <div className="bg-card border border-border rounded-lg p-4">
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
          <Icon name="Globe" size={20} />
          Browser Usage
        </h3>
        <div className="space-y-3">
          {browserData?.map(([browser, count]) => {
            const percentage = ((count / analytics?.totalLogins) * 100)?.toFixed(1);
            return (
              <div key={browser}>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-medium">{browser}</span>
                  <span className="text-sm text-muted-foreground">
                    {count} ({percentage}%)
                  </span>
                </div>
                <div className="w-full bg-muted rounded-full h-2">
                  <div
                    className="bg-success h-2 rounded-full transition-all"
                    style={{ width: `${percentage}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>
      {/* Location Breakdown */}
      <div className="bg-card border border-border rounded-lg p-4">
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
          <Icon name="MapPin" size={20} />
          Top Locations
        </h3>
        <div className="space-y-3">
          {locationData?.slice(0, 5)?.map(([location, count]) => {
            const percentage = ((count / analytics?.totalLogins) * 100)?.toFixed(1);
            return (
              <div key={location}>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm font-medium">{location}</span>
                  <span className="text-sm text-muted-foreground">
                    {count} ({percentage}%)
                  </span>
                </div>
                <div className="w-full bg-muted rounded-full h-2">
                  <div
                    className="bg-warning h-2 rounded-full transition-all"
                    style={{ width: `${percentage}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>
      {/* Login Patterns */}
      <div className="bg-card border border-border rounded-lg p-4">
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
          <Icon name="Clock" size={20} />
          Login Patterns
        </h3>
        <div className="space-y-4">
          <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
            <span className="text-sm font-medium">Most Active Hour</span>
            <span className="text-sm text-muted-foreground">
              {peakHour?.hour}:00 ({peakHour?.count} logins)
            </span>
          </div>
          <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
            <span className="text-sm font-medium">Most Used Device</span>
            <span className="text-sm text-muted-foreground">
              {analytics?.mostUsedDevice}
            </span>
          </div>
          <div className="flex items-center justify-between p-3 bg-muted rounded-lg">
            <span className="text-sm font-medium">Most Common Location</span>
            <span className="text-sm text-muted-foreground">
              {analytics?.mostCommonLocation}
            </span>
          </div>
        </div>

        {/* Hourly distribution chart */}
        <div className="mt-4">
          <p className="text-sm font-medium mb-3">Login Activity by Hour</p>
          <div className="flex items-end justify-between gap-1 h-32">
            {analytics?.loginPatternsByHour?.map((count, hour) => {
              const maxCount = Math.max(...analytics?.loginPatternsByHour);
              const height = maxCount > 0 ? (count / maxCount) * 100 : 0;
              return (
                <div key={hour} className="flex-1 flex flex-col items-center gap-1">
                  <div
                    className="w-full bg-primary rounded-t transition-all hover:bg-primary/80"
                    style={{ height: `${height}%` }}
                    title={`${hour}:00 - ${count} logins`}
                  />
                  {hour % 3 === 0 && (
                    <span className="text-xs text-muted-foreground">{hour}</span>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}