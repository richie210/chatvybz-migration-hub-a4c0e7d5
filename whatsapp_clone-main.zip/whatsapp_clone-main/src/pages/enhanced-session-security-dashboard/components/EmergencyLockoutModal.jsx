import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

export default function EmergencyLockoutModal({ 
  onConfirm, 
  onCancel, 
  sessionCount, 
  loading 
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
      <div className="bg-background border border-border rounded-lg max-w-md w-full p-6">
        <div className="flex items-start gap-4 mb-4">
          <div className="p-3 bg-destructive/10 rounded-lg">
            <Icon name="AlertTriangle" size={24} className="text-destructive" />
          </div>
          <div className="flex-1">
            <h2 className="text-xl font-bold text-foreground mb-2">
              Emergency Lockout
            </h2>
            <p className="text-sm text-muted-foreground">
              This will immediately terminate all other sessions and log out all devices except this one.
            </p>
          </div>
        </div>

        <div className="bg-destructive/10 border border-destructive/20 rounded-lg p-4 mb-6">
          <div className="flex items-center gap-2 mb-2">
            <Icon name="Shield" size={16} className="text-destructive" />
            <span className="font-semibold text-sm text-destructive">
              Security Action
            </span>
          </div>
          <ul className="text-sm text-destructive space-y-1 ml-6 list-disc">
            <li>{sessionCount} active session(s) will be terminated</li>
            <li>All other devices will be logged out immediately</li>
            <li>You will remain logged in on this device</li>
            <li>This action cannot be undone</li>
          </ul>
        </div>

        <div className="flex gap-3">
          <Button
            variant="outline"
            onClick={onCancel}
            disabled={loading}
            className="flex-1"
          >
            Cancel
          </Button>
          <Button
            variant="destructive"
            onClick={onConfirm}
            disabled={loading}
            className="flex-1"
          >
            {loading ? (
              <>
                <Icon name="Loader2" size={16} className="mr-2 animate-spin" />
                Processing...
              </>
            ) : (
              <>
                <Icon name="AlertTriangle" size={16} className="mr-2" />
                Confirm Lockout
              </>
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}