import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';

export default function LocationMap({ history }) {
  const [selectedLocation, setSelectedLocation] = useState(null);

  // Get unique locations from history
  const locations = history?.reduce((acc, entry) => {
    const key = `${entry?.location_info?.latitude},${entry?.location_info?.longitude}`;
    if (!acc?.[key] && entry?.location_info?.latitude && entry?.location_info?.longitude) {
      acc[key] = {
        lat: entry?.location_info?.latitude,
        lng: entry?.location_info?.longitude,
        city: entry?.location_info?.city,
        country: entry?.location_info?.country,
        count: 1,
        lastLogin: entry?.created_at
      };
    } else if (acc?.[key]) {
      acc[key].count++;
    }
    return acc;
  }, {});

  const locationArray = Object.values(locations || {});

  // Calculate map bounds
  const bounds = locationArray?.reduce(
    (acc, loc) => ({
      minLat: Math.min(acc?.minLat, loc?.lat),
      maxLat: Math.max(acc?.maxLat, loc?.lat),
      minLng: Math.min(acc?.minLng, loc?.lng),
      maxLng: Math.max(acc?.maxLng, loc?.lng)
    }),
    { minLat: 90, maxLat: -90, minLng: 180, maxLng: -180 }
  );

  return (
    <div className="bg-card border border-border rounded-lg overflow-hidden">
      <div className="p-4 border-b border-border">
        <h2 className="text-lg font-semibold flex items-center gap-2">
          <Icon name="Map" size={20} />
          Login Locations
        </h2>
        <p className="text-sm text-muted-foreground mt-1">
          {locationArray?.length} unique location(s) detected
        </p>
      </div>
      {/* Map Visualization (Simplified) */}
      <div className="relative bg-muted" style={{ height: '400px' }}>
        {/* Static map placeholder with location markers */}
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center">
            <Icon name="MapPin" size={48} className="mx-auto mb-4 text-muted-foreground" />
            <p className="text-sm text-muted-foreground mb-2">
              Interactive map visualization
            </p>
            <p className="text-xs text-muted-foreground">
              Showing {locationArray?.length} login location(s)
            </p>
          </div>
        </div>

        {/* Location markers overlay */}
        <div className="absolute inset-0 pointer-events-none">
          {locationArray?.map((loc, index) => (
            <div
              key={index}
              className="absolute pointer-events-auto"
              style={{
                left: `${((loc?.lng - bounds?.minLng) / (bounds?.maxLng - bounds?.minLng)) * 100}%`,
                top: `${((bounds?.maxLat - loc?.lat) / (bounds?.maxLat - bounds?.minLat)) * 100}%`,
                transform: 'translate(-50%, -50%)'
              }}
            >
              <button
                onClick={() => setSelectedLocation(loc)}
                className="relative group"
              >
                <div className="w-4 h-4 bg-primary rounded-full border-2 border-white shadow-lg animate-pulse" />
                {loc?.count > 1 && (
                  <span className="absolute -top-2 -right-2 bg-destructive text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                    {loc?.count}
                  </span>
                )}
              </button>
            </div>
          ))}
        </div>
      </div>
      {/* Location List */}
      <div className="p-4 space-y-2 max-h-64 overflow-y-auto">
        {locationArray?.map((loc, index) => (
          <div
            key={index}
            onClick={() => setSelectedLocation(loc)}
            className={`p-3 rounded-lg cursor-pointer transition-colors ${
              selectedLocation === loc
                ? 'bg-primary/10 border border-primary' :'bg-muted hover:bg-muted/80'
            }`}
          >
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Icon name="MapPin" size={16} className="text-primary" />
                <div>
                  <div className="font-medium text-sm">
                    {loc?.city}, {loc?.country}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {loc?.count} login(s) • Last: {new Date(loc?.lastLogin)?.toLocaleDateString()}
                  </div>
                </div>
              </div>
              <div className="text-xs text-muted-foreground">
                {loc?.lat?.toFixed(4)}, {loc?.lng?.toFixed(4)}
              </div>
            </div>
          </div>
        ))}
      </div>
      {locationArray?.length === 0 && (
        <div className="p-8 text-center text-muted-foreground">
          <Icon name="MapPin" size={32} className="mx-auto mb-2 opacity-50" />
          <p className="text-sm">No location data available</p>
        </div>
      )}
    </div>
  );
}