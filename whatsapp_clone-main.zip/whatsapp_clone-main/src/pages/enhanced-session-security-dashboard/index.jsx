import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../../components/AppIcon';
import Button from '../../components/ui/Button';
import appwriteSessionService from '../../services/appwriteSessionService';
import { useAuth } from '../../contexts/AuthContext';
import SessionCard from './components/SessionCard';
import LocationMap from './components/LocationMap';
import SessionAnalytics from './components/SessionAnalytics';
import SecurityAlerts from './components/SecurityAlerts';
import EmergencyLockoutModal from './components/EmergencyLockoutModal';

export default function EnhancedSessionSecurityDashboard() {
  const navigate = useNavigate();
  const { user } = useAuth();
  
  const [sessions, setSessions] = useState([]);
  const [loginHistory, setLoginHistory] = useState([]);
  const [analytics, setAnalytics] = useState(null);
  const [securityAnalysis, setSecurityAnalysis] = useState(null);
  const [loading, setLoading] = useState(true);
  const [selectedSessions, setSelectedSessions] = useState([]);
  const [showEmergencyModal, setShowEmergencyModal] = useState(false);
  const [activeTab, setActiveTab] = useState('sessions'); // sessions, history, analytics
  const [actionLoading, setActionLoading] = useState(false);

  useEffect(() => {
    if (user?.id) {
      loadSessionData();
    }
  }, [user]);

  const loadSessionData = async () => {
    setLoading(true);
    try {
      // Load all session data in parallel
      const [sessionsResult, historyResult, analyticsResult] = await Promise.all([
        appwriteSessionService?.getAllSessions(),
        appwriteSessionService?.getLoginHistory(user?.id),
        appwriteSessionService?.getSessionAnalytics(user?.id)
      ]);

      if (sessionsResult?.success) {
        setSessions(sessionsResult?.sessions || []);
      }

      if (historyResult?.success) {
        setLoginHistory(historyResult?.history || []);
        
        // Analyze for suspicious activity
        const analysis = appwriteSessionService?.analyzeSuspiciousActivity(
          historyResult?.history || []
        );
        setSecurityAnalysis(analysis);
      }

      if (analyticsResult?.success) {
        setAnalytics(analyticsResult?.analytics);
      }
    } catch (error) {
      console.error('Failed to load session data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleRevokeSession = async (sessionId) => {
    setActionLoading(true);
    try {
      const result = await appwriteSessionService?.revokeSession(sessionId);
      
      if (result?.success) {
        // Remove from local state
        setSessions(prev => prev?.filter(s => s?.id !== sessionId));
        alert('Session terminated successfully');
      } else {
        alert(result?.error || 'Failed to terminate session');
      }
    } catch (error) {
      alert('Failed to terminate session');
    } finally {
      setActionLoading(false);
    }
  };

  const handleBulkRevoke = async () => {
    if (selectedSessions?.length === 0) {
      alert('Please select sessions to revoke');
      return;
    }

    setActionLoading(true);
    try {
      const result = await appwriteSessionService?.revokeBulkSessions(selectedSessions);
      
      if (result?.success) {
        setSessions(prev => prev?.filter(s => !selectedSessions?.includes(s?.id)));
        setSelectedSessions([]);
        alert(`Successfully revoked ${result?.revoked} sessions`);
      } else {
        alert(result?.error || 'Failed to revoke sessions');
      }
    } catch (error) {
      alert('Failed to revoke sessions');
    } finally {
      setActionLoading(false);
    }
  };

  const handleEmergencyLockout = async () => {
    setActionLoading(true);
    try {
      const result = await appwriteSessionService?.emergencyLockout();
      
      if (result?.success) {
        await loadSessionData();
        setShowEmergencyModal(false);
        alert(result?.message || 'Emergency lockout completed');
      } else {
        alert(result?.error || 'Failed to complete emergency lockout');
      }
    } catch (error) {
      alert('Failed to complete emergency lockout');
    } finally {
      setActionLoading(false);
    }
  };

  const toggleSessionSelection = (sessionId) => {
    setSelectedSessions(prev => {
      if (prev?.includes(sessionId)) {
        return prev?.filter(id => id !== sessionId);
      } else {
        return [...prev, sessionId];
      }
    });
  };

  const activeSessions = sessions?.filter(s => !s?.current) || [];
  const currentSession = sessions?.find(s => s?.current);

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading session data...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-background border-b border-border">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <button
                onClick={() => navigate('/user-profile-settings')}
                className="p-2 hover:bg-muted rounded-lg transition-colors"
              >
                <Icon name="ArrowLeft" size={20} />
              </button>
              <div>
                <h1 className="text-xl md:text-2xl font-bold text-foreground">
                  Session Security
                </h1>
                <p className="text-sm text-muted-foreground mt-1">
                  Monitor and manage your active sessions
                </p>
              </div>
            </div>
            <Button
              variant="destructive"
              onClick={() => setShowEmergencyModal(true)}
              disabled={activeSessions?.length === 0}
            >
              <Icon name="AlertTriangle" size={16} className="mr-2" />
              Emergency Lockout
            </Button>
          </div>

          {/* Security Alerts */}
          {securityAnalysis?.alerts?.length > 0 && (
            <SecurityAlerts alerts={securityAnalysis?.alerts} />
          )}

          {/* Tabs */}
          <div className="flex gap-2 overflow-x-auto">
            {[
              { id: 'sessions', label: 'Active Sessions', icon: 'Monitor' },
              { id: 'history', label: 'Login History', icon: 'History' },
              { id: 'analytics', label: 'Analytics', icon: 'BarChart3' }
            ]?.map(tab => (
              <button
                key={tab?.id}
                onClick={() => setActiveTab(tab?.id)}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-colors whitespace-nowrap ${
                  activeTab === tab?.id
                    ? 'bg-primary text-primary-foreground'
                    : 'bg-muted text-muted-foreground hover:bg-muted/80'
                }`}
              >
                <Icon name={tab?.icon} size={16} />
                {tab?.label}
              </button>
            ))}
          </div>
        </div>
      </div>
      {/* Content */}
      <div className="max-w-7xl mx-auto px-4 py-6">
        {activeTab === 'sessions' && (
          <div className="space-y-6">
            {/* Bulk Actions */}
            {selectedSessions?.length > 0 && (
              <div className="bg-muted p-4 rounded-lg flex items-center justify-between">
                <span className="text-sm font-medium">
                  {selectedSessions?.length} session(s) selected
                </span>
                <Button
                  variant="destructive"
                  size="sm"
                  onClick={handleBulkRevoke}
                  disabled={actionLoading}
                >
                  Revoke Selected
                </Button>
              </div>
            )}

            {/* Current Session */}
            {currentSession && (
              <div>
                <h2 className="text-lg font-semibold mb-3 flex items-center gap-2">
                  <Icon name="CheckCircle" size={20} className="text-success" />
                  Current Session
                </h2>
                <SessionCard
                  session={currentSession}
                  isCurrent={true}
                  onRevoke={handleRevokeSession}
                  disabled={actionLoading}
                />
              </div>
            )}

            {/* Other Sessions */}
            {activeSessions?.length > 0 && (
              <div>
                <h2 className="text-lg font-semibold mb-3">
                  Other Sessions ({activeSessions?.length})
                </h2>
                <div className="space-y-3">
                  {activeSessions?.map(session => (
                    <SessionCard
                      key={session?.id}
                      session={session}
                      isCurrent={false}
                      isSelected={selectedSessions?.includes(session?.id)}
                      onSelect={() => toggleSessionSelection(session?.id)}
                      onRevoke={handleRevokeSession}
                      disabled={actionLoading}
                    />
                  ))}
                </div>
              </div>
            )}

            {activeSessions?.length === 0 && !currentSession && (
              <div className="text-center py-12">
                <Icon name="Monitor" size={48} className="mx-auto mb-4 text-muted-foreground" />
                <p className="text-muted-foreground">No active sessions found</p>
              </div>
            )}
          </div>
        )}

        {activeTab === 'history' && (
          <div className="space-y-6">
            <LocationMap history={loginHistory} />
            
            <div>
              <h2 className="text-lg font-semibold mb-3">Login History</h2>
              <div className="space-y-2">
                {loginHistory?.slice(0, 20)?.map((entry, index) => (
                  <div
                    key={index}
                    className="bg-card border border-border rounded-lg p-4"
                  >
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <Icon name="MapPin" size={16} className="text-muted-foreground" />
                          <span className="font-medium">
                            {entry?.location_info?.city}, {entry?.location_info?.country}
                          </span>
                        </div>
                        <div className="text-sm text-muted-foreground space-y-1">
                          <div className="flex items-center gap-2">
                            <Icon name="Monitor" size={14} />
                            {entry?.device_info?.browser} on {entry?.device_info?.os}
                          </div>
                          <div className="flex items-center gap-2">
                            <Icon name="Globe" size={14} />
                            {entry?.ip_address}
                          </div>
                        </div>
                      </div>
                      <div className="text-right text-sm text-muted-foreground">
                        {new Date(entry?.created_at)?.toLocaleString()}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'analytics' && analytics && (
          <SessionAnalytics analytics={analytics} />
        )}
      </div>
      {/* Emergency Lockout Modal */}
      {showEmergencyModal && (
        <EmergencyLockoutModal
          onConfirm={handleEmergencyLockout}
          onCancel={() => setShowEmergencyModal(false)}
          sessionCount={activeSessions?.length}
          loading={actionLoading}
        />
      )}
    </div>
  );
}