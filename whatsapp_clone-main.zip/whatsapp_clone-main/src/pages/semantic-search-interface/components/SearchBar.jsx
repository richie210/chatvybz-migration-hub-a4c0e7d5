import React from 'react';
import { Search, Sparkles } from 'lucide-react';
import Input from '../../../components/ui/Input';
import Button from '../../../components/ui/Button';

function SearchBar({ value, onChange, onSearch, loading }) {
  const handleSubmit = (e) => {
    e?.preventDefault();
    onSearch(value);
  };

  return (
    <form onSubmit={handleSubmit} className="w-full">
      <div className="relative">
        <div className="absolute left-4 top-1/2 -translate-y-1/2 flex items-center space-x-2">
          <Sparkles className="w-5 h-5 text-purple-500" />
          <Search className="w-5 h-5 text-gray-400" />
        </div>
        <Input
          type="text"
          value={value}
          onChange={(e) => onChange(e?.target?.value)}
          placeholder="Ask anything... e.g., 'find messages about project deadlines last month'"
          className="w-full pl-20 pr-32 py-4 text-lg border-2 border-gray-200 rounded-xl focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition-all"
          disabled={loading}
        />
        <Button
          type="submit"
          disabled={loading || !value?.trim()}
          className="absolute right-2 top-1/2 -translate-y-1/2 px-6 py-2 bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-lg hover:from-blue-700 hover:to-purple-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
        >
          {loading ? 'Searching...' : 'Search'}
        </Button>
      </div>
      <p className="mt-2 text-xs text-gray-500 text-center">
        Powered by Claude AI - Understanding context, intent, and sentiment beyond keywords
      </p>
    </form>
  );
}

export default SearchBar;