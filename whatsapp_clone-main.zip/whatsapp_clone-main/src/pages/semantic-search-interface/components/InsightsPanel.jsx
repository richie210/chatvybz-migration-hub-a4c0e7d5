import React from 'react';
import { Lightbulb, CheckCircle, FileText, Loader2 } from 'lucide-react';

function InsightsPanel({ insights, totalResults, conversationSummary, loadingSummary }) {
  const getSentimentColor = (sentiment) => {
    switch (sentiment?.toLowerCase()) {
      case 'positive': return 'text-green-600 bg-green-50';
      case 'negative': return 'text-red-600 bg-red-50';
      case 'neutral': return 'text-gray-600 bg-gray-50';
      default: return 'text-gray-600 bg-gray-50';
    }
  };

  return (
    <div className="space-y-4">
      {/* AI Insights Card */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="flex items-center space-x-2 mb-4">
          <Lightbulb className="w-5 h-5 text-yellow-500" />
          <h3 className="text-lg font-semibold text-gray-900">AI Insights</h3>
        </div>

        {/* Summary */}
        {insights?.summary && (
          <div className="mb-4">
            <p className="text-sm text-gray-700">{insights?.summary}</p>
          </div>
        )}

        {/* Sentiment */}
        {insights?.sentiment && (
          <div className="mb-4">
            <p className="text-xs font-medium text-gray-500 mb-2">Overall Sentiment</p>
            <span className={`inline-flex items-center px-3 py-1 rounded-full text-sm font-medium capitalize ${
              getSentimentColor(insights?.sentiment)
            }`}>
              {insights?.sentiment}
            </span>
          </div>
        )}

        {/* Topics */}
        {insights?.topics && insights?.topics?.length > 0 && (
          <div className="mb-4">
            <p className="text-xs font-medium text-gray-500 mb-2">Key Topics</p>
            <div className="flex flex-wrap gap-2">
              {insights?.topics?.map((topic, index) => (
                <span
                  key={index}
                  className="px-3 py-1 bg-blue-50 text-blue-700 text-xs rounded-full"
                >
                  {topic}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Action Items */}
        {insights?.actionItems && insights?.actionItems?.length > 0 && (
          <div>
            <p className="text-xs font-medium text-gray-500 mb-2">Action Items</p>
            <ul className="space-y-2">
              {insights?.actionItems?.map((item, index) => (
                <li key={index} className="flex items-start space-x-2 text-sm text-gray-700">
                  <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>
        )}

        {/* Results Count */}
        <div className="mt-4 pt-4 border-t border-gray-200">
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-600">Total Results</span>
            <span className="font-semibold text-gray-900">{totalResults || 0}</span>
          </div>
        </div>
      </div>

      {/* Conversation Summary Card */}
      {(conversationSummary || loadingSummary) && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center space-x-2 mb-4">
            <FileText className="w-5 h-5 text-purple-500" />
            <h3 className="text-lg font-semibold text-gray-900">Conversation Summary</h3>
          </div>

          {loadingSummary ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="w-6 h-6 animate-spin text-blue-600" />
            </div>
          ) : (
            <>
              {conversationSummary?.summary && (
                <p className="text-sm text-gray-700 mb-4">{conversationSummary?.summary}</p>
              )}

              {conversationSummary?.keyPoints && conversationSummary?.keyPoints?.length > 0 && (
                <div className="mb-4">
                  <p className="text-xs font-medium text-gray-500 mb-2">Key Points</p>
                  <ul className="space-y-1">
                    {conversationSummary?.keyPoints?.map((point, index) => (
                      <li key={index} className="text-sm text-gray-700 flex items-start space-x-2">
                        <span className="text-blue-500 mt-1">•</span>
                        <span>{point}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {conversationSummary?.decisions && conversationSummary?.decisions?.length > 0 && (
                <div className="mb-4">
                  <p className="text-xs font-medium text-gray-500 mb-2">Decisions Made</p>
                  <ul className="space-y-1">
                    {conversationSummary?.decisions?.map((decision, index) => (
                      <li key={index} className="text-sm text-gray-700 flex items-start space-x-2">
                        <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                        <span>{decision}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {conversationSummary?.actionItems && conversationSummary?.actionItems?.length > 0 && (
                <div>
                  <p className="text-xs font-medium text-gray-500 mb-2">Action Items</p>
                  <ul className="space-y-1">
                    {conversationSummary?.actionItems?.map((item, index) => (
                      <li key={index} className="text-sm text-gray-700 flex items-start space-x-2">
                        <span className="text-orange-500 mt-1">→</span>
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </>
          )}
        </div>
      )}
    </div>
  );
}

export default InsightsPanel;