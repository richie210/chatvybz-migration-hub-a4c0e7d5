import React from 'react';
import { MessageSquare, Clock, User, TrendingUp, Download } from 'lucide-react';
import { format } from 'date-fns';
import Button from '../../../components/ui/Button';

function SearchResults({ results, onResultClick, selectedConversation, onExport }) {
  if (!results || results?.length === 0) {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8 text-center">
        <MessageSquare className="w-12 h-12 text-gray-400 mx-auto mb-3" />
        <p className="text-gray-600">No messages found matching your query.</p>
        <p className="text-sm text-gray-500 mt-2">Try rephrasing your search or using different keywords.</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h2 className="text-lg font-semibold text-gray-900">
          {results?.length} {results?.length === 1 ? 'Result' : 'Results'} Found
        </h2>
        <Button
          onClick={onExport}
          className="flex items-center space-x-2 px-4 py-2 text-sm text-blue-600 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors"
        >
          <Download className="w-4 h-4" />
          <span>Export</span>
        </Button>
      </div>

      {/* Results List */}
      <div className="space-y-3">
        {results?.map((result, index) => (
          <div
            key={result?.messageId || index}
            onClick={() => onResultClick(result)}
            className={`bg-white rounded-xl shadow-sm border-2 p-4 cursor-pointer transition-all hover:shadow-md ${
              selectedConversation === result?.conversationId
                ? 'border-blue-500 bg-blue-50' :'border-gray-200 hover:border-blue-300'
            }`}
          >
            {/* Relevance Score */}
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center space-x-2">
                <div className="flex items-center space-x-1">
                  <TrendingUp className="w-4 h-4 text-green-600" />
                  <span className="text-xs font-medium text-green-600">
                    {Math.round(result?.relevanceScore * 100)}% Relevant
                  </span>
                </div>
                <span className="text-xs text-gray-400">•</span>
                <span className="text-xs text-gray-500 capitalize">{result?.messageType}</span>
              </div>
              <div className="flex items-center space-x-1 text-xs text-gray-500">
                <Clock className="w-3 h-3" />
                <span>{format(new Date(result?.createdAt), 'MMM d, yyyy')}</span>
              </div>
            </div>

            {/* Message Content */}
            <p className="text-gray-800 mb-2 line-clamp-2">{result?.content}</p>

            {/* Sender Info */}
            <div className="flex items-center space-x-2 text-sm text-gray-600">
              <User className="w-4 h-4" />
              <span>{result?.senderName}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default SearchResults;