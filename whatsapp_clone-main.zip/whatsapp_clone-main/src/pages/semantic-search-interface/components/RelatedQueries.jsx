import React from 'react';
import { Sparkles } from 'lucide-react';

function RelatedQueries({ queries, onQueryClick }) {
  if (!queries || queries?.length === 0) return null;

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
      <div className="flex items-center space-x-2 mb-4">
        <Sparkles className="w-5 h-5 text-purple-500" />
        <h3 className="text-lg font-semibold text-gray-900">Related Queries</h3>
      </div>
      <p className="text-xs text-gray-600 mb-3">AI-suggested follow-up searches</p>
      <div className="space-y-2">
        {queries?.map((query, index) => (
          <button
            key={index}
            onClick={() => onQueryClick(query)}
            className="w-full text-left px-4 py-3 bg-gradient-to-r from-blue-50 to-purple-50 hover:from-blue-100 hover:to-purple-100 rounded-lg transition-all text-sm text-gray-700 hover:text-gray-900 border border-transparent hover:border-blue-200"
          >
            {query}
          </button>
        ))}
      </div>
    </div>
  );
}

export default RelatedQueries;