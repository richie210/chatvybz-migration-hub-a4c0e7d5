import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { Search, Sparkles, Loader2 } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { semanticSearchService } from '../../services/semanticSearchService';
import SearchBar from './components/SearchBar';
import SearchResults from './components/SearchResults';
import InsightsPanel from './components/InsightsPanel';
import RelatedQueries from './components/RelatedQueries';

function SemanticSearchInterface() {
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();

  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [searchResults, setSearchResults] = useState(null);
  const [selectedConversation, setSelectedConversation] = useState(null);
  const [conversationSummary, setConversationSummary] = useState(null);
  const [loadingSummary, setLoadingSummary] = useState(false);

  useEffect(() => {
    if (!authLoading && !user) {
      navigate('/login');
    }
  }, [user, authLoading, navigate]);

  const handleSearch = async (query) => {
    if (!query?.trim()) return;

    try {
      setLoading(true);
      setError('');
      setSearchResults(null);
      
      const results = await semanticSearchService?.performSemanticSearch(query);
      setSearchResults(results);
      
      await semanticSearchService?.saveSearchHistory(query, results);
    } catch (err) {
      setError(err?.message || 'Search failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleRelatedQueryClick = (query) => {
    setSearchQuery(query);
    handleSearch(query);
  };

  const handleResultClick = async (result) => {
    setSelectedConversation(result?.conversationId);
    setLoadingSummary(true);
    
    try {
      const summary = await semanticSearchService?.getConversationSummary(result?.conversationId);
      setConversationSummary(summary);
    } catch (err) {
      console.error('Failed to load conversation summary:', err);
    } finally {
      setLoadingSummary(false);
    }
  };

  const handleExportResults = () => {
    if (!searchResults?.results) return;

    const exportData = {
      query: searchResults?.query,
      timestamp: new Date()?.toISOString(),
      totalResults: searchResults?.totalResults,
      insights: searchResults?.insights,
      results: searchResults?.results?.map(r => ({
        content: r?.content,
        sender: r?.senderName,
        date: r?.createdAt,
        relevanceScore: r?.relevanceScore
      }))
    };

    const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `semantic-search-${Date.now()}.json`;
    a?.click();
    URL.revokeObjectURL(url);
  };

  if (authLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-50">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Semantic Search - AI-Powered Message Search</title>
        <meta name="description" content="Search messages with AI-powered contextual understanding using Claude" />
      </Helmet>
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
        {/* Header */}
        <div className="bg-white border-b border-gray-200 shadow-sm">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg">
                  <Sparkles className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold text-gray-900">Semantic Search</h1>
                  <p className="text-sm text-gray-600">AI-powered contextual message search</p>
                </div>
              </div>
              <button
                onClick={() => navigate('/chat')}
                className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
              >
                Back to Chat
              </button>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Search Bar */}
          <SearchBar
            value={searchQuery}
            onChange={setSearchQuery}
            onSearch={handleSearch}
            loading={loading}
          />

          {/* Error Message */}
          {error && (
            <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-lg">
              <p className="text-sm text-red-800">{error}</p>
            </div>
          )}

          {/* Loading State */}
          {loading && (
            <div className="mt-8 flex flex-col items-center justify-center py-12">
              <Loader2 className="w-12 h-12 animate-spin text-blue-600 mb-4" />
              <p className="text-gray-600">Analyzing messages with AI...</p>
            </div>
          )}

          {/* Search Results */}
          {!loading && searchResults && (
            <div className="mt-8 grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Results List */}
              <div className="lg:col-span-2">
                <SearchResults
                  results={searchResults?.results}
                  onResultClick={handleResultClick}
                  selectedConversation={selectedConversation}
                  onExport={handleExportResults}
                />
              </div>

              {/* Insights Sidebar */}
              <div className="lg:col-span-1">
                <InsightsPanel
                  insights={searchResults?.insights}
                  totalResults={searchResults?.totalResults}
                  conversationSummary={conversationSummary}
                  loadingSummary={loadingSummary}
                />
                
                {searchResults?.relatedQueries?.length > 0 && (
                  <div className="mt-6">
                    <RelatedQueries
                      queries={searchResults?.relatedQueries}
                      onQueryClick={handleRelatedQueryClick}
                    />
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Empty State */}
          {!loading && !searchResults && !error && (
            <div className="mt-12 text-center py-12">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-blue-100 to-purple-100 rounded-full mb-4">
                <Search className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Start Your Semantic Search</h3>
              <p className="text-gray-600 max-w-md mx-auto mb-6">
                Use natural language to search your messages. Try queries like:
              </p>
              <div className="flex flex-wrap justify-center gap-2 max-w-2xl mx-auto">
                {[
                  'find messages about project deadlines last month',
                  'show discussions where John seemed frustrated',
                  'what did we decide about the budget?',
                  'messages with positive sentiment about the launch'
                ]?.map((example, index) => (
                  <button
                    key={index}
                    onClick={() => {
                      setSearchQuery(example);
                      handleSearch(example);
                    }}
                    className="px-4 py-2 text-sm text-blue-600 bg-blue-50 rounded-full hover:bg-blue-100 transition-colors"
                  >
                    {example}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
}

export default SemanticSearchInterface;