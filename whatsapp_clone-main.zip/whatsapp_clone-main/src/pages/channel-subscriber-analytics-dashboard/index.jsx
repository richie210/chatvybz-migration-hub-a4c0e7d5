import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { TrendingUp, Users, Eye, MessageSquare, Download, Loader2, ArrowLeft, BarChart3, Activity } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { channelAnalyticsService } from '../../services/channelAnalyticsService';
import Button from '../../components/ui/Button';
import MetricsCard from './components/MetricsCard';
import GrowthChart from './components/GrowthChart';
import EngagementChart from './components/EngagementChart';
import DemographicsPanel from './components/DemographicsPanel';
import LifecycleChart from './components/LifecycleChart';
import ContentPerformance from './components/ContentPerformance';
import OptimalTimesPanel from './components/OptimalTimesPanel';

export default function ChannelSubscriberAnalyticsDashboard() {
  const { user, loading: authLoading, isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const channelId = searchParams?.get('channelId');

  const [analytics, setAnalytics] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [dateRange, setDateRange] = useState(30);
  const [exporting, setExporting] = useState(false);

  useEffect(() => {
    if (authLoading) return;

    if (!isAuthenticated) {
      navigate('/login');
      return;
    }

    if (!channelId) {
      navigate('/channel-management-dashboard');
      return;
    }

    loadAnalytics();
  }, [authLoading, isAuthenticated, channelId, dateRange, navigate]);

  const loadAnalytics = async () => {
    try {
      setLoading(true);
      setError(null);

      const result = await channelAnalyticsService?.getSubscriberAnalytics(channelId, { days: dateRange });
      if (result?.error) throw result?.error;

      setAnalytics(result?.data);
    } catch (err) {
      console.error('Error loading analytics:', err);
      setError(err?.message || 'Failed to load analytics');
    } finally {
      setLoading(false);
    }
  };

  const handleExport = async (format) => {
    try {
      setExporting(true);
      const result = await channelAnalyticsService?.exportReport(channelId, format);
      if (result?.error) throw result?.error;

      // Download the file
      const url = URL.createObjectURL(result?.data);
      const a = document.createElement('a');
      a.href = url;
      a.download = `channel-analytics-${channelId}.${format}`;
      document.body?.appendChild(a);
      a?.click();
      document.body?.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('Error exporting report:', err);
      setError(err?.message || 'Failed to export report');
    } finally {
      setExporting(false);
    }
  };

  const handleDateRangeChange = (days) => {
    setDateRange(days);
  };

  if (authLoading || loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-50">
        <Loader2 className="w-8 h-8 animate-spin text-blue-600" />
      </div>
    );
  }

  if (error && !analytics) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-50">
        <div className="text-center">
          <p className="text-red-600 mb-4">{error}</p>
          <Button onClick={() => navigate('/channel-management-dashboard')}>
            Back to Channels
          </Button>
        </div>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Channel Analytics - Subscriber Insights</title>
        <meta name="description" content="Comprehensive channel subscriber analytics with engagement metrics and growth insights" />
      </Helmet>
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <div className="bg-white border-b border-gray-200 shadow-sm">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <button
                  onClick={() => navigate('/channel-management-dashboard')}
                  className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
                  aria-label="Back to channels"
                >
                  <ArrowLeft className="w-5 h-5 text-gray-600" />
                </button>
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg">
                    <BarChart3 className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h1 className="text-2xl font-bold text-gray-900">Channel Analytics</h1>
                    <p className="text-sm text-gray-600">Subscriber insights and engagement metrics</p>
                  </div>
                </div>
              </div>

              <div className="flex items-center space-x-3">
                {/* Date Range Selector */}
                <div className="flex items-center space-x-2 bg-gray-100 rounded-lg p-1">
                  {[7, 30, 90]?.map((days) => (
                    <button
                      key={days}
                      onClick={() => handleDateRangeChange(days)}
                      className={`px-3 py-1.5 text-sm font-medium rounded-md transition-colors ${
                        dateRange === days
                          ? 'bg-white text-blue-600 shadow-sm'
                          : 'text-gray-600 hover:text-gray-900'
                      }`}
                    >
                      {days}d
                    </button>
                  ))}
                </div>

                {/* Export Button */}
                <div className="relative group">
                  <Button
                    onClick={() => handleExport('json')}
                    disabled={exporting}
                    className="flex items-center gap-2"
                  >
                    {exporting ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <Download className="w-4 h-4" />
                    )}
                    Export
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {error && (
            <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg">
              <p className="text-sm text-red-800">{error}</p>
            </div>
          )}

          {/* Overview Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <MetricsCard
              title="Total Subscribers"
              value={analytics?.overview?.totalSubscribers || 0}
              icon={Users}
              color="blue"
              trend={analytics?.overview?.growthRate}
              trendLabel="growth rate"
            />
            <MetricsCard
              title="New Subscribers"
              value={analytics?.overview?.newSubscribers || 0}
              icon={TrendingUp}
              color="green"
              subtitle={`Last ${dateRange} days`}
            />
            <MetricsCard
              title="Engagement Rate"
              value={`${analytics?.overview?.engagementRate || 0}%`}
              icon={Activity}
              color="purple"
              subtitle="Average engagement"
            />
            <MetricsCard
              title="Total Views"
              value={analytics?.overview?.totalViews || 0}
              icon={Eye}
              color="orange"
              subtitle={`${analytics?.overview?.avgViewsPerMessage || 0} per message`}
            />
          </div>

          {/* Growth and Engagement Charts */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            <GrowthChart data={analytics?.growthTrend || []} />
            <EngagementChart data={analytics?.engagementTrend || []} />
          </div>

          {/* Demographics and Lifecycle */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            <DemographicsPanel demographics={analytics?.demographics || {}} />
            <LifecycleChart data={analytics?.lifecycle || []} />
          </div>

          {/* Content Performance and Optimal Times */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            <ContentPerformance data={analytics?.contentPerformance || []} />
            <OptimalTimesPanel times={analytics?.optimalTimes || []} />
          </div>

          {/* Top Performing Messages */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
                <MessageSquare className="w-5 h-5 text-blue-600" />
                Top Performing Messages
              </h2>
            </div>
            <div className="space-y-3">
              {analytics?.topMessages?.length > 0 ? (
                analytics?.topMessages?.map((message, index) => (
                  <div
                    key={message?.id}
                    className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
                  >
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center justify-center w-8 h-8 bg-blue-100 text-blue-600 rounded-full font-semibold text-sm">
                        {index + 1}
                      </div>
                      <div>
                        <p className="text-sm font-medium text-gray-900">
                          {message?.mediaType ? `${message?.mediaType} message` : 'Text message'}
                        </p>
                        <p className="text-xs text-gray-500">
                          {new Date(message?.sentAt)?.toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Eye className="w-4 h-4 text-gray-400" />
                      <span className="text-sm font-semibold text-gray-900">
                        {message?.viewsCount?.toLocaleString()}
                      </span>
                    </div>
                  </div>
                ))
              ) : (
                <p className="text-center text-gray-500 py-8">No messages found</p>
              )}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}