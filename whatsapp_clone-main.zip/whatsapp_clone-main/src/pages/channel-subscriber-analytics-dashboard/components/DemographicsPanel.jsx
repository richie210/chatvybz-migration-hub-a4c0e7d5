import React from 'react';
import { Globe, Shield } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

export default function DemographicsPanel({ demographics }) {
  const { countries = [], roles = [] } = demographics;

  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      <div className="mb-6">
        <h2 className="text-lg font-semibold text-gray-900 flex items-center gap-2 mb-4">
          <Globe className="w-5 h-5 text-blue-600" />
          Geographic Distribution
        </h2>
        <ResponsiveContainer width="100%" height={200}>
          <BarChart data={countries?.slice(0, 5)} layout="vertical">
            <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
            <XAxis type="number" stroke="#6b7280" style={{ fontSize: '12px' }} />
            <YAxis 
              type="category" 
              dataKey="country" 
              stroke="#6b7280" 
              style={{ fontSize: '12px' }}
              width={60}
            />
            <Tooltip 
              contentStyle={{
                backgroundColor: '#fff',
                border: '1px solid #e5e7eb',
                borderRadius: '8px',
                padding: '8px 12px'
              }}
            />
            <Bar dataKey="count" fill="#3b82f6" radius={[0, 4, 4, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div className="border-t border-gray-200 pt-6">
        <h3 className="text-sm font-semibold text-gray-900 flex items-center gap-2 mb-4">
          <Shield className="w-4 h-4 text-purple-600" />
          Role Distribution
        </h3>
        <div className="space-y-3">
          {roles?.map((role, index) => (
            <div key={index} className="flex items-center justify-between">
              <span className="text-sm text-gray-600">{role?.role}</span>
              <span className="text-sm font-semibold text-gray-900">{role?.count}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}