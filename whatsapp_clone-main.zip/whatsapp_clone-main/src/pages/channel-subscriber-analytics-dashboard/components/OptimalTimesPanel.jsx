import React from 'react';
import { Clock, TrendingUp } from 'lucide-react';

export default function OptimalTimesPanel({ times }) {
  return (
    <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
          <Clock className="w-5 h-5 text-green-600" />
          Optimal Posting Times
        </h2>
      </div>
      <div className="space-y-4">
        {times?.length > 0 ? (
          times?.map((time, index) => (
            <div 
              key={index} 
              className="flex items-center justify-between p-4 bg-gradient-to-r from-green-50 to-blue-50 rounded-lg border border-green-100"
            >
              <div className="flex items-center gap-3">
                <div className="flex items-center justify-center w-10 h-10 bg-green-100 text-green-600 rounded-full font-bold">
                  {index + 1}
                </div>
                <div>
                  <p className="text-lg font-semibold text-gray-900">{time?.time}</p>
                  <p className="text-sm text-gray-600">Peak engagement time</p>
                </div>
              </div>
              <div className="flex items-center gap-2 text-green-600">
                <TrendingUp className="w-5 h-5" />
                <span className="text-sm font-medium">{time?.engagement} views</span>
              </div>
            </div>
          ))
        ) : (
          <div className="text-center py-8">
            <Clock className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-500">Not enough data to determine optimal times</p>
          </div>
        )}
      </div>
      <div className="mt-6 p-4 bg-blue-50 rounded-lg border border-blue-100">
        <p className="text-sm text-blue-900">
          <strong>Tip:</strong> Schedule your messages during these peak hours to maximize subscriber engagement and reach.
        </p>
      </div>
    </div>
  );
}