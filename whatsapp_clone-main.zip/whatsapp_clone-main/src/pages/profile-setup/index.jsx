import { useState, useEffect, useRef } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Camera, User, CheckCircle, AlertCircle } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { profileSetupService } from '../../services/profileSetupService';

export default function ProfileSetup() {
  const navigate = useNavigate();
  const location = useLocation();
  const { signUpWithPhone } = useAuth();
  const fileInputRef = useRef(null);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Form state
  const [displayName, setDisplayName] = useState('');
  const [bio, setBio] = useState('');
  const [profilePhoto, setProfilePhoto] = useState(null);
  const [photoPreview, setPhotoPreview] = useState(null);
  
  // Validation state
  const [displayNameValid, setDisplayNameValid] = useState(null);
  const [displayNameChecking, setDisplayNameChecking] = useState(false);
  const [charCount, setCharCount] = useState(0);

  const MAX_BIO_LENGTH = 150;

  // Get phone data from location state
  const phoneNumber = location?.state?.phoneNumber;
  const countryCode = location?.state?.countryCode;
  const otpCode = location?.state?.otpCode;

  useEffect(() => {
    if (!phoneNumber || !countryCode || !otpCode) {
      navigate('/login');
    }
  }, [phoneNumber, countryCode, otpCode, navigate]);

  // Check display name availability
  useEffect(() => {
    const checkDisplayName = async () => {
      if (displayName?.length < 3) {
        setDisplayNameValid(null);
        return;
      }

      setDisplayNameChecking(true);
      try {
        const isAvailable = await profileSetupService?.checkDisplayNameAvailability(
          displayName,
          phoneNumber
        );
        setDisplayNameValid(isAvailable);
      } catch (err) {
        console.error('Error checking display name:', err);
      } finally {
        setDisplayNameChecking(false);
      }
    };

    const timeoutId = setTimeout(checkDisplayName, 500);
    return () => clearTimeout(timeoutId);
  }, [displayName, phoneNumber]);

  const handlePhotoSelect = (e) => {
    const file = e?.target?.files?.[0];
    if (!file) return;

    // Validate file size (5MB max)
    if (file?.size > 5242880) {
      setError('Photo must be less than 5MB');
      return;
    }

    // Validate file type
    if (!['image/jpeg', 'image/png', 'image/webp']?.includes(file?.type)) {
      setError('Photo must be JPEG, PNG, or WebP format');
      return;
    }

    setProfilePhoto(file);
    setPhotoPreview(URL.createObjectURL(file));
    setError('');
  };

  const handleBioChange = (e) => {
    const value = e?.target?.value;
    if (value?.length <= MAX_BIO_LENGTH) {
      setBio(value);
      setCharCount(value?.length);
    }
  };

  const handleSubmit = async (e) => {
    e?.preventDefault();
    
    if (!displayName?.trim()) {
      setError('Display name is required');
      return;
    }

    if (displayNameValid === false) {
      setError('Display name is already taken');
      return;
    }

    setLoading(true);
    setError('');
    setSuccess('');

    try {
      // Sign up with phone number first
      const { data: signUpData, error: signUpError } = await signUpWithPhone(
        phoneNumber,
        countryCode,
        displayName?.trim(),
        otpCode
      );

      if (signUpError) {
        throw new Error(signUpError?.message);
      }

      let avatarUrl = null;

      // Upload photo if selected
      if (profilePhoto && signUpData?.user?.id) {
        const filePath = await profileSetupService?.uploadProfilePhoto(
          profilePhoto,
          signUpData?.user?.id
        );
        avatarUrl = filePath;
      }

      // Update profile with additional details
      if (signUpData?.user?.id) {
        await profileSetupService?.updateProfile(signUpData?.user?.id, {
          displayName: displayName?.trim(),
          bio: bio?.trim(),
          avatarUrl
        });
      }

      setSuccess('Profile setup completed successfully!');
      
      // Navigate to email backup setup
      setTimeout(() => {
        navigate('/post-login-email-backup-setup', {
          state: {
            userId: signUpData?.user?.id
          }
        });
      }, 1000);
    } catch (err) {
      setError(err?.message || 'Failed to complete profile setup');
    } finally {
      setLoading(false);
    }
  };

  const handleSkip = () => {
    navigate('/post-login-email-backup-setup');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-xl max-w-2xl w-full p-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Complete Your Profile
          </h1>
          <p className="text-gray-600">
            Add a photo, display name, and bio to personalize your account
          </p>
        </div>

        {/* Error/Success Messages */}
        {error && (
          <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
            <p className="text-red-800 text-sm">{error}</p>
          </div>
        )}

        {success && (
          <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg flex items-start gap-3">
            <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
            <p className="text-green-800 text-sm">{success}</p>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Profile Photo Upload */}
          <div className="flex flex-col items-center">
            <input
              ref={fileInputRef}
              type="file"
              accept="image/jpeg,image/png,image/webp"
              onChange={handlePhotoSelect}
              className="hidden"
            />
            
            <div 
              onClick={() => fileInputRef?.current?.click()}
              className="relative cursor-pointer group"
            >
              <div className="w-32 h-32 rounded-full bg-gradient-to-br from-blue-100 to-indigo-100 flex items-center justify-center overflow-hidden border-4 border-white shadow-lg">
                {photoPreview ? (
                  <img 
                    src={photoPreview} 
                    alt="Profile preview" 
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <User className="w-16 h-16 text-gray-400" />
                )}
              </div>
              
              <div className="absolute bottom-0 right-0 bg-blue-600 rounded-full p-2 shadow-lg group-hover:bg-blue-700 transition-colors">
                <Camera className="w-5 h-5 text-white" />
              </div>
            </div>
            
            <p className="text-sm text-gray-500 mt-3">
              Click to upload profile photo (max 5MB)
            </p>
          </div>

          {/* Display Name */}
          <div>
            <label htmlFor="displayName" className="block text-sm font-medium text-gray-700 mb-2">
              Display Name *
            </label>
            <div className="relative">
              <input
                id="displayName"
                type="text"
                value={displayName}
                onChange={(e) => setDisplayName(e?.target?.value)}
                placeholder="Enter your display name"
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                required
                disabled={loading}
              />
              {displayNameChecking && (
                <div className="absolute right-3 top-3 text-gray-400">
                  Checking...
                </div>
              )}
              {displayNameValid !== null && !displayNameChecking && (
                <div className="absolute right-3 top-3">
                  {displayNameValid ? (
                    <CheckCircle className="w-5 h-5 text-green-600" />
                  ) : (
                    <AlertCircle className="w-5 h-5 text-red-600" />
                  )}
                </div>
              )}
            </div>
            {displayNameValid === false && (
              <p className="text-sm text-red-600 mt-1">
                This display name is already taken
              </p>
            )}
          </div>

          {/* Bio */}
          <div>
            <label htmlFor="bio" className="block text-sm font-medium text-gray-700 mb-2">
              Bio (Optional)
            </label>
            <textarea
              id="bio"
              value={bio}
              onChange={handleBioChange}
              placeholder="Tell us about yourself..."
              rows={3}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
              disabled={loading}
            />
            <div className="flex justify-between items-center mt-1">
              <p className="text-xs text-gray-500">
                Share a bit about yourself
              </p>
              <p className="text-xs text-gray-500">
                {charCount}/{MAX_BIO_LENGTH}
              </p>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-4">
            <button
              type="button"
              onClick={handleSkip}
              disabled={loading}
              className="flex-1 px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Skip for now
            </button>
            <button
              type="submit"
              disabled={loading || !displayName?.trim() || displayNameValid === false}
              className="flex-1 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
            >
              {loading ? (
                <>
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  Setting up...
                </>
              ) : (
                'Continue'
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}