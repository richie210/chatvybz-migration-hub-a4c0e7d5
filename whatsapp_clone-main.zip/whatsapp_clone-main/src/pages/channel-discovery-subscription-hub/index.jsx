import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, TrendingUp, Users, Radio, Check, Bell, BellOff, Filter, Star } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { channelService } from '../../services/channelService';
import { stripePaymentService } from '../../services/stripePaymentService';
import Icon from '../../components/AppIcon';

export default function ChannelDiscoverySubscriptionHub() {
  const { user, loading: authLoading, isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const [channels, setChannels] = useState([]);
  const [myChannels, setMyChannels] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState('discover'); // discover, subscribed
  const [sortBy, setSortBy] = useState('subscribers_count');
  const [subscribedChannelIds, setSubscribedChannelIds] = useState(new Set());
  const [subscriptionTiers, setSubscriptionTiers] = useState([]);
  const [userSubscriptions, setUserSubscriptions] = useState(new Map());

  useEffect(() => {
    if (authLoading) return;

    if (!isAuthenticated) {
      navigate('/login');
      return;
    }

    loadChannels();
    loadUserSubscriptions();
  }, [authLoading, isAuthenticated, navigate, activeTab, sortBy]);

  const loadChannels = async () => {
    try {
      setLoading(true);
      setError(null);

      if (activeTab === 'discover') {
        const result = await channelService?.discoverChannels({
          searchQuery,
          sortBy
        });
        if (result?.error) throw result?.error;
        setChannels(result?.data || []);

        // Load user's subscribed channels to mark them
        const myChannelsResult = await channelService?.getMyChannels();
        if (myChannelsResult?.data) {
          const subscribedIds = new Set(myChannelsResult?.data?.map(ch => ch?.id));
          setSubscribedChannelIds(subscribedIds);
        }
      } else {
        const result = await channelService?.getMyChannels();
        if (result?.error) throw result?.error;
        setMyChannels(result?.data || []);
      }
    } catch (err) {
      console.error('Error loading channels:', err);
      setError(err?.message);
    } finally {
      setLoading(false);
    }
  };

  const loadUserSubscriptions = async () => {
    try {
      const result = await stripePaymentService?.getUserSubscriptions();
      if (result?.data) {
        const subsMap = new Map();
        result?.data?.forEach(sub => {
          if (sub?.status === 'active') {
            subsMap?.set(sub?.channel_id, sub);
          }
        });
        setUserSubscriptions(subsMap);
      }
    } catch (err) {
      console.error('Error loading user subscriptions:', err);
    }
  };

  const loadChannelSubscriptionTiers = async (channelId) => {
    try {
      const result = await stripePaymentService?.getChannelSubscriptionTiers(channelId);
      if (result?.data) {
        return result?.data;
      }
      return [];
    } catch (err) {
      console.error('Error loading subscription tiers:', err);
      return [];
    }
  };

  const handleSearch = (e) => {
    e?.preventDefault();
    loadChannels();
  };

  const handleSubscribe = async (channelId) => {
    try {
      const result = await channelService?.subscribeToChannel(channelId);
      if (result?.error) throw result?.error;

      setSubscribedChannelIds(prev => new Set([...prev, channelId]));
      await loadChannels();
    } catch (err) {
      console.error('Error subscribing to channel:', err);
      setError(err?.message);
    }
  };

  const handleUnsubscribe = async (channelId) => {
    if (!window.confirm('Are you sure you want to unsubscribe from this channel?')) return;

    try {
      const result = await channelService?.unsubscribeFromChannel(channelId);
      if (result?.error) throw result?.error;

      setSubscribedChannelIds(prev => {
        const newSet = new Set(prev);
        newSet?.delete(channelId);
        return newSet;
      });
      await loadChannels();
    } catch (err) {
      console.error('Error unsubscribing from channel:', err);
      setError(err?.message);
    }
  };

  const handleChannelClick = (channelId) => {
    navigate(`/channel-broadcast-composer?channelId=${channelId}`);
  };

  const handleUpgradeChannel = async (channelId) => {
    navigate(`/channel-subscription-payment?channelId=${channelId}`);
  };

  if (authLoading || loading) {
    return (
      <div className="flex items-center justify-center h-screen bg-gray-50">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Loading channels...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white p-6 shadow-lg">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-center gap-3 mb-4">
            <Icon name="Radio" size={32} />
            <div>
              <h1 className="text-2xl font-bold">Channel Discovery</h1>
              <p className="text-blue-100">Explore and subscribe to broadcast channels</p>
            </div>
          </div>

          {/* Search Bar */}
          <form onSubmit={handleSearch} className="mt-4">
            <div className="relative">
              <Icon name="Search" size={20} className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e?.target?.value)}
                placeholder="Search channels by name, username, or description..."
                className="w-full pl-12 pr-4 py-3 rounded-lg text-gray-900 focus:outline-none focus:ring-2 focus:ring-blue-300"
              />
            </div>
          </form>
        </div>
      </div>
      <div className="max-w-6xl mx-auto p-6">
        {/* Tabs */}
        <div className="flex gap-4 mb-6 border-b border-gray-200">
          <button
            onClick={() => setActiveTab('discover')}
            className={`pb-3 px-4 font-medium transition-colors ${
              activeTab === 'discover' ?'text-blue-600 border-b-2 border-blue-600' :'text-gray-600 hover:text-blue-600'
            }`}
          >
            <div className="flex items-center gap-2">
              <Icon name="TrendingUp" size={20} />
              <span>Discover</span>
            </div>
          </button>
          <button
            onClick={() => setActiveTab('subscribed')}
            className={`pb-3 px-4 font-medium transition-colors ${
              activeTab === 'subscribed' ?'text-blue-600 border-b-2 border-blue-600' :'text-gray-600 hover:text-blue-600'
            }`}
          >
            <div className="flex items-center gap-2">
              <Icon name="Bell" size={20} />
              <span>My Subscriptions</span>
            </div>
          </button>
        </div>

        {/* Sort Filter (Discover Tab Only) */}
        {activeTab === 'discover' && (
          <div className="mb-6 flex items-center gap-4">
            <div className="flex items-center gap-2 text-gray-700">
              <Icon name="Filter" size={20} />
              <span className="font-medium">Sort by:</span>
            </div>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e?.target?.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="subscribers_count">Most Subscribers</option>
              <option value="messages_count">Most Active</option>
              <option value="created_at">Newest</option>
            </select>
          </div>
        )}

        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-6">
            {error}
          </div>
        )}

        {/* Discover Tab */}
        {activeTab === 'discover' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {channels?.length === 0 ? (
              <div className="col-span-full text-center py-12">
                <Icon name="Radio" size={64} className="mx-auto text-gray-300 mb-4" />
                <p className="text-gray-500 text-lg">No channels found</p>
                <p className="text-gray-400 text-sm mt-2">Try adjusting your search or filters</p>
              </div>
            ) : (
              channels?.map((channel) => (
                <div
                  key={channel?.id}
                  className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow p-6 cursor-pointer"
                  onClick={() => handleChannelClick(channel?.id)}
                >
                  <div className="flex items-start gap-4 mb-4">
                    <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center text-white font-bold text-xl flex-shrink-0">
                      {channel?.avatar_url ? (
                        <img
                          src={channel?.avatar_url}
                          alt={channel?.name}
                          className="w-full h-full rounded-full object-cover"
                        />
                      ) : (
                        channel?.name?.charAt(0)?.toUpperCase()
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-bold text-lg text-gray-900 truncate">{channel?.name}</h3>
                        {channel?.is_verified && (
                          <Icon name="Check" size={16} className="text-blue-500 flex-shrink-0" />
                        )}
                      </div>
                      {channel?.username && (
                        <p className="text-sm text-gray-500">@{channel?.username}</p>
                      )}
                    </div>
                  </div>

                  <p className="text-gray-600 text-sm mb-4 line-clamp-2">
                    {channel?.description || 'No description available'}
                  </p>

                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-4 text-sm text-gray-500">
                      <div className="flex items-center gap-1">
                        <Icon name="Users" size={16} />
                        <span>{channel?.subscribers_count?.toLocaleString() || 0}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Icon name="Radio" size={16} />
                        <span>{channel?.messages_count?.toLocaleString() || 0}</span>
                      </div>
                    </div>
                  </div>

                  {/* Premium Badge */}
                  {userSubscriptions?.has(channel?.id) && (
                    <div className="absolute top-2 right-2 bg-gradient-to-r from-yellow-400 to-yellow-500 text-white px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1">
                      <Icon name="Star" size={12} />
                      <span>Premium</span>
                    </div>
                  )}

                  <div className="flex items-center gap-2">
                    {subscribedChannelIds?.has(channel?.id) ? (
                      <>
                        <button
                          onClick={(e) => {
                            e?.stopPropagation();
                            handleUnsubscribe(channel?.id);
                          }}
                          className="flex-1 bg-gray-100 text-gray-700 px-4 py-2 rounded-lg font-medium hover:bg-gray-200 flex items-center justify-center gap-2"
                        >
                          <Icon name="Check" size={16} />
                          <span>Subscribed</span>
                        </button>
                        {!userSubscriptions?.has(channel?.id) && (
                          <button
                            onClick={(e) => {
                              e?.stopPropagation();
                              handleUpgradeChannel(channel?.id);
                            }}
                            className="bg-gradient-to-r from-yellow-500 to-yellow-600 text-white px-4 py-2 rounded-lg font-medium hover:from-yellow-600 hover:to-yellow-700 flex items-center gap-2"
                          >
                            <Icon name="Star" size={16} />
                            <span>Upgrade</span>
                          </button>
                        )}
                      </>
                    ) : (
                      <button
                        onClick={(e) => {
                          e?.stopPropagation();
                          handleSubscribe(channel?.id);
                        }}
                        className="w-full bg-blue-600 text-white px-4 py-2 rounded-lg font-medium hover:bg-blue-700 flex items-center justify-center gap-2"
                      >
                        <Icon name="Bell" size={16} />
                        <span>Subscribe</span>
                      </button>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {/* Subscribed Tab */}
        {activeTab === 'subscribed' && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {myChannels?.length === 0 ? (
              <div className="col-span-full text-center py-12">
                <Icon name="Bell" size={64} className="mx-auto text-gray-300 mb-4" />
                <p className="text-gray-500 text-lg">No subscriptions yet</p>
                <p className="text-gray-400 text-sm mt-2">Discover channels to get started</p>
                <button
                  onClick={() => setActiveTab('discover')}
                  className="mt-4 px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Explore Channels
                </button>
              </div>
            ) : (
              myChannels?.map((channel) => (
                <div
                  key={channel?.id}
                  className="bg-white rounded-lg shadow-md hover:shadow-lg transition-shadow p-6 cursor-pointer"
                  onClick={() => handleChannelClick(channel?.id)}
                >
                  <div className="flex items-start gap-4 mb-4">
                    <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-full flex items-center justify-center text-white font-bold text-xl flex-shrink-0">
                      {channel?.avatar_url ? (
                        <img
                          src={channel?.avatar_url}
                          alt={channel?.name}
                          className="w-full h-full rounded-full object-cover"
                        />
                      ) : (
                        channel?.name?.charAt(0)?.toUpperCase()
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-bold text-lg text-gray-900 truncate">{channel?.name}</h3>
                        {channel?.is_verified && (
                          <Icon name="Check" size={16} className="text-blue-500 flex-shrink-0" />
                        )}
                      </div>
                      {channel?.username && (
                        <p className="text-sm text-gray-500">@{channel?.username}</p>
                      )}
                    </div>
                  </div>

                  <p className="text-gray-600 text-sm mb-4 line-clamp-2">
                    {channel?.description || 'No description available'}
                  </p>

                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-4 text-sm text-gray-500">
                      <div className="flex items-center gap-1">
                        <Icon name="Users" size={16} />
                        <span>{channel?.subscribers_count?.toLocaleString() || 0}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Icon name="Radio" size={16} />
                        <span>{channel?.messages_count?.toLocaleString() || 0}</span>
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={(e) => {
                      e?.stopPropagation();
                      handleUnsubscribe(channel?.id);
                    }}
                    className="w-full py-2 px-4 rounded-lg font-medium bg-gray-200 text-gray-700 hover:bg-gray-300 transition-colors"
                  >
                    <div className="flex items-center justify-center gap-2">
                      <Icon name="BellOff" size={18} />
                      <span>Unsubscribe</span>
                    </div>
                  </button>
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
}