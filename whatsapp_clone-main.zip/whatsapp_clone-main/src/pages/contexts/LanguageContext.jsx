import React, { createContext, useContext, useState, useEffect } from 'react';

const LanguageContext = createContext(null);

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    // Return default values if context is not available
    return {
      currentLanguage: 'English',
      setLanguage: () => {},
      t: (key) => {
        const translations = {
          'landing_cta_web': 'Launch Web App',
          'landing_faq_title': 'Frequently Asked Questions',
          'landing_faq_desc': 'Find answers to common questions about ChatVybz',
          'footer_product': 'Product',
          'footer_company': 'Company',
          'footer_support': 'Support',
          'footer_legal': 'Legal'
        };
        return translations?.[key] || key;
      },
      dir: 'ltr'
    };
  }
  return context;
};

export const LanguageProvider = ({ children }) => {
  const [currentLanguage, setCurrentLanguage] = useState(() => {
    if (typeof window !== 'undefined') {
      return localStorage.getItem('appLanguage') || 'English';
    }
    return 'English';
  });

  const getDirection = (lang) => {
    const rtlLanguages = ['Arabic', 'Hebrew', 'Persian', 'Urdu'];
    return rtlLanguages?.includes(lang) ? 'rtl' : 'ltr';
  };

  const [dir, setDir] = useState(() => getDirection(currentLanguage));

  useEffect(() => {
    if (typeof window !== 'undefined') {
      localStorage.setItem('appLanguage', currentLanguage);
      setDir(getDirection(currentLanguage));
    }
  }, [currentLanguage]);

  const t = (key) => {
    const translations = {
      'landing_cta_web': 'Launch Web App',
      'landing_faq_title': 'Frequently Asked Questions',
      'landing_faq_desc': 'Find answers to common questions about ChatVybz',
      'footer_product': 'Product',
      'footer_company': 'Company',
      'footer_support': 'Support',
      'footer_legal': 'Legal'
    };
    return translations?.[key] || key;
  };

  const setLanguage = (lang) => {
    setCurrentLanguage(lang);
  };

  const value = {
    currentLanguage,
    setLanguage,
    t,
    dir
  };

  return (
    <LanguageContext.Provider value={value}>
      {children}
    </LanguageContext.Provider>
  );
};
