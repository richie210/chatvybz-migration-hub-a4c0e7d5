import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import Icon from '../../components/AppIcon';
import Input from '../../components/ui/Input';
import Button from '../../components/ui/Button';
import { searchService } from '../../services/searchService';
import { useAuth } from '../../contexts/AuthContext';

const AdvancedSearchInterface = () => {
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();

  const [activeTab, setActiveTab] = useState('messages');
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  
  const [searchResults, setSearchResults] = useState([]);
  const [archivedChats, setArchivedChats] = useState([]);
  const [savedSearches, setSavedSearches] = useState([]);
  
  const [filters, setFilters] = useState({
    messageType: '',
    dateFrom: '',
    dateTo: '',
    category: ''
  });

  const [showSaveSearch, setShowSaveSearch] = useState(false);
  const [saveSearchName, setSaveSearchName] = useState('');

  // Authentication guard
  useEffect(() => {
    if (!authLoading && !user) {
      navigate('/login');
    }
  }, [user, authLoading, navigate]);

  useEffect(() => {
    // Only load data after authentication is complete and user is authenticated
    if (!authLoading && user) {
      if (activeTab === 'archived') {
        loadArchivedChats();
      } else if (activeTab === 'saved') {
        loadSavedSearches();
      }
    }
  }, [activeTab, authLoading, user]);

  const loadArchivedChats = async () => {
    try {
      setLoading(true);
      const chats = await searchService?.getArchivedChats(filters);
      setArchivedChats(chats);
    } catch (err) {
      console.error('Error loading archived chats:', err);
      setError(err?.message || 'Failed to load archived chats');
    } finally {
      setLoading(false);
    }
  };

  const loadSavedSearches = async () => {
    try {
      setLoading(true);
      const searches = await searchService?.getSavedSearches();
      setSavedSearches(searches);
    } catch (err) {
      console.error('Error loading saved searches:', err);
      setError(err?.message || 'Failed to load saved searches');
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = async () => {
    if (!searchQuery?.trim()) return;

    try {
      setLoading(true);
      setError('');
      
      const results = await searchService?.searchMessages(searchQuery, filters);
      setSearchResults(results);
    } catch (err) {
      console.error('Error searching:', err);
      setError(err?.message || 'Search failed');
    } finally {
      setLoading(false);
    }
  };

  const handleSaveSearch = async () => {
    if (!saveSearchName?.trim() || !searchQuery?.trim()) return;

    try {
      await searchService?.saveSearch(saveSearchName, searchQuery, filters);
      setShowSaveSearch(false);
      setSaveSearchName('');
      
      if (activeTab === 'saved') {
        loadSavedSearches();
      }
    } catch (err) {
      console.error('Error saving search:', err);
      setError(err?.message || 'Failed to save search');
    }
  };

  const handleUseSavedSearch = async (search) => {
    setSearchQuery(search?.searchText);
    setFilters(search?.filters || {});
    setActiveTab('messages');
    
    await searchService?.updateSearchLastUsed(search?.id);
    handleSearch();
  };

  const handleDeleteSavedSearch = async (searchId) => {
    try {
      await searchService?.deleteSavedSearch(searchId);
      loadSavedSearches();
    } catch (err) {
      console.error('Error deleting search:', err);
      setError(err?.message || 'Failed to delete search');
    }
  };

  const handleUnarchiveChat = async (chatId) => {
    try {
      await searchService?.unarchiveChat(chatId);
      loadArchivedChats();
    } catch (err) {
      console.error('Error unarchiving chat:', err);
      setError(err?.message || 'Failed to unarchive chat');
    }
  };

  const tabs = [
    { id: 'messages', label: 'Messages', icon: 'MessageSquare' },
    { id: 'archived', label: 'Archived', icon: 'Archive' },
    { id: 'saved', label: 'Saved Searches', icon: 'Star' }
  ];

  const messageTypeOptions = [
    { value: '', label: 'All Types' },
    { value: 'text', label: 'Text' },
    { value: 'audio', label: 'Audio' },
    { value: 'meeting', label: 'Meeting' }
  ];

  return (
    <>
      <Helmet>
        <title>Advanced Search - ChatVybz</title>
        <meta name="description" content="Search messages, contacts, and archived chats with advanced filters and bulk operations" />
      </Helmet>

      <div className="min-h-screen bg-background">
        {/* Header */}
        <div className="bg-card border-b border-border sticky top-0 z-10">
          <div className="max-w-6xl mx-auto px-4 py-4">
            <div className="flex items-center gap-3 mb-4">
              <button
                onClick={() => navigate(-1)}
                className="p-2 hover:bg-accent rounded-lg transition-colors"
              >
                <Icon name="ArrowLeft" size={20} />
              </button>
              <div>
                <h1 className="text-xl font-semibold text-foreground">Advanced Search</h1>
                <p className="text-sm text-muted-foreground">Search messages, chats, and more</p>
              </div>
            </div>

            {/* Search Bar */}
            <div className="flex gap-2">
              <div className="flex-1 relative">
                <Icon 
                  name="Search" 
                  size={18} 
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" 
                />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e?.target?.value)}
                  onKeyPress={(e) => e?.key === 'Enter' && handleSearch()}
                  placeholder="Search messages, contacts, chats..."
                  className="w-full pl-10 pr-4 py-2.5 bg-background border border-input rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                />
              </div>
              <Button
                variant="default"
                onClick={handleSearch}
                loading={loading && activeTab === 'messages'}
                iconName="Search"
              >
                Search
              </Button>
              {searchQuery && (
                <Button
                  variant="outline"
                  onClick={() => setShowSaveSearch(true)}
                  iconName="Save"
                >
                  Save
                </Button>
              )}
            </div>

            {/* Tabs */}
            <div className="flex gap-2 mt-4">
              {tabs?.map((tab) => (
                <button
                  key={tab?.id}
                  onClick={() => setActiveTab(tab?.id)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                    activeTab === tab?.id
                      ? 'bg-primary text-primary-foreground'
                      : 'bg-background hover:bg-accent text-muted-foreground'
                  }`}
                >
                  <Icon name={tab?.icon} size={18} />
                  <span className="text-sm font-medium">{tab?.label}</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="max-w-6xl mx-auto px-4 py-6">
          {error && (
            <div className="mb-4 p-4 bg-destructive/10 border border-destructive/20 rounded-lg flex items-start gap-3">
              <Icon name="AlertCircle" size={20} color="var(--color-destructive)" />
              <p className="text-sm text-destructive">{error}</p>
            </div>
          )}

          {/* Filters */}
          {activeTab === 'messages' && (
            <div className="mb-6 bg-card border border-border rounded-xl p-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">
                    Message Type
                  </label>
                  <select
                    value={filters?.messageType}
                    onChange={(e) => setFilters({ ...filters, messageType: e?.target?.value })}
                    className="w-full px-3 py-2 bg-background border border-input rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                  >
                    {messageTypeOptions?.map((option) => (
                      <option key={option?.value} value={option?.value}>
                        {option?.label}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">
                    From Date
                  </label>
                  <input
                    type="date"
                    value={filters?.dateFrom}
                    onChange={(e) => setFilters({ ...filters, dateFrom: e?.target?.value })}
                    className="w-full px-3 py-2 bg-background border border-input rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-foreground mb-2">
                    To Date
                  </label>
                  <input
                    type="date"
                    value={filters?.dateTo}
                    onChange={(e) => setFilters({ ...filters, dateTo: e?.target?.value })}
                    className="w-full px-3 py-2 bg-background border border-input rounded-lg text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Content Area */}
          {activeTab === 'messages' && (
            <div className="space-y-3">
              {loading ? (
                <div className="text-center py-12">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
                  <p className="text-muted-foreground">Searching...</p>
                </div>
              ) : searchResults?.length === 0 && searchQuery ? (
                <div className="text-center py-12">
                  <Icon name="Search" size={48} className="mx-auto mb-4 text-muted-foreground" />
                  <p className="text-muted-foreground">No results found for "{searchQuery}"</p>
                </div>
              ) : (
                searchResults?.map((result) => (
                  <div
                    key={result?.messageId}
                    className="bg-card border border-border rounded-lg p-4 hover:border-primary/50 transition-colors cursor-pointer"
                  >
                    <div className="flex items-start justify-between mb-2">
                      <span className="text-sm font-medium text-foreground">{result?.senderName}</span>
                      <span className="text-xs text-muted-foreground">
                        {new Date(result?.createdAt)?.toLocaleDateString()}
                      </span>
                    </div>
                    <p className="text-sm text-muted-foreground line-clamp-2">
                      {result?.messagePreview}
                    </p>
                    <div className="flex items-center gap-2 mt-2">
                      <span className="text-xs px-2 py-1 rounded bg-accent/20 text-accent">
                        {result?.messageType}
                      </span>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

          {activeTab === 'archived' && (
            <div className="space-y-3">
              {loading ? (
                <div className="text-center py-12">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
                  <p className="text-muted-foreground">Loading archived chats...</p>
                </div>
              ) : archivedChats?.length === 0 ? (
                <div className="text-center py-12">
                  <Icon name="Archive" size={48} className="mx-auto mb-4 text-muted-foreground" />
                  <p className="text-muted-foreground">No archived chats</p>
                </div>
              ) : (
                archivedChats?.map((chat) => (
                  <div
                    key={chat?.id}
                    className="bg-card border border-border rounded-lg p-4"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h3 className="font-medium text-foreground mb-1">
                          {chat?.conversationName}
                        </h3>
                        <p className="text-sm text-muted-foreground line-clamp-1 mb-2">
                          {chat?.lastMessagePreview}
                        </p>
                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          <span>{chat?.messageCount} messages</span>
                          <span>•</span>
                          <span>Archived {new Date(chat?.archivedAt)?.toLocaleDateString()}</span>
                        </div>
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleUnarchiveChat(chat?.id)}
                        iconName="ArchiveRestore"
                      >
                        Unarchive
                      </Button>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}

          {activeTab === 'saved' && (
            <div className="space-y-3">
              {loading ? (
                <div className="text-center py-12">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
                  <p className="text-muted-foreground">Loading saved searches...</p>
                </div>
              ) : savedSearches?.length === 0 ? (
                <div className="text-center py-12">
                  <Icon name="Star" size={48} className="mx-auto mb-4 text-muted-foreground" />
                  <p className="text-muted-foreground">No saved searches</p>
                </div>
              ) : (
                savedSearches?.map((search) => (
                  <div
                    key={search?.id}
                    className="bg-card border border-border rounded-lg p-4"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1 cursor-pointer" onClick={() => handleUseSavedSearch(search)}>
                        <h3 className="font-medium text-foreground mb-1">
                          {search?.queryName}
                        </h3>
                        <p className="text-sm text-muted-foreground">
                          "{search?.searchText}"
                        </p>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDeleteSavedSearch(search?.id)}
                        iconName="Trash2"
                      />
                    </div>
                  </div>
                ))
              )}
            </div>
          )}
        </div>

        {/* Save Search Modal */}
        {showSaveSearch && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <div className="bg-card rounded-xl border border-border p-6 w-full max-w-md">
              <h3 className="text-lg font-semibold text-foreground mb-4">
                Save Search Query
              </h3>
              <Input
                label="Search Name"
                value={saveSearchName}
                onChange={(e) => setSaveSearchName(e?.target?.value)}
                placeholder="Enter a name for this search"
              />
              <div className="flex gap-3 mt-6">
                <Button
                  variant="outline"
                  fullWidth
                  onClick={() => setShowSaveSearch(false)}
                >
                  Cancel
                </Button>
                <Button
                  variant="default"
                  fullWidth
                  onClick={handleSaveSearch}
                >
                  Save
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </>
  );
};

export default AdvancedSearchInterface;