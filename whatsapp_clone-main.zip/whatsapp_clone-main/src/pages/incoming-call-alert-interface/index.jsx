import React, { useState, useEffect } from 'react';
import { Phone, PhoneOff, Video } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { incomingCallService } from '../../services/incomingCallService';
import { useAuth } from '../../contexts/AuthContext';

export default function IncomingCallAlertInterface() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [incomingCall, setIncomingCall] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [accepting, setAccepting] = useState(false);
  const [declining, setDeclining] = useState(false);

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }

    loadIncomingCalls();
    
    // Subscribe to new incoming calls
    const unsubscribe = incomingCallService?.subscribeToIncomingCalls(
      user?.id,
      (call) => {
        setIncomingCall(call);
      }
    );

    return () => {
      unsubscribe();
    };
  }, [user, navigate]);

  const loadIncomingCalls = async () => {
    try {
      setLoading(true);
      const calls = await incomingCallService?.getIncomingCalls(user?.id);
      
      if (calls?.length > 0) {
        setIncomingCall(calls?.[0]);
      }
    } catch (err) {
      setError(err?.message);
    } finally {
      setLoading(false);
    }
  };

  const handleAccept = async () => {
    if (!incomingCall) return;
    
    try {
      setAccepting(true);
      await incomingCallService?.acceptCall(incomingCall?.id);
      navigate('/calls', { state: { activeCall: incomingCall } });
    } catch (err) {
      setError(err?.message);
    } finally {
      setAccepting(false);
    }
  };

  const handleDecline = async () => {
    if (!incomingCall) return;
    
    try {
      setDeclining(true);
      await incomingCallService?.declineCall(incomingCall?.id);
      setIncomingCall(null);
      navigate(-1);
    } catch (err) {
      setError(err?.message);
    } finally {
      setDeclining(false);
    }
  };

  if (loading) {
    return (
      <div className="fixed inset-0 bg-gradient-to-br from-slate-900 to-slate-800 flex items-center justify-center z-50">
        <div className="text-white text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-white mx-auto mb-4"></div>
          <p className="text-lg">Loading call...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="fixed inset-0 bg-gradient-to-br from-slate-900 to-slate-800 flex items-center justify-center z-50">
        <div className="text-white text-center max-w-md mx-auto p-6">
          <div className="bg-red-500/20 border border-red-500 rounded-lg p-4 mb-4">
            <p className="text-red-100">{error}</p>
          </div>
          <button
            onClick={() => navigate(-1)}
            className="px-6 py-3 bg-white text-slate-900 rounded-full font-semibold hover:bg-slate-100 transition-colors"
          >
            Go Back
          </button>
        </div>
      </div>
    );
  }

  if (!incomingCall) {
    return (
      <div className="fixed inset-0 bg-gradient-to-br from-slate-900 to-slate-800 flex items-center justify-center z-50">
        <div className="text-white text-center">
          <p className="text-lg mb-4">No incoming calls</p>
          <button
            onClick={() => navigate(-1)}
            className="px-6 py-3 bg-white text-slate-900 rounded-full font-semibold hover:bg-slate-100 transition-colors"
          >
            Go Back
          </button>
        </div>
      </div>
    );
  }

  const callerName = incomingCall?.caller?.display_name || incomingCall?.caller?.full_name || 'Unknown Caller';
  const callerAvatar = incomingCall?.caller?.avatar_url;
  const isVideoCall = incomingCall?.call_type === 'video';

  return (
    <div className="fixed inset-0 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center z-50 p-6">
      <div className="w-full max-w-md mx-auto text-center">
        {/* Caller Profile Photo */}
        <div className="mb-8 animate-pulse-slow">
          <div className="w-32 h-32 mx-auto rounded-full overflow-hidden border-4 border-white/30 shadow-2xl">
            {callerAvatar ? (
              <img
                src={callerAvatar}
                alt={`${callerName} profile photo`}
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-full h-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
                <span className="text-5xl font-bold text-white">
                  {callerName?.charAt(0)?.toUpperCase()}
                </span>
              </div>
            )}
          </div>
        </div>

        {/* Caller Name */}
        <h1 className="text-3xl font-bold text-white mb-2">
          {callerName}
        </h1>

        {/* Call Type Badge */}
        <div className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 backdrop-blur-sm rounded-full mb-8">
          {isVideoCall ? (
            <>
              <Video className="w-4 h-4 text-white" />
              <span className="text-white font-medium">Video Call</span>
            </>
          ) : (
            <>
              <Phone className="w-4 h-4 text-white" />
              <span className="text-white font-medium">Voice Call</span>
            </>
          )}
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-center gap-8 mb-6">
          {/* Decline Button */}
          <button
            onClick={handleDecline}
            disabled={declining || accepting}
            className="group relative"
            aria-label="Decline call"
          >
            <div className="w-20 h-20 rounded-full bg-red-500 hover:bg-red-600 transition-all duration-300 flex items-center justify-center shadow-2xl hover:shadow-red-500/50 disabled:opacity-50 disabled:cursor-not-allowed">
              {declining ? (
                <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              ) : (
                <PhoneOff className="w-8 h-8 text-white" />
              )}
            </div>
            <span className="absolute -bottom-8 left-1/2 -translate-x-1/2 text-white text-sm font-medium whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity">
              Decline
            </span>
          </button>

          {/* Accept Button */}
          <button
            onClick={handleAccept}
            disabled={declining || accepting}
            className="group relative"
            aria-label="Accept call"
          >
            <div className="w-20 h-20 rounded-full bg-green-500 hover:bg-green-600 transition-all duration-300 flex items-center justify-center shadow-2xl hover:shadow-green-500/50 disabled:opacity-50 disabled:cursor-not-allowed animate-bounce-slow">
              {accepting ? (
                <div className="w-6 h-6 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              ) : (
                <Phone className="w-8 h-8 text-white" />
              )}
            </div>
            <span className="absolute -bottom-8 left-1/2 -translate-x-1/2 text-white text-sm font-medium whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity">
              Accept
            </span>
          </button>
        </div>

        {/* Quick Actions Info */}
        <p className="text-white/60 text-sm mt-12">
          Swipe for quick reply or forward options
        </p>
      </div>
      <style jsx>{`
        @keyframes pulse-slow {
          0%, 100% {
            opacity: 1;
          }
          50% {
            opacity: 0.8;
          }
        }
        
        @keyframes bounce-slow {
          0%, 100% {
            transform: translateY(0);
          }
          50% {
            transform: translateY(-10px);
          }
        }
        
        .animate-pulse-slow {
          animation: pulse-slow 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
        }
        
        .animate-bounce-slow {
          animation: bounce-slow 2s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
}