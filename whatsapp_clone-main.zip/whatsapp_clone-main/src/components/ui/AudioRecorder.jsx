import React, { useState, useEffect, useRef } from 'react';
import { Mic, Square, Trash2, Send } from 'lucide-react';
import { audioRecordingService } from '../../services/audioRecordingService';

export default function AudioRecorder({ onSend, onCancel }) {
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const [waveformData, setWaveformData] = useState([]);
  const [audioBlob, setAudioBlob] = useState(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [error, setError] = useState(null);

  const timerRef = useRef(null);
  const waveformIntervalRef = useRef(null);
  const audioRef = useRef(null);

  useEffect(() => {
    return () => {
      // Cleanup on unmount
      if (timerRef?.current) clearInterval(timerRef?.current);
      if (waveformIntervalRef?.current) clearInterval(waveformIntervalRef?.current);
      if (audioRef?.current) {
        audioRef?.current?.pause();
        audioRef.current = null;
      }
      audioRecordingService?.cleanup();
    };
  }, []);

  const startRecording = async () => {
    setError(null);
    const result = await audioRecordingService?.startRecording();

    if (!result?.success) {
      setError(result?.error);
      return;
    }

    setIsRecording(true);
    setRecordingTime(0);

    // Start timer
    timerRef.current = setInterval(() => {
      setRecordingTime(prev => prev + 1);
    }, 1000);

    // Update waveform in real-time
    waveformIntervalRef.current = setInterval(() => {
      const data = audioRecordingService?.getWaveformData();
      setWaveformData(data);
    }, 100);
  };

  const stopRecording = async () => {
    if (timerRef?.current) clearInterval(timerRef?.current);
    if (waveformIntervalRef?.current) clearInterval(waveformIntervalRef?.current);

    try {
      const result = await audioRecordingService?.stopRecording();
      setAudioBlob(result?.blob);
      setWaveformData(result?.waveform);
      setIsRecording(false);
    } catch (error) {
      setError(error?.message);
      setIsRecording(false);
    }
  };

  const cancelRecording = () => {
    audioRecordingService?.cancelRecording();
    if (timerRef?.current) clearInterval(timerRef?.current);
    if (waveformIntervalRef?.current) clearInterval(waveformIntervalRef?.current);
    setIsRecording(false);
    setAudioBlob(null);
    setWaveformData([]);
    setRecordingTime(0);
    onCancel?.();
  };

  const playAudio = () => {
    if (!audioBlob) return;

    if (isPlaying) {
      audioRef?.current?.pause();
      setIsPlaying(false);
    } else {
      if (!audioRef?.current) {
        audioRef.current = new Audio(URL.createObjectURL(audioBlob));
        audioRef.current.onended = () => setIsPlaying(false);
      }
      audioRef?.current?.play();
      setIsPlaying(true);
    }
  };

  const sendAudio = () => {
    if (!audioBlob) return;
    onSend?.(audioBlob, waveformData, recordingTime);
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs?.toString()?.padStart(2, '0')}`;
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-4 space-y-4">
      {error && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-3 text-red-700 text-sm">
          {error}
        </div>
      )}
      {/* Waveform Visualization */}
      <div className="flex items-center justify-center h-20 bg-gray-50 rounded-lg p-2">
        <div className="flex items-end justify-center gap-1 h-full w-full">
          {waveformData?.length > 0 ? (
            waveformData?.map((amplitude, index) => (
              <div
                key={index}
                className="bg-indigo-500 rounded-full transition-all duration-100"
                style={{
                  width: '3px',
                  height: `${Math.max(amplitude * 100, 5)}%`,
                  opacity: isRecording ? 0.8 : 0.5
                }}
              />
            ))
          ) : (
            <div className="text-gray-400 text-sm">
              {isRecording ? 'Recording...' : 'Click mic to start'}
            </div>
          )}
        </div>
      </div>
      {/* Time Display */}
      <div className="text-center">
        <span className="text-2xl font-mono text-gray-700">
          {formatTime(recordingTime)}
        </span>
      </div>
      {/* Controls */}
      <div className="flex items-center justify-center gap-4">
        {!isRecording && !audioBlob && (
          <button
            onClick={startRecording}
            className="p-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-full transition-colors shadow-lg"
            title="Start Recording"
          >
            <Mic className="w-6 h-6" />
          </button>
        )}

        {isRecording && (
          <>
            <button
              onClick={stopRecording}
              className="p-4 bg-red-600 hover:bg-red-700 text-white rounded-full transition-colors shadow-lg"
              title="Stop Recording"
            >
              <Square className="w-6 h-6" />
            </button>
            <button
              onClick={cancelRecording}
              className="p-4 bg-gray-600 hover:bg-gray-700 text-white rounded-full transition-colors shadow-lg"
              title="Cancel"
            >
              <Trash2 className="w-6 h-6" />
            </button>
          </>
        )}

        {audioBlob && !isRecording && (
          <>
            <button
              onClick={playAudio}
              className="p-4 bg-green-600 hover:bg-green-700 text-white rounded-full transition-colors shadow-lg"
              title={isPlaying ? 'Pause' : 'Play'}
            >
              {isPlaying ? '⏸' : '▶'}
            </button>
            <button
              onClick={cancelRecording}
              className="p-4 bg-gray-600 hover:bg-gray-700 text-white rounded-full transition-colors shadow-lg"
              title="Delete"
            >
              <Trash2 className="w-6 h-6" />
            </button>
            <button
              onClick={sendAudio}
              className="p-4 bg-indigo-600 hover:bg-indigo-700 text-white rounded-full transition-colors shadow-lg"
              title="Send Audio"
            >
              <Send className="w-6 h-6" />
            </button>
          </>
        )}
      </div>
    </div>
  );
}