import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../AppIcon';
import Image from '../AppImage';

const ProfileSettingsDropdown = ({ isOpen, onClose, triggerRef }) => {
  const navigate = useNavigate();
  const dropdownRef = useRef(null);

  const userProfile = {
    name: 'Alex Morgan',
    status: 'Available',
    avatar: '/assets/images/user-avatar.jpg'
  };

  const menuItems = [
    {
      icon: 'User',
      label: 'Profile',
      onClick: () => {
        navigate('/user-profile-settings');
        onClose();
      }
    },
    {
      icon: 'Settings',
      label: 'Settings',
      onClick: () => {
        navigate('/user-profile-settings');
        onClose();
      }
    },
    {
      icon: 'Bell',
      label: 'Notifications',
      onClick: () => {
        navigate('/user-profile-settings');
        onClose();
      }
    },
    {
      icon: 'Lock',
      label: 'Privacy',
      onClick: () => {
        navigate('/user-profile-settings');
        onClose();
      }
    },
    {
      type: 'divider'
    },
    {
      icon: 'Moon',
      label: 'Dark Mode',
      onClick: () => {
        document.documentElement?.classList?.toggle('dark');
      }
    },
    {
      type: 'divider'
    },
    {
      icon: 'LogOut',
      label: 'Log Out',
      onClick: () => {
        navigate('/login');
        onClose();
      }
    }
  ];

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        dropdownRef?.current &&
        !dropdownRef?.current?.contains(event?.target) &&
        triggerRef?.current &&
        !triggerRef?.current?.contains(event?.target)
      ) {
        onClose();
      }
    };

    const handleEscape = (event) => {
      if (event?.key === 'Escape') {
        onClose();
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
      document.addEventListener('keydown', handleEscape);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
      document.removeEventListener('keydown', handleEscape);
    };
  }, [isOpen, onClose, triggerRef]);

  if (!isOpen) return null;

  return (
    <div ref={dropdownRef} className="profile-settings-dropdown">
      <div className="profile-settings-header">
        <div className="profile-settings-user">
          <div className="profile-settings-avatar">
            <Image
              src={userProfile?.avatar}
              alt={userProfile?.name}
              className="w-full h-full object-cover"
            />
          </div>
          <div className="profile-settings-info">
            <div className="profile-settings-name">{userProfile?.name}</div>
            <div className="profile-settings-status">{userProfile?.status}</div>
          </div>
        </div>
      </div>
      <div className="profile-settings-menu">
        {menuItems?.map((item, index) => {
          if (item?.type === 'divider') {
            return <div key={index} className="profile-settings-divider" />;
          }

          return (
            <button
              key={index}
              onClick={item?.onClick}
              className="profile-settings-item w-full focus-ring"
            >
              <div className="profile-settings-item-icon">
                <Icon name={item?.icon} size={20} color="var(--color-foreground)" />
              </div>
              <span className="profile-settings-item-text">{item?.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
};

const ProfileSettingsTrigger = () => {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const triggerRef = useRef(null);

  const userProfile = {
    name: 'Alex Morgan',
    avatar: '/assets/images/user-avatar.jpg'
  };

  return (
    <div className="relative">
      <button
        ref={triggerRef}
        onClick={() => setIsDropdownOpen(!isDropdownOpen)}
        className="flex items-center gap-2 p-2 rounded-lg hover:bg-muted transition-colors focus-ring"
        aria-label="Open profile menu"
        aria-expanded={isDropdownOpen}
      >
        <div className="w-10 h-10 rounded-full overflow-hidden">
          <Image
            src={userProfile?.avatar}
            alt={userProfile?.name}
            className="w-full h-full object-cover"
          />
        </div>
        <Icon
          name={isDropdownOpen ? 'ChevronUp' : 'ChevronDown'}
          size={16}
          color="var(--color-foreground)"
        />
      </button>
      <ProfileSettingsDropdown
        isOpen={isDropdownOpen}
        onClose={() => setIsDropdownOpen(false)}
        triggerRef={triggerRef}
      />
    </div>
  );
};

export { ProfileSettingsDropdown, ProfileSettingsTrigger };
export default ProfileSettingsTrigger;