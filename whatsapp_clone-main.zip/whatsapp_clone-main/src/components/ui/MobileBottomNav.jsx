import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import Icon from '../AppIcon';

const MobileBottomNav = () => {
  const navigate = useNavigate();
  const location = useLocation();

  // Hide on public/auth pages
  const publicPaths = [
    '/',
    '/login',
    '/register',
    '/whats-app-style-phone-authentication',
    '/secure-twilio-otp-verification',
    '/qr-login',
    '/email-verification',
    '/profile-setup',
    '/post-login-email-backup-setup'
  ];

  // Don't render on public pages
  if (publicPaths?.includes(location?.pathname)) {
    return null;
  }

  const tabs = [
    {
      id: 'chats',
      label: 'Chats',
      icon: 'MessageCircle',
      path: '/main-chat-interface',
      activePaths: ['/main-chat-interface', '/chat']
    },
    {
      id: 'channels',
      label: 'Channels',
      icon: 'Radio',
      path: '/channel-management-dashboard',
      activePaths: ['/channel-management-dashboard', '/channel-creation-setup']
    },
    {
      id: 'status',
      label: 'Status',
      icon: 'Circle',
      path: '/status',
      activePaths: ['/status', '/status-stories-creation-management', '/status-stories-viewer-interface']
    },
    {
      id: 'calls',
      label: 'Calls',
      icon: 'Phone',
      path: '/calls',
      activePaths: ['/calls', '/enhanced-multi-participant-video-conference', '/incoming-call-alert-interface']
    },
    {
      id: 'payouts',
      label: 'Payouts',
      icon: 'DollarSign',
      path: '/creator-payout-withdrawal-system',
      activePaths: ['/creator-payout-withdrawal-system', '/creator-revenue-settlement-dashboard']
    },
    {
      id: 'settings',
      label: 'Settings',
      icon: 'Settings',
      path: '/profile',
      activePaths: ['/profile', '/user-profile-settings', '/enhanced-notification-settings', '/message-auto-delete-settings']
    }
  ];

  const isActive = (tab) => {
    return tab?.activePaths?.some(path => location?.pathname === path);
  };

  const handleTabClick = (path) => {
    navigate(path);
  };

  return (
    <nav className="mobile-bottom-nav lg:hidden">
      <div className="mobile-bottom-nav-container">
        {tabs?.map((tab) => {
          const active = isActive(tab);
          return (
            <button
              key={tab?.id}
              onClick={() => handleTabClick(tab?.path)}
              className={`mobile-bottom-nav-item ${
                active ? 'active' : ''
              }`}
              aria-label={tab?.label}
              aria-current={active ? 'page' : undefined}
            >
              <div className="mobile-bottom-nav-icon-wrapper">
                <Icon
                  name={tab?.icon}
                  size={24}
                  color={active ? 'var(--color-primary)' : 'var(--color-muted-foreground)'}
                />
              </div>
              <span className={`mobile-bottom-nav-label ${
                active ? 'text-primary' : 'text-muted-foreground'
              }`}>
                {tab?.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};

export default MobileBottomNav;