import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Icon from '../AppIcon';
import Image from '../AppImage';
import Input from './Input';
import Button from './Button';

const ContactAccessPanel = ({ isOpen, onClose }) => {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState('');

  const contacts = [
    {
      id: 1,
      name: 'Sarah Johnson',
      phone: '+1 (555) 123-4567',
      isAppUser: true,
      avatar: '/assets/images/avatar1.jpg',
      status: 'Hey there! I am using ChatVybz'
    },
    {
      id: 2,
      name: 'Michael Chen',
      phone: '+1 (555) 234-5678',
      isAppUser: true,
      avatar: '/assets/images/avatar2.jpg',
      status: 'Available'
    },
    {
      id: 3,
      name: 'Emma Wilson',
      phone: '+1 (555) 345-6789',
      isAppUser: true,
      avatar: '/assets/images/avatar3.jpg',
      status: 'Busy'
    },
    {
      id: 4,
      name: 'David Brown',
      phone: '+1 (555) 456-7890',
      isAppUser: false,
      avatar: '/assets/images/avatar4.jpg',
      status: null
    },
    {
      id: 5,
      name: 'Lisa Anderson',
      phone: '+1 (555) 567-8901',
      isAppUser: true,
      avatar: '/assets/images/avatar5.jpg',
      status: 'At work'
    },
    {
      id: 6,
      name: 'James Taylor',
      phone: '+1 (555) 678-9012',
      isAppUser: false,
      avatar: '/assets/images/avatar6.jpg',
      status: null
    }
  ];

  const filteredContacts = contacts?.filter(contact =>
    contact?.name?.toLowerCase()?.includes(searchQuery?.toLowerCase()) ||
    contact?.phone?.includes(searchQuery)
  );

  const handleContactClick = (contact) => {
    if (contact?.isAppUser) {
      navigate('/main-chat-interface', { state: { contactId: contact?.id } });
      onClose();
    }
  };

  const handleInviteClick = (contact) => {
    console.log('Invite contact:', contact?.name);
  };

  return (
    <div className={`contact-access-panel ${isOpen ? 'open' : ''}`}>
      <div className="contact-access-header">
        <h2 className="contact-access-title">Contacts</h2>
        <button
          onClick={onClose}
          className="p-2 rounded-lg hover:bg-muted transition-colors focus-ring"
          aria-label="Close contacts panel"
        >
          <Icon name="X" size={20} color="var(--color-foreground)" />
        </button>
      </div>
      <div className="contact-access-search">
        <Input
          type="search"
          placeholder="Search contacts..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e?.target?.value)}
          className="w-full"
        />
      </div>
      <div className="contact-access-list custom-scrollbar">
        {filteredContacts?.map((contact) => (
          <div
            key={contact?.id}
            className="contact-access-item"
            onClick={() => handleContactClick(contact)}
            style={{ cursor: contact?.isAppUser ? 'pointer' : 'default' }}
          >
            <div className="contact-access-avatar">
              <Image
                src={contact?.avatar}
                alt={contact?.name}
                className="w-full h-full object-cover"
              />
            </div>

            <div className="contact-access-info">
              <div className="contact-access-name">{contact?.name}</div>
              <div className="contact-access-phone">{contact?.phone}</div>
              {contact?.isAppUser && contact?.status && (
                <div className="text-xs text-muted-foreground mt-1 truncate">
                  {contact?.status}
                </div>
              )}
            </div>

            {contact?.isAppUser ? (
              <div className="contact-access-badge">On ChatVybz</div>
            ) : (
              <Button
                variant="outline"
                size="sm"
                onClick={(e) => {
                  e?.stopPropagation();
                  handleInviteClick(contact);
                }}
              >
                Invite
              </Button>
            )}
          </div>
        ))}

        {filteredContacts?.length === 0 && (
          <div className="flex flex-col items-center justify-center py-12 px-4 text-center">
            <Icon name="Users" size={48} color="var(--color-muted-foreground)" />
            <p className="mt-4 text-muted-foreground">No contacts found</p>
            <p className="mt-2 text-sm text-muted-foreground">
              Try adjusting your search
            </p>
          </div>
        )}
      </div>
      <div className="p-4 border-t border-border">
        <Button
          variant="default"
          fullWidth
          iconName="UserPlus"
          iconPosition="left"
          onClick={() => {
            navigate('/contact-management');
            onClose();
          }}
        >
          Add New Contact
        </Button>
      </div>
    </div>
  );
};

export default ContactAccessPanel;