import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import Icon from '../AppIcon';
import Image from '../AppImage';
import Input from './Input';
import { MessageSquare, User, Phone, Bell } from 'lucide-react';

const ChatTabNavigation = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [searchQuery, setSearchQuery] = useState('');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const conversations = [
    {
      id: 1,
      name: 'Sarah Johnson',
      lastMessage: 'Hey! Are we still on for lunch tomorrow?',
      timestamp: '10:30 AM',
      unreadCount: 2,
      isOnline: true,
      avatar: '/assets/images/avatar1.jpg'
    },
    {
      id: 2,
      name: 'Tech Team',
      lastMessage: 'John: The new feature is ready for testing',
      timestamp: '9:45 AM',
      unreadCount: 5,
      isOnline: false,
      avatar: '/assets/images/group1.jpg'
    },
    {
      id: 3,
      name: 'Michael Chen',
      lastMessage: 'Thanks for the update!',
      timestamp: 'Yesterday',
      unreadCount: 0,
      isOnline: true,
      avatar: '/assets/images/avatar2.jpg'
    },
    {
      id: 4,
      name: 'Emma Wilson',
      lastMessage: 'Can you send me the document?',
      timestamp: 'Yesterday',
      unreadCount: 0,
      isOnline: false,
      avatar: '/assets/images/avatar3.jpg'
    },
    {
      id: 5,
      name: 'Project Alpha',
      lastMessage: 'Lisa: Meeting rescheduled to 3 PM',
      timestamp: 'Tuesday',
      unreadCount: 1,
      isOnline: false,
      avatar: '/assets/images/group2.jpg'
    }
  ];

  const filteredConversations = conversations?.filter(conv =>
    conv?.name?.toLowerCase()?.includes(searchQuery?.toLowerCase())
  );

  const handleConversationClick = (conversationId) => {
    navigate('/main-chat-interface', { state: { conversationId } });
    setIsMobileMenuOpen(false);
  };

  const handleNewChat = () => {
    navigate('/contact-management');
    setIsMobileMenuOpen(false);
  };

  const isActiveConversation = (conversationId) => {
    return location?.pathname === '/main-chat-interface' && 
           location?.state?.conversationId === conversationId;
  };

  const tabs = [
    { id: 'chats', label: 'Chats', icon: MessageSquare, path: '/main-chat-interface' },
    { id: 'status', label: 'Status', icon: User, path: '/status' },
    { id: 'calls', label: 'Calls', icon: Phone, path: '/calls' },
    { id: 'notifications', label: 'Notifications', icon: Bell, path: '/notifications' }
  ];

  return (
    <>
      {/* Desktop Sidebar Navigation */}
      <aside className="chat-tab-navigation hidden lg:block custom-scrollbar">
        <div className="chat-tab-navigation-header">
          <div className="chat-tab-navigation-logo">
            <div className="chat-tab-navigation-logo-icon">
              <Icon name="MessageCircle" size={24} color="#FFFFFF" />
            </div>
            <h1 className="text-xl font-bold text-foreground">ChatVybz</h1>
          </div>
          <button
            onClick={handleNewChat}
            className="p-2 rounded-lg hover:bg-muted transition-colors focus-ring"
            aria-label="New chat"
          >
            <Icon name="Plus" size={20} color="var(--color-foreground)" />
          </button>
        </div>

        <div className="chat-tab-navigation-search">
          <Input
            type="search"
            placeholder="Search conversations..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e?.target?.value)}
            className="w-full"
          />
        </div>

        <div className="chat-tab-navigation-list custom-scrollbar">
          {filteredConversations?.map((conversation) => (
            <div
              key={conversation?.id}
              className={`chat-tab-navigation-item ${
                isActiveConversation(conversation?.id) ? 'active' : ''
              }`}
              onClick={() => handleConversationClick(conversation?.id)}
            >
              <div className="relative">
                <div className="chat-tab-navigation-avatar">
                  <Image
                    src={conversation?.avatar}
                    alt={conversation?.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                {conversation?.isOnline && (
                  <div className="chat-tab-navigation-status online" />
                )}
              </div>

              <div className="chat-tab-navigation-content">
                <div className="chat-tab-navigation-name">
                  {conversation?.name}
                </div>
                <div className="chat-tab-navigation-message">
                  {conversation?.lastMessage}
                </div>
              </div>

              <div className="chat-tab-navigation-meta">
                <div className="chat-tab-navigation-time">
                  {conversation?.timestamp}
                </div>
                {conversation?.unreadCount > 0 && (
                  <div className="chat-tab-navigation-badge">
                    {conversation?.unreadCount}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </aside>
      {/* Mobile Bottom Tab Navigation */}
      <nav className="chat-tab-navigation lg:hidden">
        <div className="mobile-tab-bar">
          <button
            onClick={() => navigate('/main-chat-interface')}
            className={`mobile-tab-item ${
              location?.pathname === '/main-chat-interface' ? 'active' : ''
            }`}
          >
            <Icon
              name="MessageCircle"
              size={24}
              color={
                location?.pathname === '/main-chat-interface' ?'var(--color-primary)' :'var(--color-muted-foreground)'
              }
            />
            <span className="mobile-tab-label">Chats</span>
          </button>

          <button
            onClick={() => navigate('/contact-management')}
            className={`mobile-tab-item ${
              location?.pathname === '/contact-management' ? 'active' : ''
            }`}
          >
            <Icon
              name="Users"
              size={24}
              color={
                location?.pathname === '/contact-management' ?'var(--color-primary)' :'var(--color-muted-foreground)'
              }
            />
            <span className="mobile-tab-label">Contacts</span>
          </button>

          <button
            onClick={() => navigate('/group-chat-management')}
            className={`mobile-tab-item ${
              location?.pathname === '/group-chat-management' ? 'active' : ''
            }`}
          >
            <Icon
              name="Users2"
              size={24}
              color={
                location?.pathname === '/group-chat-management' ?'var(--color-primary)' :'var(--color-muted-foreground)'
              }
            />
            <span className="mobile-tab-label">Groups</span>
          </button>

          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="mobile-tab-item"
          >
            <Icon
              name="Menu"
              size={24}
              color="var(--color-muted-foreground)"
            />
            <span className="mobile-tab-label">More</span>
          </button>
        </div>
      </nav>
      {/* Mobile Menu Overlay */}
      {isMobileMenuOpen && (
        <div
          className="fixed inset-0 bg-background z-200 lg:hidden"
          onClick={() => setIsMobileMenuOpen(false)}
        >
          <div className="flex flex-col h-full">
            <div className="flex items-center justify-between p-4 border-b border-border">
              <h2 className="text-xl font-bold">Menu</h2>
              <button
                onClick={() => setIsMobileMenuOpen(false)}
                className="p-2 rounded-lg hover:bg-muted"
              >
                <Icon name="X" size={24} color="var(--color-foreground)" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto p-4">
              <button
                onClick={() => {
                  navigate('/user-profile-settings');
                  setIsMobileMenuOpen(false);
                }}
                className="flex items-center gap-3 w-full p-4 rounded-lg hover:bg-muted transition-colors"
              >
                <Icon name="Settings" size={24} color="var(--color-foreground)" />
                <span className="text-foreground font-medium">Settings</span>
              </button>

              <button
                onClick={() => {
                  navigate('/broadcast-lists-management');
                  setIsMobileMenuOpen(false);
                }}
                className="flex items-center gap-3 w-full p-4 rounded-lg hover:bg-muted transition-colors"
              >
                <Icon name="Radio" size={24} color="var(--color-foreground)" />
                <span className="text-foreground font-medium">Broadcast Lists</span>
              </button>

              <button
                onClick={() => {
                  navigate('/status-stories-creation-management');
                  setIsMobileMenuOpen(false);
                }}
                className="flex items-center gap-3 w-full p-4 rounded-lg hover:bg-muted transition-colors"
              >
                <Icon name="Camera" size={24} color="var(--color-foreground)" />
                <span className="text-foreground font-medium">My Status</span>
              </button>

              <button
                onClick={() => {
                  navigate('/media-sharing');
                  setIsMobileMenuOpen(false);
                }}
                className="flex items-center gap-3 w-full p-4 rounded-lg hover:bg-muted transition-colors"
              >
                <Icon name="Image" size={24} color="var(--color-foreground)" />
                <span className="text-base font-medium">Media</span>
              </button>

              {/* Grammar & Tone Optimization */}
              <button
                onClick={() => {
                  navigate('/grammar-tone-optimization-interface');
                  setIsMobileMenuOpen(false);
                }}
                className="w-full flex items-center gap-3 px-4 py-3 hover:bg-gray-50 transition-colors text-left"
              >
                <Icon name="Sparkles" size={20} color="var(--color-primary)" />
                <span className="text-sm font-medium text-foreground">Grammar & Tone</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default ChatTabNavigation;