import React, { useState, useRef } from 'react';
import Icon from '../AppIcon';
import Image from '../AppImage';
import Button from './Button';
import Input from './Input';

const MediaCompositionOverlay = ({ isOpen, onClose, onSend, targetConversation }) => {
  const [selectedFiles, setSelectedFiles] = useState([]);
  const [caption, setCaption] = useState('');
  const [currentPreviewIndex, setCurrentPreviewIndex] = useState(0);
  const fileInputRef = useRef(null);

  if (!isOpen) return null;

  const handleFileSelect = (event) => {
    const files = Array.from(event?.target?.files);
    const fileObjects = files?.map(file => ({
      file,
      url: URL.createObjectURL(file),
      type: file?.type?.startsWith('image/') ? 'image' : 'video',
      name: file?.name,
      size: file?.size
    }));
    setSelectedFiles(prev => [...prev, ...fileObjects]);
  };

  const handleRemoveFile = (index) => {
    setSelectedFiles(prev => {
      const newFiles = [...prev];
      URL.revokeObjectURL(newFiles?.[index]?.url);
      newFiles?.splice(index, 1);
      if (currentPreviewIndex >= newFiles?.length && newFiles?.length > 0) {
        setCurrentPreviewIndex(newFiles?.length - 1);
      }
      return newFiles;
    });
  };

  const handleSend = () => {
    if (selectedFiles?.length > 0) {
      onSend({
        files: selectedFiles,
        caption,
        targetConversation
      });
      handleClose();
    }
  };

  const handleClose = () => {
    selectedFiles?.forEach(file => URL.revokeObjectURL(file?.url));
    setSelectedFiles([]);
    setCaption('');
    setCurrentPreviewIndex(0);
    onClose();
  };

  const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes?.[i];
  };

  return (
    <div className="media-composition-overlay">
      <div className="media-composition-header">
        <div className="flex items-center gap-3">
          <button
            onClick={handleClose}
            className="p-2 rounded-lg hover:bg-muted transition-colors focus-ring"
            aria-label="Close media composition"
          >
            <Icon name="X" size={24} color="var(--color-foreground)" />
          </button>
          <h2 className="media-composition-title">
            {selectedFiles?.length > 0 ? 'Preview Media' : 'Select Media'}
          </h2>
        </div>

        {selectedFiles?.length > 0 && (
          <div className="flex items-center gap-2">
            <span className="text-sm text-muted-foreground">
              {currentPreviewIndex + 1} / {selectedFiles?.length}
            </span>
          </div>
        )}
      </div>
      <div className="media-composition-content">
        {selectedFiles?.length === 0 ? (
          <div className="flex flex-col items-center justify-center gap-6">
            <div className="w-32 h-32 rounded-full bg-muted flex items-center justify-center">
              <Icon name="Image" size={64} color="var(--color-muted-foreground)" />
            </div>
            <div className="text-center">
              <h3 className="text-xl font-semibold mb-2">Select media to share</h3>
              <p className="text-muted-foreground">
                Choose photos or videos from your device
              </p>
            </div>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*,video/*"
              multiple
              onChange={handleFileSelect}
              className="hidden"
            />
            <Button
              variant="default"
              size="lg"
              iconName="Upload"
              iconPosition="left"
              onClick={() => fileInputRef?.current?.click()}
            >
              Choose Files
            </Button>
          </div>
        ) : (
          <>
            <div className="media-composition-preview">
              {selectedFiles?.[currentPreviewIndex]?.type === 'image' ? (
                <Image
                  src={selectedFiles?.[currentPreviewIndex]?.url}
                  alt={selectedFiles?.[currentPreviewIndex]?.name}
                  className="w-full h-full object-contain"
                />
              ) : (
                <video
                  src={selectedFiles?.[currentPreviewIndex]?.url}
                  controls
                  className="w-full h-full"
                />
              )}
            </div>

            {selectedFiles?.length > 1 && (
              <div className="flex items-center justify-center gap-4 mt-4">
                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => setCurrentPreviewIndex(prev => Math.max(0, prev - 1))}
                  disabled={currentPreviewIndex === 0}
                >
                  <Icon name="ChevronLeft" size={20} />
                </Button>

                <div className="flex gap-2 overflow-x-auto max-w-md">
                  {selectedFiles?.map((file, index) => (
                    <div
                      key={index}
                      className={`relative w-16 h-16 rounded-lg overflow-hidden cursor-pointer border-2 transition-all ${
                        index === currentPreviewIndex
                          ? 'border-primary' :'border-transparent'
                      }`}
                      onClick={() => setCurrentPreviewIndex(index)}
                    >
                      {file?.type === 'image' ? (
                        <Image
                          src={file?.url}
                          alt={file?.name}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full bg-muted flex items-center justify-center">
                          <Icon name="Video" size={24} color="var(--color-muted-foreground)" />
                        </div>
                      )}
                      <button
                        onClick={(e) => {
                          e?.stopPropagation();
                          handleRemoveFile(index);
                        }}
                        className="absolute top-1 right-1 w-5 h-5 rounded-full bg-destructive text-destructive-foreground flex items-center justify-center"
                      >
                        <Icon name="X" size={12} />
                      </button>
                    </div>
                  ))}
                </div>

                <Button
                  variant="outline"
                  size="icon"
                  onClick={() => setCurrentPreviewIndex(prev => Math.min(selectedFiles?.length - 1, prev + 1))}
                  disabled={currentPreviewIndex === selectedFiles?.length - 1}
                >
                  <Icon name="ChevronRight" size={20} />
                </Button>
              </div>
            )}

            <div className="media-composition-caption">
              <Input
                type="text"
                placeholder="Add a caption..."
                value={caption}
                onChange={(e) => setCaption(e?.target?.value)}
                className="w-full"
              />
              <div className="flex items-center justify-between mt-2 text-xs text-muted-foreground">
                <span>{selectedFiles?.[currentPreviewIndex]?.name}</span>
                <span>{formatFileSize(selectedFiles?.[currentPreviewIndex]?.size)}</span>
              </div>
            </div>
          </>
        )}
      </div>
      <div className="media-composition-footer">
        <div className="media-composition-actions">
          {selectedFiles?.length > 0 && (
            <>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*,video/*"
                multiple
                onChange={handleFileSelect}
                className="hidden"
              />
              <Button
                variant="outline"
                iconName="Plus"
                iconPosition="left"
                onClick={() => fileInputRef?.current?.click()}
              >
                Add More
              </Button>
            </>
          )}
        </div>

        {selectedFiles?.length > 0 && (
          <div className="flex items-center gap-3">
            <Button variant="outline" onClick={handleClose}>
              Cancel
            </Button>
            <Button
              variant="default"
              iconName="Send"
              iconPosition="right"
              onClick={handleSend}
            >
              Send {selectedFiles?.length > 1 ? `${selectedFiles?.length} files` : ''}
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};

export default MediaCompositionOverlay;