/**
 * Timezone and country code utilities
 */

// Country code to timezone mapping (ISO 3166-1 alpha-2)
export const COUNTRY_TIMEZONES = {
  'US': 'America/New_York',
  'GB': 'Europe/London',
  'CA': 'America/Toronto',
  'AU': 'Australia/Sydney',
  'DE': 'Europe/Berlin',
  'FR': 'Europe/Paris',
  'JP': 'Asia/Tokyo',
  'CN': 'Asia/Shanghai',
  'IN': 'Asia/Kolkata',
  'BR': 'America/Sao_Paulo',
  'MX': 'America/Mexico_City',
  'ES': 'Europe/Madrid',
  'IT': 'Europe/Rome',
  'NL': 'Europe/Amsterdam',
  'SE': 'Europe/Stockholm',
  'NO': 'Europe/Oslo',
  'DK': 'Europe/Copenhagen',
  'FI': 'Europe/Helsinki',
  'PL': 'Europe/Warsaw',
  'RU': 'Europe/Moscow',
  'KR': 'Asia/Seoul',
  'SG': 'Asia/Singapore',
  'HK': 'Asia/Hong_Kong',
  'TH': 'Asia/Bangkok',
  'ID': 'Asia/Jakarta',
  'PH': 'Asia/Manila',
  'VN': 'Asia/Ho_Chi_Minh',
  'MY': 'Asia/Kuala_Lumpur',
  'ZA': 'Africa/Johannesburg',
  'EG': 'Africa/Cairo',
  'NG': 'Africa/Lagos',
  'KE': 'Africa/Nairobi',
  'AR': 'America/Argentina/Buenos_Aires',
  'CL': 'America/Santiago',
  'CO': 'America/Bogota',
  'PE': 'America/Lima',
  'VE': 'America/Caracas',
  'NZ': 'Pacific/Auckland',
  'FJ': 'Pacific/Fiji'
};

// Country names for display
export const COUNTRY_NAMES = {
  'US': 'United States',
  'GB': 'United Kingdom',
  'CA': 'Canada',
  'AU': 'Australia',
  'DE': 'Germany',
  'FR': 'France',
  'JP': 'Japan',
  'CN': 'China',
  'IN': 'India',
  'BR': 'Brazil',
  'MX': 'Mexico',
  'ES': 'Spain',
  'IT': 'Italy',
  'NL': 'Netherlands',
  'SE': 'Sweden',
  'NO': 'Norway',
  'DK': 'Denmark',
  'FI': 'Finland',
  'PL': 'Poland',
  'RU': 'Russia',
  'KR': 'South Korea',
  'SG': 'Singapore',
  'HK': 'Hong Kong',
  'TH': 'Thailand',
  'ID': 'Indonesia',
  'PH': 'Philippines',
  'VN': 'Vietnam',
  'MY': 'Malaysia',
  'ZA': 'South Africa',
  'EG': 'Egypt',
  'NG': 'Nigeria',
  'KE': 'Kenya',
  'AR': 'Argentina',
  'CL': 'Chile',
  'CO': 'Colombia',
  'PE': 'Peru',
  'VE': 'Venezuela',
  'NZ': 'New Zealand',
  'FJ': 'Fiji'
};

/**
 * Get timezone for country code
 * @param {string} countryCode - ISO country code
 * @returns {string} Timezone name
 */
export function getTimezoneForCountry(countryCode) {
  return COUNTRY_TIMEZONES?.[countryCode] || 'UTC';
}

/**
 * Format date in user's timezone
 * @param {Date|string} date - Date to format
 * @param {string} timezone - IANA timezone name
 * @param {Object} options - Intl.DateTimeFormat options
 * @returns {string} Formatted date string
 */
export function formatInTimezone(date, timezone = 'UTC', options = {}) {
  const dateObj = typeof date === 'string' ? new Date(date) : date;
  
  const defaultOptions = {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
    timeZone: timezone
  };

  return new Intl.DateTimeFormat('en-US', {
    ...defaultOptions,
    ...options
  })?.format(dateObj);
}

/**
 * Get current time in user's timezone
 * @param {string} timezone - IANA timezone name
 * @returns {string} Formatted current time
 */
export function getCurrentTimeInTimezone(timezone = 'UTC') {
  return formatInTimezone(new Date(), timezone, {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit'
  });
}

/**
 * Get timezone offset in minutes
 * @param {string} timezone - IANA timezone name
 * @returns {number} Offset in minutes from UTC
 */
export function getTimezoneOffset(timezone) {
  const date = new Date();
  const utcDate = new Date(date.toLocaleString('en-US', { timeZone: 'UTC' }));
  const tzDate = new Date(date.toLocaleString('en-US', { timeZone: timezone }));
  return Math.round((tzDate - utcDate) / (1000 * 60));
}

/**
 * Format relative time (e.g., "2 hours ago")
 * @param {Date|string} date - Date to format
 * @param {string} timezone - User's timezone
 * @returns {string} Relative time string
 */
export function formatRelativeTime(date, timezone = 'UTC') {
  const dateObj = typeof date === 'string' ? new Date(date) : date;
  const now = new Date();
  
  const diffMs = now - dateObj;
  const diffSecs = Math.floor(diffMs / 1000);
  const diffMins = Math.floor(diffSecs / 60);
  const diffHours = Math.floor(diffMins / 60);
  const diffDays = Math.floor(diffHours / 24);

  if (diffSecs < 60) return 'just now';
  if (diffMins < 60) return `${diffMins}m ago`;
  if (diffHours < 24) return `${diffHours}h ago`;
  if (diffDays < 7) return `${diffDays}d ago`;
  
  return formatInTimezone(dateObj, timezone, {
    month: 'short',
    day: 'numeric'
  });
}

/**
 * Get user's current timezone from browser
 * @returns {string} IANA timezone name
 */
export function getUserTimezone() {
  return Intl.DateTimeFormat()?.resolvedOptions()?.timeZone;
}

/**
 * Detect country code from timezone
 * @param {string} timezone - IANA timezone name
 * @returns {string|null} ISO country code or null
 */
export function getCountryFromTimezone(timezone) {
  for (const [code, tz] of Object.entries(COUNTRY_TIMEZONES)) {
    if (tz === timezone) return code;
  }
  return null;
}

/**
 * Format timestamp with timezone indicator
 * @param {Date|string} date - Date to format
 * @param {string} timezone - User's timezone
 * @param {string} countryCode - User's country code
 * @returns {string} Formatted string with timezone
 */
export function formatWithTimezone(date, timezone, countryCode) {
  const formatted = formatInTimezone(date, timezone);
  const offset = getTimezoneOffset(timezone);
  const offsetHours = Math.floor(Math.abs(offset) / 60);
  const offsetMins = Math.abs(offset) % 60;
  const sign = offset >= 0 ? '+' : '-';
  
  return `${formatted} (${COUNTRY_NAMES?.[countryCode] || countryCode} ${sign}${offsetHours}:${offsetMins?.toString()?.padStart(2, '0')})`;
}

export default {
  COUNTRY_TIMEZONES,
  COUNTRY_NAMES,
  getTimezoneForCountry,
  formatInTimezone,
  getCurrentTimeInTimezone,
  getTimezoneOffset,
  formatRelativeTime,
  getUserTimezone,
  getCountryFromTimezone,
  formatWithTimezone
};