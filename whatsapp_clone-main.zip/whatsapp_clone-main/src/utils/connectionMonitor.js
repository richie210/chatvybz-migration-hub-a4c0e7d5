class ConnectionMonitor {
  constructor() {
    this.isOnline = navigator.onLine;
    this.listeners = new Set();
    this.reconnectAttempts = 0;
    this.maxReconnectAttempts = 5;
    
    // Set up event listeners
    this.setupEventListeners();
  }

  setupEventListeners() {
    window.addEventListener('online', () => this.handleOnline());
    window.addEventListener('offline', () => this.handleOffline());
  }

  handleOnline() {
    this.isOnline = true;
    this.reconnectAttempts = 0;
    console.log('Connection restored');
    this.notifyListeners({ isOnline: true, event: 'online' });
  }

  handleOffline() {
    this.isOnline = false;
    console.log('Connection lost');
    this.notifyListeners({ isOnline: false, event: 'offline' });
  }

  subscribe(callback) {
    this.listeners?.add(callback);
    // Immediately notify new listener of current status
    callback({ isOnline: this.isOnline, event: 'subscribe' });
    
    // Return unsubscribe function
    return () => {
      this.listeners?.delete(callback);
    };
  }

  notifyListeners(status) {
    this.listeners?.forEach(callback => {
      try {
        callback(status);
      } catch (error) {
        console.error('Error in connection listener:', error);
      }
    });
  }

  getStatus() {
    return {
      isOnline: this.isOnline,
      reconnectAttempts: this.reconnectAttempts
    };
  }

  // Simulate connection check (for testing)
  async checkConnection() {
    try {
      const response = await fetch('/api/health', { 
        method: 'HEAD',
        cache: 'no-cache'
      });
      return response?.ok;
    } catch (error) {
      return false;
    }
  }
}

export const connectionMonitor = new ConnectionMonitor();