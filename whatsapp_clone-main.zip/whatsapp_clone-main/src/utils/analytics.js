// Google Analytics tracking utilities

export const trackEvent = (eventName, parameters = {}) => {
  if (import.meta.env?.MODE === 'production' && typeof window.gtag !== 'undefined') {
    window.gtag('event', eventName, parameters);
  }
};

// Chat engagement tracking
export const trackChatEngagement = {
  messageSent: (messageType = 'text') => {
    trackEvent('message_sent', {
      message_type: messageType,
      page: window.location?.pathname
    });
  },

  messageReceived: () => {
    trackEvent('message_received', {
      page: window.location?.pathname
    });
  },

  conversationOpened: () => {
    trackEvent('conversation_opened', {
      page: window.location?.pathname
    });
  }
};

// Call tracking
export const trackCallEngagement = {
  callInitiated: (callType) => {
    trackEvent('call_initiated', {
      call_type: callType,
      page: window.location?.pathname
    });
  },

  callEnded: (duration, callType) => {
    trackEvent('call_ended', {
      call_type: callType,
      duration: duration,
      page: window.location?.pathname
    });
  },

  callDeclined: (callType) => {
    trackEvent('call_declined', {
      call_type: callType,
      page: window.location?.pathname
    });
  }
};

// Status tracking
export const trackStatusEngagement = {
  statusViewed: (statusId) => {
    trackEvent('status_viewed', {
      status_id: statusId,
      page: window.location?.pathname
    });
  },

  statusCreated: (mediaType) => {
    trackEvent('status_created', {
      media_type: mediaType,
      page: window.location?.pathname
    });
  },

  statusReplied: () => {
    trackEvent('status_replied', {
      page: window.location?.pathname
    });
  }
};

// Feature adoption tracking
export const trackFeatureAdoption = {
  featureUsed: (featureName) => {
    trackEvent('feature_used', {
      feature_name: featureName,
      page: window.location?.pathname
    });
  },

  settingsChanged: (settingName, settingValue) => {
    trackEvent('settings_changed', {
      setting_name: settingName,
      setting_value: String(settingValue),
      page: window.location?.pathname
    });
  }
};

export default {
  trackEvent,
  trackChatEngagement,
  trackCallEngagement,
  trackStatusEngagement,
  trackFeatureAdoption
};