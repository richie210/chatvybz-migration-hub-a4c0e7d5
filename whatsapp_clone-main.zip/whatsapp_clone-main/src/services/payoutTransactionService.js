import { supabase } from '../lib/supabase';

/**
 * Payout Transaction Service - Transaction-level analytics and detailed tracking
 */

export const payoutTransactionService = {
  /**
   * Get all transactions for a specific payout
   */
  async getPayoutTransactions(payoutId) {
    try {
      const { data, error } = await supabase
        ?.from('payout_transactions')
        ?.select('*')
        ?.eq('payout_id', payoutId)
        ?.order('transaction_date', { ascending: false });

      if (error) throw error;

      return { data, error: null };
    } catch (error) {
      console.error('Error fetching payout transactions:', error);
      return { data: null, error };
    }
  },

  /**
   * Get transaction analytics for a payout
   */
  async getTransactionAnalytics(payoutId) {
    try {
      const { data: transactions, error } = await this.getPayoutTransactions(payoutId);

      if (error) throw error;

      if (!transactions || transactions?.length === 0) {
        return {
          data: {
            totalTransactions: 0,
            byType: {},
            totalAmount: 0,
            totalFees: 0,
            netAmount: 0,
            averageTransactionAmount: 0
          },
          error: null
        };
      }

      // Calculate analytics
      const byType = {};
      let totalAmount = 0;
      let totalFees = 0;
      let netAmount = 0;

      transactions?.forEach(txn => {
        const type = txn?.transaction_type;
        if (!byType?.[type]) {
          byType[type] = {
            count: 0,
            amount: 0,
            fees: 0,
            net: 0
          };
        }

        byType[type].count += 1;
        byType[type].amount += parseFloat(txn?.amount || 0);
        byType[type].fees += parseFloat(txn?.fee_amount || 0);
        byType[type].net += parseFloat(txn?.net_amount || 0);

        totalAmount += parseFloat(txn?.amount || 0);
        totalFees += parseFloat(txn?.fee_amount || 0);
        netAmount += parseFloat(txn?.net_amount || 0);
      });

      return {
        data: {
          totalTransactions: transactions?.length,
          byType,
          totalAmount,
          totalFees,
          netAmount,
          averageTransactionAmount: totalAmount / transactions?.length
        },
        error: null
      };
    } catch (error) {
      console.error('Error calculating transaction analytics:', error);
      return { data: null, error };
    }
  },

  /**
   * Get transaction breakdown by type
   */
  getTransactionBreakdown(transactions) {
    if (!transactions || transactions?.length === 0) {
      return [];
    }

    const breakdown = {};

    transactions?.forEach(txn => {
      const type = txn?.transaction_type;
      if (!breakdown?.[type]) {
        breakdown[type] = {
          type,
          count: 0,
          amount: 0,
          percentage: 0
        };
      }

      breakdown[type].count += 1;
      breakdown[type].amount += parseFloat(txn?.amount || 0);
    });

    const total = Object.values(breakdown)?.reduce((sum, item) => sum + item?.amount, 0);

    return Object.values(breakdown)?.map(item => ({
      ...item,
      percentage: total > 0 ? (item?.amount / total) * 100 : 0
    }));
  },

  /**
   * Format transaction type for display
   */
  formatTransactionType(type) {
    const labels = {
      subscription: 'Subscription',
      ad_revenue: 'Ad Revenue',
      donation: 'Tip/Donation',
      refund: 'Refund',
      adjustment: 'Adjustment'
    };
    return labels?.[type] || type;
  },

  /**
   * Get transaction type icon
   */
  getTransactionTypeIcon(type) {
    const icons = {
      subscription: 'CreditCard',
      ad_revenue: 'TrendingUp',
      donation: 'Heart',
      refund: 'RotateCcw',
      adjustment: 'Settings'
    };
    return icons?.[type] || 'DollarSign';
  },

  /**
   * Get transaction type color
   */
  getTransactionTypeColor(type) {
    const colors = {
      subscription: 'green',
      ad_revenue: 'blue',
      donation: 'purple',
      refund: 'red',
      adjustment: 'gray'
    };
    return colors?.[type] || 'gray';
  },

  /**
   * Format currency amount
   */
  formatAmount(amount, currency = 'USD') {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency?.toUpperCase()
    })?.format(amount);
  }
};