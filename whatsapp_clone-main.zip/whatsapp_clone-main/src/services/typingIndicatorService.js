import { supabase } from '../lib/supabase';

export const typingIndicatorService = {
  // Update typing status
  async updateTypingStatus(conversationId, isTyping) {
    const { error } = await supabase?.rpc('update_typing_indicator', {
      conversation_id_param: conversationId,
      is_typing_param: isTyping
    });
    
    if (error) throw error;
  },

  // Subscribe to typing indicator updates
  subscribeToTypingIndicators(conversationId, onTypingUpdate) {
    const channel = supabase?.channel(`typing:${conversationId}`)?.on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'typing_indicators',
          filter: `conversation_id=eq.${conversationId}`
        },
        async (payload) => {
          const { data: { user } } = await supabase?.auth?.getUser();
          
          // Ignore own typing indicator updates
          if (payload?.new?.user_id === user?.id) return;
          
          if (payload?.eventType === 'INSERT' || payload?.eventType === 'UPDATE') {
            // Fetch user profile for typing indicator
            const { data: profile } = await supabase?.from('profiles')?.select('full_name')?.eq('id', payload?.new?.user_id)?.single();
            
            onTypingUpdate({
              userId: payload?.new?.user_id,
              isTyping: payload?.new?.is_typing,
              userName: profile?.full_name || 'Someone'
            });
          }
        }
      )?.subscribe();
    
    return () => {
      supabase?.removeChannel(channel);
    };
  }
};