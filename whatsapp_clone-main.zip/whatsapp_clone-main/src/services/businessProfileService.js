import { supabase } from '../lib/supabase';

export const businessProfileService = {
  /**
   * Create business profile
   */
  async createProfile(profileData) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data, error } = await supabase?.from('business_profiles')?.insert({
          user_id: user?.id,
          business_name: profileData?.businessName,
          business_description: profileData?.businessDescription,
          business_category: profileData?.businessCategory,
          business_email: profileData?.businessEmail,
          business_phone: profileData?.businessPhone,
          business_address: profileData?.businessAddress,
          business_website: profileData?.businessWebsite,
          logo_url: profileData?.logoUrl,
          banner_url: profileData?.bannerUrl,
          operating_hours: profileData?.operatingHours || {}
        })?.select()?.single();

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Create business profile error:', error);
      throw error;
    }
  },

  /**
   * Get business profile
   */
  async getProfile() {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data, error } = await supabase?.from('business_profiles')?.select('*')?.eq('user_id', user?.id)?.single();

      if (error && error?.code !== 'PGRST116') throw error;
      return data;
    } catch (error) {
      console.error('Get business profile error:', error);
      throw error;
    }
  },

  /**
   * Update business profile
   */
  async updateProfile(profileId, updates) {
    try {
      const { data, error } = await supabase?.from('business_profiles')?.update(updates)?.eq('id', profileId)?.select()?.single();

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Update business profile error:', error);
      throw error;
    }
  },

  /**
   * Add product to catalog
   */
  async addProduct(businessProfileId, productData) {
    try {
      const { data, error } = await supabase?.from('products')?.insert({
          business_profile_id: businessProfileId,
          product_name: productData?.productName,
          product_description: productData?.productDescription,
          product_category: productData?.productCategory,
          price: productData?.price,
          currency: productData?.currency || 'USD',
          stock_quantity: productData?.stockQuantity || 0,
          is_available: productData?.isAvailable !== false,
          product_images: productData?.productImages || [],
          product_variants: productData?.productVariants || [],
          sku: productData?.sku,
          weight: productData?.weight,
          dimensions: productData?.dimensions
        })?.select()?.single();

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Add product error:', error);
      throw error;
    }
  },

  /**
   * Get all products for business
   */
  async getProducts(businessProfileId) {
    try {
      const { data, error } = await supabase?.from('products')?.select('*')?.eq('business_profile_id', businessProfileId)?.order('created_at', { ascending: false });

      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Get products error:', error);
      throw error;
    }
  },

  /**
   * Update product
   */
  async updateProduct(productId, updates) {
    try {
      const { data, error } = await supabase?.from('products')?.update(updates)?.eq('id', productId)?.select()?.single();

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Update product error:', error);
      throw error;
    }
  },

  /**
   * Delete product
   */
  async deleteProduct(productId) {
    try {
      const { error } = await supabase?.from('products')?.delete()?.eq('id', productId);

      if (error) throw error;
      return { success: true };
    } catch (error) {
      console.error('Delete product error:', error);
      throw error;
    }
  },

  /**
   * Add payment method
   */
  async addPaymentMethod(businessProfileId, methodData) {
    try {
      const { data, error } = await supabase?.from('payment_methods')?.insert({
          business_profile_id: businessProfileId,
          method_type: methodData?.methodType,
          provider: methodData?.provider,
          is_active: methodData?.isActive !== false,
          configuration: methodData?.configuration || {}
        })?.select()?.single();

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Add payment method error:', error);
      throw error;
    }
  },

  /**
   * Get payment methods
   */
  async getPaymentMethods(businessProfileId) {
    try {
      const { data, error } = await supabase?.from('payment_methods')?.select('*')?.eq('business_profile_id', businessProfileId)?.order('created_at', { ascending: false });

      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Get payment methods error:', error);
      throw error;
    }
  },

  /**
   * Get business analytics
   */
  async getAnalytics(businessProfileId, dateRange = {}) {
    try {
      let query = supabase?.from('business_analytics')?.select('*')?.eq('business_profile_id', businessProfileId);

      if (dateRange?.start) query = query?.gte('date', dateRange?.start);
      if (dateRange?.end) query = query?.lte('date', dateRange?.end);

      const { data, error } = await query?.order('date', { ascending: false });

      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Get analytics error:', error);
      throw error;
    }
  },

  /**
   * Get payment transactions
   */
  async getTransactions(businessProfileId, filters = {}) {
    try {
      let query = supabase?.from('payment_transactions')?.select(`
          *,
          customer:profiles!payment_transactions_customer_id_fkey(id, full_name, avatar_url),
          product:products(id, product_name)
        `)?.eq('business_profile_id', businessProfileId);

      if (filters?.status) query = query?.eq('status', filters?.status);
      if (filters?.startDate) query = query?.gte('created_at', filters?.startDate);
      if (filters?.endDate) query = query?.lte('created_at', filters?.endDate);

      const { data, error } = await query?.order('created_at', { ascending: false });

      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Get transactions error:', error);
      throw error;
    }
  },

  /**
   * Create customer interaction
   */
  async createInteraction(businessProfileId, interactionData) {
    try {
      const { data, error } = await supabase?.from('customer_interactions')?.insert({
          business_profile_id: businessProfileId,
          customer_id: interactionData?.customerId,
          interaction_type: interactionData?.interactionType,
          message_id: interactionData?.messageId,
          notes: interactionData?.notes,
          status: interactionData?.status || 'open'
        })?.select()?.single();

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Create interaction error:', error);
      throw error;
    }
  },

  /**
   * Get customer interactions
   */
  async getInteractions(businessProfileId) {
    try {
      const { data, error } = await supabase?.from('customer_interactions')?.select(`
          *,
          customer:profiles!customer_interactions_customer_id_fkey(id, full_name, avatar_url)
        `)?.eq('business_profile_id', businessProfileId)?.order('created_at', { ascending: false });

      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Get interactions error:', error);
      throw error;
    }
  }
};
