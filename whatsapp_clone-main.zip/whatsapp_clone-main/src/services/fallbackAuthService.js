import { supabase } from '../lib/supabase';

/**
 * Fallback Authentication Service
 * Automatically tries SMS → Email → Voice call for OTP delivery
 * Ensures users always have a working authentication path
 */

const fallbackAuthService = {
  /**
   * Send OTP with automatic fallback logic
   * @param {string} phoneNumber - Phone number without country code
   * @param {string} countryCode - Country code (e.g., '+1', '+596')
   * @param {string} email - User's email for fallback (optional)
   * @returns {Promise<Object>} Result with delivery method used
   */
  async sendOTPWithFallback(phoneNumber, countryCode, email = null) {
    const fallbackChain = [];
    let lastError = null;

    console.log('🔄 Starting fallback authentication chain');
    console.log('📞 Phone:', `${countryCode}${phoneNumber}`);
    console.log('📧 Email:', email || 'Not provided');

    // Step 1: Try SMS (Primary)
    try {
      console.log('📱 Attempting SMS delivery...');
      fallbackChain?.push({ method: 'sms', status: 'attempting' });

      const { data: smsData, error: smsError } = await supabase?.functions?.invoke('send-sms-otp', {
        body: {
          phoneNumber: phoneNumber?.replace(/\D/g, ''),
          countryCode: countryCode
        }
      });

      // Check for errors - now checking success flag
      if (smsError || !smsData?.success) {
        const errorMsg = smsData?.error || smsData?.hint || smsError?.message || 'SMS delivery failed';
        console.warn('⚠️ SMS failed:', errorMsg);
        fallbackChain[0].status = 'failed';
        fallbackChain[0].error = errorMsg;
        fallbackChain[0].code = smsData?.code;
        lastError = errorMsg;
      } else if (smsData?.success) {
        console.log('✅ SMS delivered successfully');
        fallbackChain[0].status = 'success';
        return {
          data: {
            success: true,
            deliveryMethod: 'sms',attemptId: smsData?.attemptId,expiresAt: smsData?.expiresAt,phoneNumber: smsData?.phoneNumber,fallbackChain,message: 'Verification code sent via SMS'
          },
          error: null
        };
      }
    } catch (error) {
      console.error('❌ SMS exception:', error);
      fallbackChain[0].status = 'failed';
      fallbackChain[0].error = error?.message;
      lastError = error?.message;
    }

    // Step 2: Try Email (Secondary) - only if email provided
    if (email) {
      try {
        console.log('📧 SMS failed, attempting Email delivery...');
        fallbackChain?.push({ method: 'email', status: 'attempting' });

        const { data: emailData, error: emailError } = await supabase?.functions?.invoke('send-email-otp', {
          body: {
            email,
            phoneNumber: phoneNumber?.replace(/\D/g, ''),
            countryCode: countryCode
          }
        });

        if (emailError || !emailData?.success) {
          const errorMsg = emailData?.error || emailData?.hint || emailError?.message || 'Email delivery failed';
          console.warn('⚠️ Email failed:', errorMsg);
          fallbackChain[1].status = 'failed';
          fallbackChain[1].error = errorMsg;
          fallbackChain[1].code = emailData?.code;
          lastError = errorMsg;
        } else if (emailData?.success) {
          console.log('✅ Email delivered successfully');
          fallbackChain[1].status = 'success';
          return {
            data: {
              success: true,
              deliveryMethod: 'email',
              attemptId: emailData?.attemptId,
              expiresAt: emailData?.expiresAt,
              phoneNumber: emailData?.phoneNumber,
              fallbackChain,
              fallbackUsed: true,
              message: 'SMS unavailable. Verification code sent to your email'
            },
            error: null
          };
        }
      } catch (error) {
        console.error('❌ Email exception:', error);
        fallbackChain[1].status = 'failed';
        fallbackChain[1].error = error?.message;
        lastError = error?.message;
      }
    } else {
      console.log('⏭️ Skipping email fallback (no email provided)');
      fallbackChain?.push({ method: 'email', status: 'skipped', reason: 'No email provided' });
    }

    // Step 3: Try Voice Call (Tertiary)
    try {
      console.log('📞 Email failed, attempting Voice call delivery...');
      fallbackChain?.push({ method: 'voice', status: 'attempting' });

      const { data: voiceData, error: voiceError } = await supabase?.functions?.invoke('send-voice-otp', {
        body: {
          phoneNumber: phoneNumber?.replace(/\D/g, ''),
          countryCode: countryCode
        }
      });

      if (voiceError || !voiceData?.success) {
        const errorMsg = voiceData?.error || voiceData?.hint || voiceError?.message || 'Voice call failed';
        console.error('❌ Voice call failed:', errorMsg);
        fallbackChain[fallbackChain.length - 1].status = 'failed';
        fallbackChain[fallbackChain.length - 1].error = errorMsg;
        fallbackChain[fallbackChain.length - 1].code = voiceData?.code;
        lastError = errorMsg;
      } else if (voiceData?.success) {
        console.log('✅ Voice call initiated successfully');
        fallbackChain[fallbackChain.length - 1].status = 'success';
        return {
          data: {
            success: true,
            deliveryMethod: 'voice',
            attemptId: voiceData?.attemptId,
            expiresAt: voiceData?.expiresAt,
            phoneNumber: voiceData?.phoneNumber,
            callSid: voiceData?.callSid,
            fallbackChain,
            fallbackUsed: true,
            message: 'SMS and Email unavailable. Calling you with verification code'
          },
          error: null
        };
      }
    } catch (error) {
      console.error('❌ Voice call exception:', error);
      fallbackChain[fallbackChain.length - 1].status = 'failed';
      fallbackChain[fallbackChain.length - 1].error = error?.message;
      lastError = error?.message;
    }

    // All methods failed
    console.error('❌ All authentication methods failed');
    return {
      data: null,
      error: {
        message: 'Unable to send verification code',
        code: 'ALL_METHODS_FAILED',
        hint: 'All delivery methods failed. Please contact support or try QR Code authentication',
        fallbackChain,
        lastError
      }
    };
  },

  /**
   * Verify OTP code (works for any delivery method)
   * @param {string} phoneNumber - Phone number without country code
   * @param {string} countryCode - Country code
   * @param {string} otpCode - 6-digit OTP code
   * @returns {Promise<Object>} Verification result
   */
  async verifyOTP(phoneNumber, countryCode, otpCode) {
    try {
      console.log('🔐 Verifying OTP');

      if (!phoneNumber || !countryCode || !otpCode) {
        return {
          data: null,
          error: {
            message: 'Phone number, country code, and OTP are required',
            code: 'INVALID_INPUT'
          }
        };
      }

      const cleanPhone = phoneNumber?.replace(/\D/g, '');
      const cleanCode = countryCode?.replace(/\D/g, '');
      const e164Phone = `+${cleanCode}${cleanPhone}`;

      console.log(`🔍 Verifying for: ${e164Phone}`);

      // Query the database for the OTP
      const { data: attempts, error: queryError } = await supabase?.from('phone_verification_attempts')?.select('*')?.eq('phone_number', e164Phone)?.eq('otp_code', otpCode)?.eq('is_verified', false)?.gte('expires_at', new Date()?.toISOString())?.order('created_at', { ascending: false })?.limit(1);

      if (queryError) {
        console.error('❌ Query error:', queryError);
        return {
          data: null,
          error: {
            message: 'Failed to verify code',
            code: 'QUERY_ERROR'
          }
        };
      }

      if (!attempts || attempts?.length === 0) {
        return {
          data: null,
          error: {
            message: 'Invalid or expired verification code',
            code: 'INVALID_OTP'
          }
        };
      }

      const attempt = attempts?.[0];

      if (attempt?.attempts_count >= 5) {
        return {
          data: null,
          error: {
            message: 'Too many failed attempts. Please request a new code.',
            code: 'MAX_ATTEMPTS_EXCEEDED'
          }
        };
      }

      // Mark as verified
      const { error: updateError } = await supabase?.from('phone_verification_attempts')?.update({
          is_verified: true,
          verified_at: new Date()?.toISOString()
        })?.eq('id', attempt?.id);

      if (updateError) {
        console.error('❌ Update error:', updateError);
        return {
          data: null,
          error: {
            message: 'Failed to verify code',
            code: 'UPDATE_ERROR'
          }
        };
      }

      console.log('✅ OTP verified successfully');

      // Check if user exists
      const { data: existingUser } = await supabase?.from('user_profiles')?.select('user_id')?.eq('phone_number', e164Phone)?.single();

      return {
        data: {
          verified: true,
          phoneNumber: e164Phone,
          userExists: !!existingUser,
          userId: existingUser?.user_id || null,
          deliveryMethod: attempt?.delivery_method || 'sms'
        },
        error: null
      };
    } catch (error) {
      console.error('❌ Verification error:', error);
      return {
        data: null,
        error: {
          message: 'An unexpected error occurred',
          code: 'UNKNOWN_ERROR'
        }
      };
    }
  },

  /**
   * Sign in with phone after OTP verification
   * @param {string} phoneNumber - Verified phone number in E.164 format
   * @returns {Promise<Object>} Auth result
   */
  async signInWithPhone(phoneNumber) {
    try {
      console.log('🔑 Signing in with phone:', phoneNumber);

      // Check if user exists
      const { data: profile } = await supabase?.from('user_profiles')?.select('user_id')?.eq('phone_number', phoneNumber)?.single();

      if (profile) {
        console.log('✅ User exists, signing in');
        
        const { data: authData, error: authError } = await supabase?.auth?.signInWithOtp({
          phone: phoneNumber
        });

        if (authError) {
          console.error('❌ Auth error:', authError);
          return {
            data: null,
            error: {
              message: 'Failed to sign in',
              code: 'AUTH_ERROR'
            }
          };
        }

        return {
          data: {
            user: authData?.user,
            session: authData?.session
          },
          error: null
        };
      } else {
        console.log('❌ User does not exist');
        return {
          data: null,
          error: {
            message: 'User not found',
            code: 'USER_NOT_FOUND'
          }
        };
      }
    } catch (error) {
      console.error('❌ Sign in error:', error);
      return {
        data: null,
        error: {
          message: 'An unexpected error occurred',
          code: 'UNKNOWN_ERROR'
        }
      };
    }
  }
};

export default fallbackAuthService;