import { supabase } from '../lib/supabase';

export const mentionService = {
  // Extract mentions from message text and create mention records
  async createMentions(messageId, messageText) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      // Extract mentioned user IDs using database function
      const { data: mentionedIds, error: extractError } = await supabase?.rpc('extract_mentions', { message_text: messageText });

      if (extractError) throw extractError;

      if (!mentionedIds || mentionedIds?.length === 0) {
        return [];
      }

      // Create mention records
      const mentions = mentionedIds?.map(userId => ({
        message_id: messageId,
        mentioned_user_id: userId,
        mentioner_id: user?.id
      }));

      const { data, error } = await supabase?.from('message_mentions')?.insert(mentions)?.select();

      if (error) throw error;

      return data?.map(item => ({
        id: item?.id,
        messageId: item?.message_id,
        mentionedUserId: item?.mentioned_user_id,
        mentionerId: item?.mentioner_id,
        isRead: item?.is_read,
        notifiedAt: item?.notified_at,
        createdAt: item?.created_at
      })) || [];
    } catch (error) {
      console.error('Error creating mentions:', error);
      throw error;
    }
  },

  // Get mentions for current user
  async getMentionsForUser() {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data, error } = await supabase?.from('message_mentions')?.select(`
          *,
          message:chat_messages!message_mentions_message_id_fkey(
            id,
            message,
            sender_name,
            created_at,
            sender:profiles!chat_messages_sender_id_fkey(id, full_name, avatar_url)
          ),
          mentioner:profiles!message_mentions_mentioner_id_fkey(id, full_name, avatar_url)
        `)?.eq('mentioned_user_id', user?.id)?.order('created_at', { ascending: false });

      if (error) throw error;

      return data?.map(item => ({
        id: item?.id,
        messageId: item?.message_id,
        message: {
          id: item?.message?.id,
          message: item?.message?.message,
          senderName: item?.message?.sender_name,
          createdAt: item?.message?.created_at,
          sender: {
            id: item?.message?.sender?.id,
            fullName: item?.message?.sender?.full_name,
            avatarUrl: item?.message?.sender?.avatar_url
          }
        },
        mentionedUserId: item?.mentioned_user_id,
        mentioner: {
          id: item?.mentioner?.id,
          fullName: item?.mentioner?.full_name,
          avatarUrl: item?.mentioner?.avatar_url
        },
        isRead: item?.is_read,
        notifiedAt: item?.notified_at,
        createdAt: item?.created_at
      })) || [];
    } catch (error) {
      console.error('Error fetching mentions:', error);
      throw error;
    }
  },

  // Get unread mention count
  async getUnreadCount() {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      const { count, error } = await supabase?.from('message_mentions')?.select('*', { count: 'exact', head: true })?.eq('mentioned_user_id', user?.id)?.eq('is_read', false);

      if (error) throw error;
      return count || 0;
    } catch (error) {
      console.error('Error fetching unread mention count:', error);
      throw error;
    }
  },

  // Mark mention as read
  async markAsRead(mentionId) {
    try {
      const { error } = await supabase?.from('message_mentions')?.update({ is_read: true })?.eq('id', mentionId);

      if (error) throw error;
      return { success: true };
    } catch (error) {
      console.error('Error marking mention as read:', error);
      throw error;
    }
  },

  // Mark all mentions as read
  async markAllAsRead() {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      const { error } = await supabase?.from('message_mentions')?.update({ is_read: true })?.eq('mentioned_user_id', user?.id)?.eq('is_read', false);

      if (error) throw error;
      return { success: true };
    } catch (error) {
      console.error('Error marking all mentions as read:', error);
      throw error;
    }
  },

  // Search users for mention autocomplete
  async searchUsersForMention(searchQuery) {
    try {
      const { data, error } = await supabase?.from('profiles')?.select('id, full_name, email, avatar_url')?.or(`full_name.ilike.%${searchQuery}%,email.ilike.%${searchQuery}%`)?.limit(10);

      if (error) throw error;

      return data?.map(user => ({
        id: user?.id,
        fullName: user?.full_name,
        email: user?.email,
        avatarUrl: user?.avatar_url,
        displayName: user?.full_name || user?.email
      })) || [];
    } catch (error) {
      console.error('Error searching users for mention:', error);
      throw error;
    }
  },

  // Subscribe to mention changes
  subscribeToMentions(callback) {
    const channel = supabase?.channel('mentions_changes')?.on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'message_mentions'
        },
        (payload) => {
          callback(payload);
        }
      )?.subscribe();

    return () => {
      supabase?.removeChannel(channel);
    };
  }
};