import openai from '../lib/openai';
import {
  APIConnectionError,
  AuthenticationError,
  PermissionDeniedError,
  RateLimitError,
  InternalServerError
} from 'openai';

/**
 * Maps OpenAI API error types to user-friendly error messages.
 * @param {Error} error - The error object from OpenAI API.
 * @returns {Object} Error information with isInternal flag and message.
 */
function getErrorMessage(error) {
  if (error instanceof AuthenticationError) {
    return { isInternal: true, message: 'Invalid API key or authentication failed. Please check your OpenAI API key.' };
  } else if (error instanceof PermissionDeniedError) {
    return { isInternal: true, message: 'Quota exceeded or authorization failed. You may have exceeded your usage limits or do not have access to this resource.' };
  } else if (error instanceof RateLimitError) {
    return { isInternal: true, message: 'Rate limit exceeded. You are sending requests too quickly. Please wait a moment and try again.' };
  } else if (error instanceof InternalServerError) {
    return { isInternal: true, message: 'OpenAI service is currently unavailable. Please try again later.' };
  } else if (error instanceof APIConnectionError) {
    return { isInternal: true, message: 'Unable to connect to OpenAI service. Please check your API key and internet connection.' };
  } else {
    return { isInternal: false, message: error?.message || 'An unexpected error occurred. Please try again.' };
  }
}

/**
 * Analyzes message for grammar errors and provides corrections.
 * @param {string} messageText - The message text to analyze.
 * @returns {Promise<Object>} Grammar analysis with corrections.
 */
export async function analyzeGrammar(messageText) {
  try {
    const response = await openai?.chat?.completions?.create({
      model: 'gpt-5-mini',
      messages: [
        {
          role: 'system',
          content: 'You are a grammar expert. Analyze the text for grammar errors, spelling mistakes, and clarity issues. Provide specific corrections with explanations.'
        },
        {
          role: 'user',
          content: `Analyze this message for grammar and spelling errors: "${messageText}"`
        }
      ],
      response_format: {
        type: 'json_schema',
        json_schema: {
          name: 'grammar_analysis',
          schema: {
            type: 'object',
            properties: {
              hasErrors: { type: 'boolean', description: 'Whether errors were found' },
              corrections: {
                type: 'array',
                items: {
                  type: 'object',
                  properties: {
                    original: { type: 'string', description: 'Original text with error' },
                    corrected: { type: 'string', description: 'Corrected text' },
                    explanation: { type: 'string', description: 'Why this correction is needed' },
                    type: { type: 'string', enum: ['grammar', 'spelling', 'clarity', 'punctuation'], description: 'Type of error' }
                  },
                  required: ['original', 'corrected', 'explanation', 'type']
                }
              },
              correctedMessage: { type: 'string', description: 'Full corrected message' },
              confidenceScore: { type: 'number', description: 'Confidence in corrections (0-1)' }
            },
            required: ['hasErrors', 'corrections', 'correctedMessage', 'confidenceScore'],
            additionalProperties: false
          }
        }
      },
      reasoning_effort: 'minimal',
      verbosity: 'low'
    });

    return JSON.parse(response?.choices?.[0]?.message?.content);
  } catch (error) {
    const errorInfo = getErrorMessage(error);
    if (errorInfo?.isInternal) {
      console.log(errorInfo?.message);
    } else {
      console.error('Error analyzing grammar:', error);
    }
    throw new Error(errorInfo.message);
  }
}

/**
 * Optimizes message tone based on target style.
 * @param {string} messageText - The message text to optimize.
 * @param {string} targetTone - Target tone (professional, casual, friendly, formal).
 * @returns {Promise<Object>} Tone optimization results.
 */
export async function optimizeTone(messageText, targetTone = 'professional') {
  try {
    const toneDescriptions = {
      professional: 'professional and business-appropriate',
      casual: 'casual and relaxed',
      friendly: 'warm and friendly',
      formal: 'formal and respectful',
      enthusiastic: 'enthusiastic and energetic',
      neutral: 'neutral and balanced'
    };

    const response = await openai?.chat?.completions?.create({
      model: 'gpt-5-mini',
      messages: [
        {
          role: 'system',
          content: `You are a communication expert. Rewrite messages to match specific tones while preserving the core meaning. Provide alternative phrasings and explain tone adjustments.`
        },
        {
          role: 'user',
          content: `Rewrite this message to be ${toneDescriptions?.[targetTone] || toneDescriptions?.professional}: "${messageText}"`
        }
      ],
      response_format: {
        type: 'json_schema',
        json_schema: {
          name: 'tone_optimization',
          schema: {
            type: 'object',
            properties: {
              originalTone: { type: 'string', description: 'Detected tone of original message' },
              optimizedMessage: { type: 'string', description: 'Message rewritten with target tone' },
              alternatives: {
                type: 'array',
                items: {
                  type: 'object',
                  properties: {
                    text: { type: 'string', description: 'Alternative phrasing' },
                    toneStrength: { type: 'string', enum: ['subtle', 'moderate', 'strong'], description: 'How strongly the tone is applied' }
                  },
                  required: ['text', 'toneStrength']
                },
                minItems: 2,
                maxItems: 3
              },
              changes: {
                type: 'array',
                items: {
                  type: 'string',
                  description: 'Key changes made to achieve target tone'
                }
              },
              sentimentScore: { type: 'number', description: 'Sentiment score of optimized message (-1 to 1)' }
            },
            required: ['originalTone', 'optimizedMessage', 'alternatives', 'changes', 'sentimentScore'],
            additionalProperties: false
          }
        }
      },
      reasoning_effort: 'minimal',
      verbosity: 'low'
    });

    return JSON.parse(response?.choices?.[0]?.message?.content);
  } catch (error) {
    const errorInfo = getErrorMessage(error);
    if (errorInfo?.isInternal) {
      console.log(errorInfo?.message);
    } else {
      console.error('Error optimizing tone:', error);
    }
    throw new Error(errorInfo.message);
  }
}

/**
 * Performs comprehensive message enhancement (grammar + tone).
 * @param {string} messageText - The message text to enhance.
 * @param {string} targetTone - Target tone for optimization.
 * @returns {Promise<Object>} Complete enhancement analysis.
 */
export async function enhanceMessage(messageText, targetTone = 'professional') {
  try {
    const [grammarResult, toneResult] = await Promise.all([
      analyzeGrammar(messageText),
      optimizeTone(messageText, targetTone)
    ]);

    return {
      grammar: grammarResult,
      tone: toneResult,
      finalSuggestion: grammarResult?.hasErrors ? grammarResult?.correctedMessage : toneResult?.optimizedMessage
    };
  } catch (error) {
    throw error;
  }
}

export const grammarToneService = {
  analyzeGrammar,
  optimizeTone,
  enhanceMessage
};