import nacl from 'tweetnacl';
import util from 'tweetnacl-util';

const { encodeBase64, decodeBase64, encodeUTF8, decodeUTF8 } = util;

class EncryptionService {
  constructor() {
    this.keyPair = null;
    this.recipientPublicKeys = new Map();
  }

  // Generate a new key pair for the current user
  generateKeyPair() {
    this.keyPair = nacl?.box?.keyPair();
    return {
      publicKey: encodeBase64(this.keyPair?.publicKey),
      privateKey: encodeBase64(this.keyPair?.secretKey)
    };
  }

  // Load existing key pair from storage
  loadKeyPair(publicKey, privateKey) {
    try {
      this.keyPair = {
        publicKey: decodeBase64(publicKey),
        secretKey: decodeBase64(privateKey)
      };
      return true;
    } catch (error) {
      console.error('Error loading key pair:', error);
      return false;
    }
  }

  // Store recipient's public key
  addRecipientPublicKey(recipientId, publicKey) {
    try {
      this.recipientPublicKeys?.set(recipientId, decodeBase64(publicKey));
      return true;
    } catch (error) {
      console.error('Error adding recipient public key:', error);
      return false;
    }
  }

  // Encrypt a message for a specific recipient
  encryptMessage(message, recipientId) {
    if (!this.keyPair) {
      throw new Error('Key pair not initialized. Please generate or load keys first.');
    }

    const recipientPublicKey = this.recipientPublicKeys?.get(recipientId);
    if (!recipientPublicKey) {
      throw new Error(`Public key not found for recipient: ${recipientId}`);
    }

    try {
      // Generate a random nonce
      const nonce = nacl?.randomBytes(nacl?.box?.nonceLength);
      
      // Encode message to UTF-8
      const messageUint8 = encodeUTF8(message);
      
      // Encrypt the message
      const encrypted = nacl?.box(
        messageUint8,
        nonce,
        recipientPublicKey,
        this.keyPair?.secretKey
      );

      // Return encrypted message and nonce as base64
      return {
        encryptedMessage: encodeBase64(encrypted),
        nonce: encodeBase64(nonce)
      };
    } catch (error) {
      console.error('Encryption error:', error);
      throw new Error('Failed to encrypt message');
    }
  }

  // Decrypt a message from a specific sender
  decryptMessage(encryptedData, senderPublicKey) {
    if (!this.keyPair) {
      throw new Error('Key pair not initialized. Please generate or load keys first.');
    }

    try {
      // Decode base64 strings
      const encrypted = decodeBase64(encryptedData?.encryptedMessage);
      const nonce = decodeBase64(encryptedData?.nonce);
      const senderPublicKeyDecoded = decodeBase64(senderPublicKey);

      // Decrypt the message
      const decrypted = nacl?.box?.open(
        encrypted,
        nonce,
        senderPublicKeyDecoded,
        this.keyPair?.secretKey
      );

      if (!decrypted) {
        throw new Error('Decryption failed - message may be corrupted');
      }

      // Decode UTF-8 to string
      return decodeUTF8(decrypted);
    } catch (error) {
      console.error('Decryption error:', error);
      throw new Error('Failed to decrypt message');
    }
  }

  // Get current user's public key
  getPublicKey() {
    if (!this.keyPair) {
      return null;
    }
    return encodeBase64(this.keyPair?.publicKey);
  }

  // Clear all keys (for logout)
  clearKeys() {
    this.keyPair = null;
    this.recipientPublicKeys?.clear();
  }
}

// Export a singleton instance
export const encryptionService = new EncryptionService();