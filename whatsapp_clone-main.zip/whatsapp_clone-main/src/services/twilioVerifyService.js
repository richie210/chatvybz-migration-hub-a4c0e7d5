import { supabase } from '../lib/supabase';
import phoneValidationService from './phoneValidationService';

/**
 * Twilio Verify Service
 * Handles OTP verification using Twilio Verify API
 * Provides automatic fallback from SMS to voice call
 */

const twilioVerifyService = {
  /**
   * Send verification code via Twilio Verify
   * @param {string} phoneNumber - Phone number in E.164 format
   * @param {string} channel - 'sms' or 'call'
   * @returns {Promise<Object>} Verification result
   */
  async sendVerificationCode(phoneNumber, channel = 'sms') {
    try {
      // Validate phone number exists
      if (!phoneNumber || typeof phoneNumber !== 'string') {
        throw new Error('Phone number is required');
      }

      // Validate phone number format
      if (!phoneValidationService?.isE164Format(phoneNumber)) {
        throw new Error('Phone number must be in E.164 format (e.g., +596696972158)');
      }

      // Call Supabase Edge Function for Twilio Verify
      const { data, error } = await supabase?.functions?.invoke('twilio-verify-send', {
        body: {
          phoneNumber,
          channel // 'sms' or 'call'
        }
      });

      // When edge function returns non-2xx status, error object is populated
      // The actual error message is in the response body which we need to extract
      if (error) {
        console.error('Twilio Verify send error:', error);
        
        // The error response body is available in data even when error is present
        // This is because the edge function returns JSON with {error: "message"}
        let actualError = 'Failed to send verification code';
        
        // First check if data has the error message (most reliable)
        if (data?.error) {
          actualError = data?.error;
        }
        // Fallback to error message if data.error not available
        else if (error?.message && !error?.message?.includes('Edge Function returned a non-2xx')) {
          actualError = error?.message;
        }
        
        throw new Error(actualError);
      }

      // Check for error in response data (for 2xx responses with error field)
      if (data?.error) {
        console.error('Twilio Verify send error from edge function:', data?.error);
        throw new Error(data.error);
      }

      return {
        success: true,
        status: data?.status, // 'pending'
        channel: data?.channel,
        to: data?.to,
        valid: data?.valid,
        message: `Verification code sent via ${channel}`,
        fallbackAvailable: channel === 'sms' // Can fallback to call if SMS fails
      };
    } catch (error) {
      console.error('Send verification code error:', error);
      throw error;
    }
  },

  /**
   * Verify OTP code via Twilio Verify
   * @param {string} phoneNumber - Phone number in E.164 format
   * @param {string} code - Verification code
   * @returns {Promise<Object>} Verification result
   */
  async verifyCode(phoneNumber, code) {
    try {
      // Validate phone number format
      if (!phoneValidationService?.isE164Format(phoneNumber)) {
        throw new Error('Phone number must be in E.164 format');
      }

      // Validate code format (6 digits)
      if (!/^\d{6}$/?.test(code)) {
        throw new Error('Verification code must be 6 digits');
      }

      // Call Supabase Edge Function for Twilio Verify Check
      const { data, error } = await supabase?.functions?.invoke('twilio-verify-check', {
        body: {
          phoneNumber,
          code
        }
      });

      if (error) {
        console.error('Twilio Verify check error:', error);
        throw new Error(error.message || 'Failed to verify code');
      }

      if (data?.error) {
        throw new Error(data.error);
      }

      // Check verification status
      if (data?.status !== 'approved') {
        throw new Error('Invalid or expired verification code');
      }

      return {
        success: true,
        status: data?.status, // 'approved'
        valid: data?.valid,
        to: data?.to,
        message: 'Phone number verified successfully'
      };
    } catch (error) {
      console.error('Verify code error:', error);
      throw error;
    }
  },

  /**
   * Send verification with automatic fallback
   * Tries SMS first, then voice call if SMS fails
   * @param {string} phoneNumber - Phone number in E.164 format
   * @returns {Promise<Object>} Verification result
   */
  async sendWithFallback(phoneNumber) {
    try {
      // Try SMS first
      try {
        const result = await this.sendVerificationCode(phoneNumber, 'sms');
        return result;
      } catch (smsError) {
        console.warn('SMS verification failed, trying voice call:', smsError);
        
        // Check if error is due to missing credentials
        if (smsError?.message?.includes('credentials not configured') || 
            smsError?.message?.includes('Twilio Verify credentials')) {
          throw smsError; // Don't try fallback if credentials are missing
        }
        
        // Fallback to voice call
        try {
          const result = await this.sendVerificationCode(phoneNumber, 'call');
          return {
            ...result,
            fallbackUsed: true,
            fallbackReason: 'SMS delivery failed'
          };
        } catch (callError) {
          console.error('Voice call verification also failed:', callError);
          // Throw the more specific error
          throw callError;
        }
      }
    } catch (error) {
      console.error('Send with fallback error:', error);
      
      // Provide more specific error messages
      if (error?.message?.includes('credentials not configured')) {
        throw new Error('Twilio Verify service is not configured. Please contact support.');
      } else if (error?.message?.includes('Rate limit')) {
        throw new Error(error.message);
      } else if (error?.message?.includes('E.164 format')) {
        throw new Error('Invalid phone number format. Please include country code (e.g., +1234567890)');
      } else if (error?.message) {
        throw error; // Preserve specific error message
      } else {
        throw new Error('Failed to send verification code. Please try again later.');
      }
    }
  },

  /**
   * Check rate limit for phone number
   * @param {string} phoneNumber - Phone number in E.164 format
   * @returns {Promise<Object>} Rate limit status
   */
  async checkRateLimit(phoneNumber) {
    try {
      const countryCode = phoneValidationService?.extractCountryCode(phoneNumber);
      
      const { data, error } = await supabase?.rpc('check_phone_rate_limit', {
        p_phone_number: phoneNumber,
        p_country_code: countryCode
      });

      if (error) throw error;

      return {
        allowed: data?.allowed || false,
        requestsRemaining: data?.requests_remaining || 0,
        resetAt: data?.reset_at,
        message: data?.message
      };
    } catch (error) {
      console.error('Rate limit check error:', error);
      throw error;
    }
  },

  /**
   * Resend verification code
   * @param {string} phoneNumber - Phone number in E.164 format
   * @param {string} preferredChannel - 'sms' or 'call'
   * @returns {Promise<Object>} Verification result
   */
  async resendCode(phoneNumber, preferredChannel = 'sms') {
    try {
      // Check rate limit first
      const rateLimit = await this.checkRateLimit(phoneNumber);
      
      if (!rateLimit?.allowed) {
        throw new Error(rateLimit.message || 'Rate limit exceeded. Please try again later.');
      }

      // Send new code
      return await this.sendVerificationCode(phoneNumber, preferredChannel);
    } catch (error) {
      console.error('Resend code error:', error);
      throw error;
    }
  }
};

export default twilioVerifyService;
