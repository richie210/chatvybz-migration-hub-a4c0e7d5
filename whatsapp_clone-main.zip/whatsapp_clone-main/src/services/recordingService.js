import { supabase } from '../lib/supabase';

/**
 * Recording Service
 * Handles call/meeting recording operations including uploads, AI processing, and sharing
 */

/**
 * Maps status codes to user-friendly error messages
 * @param {number} statusCode - HTTP status code
 * @param {Object} errorData - Error data from response
 * @returns {Object} Object with isInternal flag and error message
 */
function getErrorMessage(statusCode, errorData) {
  if (statusCode === 401) {
    return { isInternal: true, message: 'Authentication required. Please sign in to continue.' };
  } else if (statusCode === 403) {
    return { isInternal: true, message: 'You do not have permission to access this recording.' };
  } else if (statusCode === 404) {
    return { isInternal: true, message: 'Recording not found.' };
  } else {
    return { isInternal: false, message: errorData?.message || 'An error occurred with the recording operation.' };
  }
}

/**
 * Uploads a recording file to Supabase storage
 * @param {File} file - Recording file to upload
 * @param {string} type - Recording type (call/meeting/conference)
 * @param {string} relatedId - ID of related call or meeting
 * @returns {Promise<Object>} Upload result with file URL
 */
export const uploadRecording = async (file, type, relatedId) => {
  try {
    const { data: { user } } = await supabase?.auth?.getUser();
    if (!user) {
      const error = new Error('User not authenticated');
      error.statusCode = 401;
      throw error;
    }

    // Generate unique filename
    const fileExt = file?.name?.split('.')?.pop();
    const fileName = `${relatedId}_${Date.now()}.${fileExt}`;
    const filePath = `${user?.id}/${fileName}`;

    // Upload to storage
    const { data: uploadData, error: uploadError } = await supabase?.storage?.from('call-recordings')?.upload(filePath, file, {
        cacheControl: '3600',
        upsert: false
      });

    if (uploadError) {
      console.error('Storage upload error:', uploadError);
      throw uploadError;
    }

    // Get signed URL (valid for 1 year)
    const { data: urlData } = await supabase?.storage?.from('call-recordings')?.createSignedUrl(filePath, 31536000);

    // Create recording record
    const recordingData = {
      file_url: urlData?.signedUrl || filePath,
      file_size: file?.size,
      recording_type: type,
      uploaded_by: user?.id,
      is_processing: true
    };

    if (type === 'call') {
      recordingData.call_id = relatedId;
    } else {
      recordingData.meeting_id = relatedId;
    }

    const { data, error } = await supabase?.from('meeting_recordings')?.insert([recordingData])?.select()?.single();

    if (error) {
      console.error('Database insert error:', error);
      throw error;
    }

    return { success: true, recording: data };
  } catch (error) {
    const errorInfo = getErrorMessage(error?.statusCode || 500, error);
    const err = new Error(errorInfo.message);
    err.statusCode = error?.statusCode || 500;
    
    if (!errorInfo?.isInternal) {
      console.error('Upload recording error:', err);
    }
    throw err;
  }
};

/**
 * Gets all recordings for the current user
 * @param {Object} filters - Optional filters (type, dateRange)
 * @returns {Promise<Array>} List of recordings
 */
export const getRecordings = async (filters = {}) => {
  try {
    const { data: { user } } = await supabase?.auth?.getUser();
    if (!user) {
      const error = new Error('User not authenticated');
      error.statusCode = 401;
      throw error;
    }

    let query = supabase?.from('meeting_recordings')?.select(`
        *,
        meetings!meeting_recordings_meeting_id_fkey (
          id,
          title,
          host_id
        ),
        calls!meeting_recordings_call_id_fkey (
          id,
          call_type,
          initiator_id,
          recipient_id
        ),
        profiles!meeting_recordings_uploaded_by_fkey (
          id,
          full_name,
          avatar_url
        )
      `)?.order('created_at', { ascending: false });

    // Apply filters
    if (filters?.type) {
      query = query?.eq('recording_type', filters?.type);
    }

    if (filters?.dateRange) {
      const { start, end } = filters?.dateRange;
      if (start) query = query?.gte('created_at', start);
      if (end) query = query?.lte('created_at', end);
    }

    const { data, error } = await query;

    if (error) {
      console.error('Fetch recordings error:', error);
      throw error;
    }

    return data || [];
  } catch (error) {
    const errorInfo = getErrorMessage(error?.statusCode || 500, error);
    const err = new Error(errorInfo.message);
    err.statusCode = error?.statusCode || 500;
    
    if (!errorInfo?.isInternal) {
      console.error('Get recordings error:', err);
    }
    throw err;
  }
};

/**
 * Gets a specific recording by ID
 * @param {string} recordingId - Recording UUID
 * @returns {Promise<Object>} Recording details
 */
export const getRecordingById = async (recordingId) => {
  try {
    const { data, error } = await supabase?.from('meeting_recordings')?.select(`
        *,
        meetings!meeting_recordings_meeting_id_fkey (
          id,
          title,
          host_id,
          scheduled_time
        ),
        calls!meeting_recordings_call_id_fkey (
          id,
          call_type,
          initiator_id,
          recipient_id,
          started_at
        ),
        profiles!meeting_recordings_uploaded_by_fkey (
          id,
          full_name,
          avatar_url,
          email
        ),
        recording_shares!recording_shares_recording_id_fkey (
          id,
          shared_with_id,
          permission,
          expires_at,
          profiles!recording_shares_shared_with_id_fkey (
            id,
            full_name,
            email,
            avatar_url
          )
        )
      `)?.eq('id', recordingId)?.single();

    if (error) {
      console.error('Fetch recording error:', error);
      throw error;
    }

    return data;
  } catch (error) {
    const errorInfo = getErrorMessage(error?.statusCode || 500, error);
    const err = new Error(errorInfo.message);
    err.statusCode = error?.statusCode || 500;
    
    if (!errorInfo?.isInternal) {
      console.error('Get recording by ID error:', err);
    }
    throw err;
  }
};

/**
 * Shares a recording with another user
 * @param {string} recordingId - Recording UUID
 * @param {string} userId - User ID to share with
 * @param {string} permission - Permission level (view/download/full_access)
 * @param {Date} expiresAt - Optional expiration date
 * @returns {Promise<Object>} Share result
 */
export const shareRecording = async (recordingId, userId, permission = 'view', expiresAt = null) => {
  try {
    const { data: { user } } = await supabase?.auth?.getUser();
    if (!user) {
      const error = new Error('User not authenticated');
      error.statusCode = 401;
      throw error;
    }

    const { data, error } = await supabase?.from('recording_shares')?.insert([{
        recording_id: recordingId,
        shared_with_id: userId,
        shared_by_id: user?.id,
        permission,
        expires_at: expiresAt
      }])?.select()?.single();

    if (error) {
      console.error('Share recording error:', error);
      throw error;
    }

    return { success: true, share: data };
  } catch (error) {
    const errorInfo = getErrorMessage(error?.statusCode || 500, error);
    const err = new Error(errorInfo.message);
    err.statusCode = error?.statusCode || 500;
    
    if (!errorInfo?.isInternal) {
      console.error('Share recording error:', err);
    }
    throw err;
  }
};

/**
 * Revokes sharing access for a recording
 * @param {string} shareId - Share UUID
 * @returns {Promise<Object>} Revoke result
 */
export const revokeRecordingShare = async (shareId) => {
  try {
    const { error } = await supabase?.from('recording_shares')?.delete()?.eq('id', shareId);

    if (error) {
      console.error('Revoke share error:', error);
      throw error;
    }

    return { success: true };
  } catch (error) {
    const errorInfo = getErrorMessage(error?.statusCode || 500, error);
    const err = new Error(errorInfo.message);
    err.statusCode = error?.statusCode || 500;
    
    if (!errorInfo?.isInternal) {
      console.error('Revoke recording share error:', err);
    }
    throw err;
  }
};

/**
 * Deletes a recording
 * @param {string} recordingId - Recording UUID
 * @returns {Promise<Object>} Delete result
 */
export const deleteRecording = async (recordingId) => {
  try {
    // Get recording to delete file from storage
    const recording = await getRecordingById(recordingId);
    
    if (recording?.file_url) {
      // Extract file path from signed URL or direct path
      const filePath = recording?.file_url?.includes('call-recordings/') 
        ? recording?.file_url?.split('call-recordings/')?.[1]?.split('?')?.[0]
        : null;

      if (filePath) {
        const { error: storageError } = await supabase?.storage?.from('call-recordings')?.remove([filePath]);

        if (storageError) {
          console.error('Storage delete error:', storageError);
        }
      }
    }

    // Delete recording record
    const { error } = await supabase?.from('meeting_recordings')?.delete()?.eq('id', recordingId);

    if (error) {
      console.error('Delete recording error:', error);
      throw error;
    }

    return { success: true };
  } catch (error) {
    const errorInfo = getErrorMessage(error?.statusCode || 500, error);
    const err = new Error(errorInfo.message);
    err.statusCode = error?.statusCode || 500;
    
    if (!errorInfo?.isInternal) {
      console.error('Delete recording error:', err);
    }
    throw err;
  }
};

/**
 * Updates recording publicity setting
 * @param {string} recordingId - Recording UUID
 * @param {boolean} isPublic - Public visibility flag
 * @returns {Promise<Object>} Update result
 */
export const updateRecordingVisibility = async (recordingId, isPublic) => {
  try {
    const { data, error } = await supabase?.from('meeting_recordings')?.update({ is_public: isPublic })?.eq('id', recordingId)?.select()?.single();

    if (error) {
      console.error('Update visibility error:', error);
      throw error;
    }

    return { success: true, recording: data };
  } catch (error) {
    const errorInfo = getErrorMessage(error?.statusCode || 500, error);
    const err = new Error(errorInfo.message);
    err.statusCode = error?.statusCode || 500;
    
    if (!errorInfo?.isInternal) {
      console.error('Update recording visibility error:', err);
    }
    throw err;
  }
};