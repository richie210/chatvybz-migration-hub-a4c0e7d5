import { supabase } from '../lib/supabase';

/**
 * Custom OTP Authentication Service
 * Replaces Twilio with secure CSPRNG-based OTP generation
 * Implements hashed storage, rate limiting, and WhatsApp Business API delivery
 */

/**
 * Validates phone number in E.164 format
 * @param {string} countryCode - Country calling code (e.g., '+1')
 * @param {string} phoneNumber - Local phone number
 * @returns {Object} - Validation result with isValid and formattedPhone
 */
const validatePhoneE164 = (countryCode, phoneNumber) => {
  try {
    // Remove all non-digit characters
    const cleanPhone = phoneNumber?.replace(/\D/g, '');
    const cleanCode = countryCode?.replace(/\D/g, '');
    
    // Basic validation
    if (!cleanPhone || cleanPhone?.length < 7 || cleanPhone?.length > 15) {
      return {
        isValid: false,
        error: 'Phone number must be between 7 and 15 digits'
      };
    }
    
    // Format to E.164: +{country_code}{phone_number}
    const formattedPhone = `+${cleanCode}${cleanPhone}`;
    
    return {
      isValid: true,
      formattedPhone,
      countryCode: `+${cleanCode}`,
      localNumber: cleanPhone
    };
  } catch (error) {
    return {
      isValid: false,
      error: 'Invalid phone number format'
    };
  }
};

/**
 * Checks rate limit for phone number
 * @param {string} phoneNumber - Phone number in E.164 format
 * @param {string} countryCode - Country code
 * @returns {Promise<Object>} - Rate limit status
 */
const checkPhoneRateLimit = async (phoneNumber, countryCode) => {
  try {
    const { data, error } = await supabase?.rpc('check_phone_rate_limit', {
      p_phone_number: phoneNumber,
      p_country_code: countryCode
    });
    
    if (error) throw error;
    
    return {
      allowed: data?.allowed || false,
      requestsRemaining: data?.requests_remaining || 0,
      resetAt: data?.reset_at,
      message: data?.message
    };
  } catch (error) {
    console.error('Rate limit check error:', error);
    throw new Error(error?.message || 'Failed to check rate limit');
  }
};

/**
 * Sends OTP to phone number via custom OTP system (WhatsApp Business API with SMS fallback)
 * @param {string} phoneNumber - Phone number in E.164 format
 * @param {string} countryCode - Country code
 * @returns {Promise<Object>} - Result with attemptId and userExists flag
 */
const sendPhoneOTP = async (phoneNumber, countryCode) => {
  try {
    console.log('📞 sendPhoneOTP called with:', { phoneNumber, countryCode });

    // Defensive null checks
    if (!phoneNumber || typeof phoneNumber !== 'string') {
      throw new Error('Phone number is required and must be a string');
    }

    if (!countryCode || typeof countryCode !== 'string') {
      throw new Error('Country code is required and must be a string');
    }

    // Validate phone number with error handling
    let validation;
    try {
      validation = validatePhoneE164(countryCode, phoneNumber);
      console.log('✅ Phone validation result:', validation);
    } catch (validationError) {
      console.error('❌ Phone validation error:', validationError);
      throw new Error('Failed to validate phone number format');
    }

    if (!validation?.isValid) {
      throw new Error(validation?.error || 'Invalid phone number format');
    }

    // Check if user exists with this phone number
    let existingUser = null;
    try {
      const { data: userData, error: userError } = await supabase
        ?.from('profiles')
        ?.select('id, phone')
        ?.eq('phone', validation?.formattedPhone)
        ?.eq('country_code', validation?.countryCode)
        ?.single();

      if (!userError) {
        existingUser = userData;
      }
      console.log('👤 User exists check:', !!existingUser);
    } catch (userCheckError) {
      console.warn('⚠️ User check error (non-critical):', userCheckError);
      // Continue even if user check fails
    }

    // Call custom OTP generation Edge Function
    console.log('📤 Calling custom-otp-generate edge function...');

    try {
      const supabaseUrl = supabase?.supabaseUrl;
      const supabaseKey = supabase?.supabaseKey;
      
      if (!supabaseUrl || !supabaseKey) {
        throw new Error('Supabase client not properly configured');
      }
      
      const edgeFunctionUrl = `${supabaseUrl}/functions/v1/custom-otp-generate`;
      
      const fetchResponse = await fetch(edgeFunctionUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${supabaseKey}`,
        },
        body: JSON.stringify({
          phoneNumber: validation?.localNumber,
          countryCode: validation?.countryCode,
          ipAddress: null, // Can be captured from request if needed
          userAgent: navigator?.userAgent || null,
        }),
      });

      const responseData = await fetchResponse?.json();
      
      console.log('📥 Edge function raw response:', { 
        status: fetchResponse?.status,
        ok: fetchResponse?.ok,
        data: responseData
      });
      
      // Handle rate limit errors (429)
      if (fetchResponse?.status === 429) {
        const errorMessage = responseData?.error || 'Rate limit exceeded';
        const resetAt = responseData?.resetAt;
        
        console.error('❌ Rate limit exceeded:', { errorMessage, resetAt });
        
        // Return structured error instead of throwing
        return {
          data: null,
          error: {
            message: errorMessage,
            code: 'RATE_LIMIT_EXCEEDED',
            resetAt: resetAt,
            requestsRemaining: 0
          }
        };
      }
      
      // Handle non-2xx responses
      if (!fetchResponse?.ok) {
        const errorMessage = responseData?.error || 'Failed to send OTP';
        console.error('❌ Edge function error:', errorMessage);
        
        return {
          data: null,
          error: {
            message: errorMessage,
            code: 'OTP_SEND_FAILED'
          }
        };
      }
      
      const data = responseData;

      // Verify success response
      if (!data || !data?.success) {
        console.error('❌ Edge function did not return success:', data);
        return {
          data: null,
          error: {
            message: 'Failed to send OTP. Please try again.',
            code: 'OTP_SEND_FAILED'
          }
        };
      }

      console.log('✅ OTP sent successfully:', data);

      return {
        data: {
          success: true,
          attemptId: data?.attemptId,
          message: data?.message || 'OTP sent successfully to your phone via WhatsApp',
          expiresAt: data?.expiresAt,
          phoneNumber: validation?.formattedPhone,
          userExists: !!existingUser,
          requestsRemaining: data?.requestsRemaining,
          // TESTING ONLY: Remove in production
          testOTP: data?.testOTP, // For testing without WhatsApp integration
        },
        error: null
      };
    } catch (invokeError) {
      console.error('❌ Edge function invocation error:', invokeError);
      return {
        data: null,
        error: {
          message: invokeError?.message || 'Failed to send OTP',
          code: 'NETWORK_ERROR'
        }
      };
    }
  } catch (error) {
    console.error('❌ Send OTP error:', error);
    console.error('❌ Error stack:', error?.stack);
    return {
      data: null,
      error: {
        message: error?.message || 'An unexpected error occurred',
        code: 'UNKNOWN_ERROR'
      }
    };
  }
};

/**
 * Verifies OTP code using custom OTP system
 * @param {string} phoneNumber - Phone number in E.164 format
 * @param {string} countryCode - Country code
 * @param {string} otpCode - OTP code to verify
 * @returns {Promise<Object>} - Verification result
 */
const verifyPhoneOTP = async (phoneNumber, countryCode, otpCode) => {
  try {
    console.log('🔍 verifyPhoneOTP called with:', { phoneNumber, countryCode, otpCode });

    // Validate phone number
    let validation = validatePhoneE164(countryCode, phoneNumber);
    if (!validation?.isValid) {
      throw new Error(validation.error);
    }

    // Validate OTP format
    if (!/^\d{6}$/?.test(otpCode)) {
      throw new Error('OTP code must be 6 digits');
    }

    // Call custom OTP verification Edge Function
    console.log('📤 Calling custom-otp-verify edge function...');

    const supabaseUrl = supabase?.supabaseUrl;
    const supabaseKey = supabase?.supabaseKey;
    
    if (!supabaseUrl || !supabaseKey) {
      throw new Error('Supabase client not properly configured');
    }
    
    const edgeFunctionUrl = `${supabaseUrl}/functions/v1/custom-otp-verify`;
    
    const fetchResponse = await fetch(edgeFunctionUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${supabaseKey}`,
      },
      body: JSON.stringify({
        phoneNumber: validation?.localNumber,
        countryCode: validation?.countryCode,
        otpCode: otpCode?.toString(),
      }),
    });

    const responseData = await fetchResponse?.json();
    
    console.log('📥 Verify response:', { 
      status: fetchResponse?.status,
      ok: fetchResponse?.ok,
      data: responseData
    });

    // Handle non-2xx responses
    if (!fetchResponse?.ok) {
      const errorMessage = responseData?.error || 'Invalid OTP code';
      const errorCode = responseData?.code || 'VERIFICATION_FAILED';
      const attemptsRemaining = responseData?.attemptsRemaining;

      console.error('❌ Verification failed:', errorMessage);

      // Provide user-friendly error messages
      if (errorCode === 'OTP_NOT_FOUND') {
        throw new Error('No valid OTP found. Please request a new code.');
      } else if (errorCode === 'RATE_LIMIT_EXCEEDED') {
        throw new Error('Too many failed attempts. Please request a new code.');
      } else if (errorCode === 'ALREADY_USED') {
        throw new Error('This OTP has already been used. Please request a new code.');
      } else if (errorCode === 'INVALID_OTP' && attemptsRemaining !== undefined) {
        throw new Error(`Invalid OTP code. ${attemptsRemaining} attempts remaining.`);
      } else {
        throw new Error(errorMessage);
      }
    }

    const data = responseData;

    if (!data?.success) {
      throw new Error('Verification failed. Please try again.');
    }

    console.log('✅ OTP verified successfully');
    return data;
  } catch (error) {
    console.error('❌ verifyPhoneOTP error:', error);
    throw error;
  }
};

/**
 * Signs up user with phone number after OTP verification
 * @param {string} phoneNumber - Verified phone number
 * @param {string} countryCode - Country code
 * @param {string} fullName - User's full name
 * @param {Object} additionalData - Additional profile data
 * @returns {Promise<Object>} - Signup result
 */
const signUpWithPhone = async (phoneNumber, countryCode, fullName, additionalData = {}) => {
  try {
    // Validate phone number
    let validation = validatePhoneE164(countryCode, phoneNumber);
    if (!validation?.isValid) {
      throw new Error(validation.error);
    }
    
    // Sign up with Supabase Auth using phone
    const { data, error } = await supabase?.auth?.signUp({
      phone: validation?.formattedPhone,
      password: Math.random()?.toString(36)?.slice(-12), // Random password (not used for phone auth)
      options: {
        data: {
          full_name: fullName,
          phone: validation?.formattedPhone,
          country_code: validation?.countryCode,
          ...additionalData
        }
      }
    });
    
    if (error) throw error;
    
    return {
      success: true,
      user: data?.user,
      session: data?.session
    };
  } catch (error) {
    console.error('Phone signup error:', error);
    throw new Error(error?.message || 'Failed to sign up with phone number');
  }
};

/**
 * Signs in user with phone number and OTP
 * @param {string} phoneNumber - Phone number in E.164 format
 * @param {string} countryCode - Country code
 * @returns {Promise<Object>} - Signin result
 */
const signInWithPhone = async (phoneNumber, countryCode) => {
  try {
    // Validate phone number
    let validation = validatePhoneE164(countryCode, phoneNumber);
    if (!validation?.isValid) {
      throw new Error(validation.error);
    }
    
    // Check if user exists with this phone number
    const { data: profile, error: profileError } = await supabase
      ?.from('profiles')
      ?.select('id, phone, email')
      ?.eq('phone', validation?.formattedPhone)
      ?.eq('country_code', validation?.countryCode)
      ?.single();
    
    if (profileError || !profile) {
      throw new Error('No account found with this phone number. Please sign up first.');
    }
    
    // Sign in with phone using Supabase Auth
    const { data, error } = await supabase?.auth?.signInWithOtp({
      phone: validation?.formattedPhone
    });
    
    if (error) throw error;
    
    return {
      success: true,
      user: data?.user,
      session: data?.session
    };
  } catch (error) {
    console.error('Phone signin error:', error);
    throw new Error(error?.message || 'Failed to sign in with phone number');
  }
};

/**
 * Checks if user exists with phone number
 * @param {string} phoneNumber - Phone number in E.164 format
 * @returns {Promise<Object>} - User profile if exists
 */
const checkUserExists = async (phoneNumber) => {
  try {
    const { data: profile, error } = await supabase
      ?.from('profiles')
      ?.select('id, phone, email, full_name')
      ?.eq('phone', phoneNumber)
      ?.single();
    
    if (error && error?.code !== 'PGRST116') {
      throw error;
    }
    
    return { data: profile, error: null };
  } catch (error) {
    console.error('Check user exists error:', error);
    return { data: null, error };
  }
};

// Export as default object for consistent usage
const phoneAuthService = {
  validatePhoneE164,
  checkPhoneRateLimit,
  sendPhoneOTP,
  verifyPhoneOTP,
  signUpWithPhone,
  signInWithPhone,
  checkUserExists
};

export default phoneAuthService;