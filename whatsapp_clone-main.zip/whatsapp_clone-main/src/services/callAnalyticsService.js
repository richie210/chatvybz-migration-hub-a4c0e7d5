import { supabase } from '../lib/supabase';

export const callAnalyticsService = {
  /**
   * Get call volume metrics
   * @param {Object} dateRange - Start and end dates
   * @returns {Promise<Object>} Call volume data
   */
  async getCallVolumeMetrics(dateRange = {}) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      const { start, end } = dateRange;
      let query = supabase
        ?.from('calls')
        ?.select('id, call_type, call_status, created_at, started_at, ended_at, duration')
        ?.or(`initiator_id.eq.${user?.id},recipient_id.eq.${user?.id}`);

      if (start) query = query?.gte('created_at', start);
      if (end) query = query?.lte('created_at', end);

      const { data, error } = await query;
      if (error) throw error;

      // Calculate metrics
      const totalCalls = data?.length || 0;
      const completedCalls = data?.filter(c => c?.call_status === 'ended')?.length || 0;
      const missedCalls = data?.filter(c => c?.call_status === 'declined' || c?.call_status === 'missed')?.length || 0;
      const avgDuration = completedCalls > 0 
        ? data?.filter(c => c?.duration)?.reduce((sum, c) => sum + (c?.duration || 0), 0) / completedCalls 
        : 0;

      // Group by date for trend analysis
      const callsByDate = {};
      data?.forEach(call => {
        const date = new Date(call?.created_at)?.toISOString()?.split('T')?.[0];
        callsByDate[date] = (callsByDate?.[date] || 0) + 1;
      });

      const trendData = Object.entries(callsByDate)?.map(([date, count]) => ({
        date,
        count
      }))?.sort((a, b) => new Date(a?.date) - new Date(b?.date));

      return {
        totalCalls,
        completedCalls,
        missedCalls,
        avgDuration: Math.round(avgDuration),
        answerRate: totalCalls > 0 ? ((completedCalls / totalCalls) * 100)?.toFixed(1) : 0,
        trendData,
        callsByType: {
          voice: data?.filter(c => c?.call_type === 'voice')?.length || 0,
          video: data?.filter(c => c?.call_type === 'video')?.length || 0,
          conference: data?.filter(c => c?.call_type === 'conference')?.length || 0
        }
      };
    } catch (error) {
      console.error('Get call volume metrics error:', error);
      throw error;
    }
  },

  /**
   * Get participant engagement metrics
   * @param {Object} dateRange - Start and end dates
   * @returns {Promise<Object>} Engagement data
   */
  async getParticipantEngagement(dateRange = {}) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      const { start, end } = dateRange;
      let query = supabase
        ?.from('call_participants')
        ?.select(`
          *,
          call:calls!call_participants_call_id_fkey(
            id,
            call_type,
            created_at,
            initiator_id,
            recipient_id
          ),
          user:profiles!call_participants_user_id_fkey(
            id,
            full_name
          )
        `);

      if (start) query = query?.gte('joined_at', start);
      if (end) query = query?.lte('joined_at', end);

      const { data, error } = await query;
      if (error) throw error;

      // Calculate engagement metrics
      const participantStats = {};
      data?.forEach(participant => {
        const userId = participant?.user_id;
        if (!participantStats?.[userId]) {
          participantStats[userId] = {
            userId,
            userName: participant?.user?.full_name,
            totalCalls: 0,
            totalDuration: 0,
            mutedTime: 0,
            videoOnTime: 0
          };
        }

        participantStats[userId].totalCalls += 1;
        
        if (participant?.joined_at && participant?.left_at) {
          const duration = new Date(participant?.left_at) - new Date(participant?.joined_at);
          participantStats[userId].totalDuration += duration / 1000; // Convert to seconds
        }
      });

      const engagementData = Object.values(participantStats)?.map(stat => ({
        userId: stat?.userId,
        userName: stat?.userName,
        totalCalls: stat?.totalCalls,
        avgDuration: stat?.totalCalls > 0 ? Math.round(stat?.totalDuration / stat?.totalCalls) : 0,
        engagementScore: Math.min(100, Math.round((stat?.totalCalls * 10) + (stat?.totalDuration / 3600)))
      }))?.sort((a, b) => b?.engagementScore - a?.engagementScore);

      return {
        totalParticipants: engagementData?.length,
        topParticipants: engagementData?.slice(0, 10),
        avgEngagementScore: engagementData?.length > 0
          ? Math.round(engagementData?.reduce((sum, p) => sum + p?.engagementScore, 0) / engagementData?.length)
          : 0
      };
    } catch (error) {
      console.error('Get participant engagement error:', error);
      throw error;
    }
  },

  /**
   * Get recording performance metrics
   * @param {Object} dateRange - Start and end dates
   * @returns {Promise<Object>} Recording metrics
   */
  async getRecordingMetrics(dateRange = {}) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      const { start, end } = dateRange;
      let query = supabase
        ?.from('meeting_recordings')
        ?.select('*');

      if (start) query = query?.gte('created_at', start);
      if (end) query = query?.lte('created_at', end);

      const { data, error } = await query;
      if (error) throw error;

      const totalRecordings = data?.length || 0;
      const totalStorage = data?.reduce((sum, r) => sum + (r?.file_size || 0), 0);
      const processingRecordings = data?.filter(r => r?.is_processing)?.length || 0;
      const completedRecordings = data?.filter(r => !r?.is_processing)?.length || 0;

      // Group by type
      const recordingsByType = {
        call: data?.filter(r => r?.recording_type === 'call')?.length || 0,
        meeting: data?.filter(r => r?.recording_type === 'meeting')?.length || 0,
        conference: data?.filter(r => r?.recording_type === 'conference')?.length || 0
      };

      return {
        totalRecordings,
        totalStorageGB: (totalStorage / (1024 ** 3))?.toFixed(2),
        processingRecordings,
        completedRecordings,
        completionRate: totalRecordings > 0 ? ((completedRecordings / totalRecordings) * 100)?.toFixed(1) : 0,
        recordingsByType,
        avgFileSize: totalRecordings > 0 ? ((totalStorage / totalRecordings) / (1024 ** 2))?.toFixed(2) : 0
      };
    } catch (error) {
      console.error('Get recording metrics error:', error);
      throw error;
    }
  },

  /**
   * Get usage trends and patterns
   * @param {Object} dateRange - Start and end dates
   * @returns {Promise<Object>} Usage trend data
   */
  async getUsageTrends(dateRange = {}) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      const { start, end } = dateRange;
      let query = supabase
        ?.from('calls')
        ?.select('id, call_type, created_at, started_at, ended_at')
        ?.or(`initiator_id.eq.${user?.id},recipient_id.eq.${user?.id}`);

      if (start) query = query?.gte('created_at', start);
      if (end) query = query?.lte('created_at', end);

      const { data, error } = await query;
      if (error) throw error;

      // Analyze peak usage hours
      const hourlyUsage = Array(24)?.fill(0);
      data?.forEach(call => {
        const hour = new Date(call?.created_at)?.getHours();
        hourlyUsage[hour] += 1;
      });

      const peakHour = hourlyUsage?.indexOf(Math.max(...hourlyUsage));

      // Day of week analysis
      const weekdayUsage = Array(7)?.fill(0);
      data?.forEach(call => {
        const day = new Date(call?.created_at)?.getDay();
        weekdayUsage[day] += 1;
      });

      const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
      const peakDay = dayNames?.[weekdayUsage?.indexOf(Math.max(...weekdayUsage))];

      return {
        peakUsageHour: `${peakHour}:00`,
        peakUsageDay: peakDay,
        hourlyDistribution: hourlyUsage?.map((count, hour) => ({
          hour: `${hour}:00`,
          count
        })),
        weeklyDistribution: weekdayUsage?.map((count, day) => ({
          day: dayNames?.[day],
          count
        })),
        totalCallsAnalyzed: data?.length
      };
    } catch (error) {
      console.error('Get usage trends error:', error);
      throw error;
    }
  },

  /**
   * Get comprehensive dashboard data
   * @param {Object} dateRange - Start and end dates
   * @returns {Promise<Object>} Complete analytics data
   */
  async getDashboardData(dateRange = {}) {
    try {
      const [volumeMetrics, engagement, recordings, trends] = await Promise.all([
        this.getCallVolumeMetrics(dateRange),
        this.getParticipantEngagement(dateRange),
        this.getRecordingMetrics(dateRange),
        this.getUsageTrends(dateRange)
      ]);

      return {
        volumeMetrics,
        engagement,
        recordings,
        trends,
        lastUpdated: new Date()?.toISOString()
      };
    } catch (error) {
      console.error('Get dashboard data error:', error);
      throw error;
    }
  }
};