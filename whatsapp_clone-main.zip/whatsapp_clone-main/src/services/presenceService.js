import { supabase } from '../lib/supabase';

/**
 * Presence Service - Manages real-time user online/offline status
 * Uses Supabase Presence API for tracking active users
 */

class PresenceService {
  constructor() {
    this.presenceChannels = new Map();
    this.userPresenceStates = new Map();
  }

  /**
   * Subscribe to presence updates for a conversation
   * @param {string} conversationId - Conversation ID to track presence
   * @param {Function} onPresenceChange - Callback when user presence changes
   * @returns {Function} Cleanup function
   */
  subscribeToPresence(conversationId, onPresenceChange) {
    const channelName = `presence:${conversationId}`;
    
    // Check if already subscribed
    if (this.presenceChannels?.has(channelName)) {
      return () => this.unsubscribeFromPresence(conversationId);
    }

    const channel = supabase?.channel(channelName, {
      config: {
        presence: {
          key: conversationId
        }
      }
    });

    // Track presence state changes
    channel
      ?.on('presence', { event: 'sync' }, () => {
        const state = channel?.presenceState();
        this.userPresenceStates?.set(conversationId, state);
        
        // Convert presence state to user list
        const onlineUsers = [];
        Object.keys(state || {})?.forEach(key => {
          state?.[key]?.forEach(presence => {
            onlineUsers?.push({
              userId: presence?.user_id,
              userName: presence?.user_name,
              lastSeen: presence?.online_at
            });
          });
        });
        
        if (onPresenceChange) {
          onPresenceChange(onlineUsers);
        }
      })
      ?.on('presence', { event: 'join' }, ({ key, newPresences }) => {
        // User came online
        newPresences?.forEach(presence => {
          if (onPresenceChange) {
            onPresenceChange([{
              userId: presence?.user_id,
              userName: presence?.user_name,
              status: 'online',
              lastSeen: new Date()
            }]);
          }
        });
      })
      ?.on('presence', { event: 'leave' }, ({ key, leftPresences }) => {
        // User went offline
        leftPresences?.forEach(presence => {
          if (onPresenceChange) {
            onPresenceChange([{
              userId: presence?.user_id,
              userName: presence?.user_name,
              status: 'offline',
              lastSeen: new Date()
            }]);
          }
        });
      })
      ?.subscribe(async (status) => {
        if (status === 'SUBSCRIBED') {
          // Track own presence
          const { data: { user } } = await supabase?.auth?.getUser();
          if (user) {
            await channel?.track({
              user_id: user?.id,
              user_name: user?.user_metadata?.full_name || 'User',
              online_at: new Date()?.toISOString()
            });
          }
        }
      });

    this.presenceChannels?.set(channelName, channel);

    return () => this.unsubscribeFromPresence(conversationId);
  }

  /**
   * Unsubscribe from presence updates
   * @param {string} conversationId - Conversation ID
   */
  async unsubscribeFromPresence(conversationId) {
    const channelName = `presence:${conversationId}`;
    const channel = this.presenceChannels?.get(channelName);
    
    if (channel) {
      await channel?.untrack();
      await supabase?.removeChannel(channel);
      this.presenceChannels?.delete(channelName);
      this.userPresenceStates?.delete(conversationId);
    }
  }

  /**
   * Update own presence status
   * @param {string} conversationId - Conversation ID
   * @param {Object} presenceData - Additional presence data
   */
  async updatePresence(conversationId, presenceData = {}) {
    const channelName = `presence:${conversationId}`;
    const channel = this.presenceChannels?.get(channelName);
    
    if (channel) {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (user) {
        await channel?.track({
          user_id: user?.id,
          user_name: user?.user_metadata?.full_name || 'User',
          online_at: new Date()?.toISOString(),
          ...presenceData
        });
      }
    }
  }

  /**
   * Get current presence state for a conversation
   * @param {string} conversationId - Conversation ID
   * @returns {Array} List of online users
   */
  getPresenceState(conversationId) {
    const state = this.userPresenceStates?.get(conversationId);
    if (!state) return [];

    const onlineUsers = [];
    Object.keys(state)?.forEach(key => {
      state?.[key]?.forEach(presence => {
        onlineUsers?.push({
          userId: presence?.user_id,
          userName: presence?.user_name,
          lastSeen: presence?.online_at
        });
      });
    });

    return onlineUsers;
  }

  /**
   * Cleanup all presence subscriptions
   */
  async cleanup() {
    const promises = Array.from(this.presenceChannels?.keys())?.map(channelName => {
      const conversationId = channelName?.replace('presence:', '');
      return this.unsubscribeFromPresence(conversationId);
    });
    await Promise.all(promises);
  }
}

export const presenceService = new PresenceService();
export default presenceService;
