import { supabase } from '../lib/supabase';

export const profileSetupService = {
  /**
   * Upload profile photo to storage
   */
  async uploadProfilePhoto(file, userId) {
    try {
      const fileExt = file?.name?.split('.')?.pop();
      const fileName = `${userId}-${Date.now()}.${fileExt}`;
      const filePath = `${userId}/${fileName}`;

      const { error: uploadError } = await supabase?.storage?.from('profile-photos')?.upload(filePath, file);

      if (uploadError) throw uploadError;

      return filePath;
    } catch (error) {
      console.error('Error uploading profile photo:', error);
      throw error;
    }
  },

  /**
   * Get signed URL for profile photo
   */
  async getProfilePhotoUrl(filePath) {
    try {
      if (!filePath) return null;

      const { data, error } = await supabase?.storage?.from('profile-photos')?.createSignedUrl(filePath, 3600); // 1 hour expiry

      if (error) throw error;
      return data?.signedUrl;
    } catch (error) {
      console.error('Error getting profile photo URL:', error);
      return null;
    }
  },

  /**
   * Update profile with display name, bio, and photo
   */
  async updateProfile(userId, { displayName, bio, avatarUrl }) {
    try {
      const { data, error } = await supabase?.from('profiles')?.update({
          display_name: displayName,
          bio: bio,
          avatar_url: avatarUrl,
          profile_setup_completed: true,
          updated_at: new Date()?.toISOString()
        })?.eq('id', userId)?.select()?.single();

      if (error) throw error;

      return {
        id: data?.id,
        displayName: data?.display_name,
        bio: data?.bio,
        avatarUrl: data?.avatar_url,
        profileSetupCompleted: data?.profile_setup_completed
      };
    } catch (error) {
      console.error('Error updating profile:', error);
      throw error;
    }
  },

  /**
   * Check if display name is available
   */
  async checkDisplayNameAvailability(displayName, currentUserId) {
    try {
      const { data, error } = await supabase?.from('profiles')?.select('id')?.eq('display_name', displayName)?.neq('id', currentUserId)?.maybeSingle();

      if (error) throw error;

      return !data; // true if available, false if taken
    } catch (error) {
      console.error('Error checking display name:', error);
      throw error;
    }
  },

  /**
   * Get profile completion status
   */
  async getProfileStatus(userId) {
    try {
      const { data, error } = await supabase?.from('profiles')?.select('display_name, bio, avatar_url, profile_setup_completed')?.eq('id', userId)?.single();

      if (error) throw error;

      return {
        displayName: data?.display_name,
        bio: data?.bio,
        avatarUrl: data?.avatar_url,
        profileSetupCompleted: data?.profile_setup_completed
      };
    } catch (error) {
      console.error('Error getting profile status:', error);
      throw error;
    }
  }
};