import { supabase } from '../lib/supabase';

/**
 * Service for managing enhanced notification preferences
 */
export const enhancedNotificationService = {
  /**
   * Get notification preferences for a user
   * @param {string} userId - User ID
   * @returns {Promise<Object>} Notification preferences
   */
  async getNotificationPreferences(userId) {
    const { data, error } = await supabase?.from('notification_preferences')?.select('*')?.eq('user_id', userId)?.single();

    if (error) {
      // If no preferences exist, return defaults
      if (error?.code === 'PGRST116') {
        return {
          callNotifications: true,
          messageNotifications: true,
          groupNotifications: true,
          replyNotifications: true,
          statusNotifications: true,
          mutedConversations: [],
        };
      }
      throw error;
    }

    // Convert snake_case to camelCase
    return {
      id: data?.id,
      userId: data?.user_id,
      callNotifications: data?.call_notifications,
      messageNotifications: data?.message_notifications,
      groupNotifications: data?.group_notifications,
      replyNotifications: data?.reply_notifications,
      statusNotifications: data?.status_notifications,
      mutedConversations: data?.muted_conversations || [],
      createdAt: data?.created_at,
      updatedAt: data?.updated_at,
    };
  },

  /**
   * Update notification preferences
   * @param {string} userId - User ID
   * @param {Object} preferences - Notification preferences to update
   * @returns {Promise<Object>} Updated preferences
   */
  async updateNotificationPreferences(userId, preferences) {
    // Convert camelCase to snake_case
    const dbPreferences = {
      user_id: userId,
    };

    if (preferences?.callNotifications !== undefined) {
      dbPreferences.call_notifications = preferences?.callNotifications;
    }
    if (preferences?.messageNotifications !== undefined) {
      dbPreferences.message_notifications = preferences?.messageNotifications;
    }
    if (preferences?.groupNotifications !== undefined) {
      dbPreferences.group_notifications = preferences?.groupNotifications;
    }
    if (preferences?.replyNotifications !== undefined) {
      dbPreferences.reply_notifications = preferences?.replyNotifications;
    }
    if (preferences?.statusNotifications !== undefined) {
      dbPreferences.status_notifications = preferences?.statusNotifications;
    }
    if (preferences?.mutedConversations !== undefined) {
      dbPreferences.muted_conversations = preferences?.mutedConversations;
    }

    const { data, error } = await supabase?.from('notification_preferences')?.upsert(dbPreferences, {
        onConflict: 'user_id',
      })?.select()?.single();

    if (error) throw error;

    // Convert back to camelCase
    return {
      id: data?.id,
      userId: data?.user_id,
      callNotifications: data?.call_notifications,
      messageNotifications: data?.message_notifications,
      groupNotifications: data?.group_notifications,
      replyNotifications: data?.reply_notifications,
      statusNotifications: data?.status_notifications,
      mutedConversations: data?.muted_conversations || [],
      createdAt: data?.created_at,
      updatedAt: data?.updated_at,
    };
  },

  /**
   * Subscribe to notification preference changes
   * @param {string} userId - User ID
   * @param {Function} onUpdate - Callback when preferences change
   * @returns {Function} Unsubscribe function
   */
  subscribeToPreferenceChanges(userId, onUpdate) {
    const channel = supabase?.channel('notification-preferences')?.on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'notification_preferences',
          filter: `user_id=eq.${userId}`,
        },
        (payload) => {
          const data = payload?.new;
          onUpdate({
            id: data?.id,
            userId: data?.user_id,
            callNotifications: data?.call_notifications,
            messageNotifications: data?.message_notifications,
            groupNotifications: data?.group_notifications,
            replyNotifications: data?.reply_notifications,
            statusNotifications: data?.status_notifications,
            mutedConversations: data?.muted_conversations || [],
            createdAt: data?.created_at,
            updatedAt: data?.updated_at,
          });
        }
      )?.subscribe();

    return () => {
      supabase?.removeChannel(channel);
    };
  },

  /**
   * Mute a conversation
   * @param {string} userId - User ID
   * @param {string} conversationId - Conversation ID to mute
   * @returns {Promise<Object>} Updated preferences
   */
  async muteConversation(userId, conversationId) {
    const preferences = await this.getNotificationPreferences(userId);
    const mutedConversations = preferences?.mutedConversations || [];
    
    if (!mutedConversations?.includes(conversationId)) {
      mutedConversations?.push(conversationId);
      return await this.updateNotificationPreferences(userId, {
        mutedConversations,
      });
    }
    
    return preferences;
  },

  /**
   * Unmute a conversation
   * @param {string} userId - User ID
   * @param {string} conversationId - Conversation ID to unmute
   * @returns {Promise<Object>} Updated preferences
   */
  async unmuteConversation(userId, conversationId) {
    const preferences = await this.getNotificationPreferences(userId);
    const mutedConversations = (preferences?.mutedConversations || [])?.filter(
      (id) => id !== conversationId
    );
    
    return await this.updateNotificationPreferences(userId, {
      mutedConversations,
    });
  },
};