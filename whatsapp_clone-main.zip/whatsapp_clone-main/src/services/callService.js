import { supabase } from '../lib/supabase';
import { encryptionService } from './encryptionService';

export const callService = {
  // Initiate a new call
  async initiateCall(recipientId, callType = 'voice') {
    const { data: { user } } = await supabase?.auth?.getUser();
    if (!user) throw new Error('Not authenticated');

    const { data, error } = await supabase?.from('calls')?.insert([{
        initiator_id: user?.id,
        recipient_id: recipientId,
        call_type: callType,
        call_status: 'ringing',
        started_at: null
      }])?.select(`
        *,
        initiator:profiles!calls_initiator_id_fkey(id, full_name, avatar_url),
        recipient:profiles!calls_recipient_id_fkey(id, full_name, avatar_url)
      `)?.single();

    if (error) throw error;
    return data;
  },

  // Answer a call
  async answerCall(callId) {
    const { data, error } = await supabase?.from('calls')?.update({
        call_status: 'ongoing',
        started_at: new Date()?.toISOString()
      })?.eq('id', callId)?.select()?.single();

    if (error) throw error;
    return data;
  },

  // End a call
  async endCall(callId) {
    const { data, error } = await supabase?.from('calls')?.update({
        call_status: 'ended',
        ended_at: new Date()?.toISOString()
      })?.eq('id', callId)?.select()?.single();

    if (error) throw error;
    return data;
  },

  // Decline a call
  async declineCall(callId) {
    const { data, error } = await supabase?.from('calls')?.update({ call_status: 'declined' })?.eq('id', callId)?.select()?.single();

    if (error) throw error;
    return data;
  },

  // Update call settings (mute, speaker)
  async updateCallSettings(callId, settings) {
    const { data, error } = await supabase?.from('calls')?.update(settings)?.eq('id', callId)?.select()?.single();

    if (error) throw error;
    return data;
  },

  // Get call history
  async getCallHistory() {
    const { data: { user } } = await supabase?.auth?.getUser();
    if (!user) throw new Error('Not authenticated');

    const { data, error } = await supabase?.from('calls')?.select(`
        *,
        initiator:profiles!calls_initiator_id_fkey(id, full_name, avatar_url, phone_number),
        recipient:profiles!calls_recipient_id_fkey(id, full_name, avatar_url, phone_number)
      `)?.or(`initiator_id.eq.${user?.id},recipient_id.eq.${user?.id}`)?.order('created_at', { ascending: false })?.limit(50);

    if (error) throw error;
    return data;
  },

  // Get active call
  async getActiveCall() {
    const { data: { user } } = await supabase?.auth?.getUser();
    if (!user) throw new Error('Not authenticated');

    const { data, error } = await supabase?.from('calls')?.select(`
        *,
        initiator:profiles!calls_initiator_id_fkey(id, full_name, avatar_url),
        recipient:profiles!calls_recipient_id_fkey(id, full_name, avatar_url)
      `)?.or(`initiator_id.eq.${user?.id},recipient_id.eq.${user?.id}`)?.in('call_status', ['ringing', 'ongoing'])?.order('created_at', { ascending: false })?.limit(1)?.maybeSingle();

    if (error) throw error;
    return data;
  },

  // Conference call - add participant
  async addParticipant(callId, userId) {
    const { data, error } = await supabase?.from('call_participants')?.insert([{
        call_id: callId,
        user_id: userId,
        is_muted: false,
        is_video_on: true
      }])?.select()?.single();

    if (error) throw error;
    return data;
  },

  // Get call participants
  async getCallParticipants(callId) {
    const { data, error } = await supabase?.from('call_participants')?.select(`
        *,
        user:profiles(id, full_name, avatar_url)
      `)?.eq('call_id', callId)?.is('left_at', null);

    if (error) throw error;
    return data;
  },

  // Update participant settings
  async updateParticipant(participantId, settings) {
    const { data, error } = await supabase?.from('call_participants')?.update(settings)?.eq('id', participantId)?.select()?.single();

    if (error) throw error;
    return data;
  },

  // Leave conference call
  async leaveConference(participantId) {
    const { data, error } = await supabase?.from('call_participants')?.update({ left_at: new Date()?.toISOString() })?.eq('id', participantId)?.select()?.single();

    if (error) throw error;
    return data;
  },

  // Subscribe to call updates
  subscribeToCallUpdates(callId, callback) {
    return supabase?.channel(`call:${callId}`)?.on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'calls',
          filter: `id=eq.${callId}`
        },
        callback
      )?.subscribe();
  },

  // Subscribe to incoming calls
  subscribeToIncomingCalls(userId, callback) {
    return supabase?.channel(`user-calls:${userId}`)?.on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'calls',
          filter: `recipient_id=eq.${userId}`
        },
        callback
      )?.subscribe();
  },

  /**
   * Start an encrypted call with metadata encryption
   * @param {string} initiatorId - Caller user ID
   * @param {string} recipientId - Recipient user ID  
   * @param {string} callType - 'voice' | 'video' | 'conference'
   * @param {Object} metadata - Call metadata to encrypt (notes, settings, etc.)
   * @returns {Promise<Object>} Call record
   */
  async startEncryptedCall(initiatorId, recipientId, callType, metadata = {}) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      // Encrypt call metadata
      const encryptedData = encryptionService?.encryptMessage(
        JSON.stringify(metadata),
        recipientId
      );

      const { data, error } = await supabase?.from('calls')?.insert({
        initiator_id: initiatorId,
        recipient_id: recipientId,
        call_type: callType,
        call_status: 'ringing',
        is_encrypted: true,
        nonce: encryptedData?.nonce,
        encrypted_metadata: encryptedData?.encryptedMessage ? 
          { data: encryptedData?.encryptedMessage } : null
      })?.select()?.single();

      if (error) throw error;

      return {
        success: true,
        call: {
          id: data?.id,
          callType: data?.call_type,
          callStatus: data?.call_status,
          isEncrypted: data?.is_encrypted,
          timestamp: new Date(data.created_at)
        }
      };
    } catch (error) {
      console.error('Error starting encrypted call:', error);
      throw error;
    }
  },

  /**
   * Get call details with decrypted metadata
   * @param {string} callId - Call ID
   * @returns {Promise<Object>} Call details with decrypted metadata
   */
  async getCallWithMetadata(callId) {
    try {
      const { data, error } = await supabase?.from('calls')?.select(`
          *,
          initiator:initiator_id(id, full_name, avatar_url, public_key),
          recipient:recipient_id(id, full_name, avatar_url, public_key)
        `)?.eq('id', callId)?.single();

      if (error) throw error;

      let decryptedMetadata = {};

      // Decrypt metadata if encrypted
      if (data?.is_encrypted && data?.nonce && data?.encrypted_metadata) {
        try {
          const { data: { user } } = await supabase?.auth?.getUser();
          if (user) {
            const senderPublicKey = data?.initiator?.public_key;
            const decryptedString = encryptionService?.decryptMessage(
              { 
                encryptedMessage: data?.encrypted_metadata?.data, 
                nonce: data?.nonce 
              },
              senderPublicKey
            );
            decryptedMetadata = JSON.parse(decryptedString);
          }
        } catch (error) {
          console.error('Error decrypting call metadata:', error);
          decryptedMetadata = { error: 'Failed to decrypt metadata' };
        }
      }

      return {
        id: data?.id,
        callType: data?.call_type,
        callStatus: data?.call_status,
        duration: data?.duration,
        startedAt: data?.started_at ? new Date(data.started_at) : null,
        endedAt: data?.ended_at ? new Date(data.ended_at) : null,
        isEncrypted: data?.is_encrypted || false,
        metadata: decryptedMetadata,
        initiator: {
          id: data?.initiator?.id,
          name: data?.initiator?.full_name,
          avatar: data?.initiator?.avatar_url
        },
        recipient: {
          id: data?.recipient?.id,
          name: data?.recipient?.full_name,
          avatar: data?.recipient?.avatar_url
        }
      };
    } catch (error) {
      console.error('Error fetching call with metadata:', error);
      throw error;
    }
  },

  /**
   * Update call metadata (encrypted)
   * @param {string} callId - Call ID
   * @param {Object} newMetadata - New metadata to encrypt and store
   * @returns {Promise<Object>} Update result
   */
  async updateCallMetadata(callId, newMetadata) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      // Get call recipient
      const { data: callData } = await supabase?.from('calls')?.select('recipient_id')?.eq('id', callId)?.single();

      if (!callData) throw new Error('Call not found');

      // Encrypt new metadata
      const encryptedData = encryptionService?.encryptMessage(
        JSON.stringify(newMetadata),
        callData?.recipient_id
      );

      const { error } = await supabase?.from('calls')?.update({
          encrypted_metadata: { data: encryptedData?.encryptedMessage },
          nonce: encryptedData?.nonce,
          is_encrypted: true
        })?.eq('id', callId);

      if (error) throw error;

      return { success: true };
    } catch (error) {
      console.error('Error updating call metadata:', error);
      throw error;
    }
  }
};

export default callService;