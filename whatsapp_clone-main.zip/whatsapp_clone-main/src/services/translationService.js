import translate from 'google-translate-api-x';
import { supabase } from '../lib/supabase';

/**
 * Translation Service
 * 
 * Handles real-time text translation using Google Translate API
 * with on-demand translation, caching, and language detection
 */

class TranslationService {
  constructor() {
    this.cache = new Map(); // In-memory cache for quick access
    this.supportedLanguages = [
      { code: 'en', name: 'English' },
      { code: 'es', name: 'Spanish' },
      { code: 'fr', name: 'French' },
      { code: 'de', name: 'German' },
      { code: 'it', name: 'Italian' },
      { code: 'pt', name: 'Portuguese' },
      { code: 'ru', name: 'Russian' },
      { code: 'ja', name: 'Japanese' },
      { code: 'ko', name: 'Korean' },
      { code: 'zh-CN', name: 'Chinese (Simplified)' },
      { code: 'ar', name: 'Arabic' },
      { code: 'hi', name: 'Hindi' }
    ];
  }

  /**
   * Detect language of the text
   * @param {string} text - Text to detect language for
   * @returns {Promise<string>} - Detected language code
   */
  async detectLanguage(text) {
    try {
      const result = await translate(text, { to: 'en' });
      return result?.from?.language?.iso || 'en';
    } catch (error) {
      console.error('Language detection error:', error);
      return 'en'; // Default to English
    }
  }

  /**
   * Translate text to target language
   * @param {string} text - Text to translate
   * @param {string} targetLanguage - Target language code
   * @param {string} sourceLanguage - Source language code (optional, auto-detect if not provided)
   * @returns {Promise<Object>} - Translation result
   */
  async translateText(text, targetLanguage, sourceLanguage = null) {
    try {
      // Check in-memory cache first
      const cacheKey = `${text}:${targetLanguage}`;
      if (this.cache?.has(cacheKey)) {
        return {
          success: true,
          translatedText: this.cache?.get(cacheKey),
          sourceLanguage: sourceLanguage,
          cached: true
        };
      }

      // Perform translation
      const options = {
        to: targetLanguage
      };

      if (sourceLanguage) {
        options.from = sourceLanguage;
      }

      const result = await translate(text, options);

      const translatedText = result?.text;
      const detectedSourceLanguage = result?.from?.language?.iso;

      // Cache the result
      this.cache?.set(cacheKey, translatedText);

      return {
        success: true,
        translatedText: translatedText,
        sourceLanguage: detectedSourceLanguage || sourceLanguage,
        targetLanguage: targetLanguage,
        cached: false
      };
    } catch (error) {
      console.error('Translation error:', error);
      return {
        success: false,
        error: error?.message || 'Translation failed',
        translatedText: text // Return original text on error
      };
    }
  }

  /**
   * Translate message with database caching
   * @param {string} messageId - Message ID
   * @param {string} text - Text to translate
   * @param {string} targetLanguage - Target language code
   * @returns {Promise<Object>} - Translation result
   */
  async translateMessage(messageId, text, targetLanguage) {
    try {
      // Check database cache first
      const { data: message, error: fetchError } = await supabase?.from('chat_messages')?.select('translations, original_language')?.eq('id', messageId)?.single();

      if (fetchError) throw fetchError;

      // Check if translation already exists in database
      if (message?.translations?.[targetLanguage]) {
        return {
          success: true,
          translatedText: message?.translations?.[targetLanguage],
          sourceLanguage: message?.original_language,
          cached: true
        };
      }

      // Perform translation
      const result = await this.translateText(
        text,
        targetLanguage,
        message?.original_language
      );

      if (!result?.success) {
        return result;
      }

      // Cache translation in database
      const { error: cacheError } = await supabase?.rpc('cache_translation', {
          message_uuid: messageId,
          target_language: targetLanguage,
          translated_text: result?.translatedText
        });

      if (cacheError) {
        console.error('Failed to cache translation:', cacheError);
      }

      // Update original language if not set
      if (!message?.original_language && result?.sourceLanguage) {
        await supabase?.from('chat_messages')?.update({ original_language: result?.sourceLanguage })?.eq('id', messageId);
      }

      return result;
    } catch (error) {
      console.error('Message translation error:', error);
      return {
        success: false,
        error: error?.message || 'Translation failed',
        translatedText: text
      };
    }
  }

  /**
   * Get supported languages
   * @returns {Array} - List of supported languages
   */
  getSupportedLanguages() {
    return this.supportedLanguages;
  }

  /**
   * Check if language is supported
   * @param {string} languageCode - Language code to check
   * @returns {boolean} - True if language is supported
   */
  isLanguageSupported(languageCode) {
    return this.supportedLanguages?.some(lang => lang?.code === languageCode);
  }

  /**
   * Clear in-memory cache
   */
  clearCache() {
    this.cache?.clear();
  }

  /**
   * Get cache size
   * @returns {number} - Number of cached translations
   */
  getCacheSize() {
    return this.cache?.size || 0;
  }
}

export const translationService = new TranslationService();

/**
 * Get user translation settings
 */
export const getTranslationSettings = async (userId) => {
  const { data, error } = await supabase?.from('appearance_settings')?.select('auto_translate_enabled, translation_preference, do_not_translate_languages, preferred_translation_language, translate_entire_chats')?.eq('user_id', userId)?.single();

  if (error) {
    console.error('Error fetching translation settings:', error);
    throw error;
  }

  return {
    autoTranslateEnabled: data?.auto_translate_enabled || false,
    translationPreference: data?.translation_preference || 'ask_before',
    doNotTranslateLanguages: data?.do_not_translate_languages || [],
    preferredTranslationLanguage: data?.preferred_translation_language || 'en',
    translateEntireChats: data?.translate_entire_chats || false
  };
};

/**
 * Update user translation settings
 */
export const updateTranslationSettings = async (userId, settings) => {
  const { error } = await supabase?.from('appearance_settings')?.update({
      auto_translate_enabled: settings?.autoTranslateEnabled,
      translation_preference: settings?.translationPreference,
      do_not_translate_languages: settings?.doNotTranslateLanguages,
      preferred_translation_language: settings?.preferredTranslationLanguage,
      translate_entire_chats: settings?.translateEntireChats,
      updated_at: new Date()?.toISOString()
    })?.eq('user_id', userId);

  if (error) {
    console.error('Error updating translation settings:', error);
    throw error;
  }

  return { success: true };
};

/**
 * Check if translation should be triggered for a language
 */
export const shouldTranslate = (settings, detectedLanguage) => {
  if (!settings?.autoTranslateEnabled) return false;
  
  // Check if language is in do-not-translate list
  if (settings?.doNotTranslateLanguages?.includes(detectedLanguage)) return false;
  
  // Check preference
  if (settings?.translationPreference === 'never') return false;
  if (settings?.translationPreference === 'auto_all') return true;
  
  // Default: ask_before
  return 'ask';
};