import { supabase } from '../lib/supabase';

export const notificationService = {
  // Get all notifications for current user
  async getUserNotifications(userId) {
    try {
      const notifications = [];

      // Get unread messages
      const { data: messages } = await supabase?.from('chat_messages')?.select('id, message, sender_id, sender_name, created_at, read_at, profiles!chat_messages_sender_id_fkey(full_name, avatar_url)')?.eq('recipient_id', userId)?.is('read_at', null)?.order('created_at', { ascending: false })?.limit(50);

      if (messages) {
        notifications?.push(...messages?.map(msg => ({
          id: msg?.id,
          type: 'message',
          title: msg?.profiles?.full_name || msg?.sender_name || 'Unknown',
          message: msg?.message,
          timestamp: msg?.created_at,
          read: !!msg?.read_at,
          avatar: msg?.profiles?.avatar_url,
          senderId: msg?.sender_id
        })));
      }

      // Get recent calls
      const { data: calls } = await supabase?.from('calls')?.select('id, call_type, call_status, created_at, initiator_id, recipient_id, profiles!calls_initiator_id_fkey(full_name, avatar_url)')?.or(`initiator_id.eq.${userId},recipient_id.eq.${userId}`)?.order('created_at', { ascending: false })?.limit(20);

      if (calls) {
        notifications?.push(...calls?.map(call => ({
          id: call?.id,
          type: 'call',
          title: call?.profiles?.full_name || 'Unknown',
          message: `${call?.call_type} call - ${call?.call_status}`,
          timestamp: call?.created_at,
          read: true,
          avatar: call?.profiles?.avatar_url,
          callType: call?.call_type,
          callStatus: call?.call_status
        })));
      }

      // Get status replies
      const { data: replies } = await supabase?.from('status_replies')?.select(`
          id, 
          reply_text, 
          created_at,
          user_id,
          status_updates!inner(user_id),
          profiles!status_replies_user_id_fkey(full_name, avatar_url)
        `)?.eq('status_updates.user_id', userId)?.order('created_at', { ascending: false })?.limit(20);

      if (replies) {
        notifications?.push(...replies?.map(reply => ({
          id: reply?.id,
          type: 'status_reply',
          title: reply?.profiles?.full_name || 'Unknown',
          message: reply?.reply_text,
          timestamp: reply?.created_at,
          read: true,
          avatar: reply?.profiles?.avatar_url
        })));
      }

      // Get status views (only view count updates)
      const { data: statusUpdates } = await supabase?.from('status_updates')?.select('id, caption, view_count, created_at, updated_at')?.eq('user_id', userId)?.gt('view_count', 0)?.order('updated_at', { ascending: false })?.limit(10);

      if (statusUpdates) {
        notifications?.push(...statusUpdates?.map(status => ({
          id: status?.id,
          type: 'status_view',
          title: 'Status Update',
          message: `${status?.view_count} ${status?.view_count === 1 ? 'view' : 'views'} on your status`,
          timestamp: status?.updated_at,
          read: true,
          caption: status?.caption
        })));
      }

      // Sort all notifications by timestamp
      return notifications?.sort((a, b) => 
        new Date(b.timestamp) - new Date(a.timestamp)
      );
    } catch (error) {
      console.error('Error fetching notifications:', error);
      throw error;
    }
  },

  // Get notification preferences
  async getNotificationPreferences(userId) {
    try {
      const { data, error } = await supabase?.from('notification_preferences')?.select('*')?.eq('user_id', userId)?.single();

      if (error && error?.code !== 'PGRST116') throw error;

      // Return default if not found
      if (!data) {
        return {
          message_notifications: true,
          call_notifications: true,
          status_notifications: true,
          reply_notifications: true,
          group_notifications: true,
          muted_conversations: []
        };
      }

      return data;
    } catch (error) {
      console.error('Error fetching notification preferences:', error);
      throw error;
    }
  },

  // Update notification preferences
  async updateNotificationPreferences(userId, preferences) {
    try {
      const { data, error } = await supabase?.from('notification_preferences')?.upsert({
          user_id: userId,
          ...preferences,
          updated_at: new Date()?.toISOString()
        }, {
          onConflict: 'user_id'
        })?.select()?.single();

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error updating notification preferences:', error);
      throw error;
    }
  },

  // Mark message as read
  async markMessageAsRead(messageId) {
    try {
      const { error } = await supabase?.from('chat_messages')?.update({ read_at: new Date()?.toISOString() })?.eq('id', messageId);

      if (error) throw error;
    } catch (error) {
      console.error('Error marking message as read:', error);
      throw error;
    }
  },

  // Subscribe to real-time notifications
  subscribeToNotifications(userId, callback) {
    const channel = supabase?.channel('notifications')?.on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'chat_messages',
          filter: `recipient_id=eq.${userId}`
        },
        callback
      )?.on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'calls',
          filter: `recipient_id=eq.${userId}`
        },
        callback
      )?.on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'status_replies'
        },
        callback
      )?.subscribe();

    return () => {
      supabase?.removeChannel(channel);
    };
  }
};

export default notificationService;