import { supabase } from '../lib/supabase';

/**
 * Admin Ad Service
 * Manages broadcast announcements and advertisements
 */

export const adminAdService = {
  /**
   * Create new ad
   */
  async createAd(adData) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data, error } = await supabase
        ?.from('admin_ads')
        ?.insert({
          ...adData,
          created_by: user?.id
        })
        ?.select()
        ?.single();

      if (error) throw error;
      return { data, error: null };
    } catch (error) {
      console.error('Error creating ad:', error);
      return { data: null, error };
    }
  },

  /**
   * Get all ads with pagination
   */
  async getAds({ page = 1, limit = 20, activeOnly = false }) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      const offset = (page - 1) * limit;

      let query = supabase
        ?.from('admin_ads')
        ?.select('*', { count: 'exact' });

      if (activeOnly) {
        query = query
          ?.eq('is_active', true)
          ?.lte('start_date', new Date()?.toISOString())
          ?.gte('end_date', new Date()?.toISOString());
      }

      const { data, error, count } = await query
        ?.order('created_at', { ascending: false })
        ?.range(offset, offset + limit - 1);

      if (error) throw error;

      return {
        data,
        count,
        page,
        totalPages: Math.ceil((count || 0) / limit),
        error: null
      };
    } catch (error) {
      console.error('Error fetching ads:', error);
      return { data: null, count: 0, page, totalPages: 0, error };
    }
  },

  /**
   * Get single ad by ID
   */
  async getAdById(adId) {
    try {
      const { data, error } = await supabase
        ?.from('admin_ads')
        ?.select('*')
        ?.eq('id', adId)
        ?.single();

      if (error) throw error;
      return { data, error: null };
    } catch (error) {
      console.error('Error fetching ad:', error);
      return { data: null, error };
    }
  },

  /**
   * Update ad
   */
  async updateAd(adId, updates) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data, error } = await supabase
        ?.from('admin_ads')
        ?.update(updates)
        ?.eq('id', adId)
        ?.select()
        ?.single();

      if (error) throw error;
      return { data, error: null };
    } catch (error) {
      console.error('Error updating ad:', error);
      return { data: null, error };
    }
  },

  /**
   * Delete ad
   */
  async deleteAd(adId) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      const { error } = await supabase
        ?.from('admin_ads')
        ?.delete()
        ?.eq('id', adId);

      if (error) throw error;
      return { error: null };
    } catch (error) {
      console.error('Error deleting ad:', error);
      return { error };
    }
  },

  /**
   * Get active ad for user (public API)
   */
  async getActiveAdForUser() {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) return { data: null, error: null };

      // Get user country code
      const { data: profile } = await supabase
        ?.from('profiles')
        ?.select('country_code')
        ?.eq('id', user?.id)
        ?.single();

      const countryCode = profile?.country_code || null;

      // Call function to get active ad
      const { data, error } = await supabase
        ?.rpc('get_active_ad_for_user', { p_user_country_code: countryCode });

      if (error) throw error;

      return { data: data?.[0] || null, error: null };
    } catch (error) {
      console.error('Error fetching active ad:', error);
      return { data: null, error };
    }
  },

  /**
   * Track ad impression
   */
  async trackImpression(adId) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) return { error: null };

      // Get user country code
      const { data: profile } = await supabase
        ?.from('profiles')
        ?.select('country_code')
        ?.eq('id', user?.id)
        ?.single();

      const { error } = await supabase
        ?.from('ad_impression_tracking')
        ?.insert({
          ad_id: adId,
          user_id: user?.id,
          user_country_code: profile?.country_code || null
        });

      if (error) throw error;
      return { error: null };
    } catch (error) {
      console.error('Error tracking impression:', error);
      return { error };
    }
  },

  /**
   * Track ad click
   */
  async trackClick(adId) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) return { error: null };

      // Get user country code
      const { data: profile } = await supabase
        ?.from('profiles')
        ?.select('country_code')
        ?.eq('id', user?.id)
        ?.single();

      const { error } = await supabase
        ?.from('ad_click_tracking')
        ?.insert({
          ad_id: adId,
          user_id: user?.id,
          user_country_code: profile?.country_code || null,
          user_agent: navigator?.userAgent || null
        });

      if (error) throw error;
      return { error: null };
    } catch (error) {
      console.error('Error tracking click:', error);
      return { error };
    }
  },

  /**
   * Get ad performance metrics
   */
  async getAdPerformance(adId) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      // Get ad details
      const { data: ad, error: adError } = await supabase
        ?.from('admin_ads')
        ?.select('*')
        ?.eq('id', adId)
        ?.single();

      if (adError) throw adError;

      // Get click details
      const { data: clicks, error: clicksError } = await supabase
        ?.from('ad_click_tracking')
        ?.select('clicked_at, user_country_code')
        ?.eq('ad_id', adId);

      if (clicksError) throw clicksError;

      // Get impression details
      const { data: impressions, error: impressionsError } = await supabase
        ?.from('ad_impression_tracking')
        ?.select('viewed_at, user_country_code')
        ?.eq('ad_id', adId);

      if (impressionsError) throw impressionsError;

      // Calculate CTR
      const ctr = ad?.impressions_count > 0
        ? ((ad?.clicks_count / ad?.impressions_count) * 100)?.toFixed(2)
        : 0;

      return {
        data: {
          ad,
          clicks,
          impressions,
          ctr,
          totalClicks: ad?.clicks_count || 0,
          totalImpressions: ad?.impressions_count || 0
        },
        error: null
      };
    } catch (error) {
      console.error('Error fetching ad performance:', error);
      return { data: null, error };
    }
  }
};

export default adminAdService;