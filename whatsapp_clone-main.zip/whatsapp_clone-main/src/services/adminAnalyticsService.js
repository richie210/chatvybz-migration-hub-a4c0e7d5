import { supabase } from '../lib/supabase';

/**
 * Admin Analytics Service
 * Privacy-focused analytics for platform administrators
 */

export const adminAnalyticsService = {
  /**
   * Check if current user is admin
   */
  async isAdmin() {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) return false;

      const { data, error } = await supabase
        ?.from('profiles')
        ?.select('is_admin')
        ?.eq('id', user?.id)
        ?.single();

      if (error) throw error;
      return data?.is_admin === true;
    } catch (error) {
      console.error('Error checking admin status:', error);
      return false;
    }
  },

  /**
   * Get dashboard overview metrics
   */
  async getDashboardMetrics() {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      // Total users
      const { count: totalUsers, error: usersError } = await supabase
        ?.from('profiles')
        ?.select('*', { count: 'exact', head: true });

      if (usersError) throw usersError;

      // Users by country
      const { data: usersByCountry, error: countryError } = await supabase
        ?.from('profiles')
        ?.select('country_code')
        ?.not('country_code', 'is', null);

      if (countryError) throw countryError;

      // Count by country
      const countryCounts = {};
      usersByCountry?.forEach(user => {
        const code = user?.country_code || 'Unknown';
        countryCounts[code] = (countryCounts?.[code] || 0) + 1;
      });

      // Daily/Monthly active users (users who logged in recently)
      const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000)?.toISOString();
      const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)?.toISOString();

      const { count: dau, error: dauError } = await supabase
        ?.from('profiles')
        ?.select('*', { count: 'exact', head: true })
        ?.gte('updated_at', oneDayAgo);

      if (dauError) throw dauError;

      const { count: mau, error: mauError } = await supabase
        ?.from('profiles')
        ?.select('*', { count: 'exact', head: true })
        ?.gte('updated_at', thirtyDaysAgo);

      if (mauError) throw mauError;

      // Message volume today
      const today = new Date()?.toISOString()?.split('T')?.[0];
      const { data: todayMessages, error: messagesError } = await supabase
        ?.from('daily_message_volume')
        ?.select('message_count')
        ?.eq('day', today);

      if (messagesError) throw messagesError;

      const totalMessagesToday = todayMessages?.reduce((sum, row) => sum + (row?.message_count || 0), 0) || 0;

      return {
        totalUsers: totalUsers || 0,
        dailyActiveUsers: dau || 0,
        monthlyActiveUsers: mau || 0,
        totalMessagesToday,
        usersByCountry: countryCounts
      };
    } catch (error) {
      console.error('Error fetching dashboard metrics:', error);
      throw error;
    }
  },

  /**
   * Get message volume trends
   */
  async getMessageVolumeTrends(days = 30) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      const startDate = new Date(Date.now() - days * 24 * 60 * 60 * 1000)?.toISOString()?.split('T')?.[0];

      const { data, error } = await supabase
        ?.from('daily_message_volume')
        ?.select('day, country_code, message_count')
        ?.gte('day', startDate)
        ?.order('day', { ascending: true });

      if (error) throw error;

      // Aggregate by day
      const dailyTotals = {};
      data?.forEach(row => {
        const day = row?.day;
        dailyTotals[day] = (dailyTotals?.[day] || 0) + (row?.message_count || 0);
      });

      const trendData = Object.entries(dailyTotals)?.map(([day, count]) => ({
        date: day,
        count
      }));

      return { data: trendData, error: null };
    } catch (error) {
      console.error('Error fetching message volume trends:', error);
      return { data: null, error };
    }
  },

  /**
   * Get user growth trends
   */
  async getUserGrowthTrends(days = 30) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      const startDate = new Date(Date.now() - days * 24 * 60 * 60 * 1000)?.toISOString();

      const { data, error } = await supabase
        ?.from('profiles')
        ?.select('created_at')
        ?.gte('created_at', startDate)
        ?.order('created_at', { ascending: true });

      if (error) throw error;

      // Group by day
      const dailySignups = {};
      data?.forEach(profile => {
        const day = profile?.created_at?.split('T')?.[0];
        dailySignups[day] = (dailySignups?.[day] || 0) + 1;
      });

      const trendData = Object.entries(dailySignups)?.map(([date, signups]) => ({
        date,
        signups
      }));

      return { data: trendData, error: null };
    } catch (error) {
      console.error('Error fetching user growth trends:', error);
      return { data: null, error };
    }
  },

  /**
   * Get all users with pagination and search
   */
  async getUsers({ page = 1, limit = 20, search = '', country = null }) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      const offset = (page - 1) * limit;

      let query = supabase
        ?.from('profiles')
        ?.select('id, email, full_name, country_code, created_at, avatar_url', { count: 'exact' });

      if (search) {
        query = query?.or(`email.ilike.%${search}%,full_name.ilike.%${search}%`);
      }

      if (country) {
        query = query?.eq('country_code', country);
      }

      const { data, error, count } = await query
        ?.order('created_at', { ascending: false })
        ?.range(offset, offset + limit - 1);

      if (error) throw error;

      return {
        data,
        count,
        page,
        totalPages: Math.ceil((count || 0) / limit),
        error: null
      };
    } catch (error) {
      console.error('Error fetching users:', error);
      return { data: null, count: 0, page, totalPages: 0, error };
    }
  },

  /**
   * Ban user
   */
  async banUser(userId, reason) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data, error } = await supabase
        ?.from('user_ban_status')
        ?.upsert({
          user_id: userId,
          is_banned: true,
          ban_reason: reason,
          banned_by: user?.id,
          banned_at: new Date()?.toISOString()
        }, { onConflict: 'user_id' })
        ?.select()
        ?.single();

      if (error) throw error;
      return { data, error: null };
    } catch (error) {
      console.error('Error banning user:', error);
      return { data: null, error };
    }
  },

  /**
   * Suspend user
   */
  async suspendUser(userId, reason, durationDays = 7) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      const suspensionUntil = new Date(Date.now() + durationDays * 24 * 60 * 60 * 1000)?.toISOString();

      const { data, error } = await supabase
        ?.from('user_ban_status')
        ?.upsert({
          user_id: userId,
          is_suspended: true,
          suspension_reason: reason,
          suspended_by: user?.id,
          suspended_at: new Date()?.toISOString(),
          suspension_until: suspensionUntil
        }, { onConflict: 'user_id' })
        ?.select()
        ?.single();

      if (error) throw error;
      return { data, error: null };
    } catch (error) {
      console.error('Error suspending user:', error);
      return { data: null, error };
    }
  },

  /**
   * Restore user (remove ban/suspension)
   */
  async restoreUser(userId, reason) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data, error } = await supabase
        ?.from('user_ban_status')
        ?.update({
          is_banned: false,
          is_suspended: false,
          ban_reason: null,
          suspension_reason: null,
          suspension_until: null,
          updated_at: new Date()?.toISOString()
        })
        ?.eq('user_id', userId)
        ?.select()
        ?.single();

      if (error) throw error;
      return { data, error: null };
    } catch (error) {
      console.error('Error restoring user:', error);
      return { data: null, error };
    }
  },

  /**
   * Get user ban status
   */
  async getUserBanStatus(userId) {
    try {
      const { data, error } = await supabase
        ?.from('user_ban_status')
        ?.select('*')
        ?.eq('user_id', userId)
        ?.single();

      if (error && error?.code !== 'PGRST116') throw error;
      return { data: data || null, error: null };
    } catch (error) {
      console.error('Error fetching user ban status:', error);
      return { data: null, error };
    }
  }
};

export default adminAnalyticsService;