import { supabase } from '../lib/supabase';

/**
 * Service for managing message file attachments.
 * Handles file uploads to Supabase Storage and attachment metadata in database.
 */
export const fileAttachmentService = {
  /**
   * Upload a file to Supabase Storage and create attachment record.
   * @param {File} file - The file to upload.
   * @param {string} messageId - The message ID to attach the file to.
   * @param {string} userId - The current user's ID.
   * @returns {Promise<Object>} The created attachment record.
   */
  async uploadAttachment(file, messageId, userId) {
    try {
      // Generate unique file path
      const fileExt = file?.name?.split('.')?.pop();
      const fileName = `${Date.now()}_${Math.random()?.toString(36)?.substring(7)}.${fileExt}`;
      const filePath = `${userId}/${fileName}`;

      // Upload file to storage
      const { data: uploadData, error: uploadError } = await supabase?.storage
        ?.from('message-attachments')
        ?.upload(filePath, file, {
          cacheControl: '3600',
          upsert: false
        });

      if (uploadError) throw uploadError;

      // Get public URL (will use signed URL for private access)
      const { data: { publicUrl } } = supabase?.storage
        ?.from('message-attachments')
        ?.getPublicUrl(filePath);

      // Determine file type category
      const fileType = this.getFileTypeCategory(file?.type);

      // Get image/video dimensions if applicable
      let width = null;
      let height = null;
      let duration = null;

      if (fileType === 'image') {
        const dimensions = await this.getImageDimensions(file);
        width = dimensions?.width;
        height = dimensions?.height;
      } else if (fileType === 'video') {
        const videoData = await this.getVideoMetadata(file);
        width = videoData?.width;
        height = videoData?.height;
        duration = videoData?.duration;
      } else if (fileType === 'audio') {
        duration = await this.getAudioDuration(file);
      }

      // Create attachment record in database
      const { data: attachment, error: dbError } = await supabase
        ?.from('message_attachments')
        ?.insert({
          message_id: messageId,
          file_name: file?.name,
          file_type: fileType,
          file_size: file?.size,
          file_url: publicUrl,
          mime_type: file?.type,
          width,
          height,
          duration
        })
        ?.select()
        ?.single();

      if (dbError) throw dbError;

      return attachment;
    } catch (error) {
      console.error('Error uploading attachment:', error);
      throw error;
    }
  },

  /**
   * Get signed URL for private file access.
   * @param {string} filePath - The file path in storage.
   * @returns {Promise<string>} Signed URL for file access.
   */
  async getSignedUrl(filePath) {
    try {
      const { data, error } = await supabase?.storage
        ?.from('message-attachments')
        ?.createSignedUrl(filePath, 3600); // 1 hour expiry

      if (error) throw error;
      return data?.signedUrl;
    } catch (error) {
      console.error('Error getting signed URL:', error);
      throw error;
    }
  },

  /**
   * Get attachments for a message.
   * @param {string} messageId - The message ID.
   * @returns {Promise<Array>} Array of attachment records.
   */
  async getMessageAttachments(messageId) {
    try {
      const { data, error } = await supabase
        ?.from('message_attachments')?.select('*')?.eq('message_id', messageId)?.order('created_at', { ascending: true });

      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Error fetching attachments:', error);
      throw error;
    }
  },

  /**
   * Delete an attachment.
   * @param {string} attachmentId - The attachment ID.
   * @param {string} fileUrl - The file URL to delete from storage.
   * @returns {Promise<void>}
   */
  async deleteAttachment(attachmentId, fileUrl) {
    try {
      // Extract file path from URL
      const urlParts = fileUrl?.split('/message-attachments/');
      const filePath = urlParts?.[1];

      // Delete from storage
      if (filePath) {
        await supabase?.storage
          ?.from('message-attachments')
          ?.remove([filePath]);
      }

      // Delete from database
      const { error } = await supabase
        ?.from('message_attachments')?.delete()?.eq('id', attachmentId);

      if (error) throw error;
    } catch (error) {
      console.error('Error deleting attachment:', error);
      throw error;
    }
  },

  /**
   * Categorize file type.
   * @param {string} mimeType - The MIME type of the file.
   * @returns {string} File type category (image, video, audio, document).
   */
  getFileTypeCategory(mimeType) {
    if (mimeType?.startsWith('image/')) return 'image';
    if (mimeType?.startsWith('video/')) return 'video';
    if (mimeType?.startsWith('audio/')) return 'audio';
    return 'document';
  },

  /**
   * Get image dimensions.
   * @param {File} file - The image file.
   * @returns {Promise<Object>} Object with width and height.
   */
  getImageDimensions(file) {
    return new Promise((resolve) => {
      const img = new Image();
      img.onload = () => {
        resolve({ width: img.width, height: img.height });
        URL.revokeObjectURL(img.src);
      };
      img.onerror = () => resolve({ width: null, height: null });
      img.src = URL.createObjectURL(file);
    });
  },

  /**
   * Get video metadata.
   * @param {File} file - The video file.
   * @returns {Promise<Object>} Object with width, height, and duration.
   */
  getVideoMetadata(file) {
    return new Promise((resolve) => {
      const video = document.createElement('video');
      video.preload = 'metadata';
      video.onloadedmetadata = () => {
        resolve({
          width: video.videoWidth,
          height: video.videoHeight,
          duration: Math.floor(video.duration)
        });
        URL.revokeObjectURL(video.src);
      };
      video.onerror = () => resolve({ width: null, height: null, duration: null });
      video.src = URL.createObjectURL(file);
    });
  },

  /**
   * Get audio duration.
   * @param {File} file - The audio file.
   * @returns {Promise<number>} Duration in seconds.
   */
  getAudioDuration(file) {
    return new Promise((resolve) => {
      const audio = new Audio();
      audio.onloadedmetadata = () => {
        resolve(Math.floor(audio.duration));
        URL.revokeObjectURL(audio.src);
      };
      audio.onerror = () => resolve(null);
      audio.src = URL.createObjectURL(file);
    });
  },

  /**
   * Format file size for display.
   * @param {number} bytes - File size in bytes.
   * @returns {string} Formatted file size.
   */
  formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes?.[i];
  },

  /**
   * Validate file before upload.
   * @param {File} file - The file to validate.
   * @param {number} maxSize - Maximum file size in bytes (default 100MB).
   * @returns {Object} Validation result with isValid and error message.
   */
  validateFile(file, maxSize = 100 * 1024 * 1024) {
    if (!file) {
      return { isValid: false, error: 'No file provided' };
    }

    if (file?.size > maxSize) {
      return {
        isValid: false,
        error: `File size exceeds maximum of ${this.formatFileSize(maxSize)}`
      };
    }

    // Check for allowed file types
    const allowedTypes = [
      'image/', 'video/', 'audio/',
      'application/pdf',
      'application/msword',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      'application/vnd.ms-excel',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'text/plain'
    ];

    const isAllowed = allowedTypes?.some(type => file?.type?.startsWith(type));
    if (!isAllowed) {
      return {
        isValid: false,
        error: 'File type not supported'
      };
    }

    return { isValid: true };
  }
};