import claude from '../lib/claude';
import { supabase } from '../lib/supabase';

/**
 * Maps Anthropic API error status codes to user-friendly error messages.
 * @param {number} statusCode - The HTTP status code from Anthropic API.
 * @param {Object} errorData - The error data from API response.
 * @returns {Object} Object with isInternal flag and error message.
 */
function getErrorMessage(statusCode, errorData) {
  if (statusCode === 401) {
    return { isInternal: true, message: 'Invalid API key or authentication failed. Please check your Anthropic API key.' };
  } else if (statusCode === 403) {
    return { isInternal: true, message: 'Permission denied. Your API key does not have access to the specified resource.' };
  } else if (statusCode === 404) {
    return { isInternal: true, message: 'Resource not found. The requested endpoint or model may not exist.' };
  } else if (statusCode === 429) {
    return { isInternal: true, message: 'Rate limit exceeded. You are sending requests too quickly. Please wait a moment and try again.' };
  } else if (statusCode === 500) {
    return { isInternal: true, message: 'Anthropic service error. An unexpected error occurred on their servers. Please try again later.' };
  } else if (statusCode === 529) {
    return { isInternal: true, message: 'Anthropic service is temporarily overloaded. Please try again in a few moments.' };
  } else {
    return { isInternal: false, message: errorData?.error?.message || 'An unexpected error occurred. Please try again.' };
  }
}

/**
 * Generates context-aware quick response suggestions using Claude AI.
 * Analyzes recent conversation history and the latest message to provide relevant replies.
 * @param {string} messageContent - The message content to analyze.
 * @param {string} conversationId - The conversation/contact ID.
 * @param {string} userId - The current user's ID.
 * @returns {Promise<Array>} Array of suggested quick responses with text and type.
 */
export async function generateClaudeQuickResponses(messageContent, conversationId, userId) {
  try {
    // Fetch recent conversation context (last 10 messages)
    const { data: recentMessages } = await supabase
      ?.from('chat_messages')
      ?.select('message, sender_name, sender_id, created_at')
      ?.or(`and(sender_id.eq.${userId},recipient_id.eq.${conversationId}),and(sender_id.eq.${conversationId},recipient_id.eq.${userId})`)
      ?.order('created_at', { ascending: false })
      ?.limit(10);

    const contextMessages = recentMessages
      ?.reverse()
      ?.map(msg => `${msg?.sender_name}: ${msg?.message}`)
      ?.join('\n') || '';

    const response = await claude?.messages?.create({
      model: 'claude-sonnet-4-5-20250929',
      max_tokens: 1024,
      messages: [
        {
          role: 'user',
          content: `You are a helpful assistant that generates contextually appropriate quick reply suggestions for chat conversations.

Recent conversation:
${contextMessages}

Latest message: "${messageContent}"

Generate 3-4 short, natural responses that would be appropriate given the conversation context.
Keep responses concise (under 50 characters each), friendly, and relevant to the message content.

Respond with a JSON object in this exact format:
{
  "suggestions": [
    {"text": "response text", "type": "acknowledgment"},
    {"text": "response text", "type": "question"},
    {"text": "response text", "type": "agreement"}
  ]
}

Types can be: acknowledgment, question, agreement, emoji`
        }
      ]
    });

    const content = response?.content?.[0]?.text;
    if (!content) {
      throw new Error('No response from Claude API');
    }

    // Parse JSON from response
    const jsonMatch = content?.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      throw new Error('Invalid JSON response from Claude');
    }

    const result = JSON.parse(jsonMatch?.[0]);
    return result?.suggestions || [];
  } catch (error) {
    // Handle Anthropic API errors
    if (error?.status) {
      const errorInfo = getErrorMessage(error?.status, error);
      if (!errorInfo?.isInternal) {
        console.error('Claude API error:', error);
      }
      throw new Error(errorInfo?.message);
    }
    
    // Handle other errors
    console.error('Error generating Claude quick responses:', error);
    throw error;
  }
}

/**
 * Analyzes message sentiment and context using Claude AI.
 * Provides insights about the message tone, topics, and urgency.
 * @param {string} messageContent - The message to analyze.
 * @returns {Promise<Object>} Analysis result with sentiment, topics, and urgency.
 */
export async function analyzeMessageWithClaude(messageContent) {
  try {
    const response = await claude?.messages?.create({
      model: 'claude-haiku-4-5-20251001',
      max_tokens: 512,
      messages: [
        {
          role: 'user',
          content: `Analyze the sentiment and main topics of this message. Be concise.

Message: "${messageContent}"

Respond with a JSON object in this exact format:
{
  "sentiment": "positive" or "negative" or "neutral" or "question",
  "topics": ["topic1", "topic2"],
  "urgency": "low" or "medium" or "high"
}`
        }
      ]
    });

    const content = response?.content?.[0]?.text;
    if (!content) {
      throw new Error('No response from Claude API');
    }

    // Parse JSON from response
    const jsonMatch = content?.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      throw new Error('Invalid JSON response from Claude');
    }

    return JSON.parse(jsonMatch?.[0]);
  } catch (error) {
    // Handle Anthropic API errors
    if (error?.status) {
      const errorInfo = getErrorMessage(error?.status, error);
      if (!errorInfo?.isInternal) {
        console.error('Claude API error:', error);
      }
      throw new Error(errorInfo?.message);
    }
    
    // Handle other errors
    console.error('Error analyzing message with Claude:', error);
    throw error;
  }
}

export const claudeReplyService = {
  generateQuickResponses: generateClaudeQuickResponses,
  analyzeMessage: analyzeMessageWithClaude
};