import { supabase } from '../lib/supabase';

export const twoFactorAuthService = {
  // TOTP Secret Management
  async setupTOTP() {
    const { data: { user } } = await supabase?.auth?.getUser();
    if (!user) throw new Error('Not authenticated');

    // Generate TOTP secret
    let secret = this.generateTOTPSecret();
    
    const { data, error } = await supabase?.from('totp_secrets')?.insert({
        user_id: user?.id,
        secret_key: secret
      })?.select()?.single();

    if (error) throw error;

    return {
      secret: data?.secret_key,
      qrCodeUrl: this.generateQRCodeUrl(user?.email, secret),
      manualEntryKey: secret
    };
  },

  async verifyTOTP(token) {
    const { data: { user } } = await supabase?.auth?.getUser();
    if (!user) throw new Error('Not authenticated');

    const { data: totpData, error: fetchError } = await supabase?.from('totp_secrets')?.select('*')?.eq('user_id', user?.id)?.eq('is_verified', false)?.single();

    if (fetchError) throw fetchError;

    // In production, verify token against secret using TOTP library
    const isValid = this.verifyTOTPToken(totpData?.secret_key, token);

    if (isValid) {
      const { error: updateError } = await supabase?.from('totp_secrets')?.update({
          is_verified: true,
          verified_at: new Date()?.toISOString()
        })?.eq('id', totpData?.id);

      if (updateError) throw updateError;

      await this.logAuditEvent(user?.id, 'totp_enabled', true);
      return { success: true };
    }

    throw new Error('Invalid verification code');
  },

  async disableTOTP() {
    const { data: { user } } = await supabase?.auth?.getUser();
    if (!user) throw new Error('Not authenticated');

    const { error } = await supabase?.from('totp_secrets')?.delete()?.eq('user_id', user?.id);

    if (error) throw error;

    await this.logAuditEvent(user?.id, 'totp_disabled', true);
    return { success: true };
  },

  async getTOTPStatus() {
    const { data: { user } } = await supabase?.auth?.getUser();
    if (!user) throw new Error('Not authenticated');

    const { data, error } = await supabase?.from('totp_secrets')?.select('is_verified, created_at, verified_at')?.eq('user_id', user?.id)?.single();

    if (error && error?.code !== 'PGRST116') throw error;

    return {
      isEnabled: !!data,
      isVerified: data?.is_verified || false,
      setupDate: data?.verified_at || data?.created_at
    };
  },

  // Backup Codes Management
  async generateBackupCodes() {
    const { data: { user } } = await supabase?.auth?.getUser();
    if (!user) throw new Error('Not authenticated');

    const { data, error } = await supabase?.rpc('generate_backup_codes', {
      p_user_id: user?.id,
      p_count: 10
    });

    if (error) throw error;

    await this.logAuditEvent(user?.id, 'backup_codes_generated', true);
    return data;
  },

  async getBackupCodesStatus() {
    const { data: { user } } = await supabase?.auth?.getUser();
    if (!user) throw new Error('Not authenticated');

    const { data, error } = await supabase?.from('backup_codes')?.select('id, is_used, created_at')?.eq('user_id', user?.id);

    if (error) throw error;

    return {
      total: data?.length,
      used: data?.filter(code => code?.is_used)?.length,
      remaining: data?.filter(code => !code?.is_used)?.length
    };
  },

  async verifyBackupCode(code) {
    const { data: { user } } = await supabase?.auth?.getUser();
    if (!user) throw new Error('Not authenticated');

    const { data, error } = await supabase?.rpc('verify_backup_code', {
      p_user_id: user?.id,
      p_code: code
    });

    if (error) throw error;

    const success = data === true;
    await this.logAuditEvent(user?.id, 'backup_code_used', success);

    return { success };
  },

  // Trusted Devices Management
  async addTrustedDevice(deviceInfo) {
    const { data: { user } } = await supabase?.auth?.getUser();
    if (!user) throw new Error('Not authenticated');

    const fingerprint = this.generateDeviceFingerprint(deviceInfo);

    const { data, error } = await supabase?.from('trusted_devices')?.insert({
        user_id: user?.id,
        device_name: deviceInfo?.deviceName,
        device_fingerprint: fingerprint,
        device_type: deviceInfo?.deviceType,
        browser_info: deviceInfo?.browserInfo,
        ip_address: deviceInfo?.ipAddress,
        location: deviceInfo?.location,
        expires_at: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)?.toISOString() // 30 days
      })?.select()?.single();

    if (error) throw error;

    await this.logAuditEvent(user?.id, 'device_trusted', true, data?.id);
    return data;
  },

  async getTrustedDevices() {
    const { data: { user } } = await supabase?.auth?.getUser();
    if (!user) throw new Error('Not authenticated');

    const { data, error } = await supabase?.from('trusted_devices')?.select('*')?.eq('user_id', user?.id)?.eq('is_trusted', true)?.order('last_accessed_at', { ascending: false });

    if (error) throw error;

    return data?.map(device => ({
      id: device?.id,
      deviceName: device?.device_name,
      deviceType: device?.device_type,
      browserInfo: device?.browser_info,
      ipAddress: device?.ip_address,
      location: device?.location,
      lastAccessed: device?.last_accessed_at,
      createdAt: device?.created_at,
      expiresAt: device?.expires_at
    }));
  },

  async revokeTrustedDevice(deviceId) {
    const { data: { user } } = await supabase?.auth?.getUser();
    if (!user) throw new Error('Not authenticated');

    const { error } = await supabase?.from('trusted_devices')?.delete()?.eq('id', deviceId)?.eq('user_id', user?.id);

    if (error) throw error;

    await this.logAuditEvent(user?.id, 'device_revoked', true, deviceId);
    return { success: true };
  },

  async checkDeviceTrust(deviceFingerprint) {
    const { data: { user } } = await supabase?.auth?.getUser();
    if (!user) throw new Error('Not authenticated');

    const { data, error } = await supabase?.from('trusted_devices')?.select('id')?.eq('user_id', user?.id)?.eq('device_fingerprint', deviceFingerprint)?.eq('is_trusted', true)?.gte('expires_at', new Date()?.toISOString())?.single();

    if (error && error?.code !== 'PGRST116') throw error;

    return { isTrusted: !!data };
  },

  // Audit Log
  async getAuditLog() {
    const { data: { user } } = await supabase?.auth?.getUser();
    if (!user) throw new Error('Not authenticated');

    const { data, error } = await supabase?.from('two_fa_audit_log')?.select('*')?.eq('user_id', user?.id)?.order('created_at', { ascending: false })?.limit(50);

    if (error) throw error;

    return data?.map(log => ({
      id: log?.id,
      eventType: log?.event_type,
      success: log?.success,
      ipAddress: log?.ip_address,
      userAgent: log?.user_agent,
      metadata: log?.metadata,
      createdAt: log?.created_at
    }));
  },

  async logAuditEvent(userId, eventType, success, deviceId = null) {
    const { error } = await supabase?.from('two_fa_audit_log')?.insert({
        user_id: userId,
        event_type: eventType,
        device_id: deviceId,
        success: success,
        ip_address: await this.getClientIP(),
        user_agent: navigator.userAgent
      });

    if (error) console.error('Failed to log audit event:', error);
  },

  // Helper functions
  generateTOTPSecret() {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    let secret = '';
    for (let i = 0; i < 32; i++) {
      secret += chars?.charAt(Math.floor(Math.random() * chars?.length));
    }
    return secret;
  },

  generateQRCodeUrl(email, secret) {
    const issuer = 'WhatsApp Clone';
    const otpauth = `otpauth://totp/${encodeURIComponent(issuer)}:${encodeURIComponent(email)}?secret=${secret}&issuer=${encodeURIComponent(issuer)}`;
    return `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(otpauth)}`;
  },

  verifyTOTPToken(secret, token) {
    // In production, use authenticator library (e.g., otplib)
    // For now, simple validation
    return token && token?.length === 6 && /^\d+$/?.test(token);
  },

  generateDeviceFingerprint(deviceInfo) {
    const data = `${deviceInfo?.userAgent}-${deviceInfo?.platform}-${deviceInfo?.language}`;
    return btoa(data)?.substring(0, 64);
  },

  async getClientIP() {
    try {
      const response = await fetch('https://api.ipify.org?format=json');
      const data = await response?.json();
      return data?.ip;
    } catch {
      return 'unknown';
    }
  }
};

export default twoFactorAuthService;