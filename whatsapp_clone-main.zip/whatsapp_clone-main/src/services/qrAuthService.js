import { supabase } from '../lib/supabase';

/**
 * Generates a unique QR authentication token.
 * @returns {Promise<Object>} QR token data with ID and expiration.
 */
export async function generateQRToken() {
  try {
    const tokenId = crypto.randomUUID();
    const expiresAt = new Date(Date.now() + 5 * 60 * 1000); // 5 minutes

    const { data, error } = await supabase?.from('qr_auth_tokens')?.insert({
        id: tokenId,
        status: 'pending',
        expires_at: expiresAt?.toISOString()
      })?.select()?.single();

    if (error) throw error;

    return {
      tokenId,
      expiresAt,
      qrData: JSON.stringify({
        type: 'auth',
        tokenId,
        timestamp: Date.now()
      })
    };
  } catch (error) {
    console.error('Error generating QR token:', error);
    throw new Error('Failed to generate QR code');
  }
}

/**
 * Verifies QR token scanned by mobile device.
 * @param {string} tokenId - The QR token ID.
 * @param {string} userId - The authenticated user ID from mobile.
 * @returns {Promise<Object>} Verification result.
 */
export async function verifyQRToken(tokenId, userId) {
  try {
    // Check if token exists and is valid
    const { data: token, error: fetchError } = await supabase?.from('qr_auth_tokens')?.select('*')?.eq('id', tokenId)?.eq('status', 'pending')?.single();

    if (fetchError || !token) {
      throw new Error('Invalid or expired QR code');
    }

    // Check expiration
    if (new Date(token.expires_at) < new Date()) {
      await supabase?.from('qr_auth_tokens')?.update({ status: 'expired' })?.eq('id', tokenId);
      throw new Error('QR code has expired');
    }

    // Update token with user info
    const { error: updateError } = await supabase?.from('qr_auth_tokens')?.update({
        status: 'verified',
        user_id: userId,
        verified_at: new Date()?.toISOString()
      })?.eq('id', tokenId);

    if (updateError) throw updateError;

    return { success: true, userId };
  } catch (error) {
    console.error('Error verifying QR token:', error);
    throw error;
  }
}

/**
 * Polls for QR token verification status.
 * @param {string} tokenId - The QR token ID to check.
 * @returns {Promise<Object>} Token status and user data if verified.
 */
export async function checkQRTokenStatus(tokenId) {
  try {
    const { data, error } = await supabase?.from('qr_auth_tokens')?.select('*, profiles(id, email, full_name, avatar_url)')?.eq('id', tokenId)?.single();

    if (error) throw error;

    return {
      status: data?.status,
      userId: data?.user_id,
      profile: data?.profiles,
      expiresAt: data?.expires_at
    };
  } catch (error) {
    console.error('Error checking QR token status:', error);
    throw error;
  }
}

/**
 * Creates authenticated session after QR verification.
 * @param {string} userId - The verified user ID.
 * @returns {Promise<Object>} Session data.
 */
export async function createQRSession(userId) {
  try {
    // Get user profile
    const { data: profile, error: profileError } = await supabase?.from('profiles')?.select('*')?.eq('id', userId)?.single();

    if (profileError) throw profileError;

    // Create session token
    const sessionToken = crypto.randomUUID();
    
    return {
      sessionToken,
      user: profile,
      expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000) // 24 hours
    };
  } catch (error) {
    console.error('Error creating QR session:', error);
    throw error;
  }
}

/**
 * Cleans up expired QR tokens.
 */
export async function cleanupExpiredTokens() {
  try {
    await supabase?.from('qr_auth_tokens')?.delete()?.lt('expires_at', new Date()?.toISOString());
  } catch (error) {
    console.error('Error cleaning up expired tokens:', error);
  }
}

export const qrAuthService = {
  generateQRToken,
  verifyQRToken,
  checkQRTokenStatus,
  createQRSession,
  cleanupExpiredTokens
};