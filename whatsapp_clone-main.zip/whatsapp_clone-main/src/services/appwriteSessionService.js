import { account } from '../lib/appwrite';
import UAParser from 'ua-parser-js';
import { supabase } from '../lib/supabase';

/**
 * Appwrite Session Tracking Service
 * Handles comprehensive session management with device information,
 * login location history, and individual device revocation controls
 */

const appwriteSessionService = {
  /**
   * Get device information from user agent
   * @returns {Object} - Device fingerprint data
   */
  getDeviceInfo() {
    const parser = new UAParser();
    const result = parser?.getResult();
    
    return {
      browser: `${result?.browser?.name || 'Unknown'} ${result?.browser?.version || ''}`?.trim(),
      os: `${result?.os?.name || 'Unknown'} ${result?.os?.version || ''}`?.trim(),
      device: result?.device?.model || result?.device?.type || 'Desktop',
      deviceType: result?.device?.type || 'desktop',
      userAgent: navigator?.userAgent
    };
  },

  /**
   * Get approximate location from IP address using ipapi.co
   * @returns {Promise<Object>} - Location data
   */
  async getLocationInfo() {
    try {
      const response = await fetch('https://ipapi.co/json/');
      const data = await response?.json();
      
      return {
        ip: data?.ip || 'Unknown',
        city: data?.city || 'Unknown',
        region: data?.region || '',
        country: data?.country_name || 'Unknown',
        countryCode: data?.country_code || '',
        latitude: data?.latitude || null,
        longitude: data?.longitude || null,
        timezone: data?.timezone || '',
        isp: data?.org || 'Unknown'
      };
    } catch (error) {
      console.error('Failed to get location:', error);
      return {
        ip: 'Unknown',
        city: 'Unknown',
        country: 'Unknown',
        latitude: null,
        longitude: null
      };
    }
  },

  /**
   * Get all active sessions from Appwrite
   * @returns {Promise<Object>} - List of sessions with metadata
   */
  async getAllSessions() {
    try {
      const sessions = await account?.listSessions();
      
      // Enrich sessions with stored metadata from Supabase
      const enrichedSessions = await Promise.all(
        sessions?.sessions?.map(async (session) => {
          // Try to get stored session metadata
          const { data: metadata } = await supabase?.from('session_history')?.select('*')?.eq('session_id', session?.$id)?.order('created_at', { ascending: false })?.limit(1)?.single();
          
          return {
            id: session?.$id,
            provider: session?.provider,
            createdAt: session?.$createdAt,
            current: session?.current || false,
            deviceInfo: metadata?.device_info || {},
            locationInfo: metadata?.location_info || {},
            ipAddress: metadata?.ip_address || 'Unknown',
            lastActive: metadata?.last_active || session?.$createdAt,
            trustStatus: metadata?.trust_status || 'unknown',
            riskScore: metadata?.risk_score || 0
          };
        })
      );
      
      return {
        success: true,
        sessions: enrichedSessions,
        total: sessions?.total || 0
      };
    } catch (error) {
      console.error('Failed to get sessions:', error);
      return {
        success: false,
        error: error?.message || 'Failed to retrieve sessions',
        sessions: []
      };
    }
  },

  /**
   * Track session creation with device and location info
   * Called after successful authentication
   * @param {string} sessionId - Appwrite session ID
   * @param {string} userId - User ID
   * @returns {Promise<Object>} - Tracking result
   */
  async trackSessionCreation(sessionId, userId) {
    try {
      const deviceInfo = this.getDeviceInfo();
      const locationInfo = await this.getLocationInfo();
      
      // Store session metadata in Supabase
      const { data, error } = await supabase?.from('session_history')?.insert({
          session_id: sessionId,
          user_id: userId,
          device_info: deviceInfo,
          location_info: locationInfo,
          ip_address: locationInfo?.ip,
          trust_status: 'trusted',
          risk_score: 0,
          last_active: new Date()?.toISOString()
        })?.select()?.single();
      
      if (error) throw error;
      
      return {
        success: true,
        data
      };
    } catch (error) {
      console.error('Failed to track session:', error);
      return {
        success: false,
        error: error?.message
      };
    }
  },

  /**
   * Update last active timestamp for current session
   * @param {string} sessionId - Session ID to update
   * @returns {Promise<Object>} - Update result
   */
  async updateLastActive(sessionId) {
    try {
      const { error } = await supabase?.from('session_history')?.update({ last_active: new Date()?.toISOString() })?.eq('session_id', sessionId);
      
      if (error) throw error;
      
      return { success: true };
    } catch (error) {
      console.error('Failed to update last active:', error);
      return { success: false, error: error?.message };
    }
  },

  /**
   * Revoke a specific session (device)
   * @param {string} sessionId - Session ID to revoke
   * @returns {Promise<Object>} - Revocation result
   */
  async revokeSession(sessionId) {
    try {
      await account?.deleteSession(sessionId);
      
      // Mark as revoked in Supabase
      await supabase?.from('session_history')?.update({ 
          revoked_at: new Date()?.toISOString(),
          trust_status: 'revoked'
        })?.eq('session_id', sessionId);
      
      return {
        success: true,
        message: 'Session terminated successfully'
      };
    } catch (error) {
      console.error('Failed to revoke session:', error);
      return {
        success: false,
        error: error?.message || 'Failed to terminate session'
      };
    }
  },

  /**
   * Revoke multiple sessions at once
   * @param {Array<string>} sessionIds - Array of session IDs to revoke
   * @returns {Promise<Object>} - Bulk revocation result
   */
  async revokeBulkSessions(sessionIds) {
    try {
      const results = await Promise.allSettled(
        sessionIds?.map(id => this.revokeSession(id))
      );
      
      const successful = results?.filter(r => r?.status === 'fulfilled' && r?.value?.success);
      const failed = results?.filter(r => r?.status === 'rejected' || !r?.value?.success);
      
      return {
        success: true,
        revoked: successful?.length,
        failed: failed?.length,
        total: sessionIds?.length
      };
    } catch (error) {
      console.error('Bulk revocation failed:', error);
      return {
        success: false,
        error: error?.message
      };
    }
  },

  /**
   * Emergency lockout - revoke ALL sessions except current
   * @returns {Promise<Object>} - Lockout result
   */
  async emergencyLockout() {
    try {
      const { sessions } = await this.getAllSessions();
      const otherSessions = sessions?.filter(s => !s?.current);
      
      if (otherSessions?.length === 0) {
        return {
          success: true,
          message: 'No other sessions to revoke'
        };
      }
      
      const result = await this.revokeBulkSessions(
        otherSessions?.map(s => s?.id)
      );
      
      return {
        success: true,
        message: `Revoked ${result?.revoked} sessions`,
        ...result
      };
    } catch (error) {
      console.error('Emergency lockout failed:', error);
      return {
        success: false,
        error: error?.message
      };
    }
  },

  /**
   * Get login location history for a user
   * @param {string} userId - User ID
   * @param {number} limit - Number of records to fetch
   * @returns {Promise<Object>} - Location history
   */
  async getLoginHistory(userId, limit = 50) {
    try {
      const { data, error } = await supabase?.from('session_history')?.select('*')?.eq('user_id', userId)?.order('created_at', { ascending: false })?.limit(limit);
      
      if (error) throw error;
      
      return {
        success: true,
        history: data || [],
        total: data?.length || 0
      };
    } catch (error) {
      console.error('Failed to get login history:', error);
      return {
        success: false,
        error: error?.message,
        history: []
      };
    }
  },

  /**
   * Analyze suspicious login patterns
   * @param {Array} history - Login history array
   * @returns {Object} - Security analysis
   */
  analyzeSuspiciousActivity(history) {
    const alerts = [];
    
    // Check for rapid location changes (impossible travel)
    for (let i = 0; i < history?.length - 1; i++) {
      const current = history?.[i];
      const previous = history?.[i + 1];
      
      if (current?.location_info?.city && previous?.location_info?.city) {
        if (current?.location_info?.city !== previous?.location_info?.city) {
          const timeDiff = new Date(current?.created_at) - new Date(previous?.created_at);
          const hoursDiff = timeDiff / (1000 * 60 * 60);
          
          // If location changed in less than 1 hour, flag as suspicious
          if (hoursDiff < 1) {
            alerts?.push({
              type: 'impossible_travel',
              severity: 'high',
              message: `Login from ${current?.location_info?.city} shortly after ${previous?.location_info?.city}`,
              timestamp: current?.created_at
            });
          }
        }
      }
    }
    
    // Check for unusual devices
    const deviceTypes = history?.map(h => h?.device_info?.deviceType);
    const uniqueDevices = [...new Set(deviceTypes)];
    
    if (uniqueDevices?.length > 5) {
      alerts?.push({
        type: 'multiple_devices',
        severity: 'medium',
        message: `Account accessed from ${uniqueDevices?.length} different device types`,
        timestamp: new Date()?.toISOString()
      });
    }
    
    return {
      alerts,
      riskLevel: alerts?.length > 2 ? 'high' : alerts?.length > 0 ? 'medium' : 'low'
    };
  },

  /**
   * Get session analytics
   * @param {string} userId - User ID
   * @returns {Promise<Object>} - Session analytics data
   */
  async getSessionAnalytics(userId) {
    try {
      const { history } = await this.getLoginHistory(userId, 100);
      
      // Device usage trends
      const deviceCounts = {};
      const locationCounts = {};
      const browserCounts = {};
      
      history?.forEach(session => {
        const device = session?.device_info?.device || 'Unknown';
        const location = session?.location_info?.city || 'Unknown';
        const browser = session?.device_info?.browser || 'Unknown';
        
        deviceCounts[device] = (deviceCounts?.[device] || 0) + 1;
        locationCounts[location] = (locationCounts?.[location] || 0) + 1;
        browserCounts[browser] = (browserCounts?.[browser] || 0) + 1;
      });
      
      // Login patterns by time
      const loginsByHour = Array(24)?.fill(0);
      history?.forEach(session => {
        const hour = new Date(session?.created_at)?.getHours();
        loginsByHour[hour]++;
      });
      
      return {
        success: true,
        analytics: {
          totalLogins: history?.length,
          uniqueDevices: Object.keys(deviceCounts)?.length,
          uniqueLocations: Object.keys(locationCounts)?.length,
          deviceBreakdown: deviceCounts,
          locationBreakdown: locationCounts,
          browserBreakdown: browserCounts,
          loginPatternsByHour: loginsByHour,
          mostUsedDevice: Object.keys(deviceCounts)?.reduce((a, b) => 
            deviceCounts?.[a] > deviceCounts?.[b] ? a : b, 'Unknown'
          ),
          mostCommonLocation: Object.keys(locationCounts)?.reduce((a, b) => 
            locationCounts?.[a] > locationCounts?.[b] ? a : b, 'Unknown'
          )
        }
      };
    } catch (error) {
      console.error('Failed to get analytics:', error);
      return {
        success: false,
        error: error?.message
      };
    }
  }
};

export default appwriteSessionService;