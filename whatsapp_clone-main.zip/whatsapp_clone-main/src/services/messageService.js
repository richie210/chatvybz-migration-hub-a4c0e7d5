import { supabase } from '../lib/supabase';
import { encryptionService } from './encryptionService';
import { offlineStorageService } from './offlineStorageService';
import { connectionMonitor } from '../utils/connectionMonitor';
import { realtimeService } from './realtimeService';

export const messageService = {
  initialized: false,

  // Initialize encryption keys
  async initialize() {
    if (this.initialized) return;

    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) return;

      // Try to load existing keys from storage
      const storedKeys = await offlineStorageService?.getEncryptionKeys();
      
      if (storedKeys) {
        // Load existing keys
        encryptionService?.loadKeyPair(storedKeys?.publicKey, storedKeys?.privateKey);
      } else {
        // Generate new keys for first-time users
        const keys = encryptionService?.generateKeyPair();
        await offlineStorageService?.storeEncryptionKeys(keys?.publicKey, keys?.privateKey);
        
        // Store public key in user profile
        await supabase?.from('users')?.update({
          public_key: keys?.publicKey
        })?.eq('id', user?.id);
      }

      // Load recipient public keys from storage
      const recipientKeys = await offlineStorageService?.getAllRecipientPublicKeys();
      Object.entries(recipientKeys)?.forEach(([recipientId, publicKey]) => {
        encryptionService?.addRecipientPublicKey(recipientId, publicKey);
      });

      this.initialized = true;

      // Set up connection monitor to process queue when online
      connectionMonitor?.subscribe(async (status) => {
        if (status?.isOnline && status?.event === 'online') {
          await this.processMessageQueue();
        }
      });

    } catch (error) {
      console.error('Error initializing message service:', error);
    }
  },

  // Get or fetch recipient's public key
  async getRecipientPublicKey(recipientId) {
    // Check if we already have it
    let publicKey = await offlineStorageService?.getRecipientPublicKey(recipientId);
    
    if (!publicKey) {
      // Fetch from database
      const { data, error } = await supabase?.from('users')?.select('public_key')?.eq('id', recipientId)?.single();
      
      if (!error && data?.public_key) {
        publicKey = data?.public_key;
        // Store for future use
        await offlineStorageService?.storeRecipientPublicKey(recipientId, publicKey);
        encryptionService?.addRecipientPublicKey(recipientId, publicKey);
      }
    } else {
      // Add to encryption service if not already there
      encryptionService?.addRecipientPublicKey(recipientId, publicKey);
    }
    
    return publicKey;
  },

  // Get messages for a conversation
  async getMessages(contactId) {
    await this.initialize();

    // Get current authenticated user
    const { data: { user } } = await supabase?.auth?.getUser();
    if (!user) throw new Error('Not authenticated');

    // Fetch messages between current user and the contact
    const { data, error } = await supabase
      ?.from('chat_messages')
      ?.select(`
        *,
        sender:sender_id(id, full_name, avatar_url, public_key),
        recipient:recipient_id(id, full_name, avatar_url, public_key)
      `)
      ?.or(`and(sender_id.eq.${user?.id},recipient_id.eq.${contactId}),and(sender_id.eq.${contactId},recipient_id.eq.${user?.id})`)
      ?.order('created_at', { ascending: true });
    
    if (error) throw error;
    
    return data?.map(msg => {
      let decryptedContent = msg?.message;
      
      // Decrypt if message is encrypted
      if (msg?.is_encrypted && msg?.nonce) {
        try {
          const senderPublicKey = msg?.sender?.public_key;
          decryptedContent = encryptionService?.decryptMessage(
            { encryptedMessage: msg?.message, nonce: msg?.nonce },
            senderPublicKey
          );
        } catch (error) {
          console.error('Error decrypting message:', error);
          decryptedContent = '[Encrypted message - decryption failed]';
        }
      }

      return {
        id: msg?.id,
        type: 'text',
        content: decryptedContent,
        timestamp: new Date(msg.created_at),
        status: msg?.status,
        deliveredAt: msg?.delivered_at ? new Date(msg.delivered_at) : null,
        readAt: msg?.read_at ? new Date(msg.read_at) : null,
        isSent: msg?.sender_id === user?.id,
        isEncrypted: msg?.is_encrypted || false,
        sender: {
          id: msg?.sender?.id,
          name: msg?.sender?.full_name,
          avatar: msg?.sender?.avatar_url
        }
      };
    });
  },

  /**
   * Get messages with thread information
   * @param {string} contactId - Contact/recipient user ID
   * @param {boolean} includeThreads - Whether to include thread messages
   * @returns {Promise<Array>} Messages with thread data
   */
  async getMessagesWithThreads(contactId, includeThreads = false) {
    await this.initialize();

    // Get current authenticated user
    const { data: { user } } = await supabase?.auth?.getUser();
    if (!user) throw new Error('Not authenticated');

    let query = supabase
      ?.from('chat_messages')
      ?.select(`
        *,
        sender:sender_id(id, full_name, avatar_url, public_key),
        recipient:recipient_id(id, full_name, avatar_url, public_key)
      `)
      ?.or(`and(sender_id.eq.${user?.id},recipient_id.eq.${contactId}),and(sender_id.eq.${contactId},recipient_id.eq.${user?.id})`);

    // Exclude threaded replies from main list unless includeThreads is true
    if (!includeThreads) {
      query = query?.is('parent_message_id', null);
    }

    query = query?.order('created_at', { ascending: true });

    const { data, error } = await query;

    if (error) throw error;

    return data?.map(msg => {
      let decryptedContent = msg?.message;

      // Decrypt if message is encrypted
      if (msg?.is_encrypted && msg?.nonce) {
        try {
          const senderPublicKey = msg?.sender?.public_key;
          decryptedContent = encryptionService?.decryptMessage(
            { encryptedMessage: msg?.message, nonce: msg?.nonce },
            senderPublicKey
          );
        } catch (error) {
          console.error('Error decrypting message:', error);
          decryptedContent = '[Encrypted message - decryption failed]';
        }
      }

      return {
        id: msg?.id,
        type: 'text',
        content: decryptedContent,
        timestamp: new Date(msg.created_at),
        status: msg?.status,
        deliveredAt: msg?.delivered_at ? new Date(msg.delivered_at) : null,
        readAt: msg?.read_at ? new Date(msg.read_at) : null,
        isSent: msg?.sender_id === user?.id,
        isEncrypted: msg?.is_encrypted || false,
        // Thread information
        parentMessageId: msg?.parent_message_id,
        threadId: msg?.thread_id,
        replyCount: msg?.reply_count || 0,
        isThreadRoot: msg?.is_thread_root || false,
        sender: {
          id: msg?.sender?.id,
          name: msg?.sender?.full_name,
          avatar: msg?.sender?.avatar_url
        }
      };
    });
  },

  /**
   * Send a message (text or audio)
   */
  async sendMessage(receiverId, content, options = {}) {
    try {
      await this.initialize();

      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      // Get recipient's public key
      const recipientPublicKey = await this.getRecipientPublicKey(receiverId);
      
      if (!recipientPublicKey) {
        throw new Error('Recipient public key not found. Cannot encrypt message.');
      }

      // Encrypt the message
      const encryptedData = encryptionService?.encryptMessage(content, receiverId);

      const messageData = {
        sender_id: user?.id,
        recipient_id: receiverId,
        message: encryptedData?.encryptedMessage || content,
        message_type: options?.messageType || 'text',
        status: 'sent',
        is_encrypted: !!encryptedData?.encryptedMessage,
        nonce: encryptedData?.nonce || null,
        // Audio-specific fields
        audio_url: options?.audioUrl || null,
        audio_duration: options?.audioDuration || null,
        audio_waveform: options?.audioWaveform || null
      };

      // Check if online
      if (!connectionMonitor?.getStatus()?.isOnline) {
        // Queue message for later
        const queueId = await offlineStorageService?.queueMessage({
          ...messageData,
          originalMessage: content,
          recipientId: receiverId,
          messageType: options?.messageType || 'text'
        });

        return {
          success: true,
          message: {
            id: queueId,
            type: options?.messageType || 'text',
            content: content,
            timestamp: new Date(),
            status: 'queued',
            isSent: true,
            isEncrypted: !!encryptedData?.encryptedMessage
          }
        };
      }

      // Send immediately if online
      const { data, error } = await supabase?.from('chat_messages')?.insert(messageData)?.select()?.single();
      
      if (error) throw error;
      
      return {
        success: true,
        message: {
          id: data?.id,
          type: options?.messageType || 'text',
          content: content,
          timestamp: new Date(data.created_at),
          status: data?.status,
          isSent: true,
          isEncrypted: !!encryptedData?.encryptedMessage
        }
      };
    } catch (error) {
      // Queue message on error
      const queueId = await offlineStorageService?.queueMessage({
        sender_id: user?.id,
        recipient_id: receiverId,
        originalMessage: content,
        messageType: options?.messageType || 'text',
        error: error?.message
      });

      return {
        success: false,
        message: {
          id: queueId,
          type: options?.messageType || 'text',
          content: content,
          timestamp: new Date(),
          status: 'queued',
          isSent: true,
          isEncrypted: true
        }
      };
    }
  },

  // Process queued messages
  async processMessageQueue() {
    const queuedMessages = await offlineStorageService?.getQueuedMessages();
    
    if (queuedMessages?.length === 0) return;

    console.log(`Processing ${queuedMessages?.length} queued messages...`);

    for (const queuedMsg of queuedMessages) {
      try {
        // Check if already encrypted or needs encryption
        let messagePayload;
        
        if (queuedMsg?.is_encrypted) {
          messagePayload = queuedMsg;
        } else {
          // Encrypt message if not already encrypted
          const recipientPublicKey = await this.getRecipientPublicKey(queuedMsg?.recipient_id);
          if (!recipientPublicKey) {
            console.error('Cannot process message - recipient public key not found');
            continue;
          }

          const encryptedData = encryptionService?.encryptMessage(
            queuedMsg?.originalMessage,
            queuedMsg?.recipient_id
          );

          messagePayload = {
            sender_id: queuedMsg?.sender_id,
            recipient_id: queuedMsg?.recipient_id,
            message: encryptedData?.encryptedMessage,
            nonce: encryptedData?.nonce,
            is_encrypted: true,
            status: 'sent',
            is_private: true
          };
        }

        // Attempt to send
        const { data, error } = await supabase?.from('chat_messages')?.insert(messagePayload)?.select()?.single();

        if (error) {
          // Update retry count
          await offlineStorageService?.updateQueuedMessage(queuedMsg?.queueId, {
            retryCount: (queuedMsg?.retryCount || 0) + 1,
            lastError: error?.message
          });
          console.error('Error sending queued message:', error);
        } else {
          // Success - remove from queue
          await offlineStorageService?.removeFromQueue(queuedMsg?.queueId);
          console.log('Successfully sent queued message:', data?.id);
        }
      } catch (error) {
        console.error('Error processing queued message:', error);
      }
    }
  },

  // Update message status (delivered/read)
  async updateMessageStatus(messageId, status) {
    const { error } = await supabase?.rpc('update_message_status', {
      message_uuid: messageId,
      new_status: status
    });
    
    if (error) throw error;
  },

  // Mark messages as read
  async markMessagesAsRead(messageIds) {
    for (const messageId of messageIds) {
      await this.updateMessageStatus(messageId, 'read');
    }
  },

  // Subscribe to real-time message updates
  async subscribeToMessages(contactId, onMessage) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) {
        console.warn('No authenticated user found for message subscription');
        return () => {};
      }

      const channel = supabase?.channel(`messages:${user?.id}-${contactId}`)?.on(
          'postgres_changes',
          {
            event: '*',
            schema: 'public',
            table: 'chat_messages',
            filter: `or(and(sender_id.eq.${user?.id},recipient_id.eq.${contactId}),and(sender_id.eq.${contactId},recipient_id.eq.${user?.id}))`
          },
          async (payload) => {
            if (payload?.eventType === 'INSERT') {
              let decryptedContent = payload?.new?.message;
              
              // Decrypt if encrypted
              if (payload?.new?.is_encrypted && payload?.new?.nonce) {
                try {
                  // Fetch sender's public key if needed
                  const { data: senderData } = await supabase?.from('users')?.select('public_key')?.eq('id', payload?.new?.sender_id)?.single();
                  
                  if (senderData?.public_key) {
                    decryptedContent = encryptionService?.decryptMessage(
                      { 
                        encryptedMessage: payload?.new?.message, 
                        nonce: payload?.new?.nonce 
                      },
                      senderData?.public_key
                    );
                  }
                } catch (error) {
                  console.error('Error decrypting real-time message:', error);
                  decryptedContent = '[Encrypted message]';
                }
              }

              onMessage({
                type: 'new',
                message: {
                  id: payload?.new?.id,
                  type: 'text',
                  content: decryptedContent,
                  timestamp: new Date(payload.new.created_at),
                  status: payload?.new?.status,
                  isSent: payload?.new?.sender_id === user?.id,
                  isEncrypted: payload?.new?.is_encrypted || false
                }
              });
            } else if (payload?.eventType === 'UPDATE') {
              onMessage({
                type: 'update',
                message: {
                  id: payload?.new?.id,
                  status: payload?.new?.status,
                  deliveredAt: payload?.new?.delivered_at ? new Date(payload.new.delivered_at) : null,
                  readAt: payload?.new?.read_at ? new Date(payload.new.read_at) : null
                }
              });
            }
          }
        )?.subscribe();
      
      return () => {
        supabase?.removeChannel(channel);
      };
    } catch (error) {
      console.error('Error setting up message subscription:', error);
      return () => {};
    }
  },

  // Delete a message
  async deleteMessage(messageId) {
    const { error } = await supabase?.from('chat_messages')?.delete()?.eq('id', messageId);
    
    if (error) throw error;
  },

  /**
   * Edit a message
   * @param {string} messageId - Message ID to edit
   * @param {string} newContent - New message content
   * @returns {Promise<Object>} - Edit result
   */
  async editMessage(messageId, newContent) {
    try {
      const { data, error } = await supabase?.rpc('edit_message', {
          message_uuid: messageId,
          new_content: newContent
        });

      if (error) throw error;

      if (!data?.success) {
        throw new Error(data?.error || 'Failed to edit message');
      }

      return {
        success: true,
        message: 'Message edited successfully'
      };
    } catch (error) {
      console.error('Edit message error:', error);
      throw error;
    }
  },

  /**
   * Check if message can be edited
   * @param {string} messageId - Message ID
   * @returns {Promise<boolean>} - True if message can be edited
   */
  async canEditMessage(messageId) {
    try {
      const { data, error } = await supabase?.rpc('can_edit_message', {
          message_uuid: messageId,
          edit_window_minutes: 15
        });

      if (error) throw error;
      return data || false;
    } catch (error) {
      console.error('Check edit permission error:', error);
      return false;
    }
  },

  /**
   * Delete message with visibility controls
   * @param {string} messageId - Message ID to delete
   * @param {boolean} deleteForEveryone - Delete for everyone or just current user
   * @returns {Promise<Object>} - Delete result
   */
  async deleteMessageWithVisibility(messageId, deleteForEveryone = false) {
    try {
      const { data, error } = await supabase?.rpc('delete_message_with_visibility', {
          message_uuid: messageId,
          delete_for_everyone: deleteForEveryone
        });

      if (error) throw error;

      if (!data?.success) {
        throw new Error(data?.error || 'Failed to delete message');
      }

      return {
        success: true,
        message: data?.message
      };
    } catch (error) {
      console.error('Delete message error:', error);
      throw error;
    }
  },

  /**
   * Toggle reaction on a message
   * @param {string} messageId - Message ID
   * @param {string} emoji - Reaction emoji
   * @returns {Promise<Object>} - Toggle result
   */
  async toggleReaction(messageId, emoji) {
    try {
      const { data, error } = await supabase?.rpc('toggle_reaction', {
          message_uuid: messageId,
          reaction_emoji: emoji
        });

      if (error) throw error;

      if (!data?.success) {
        throw new Error(data?.error || 'Failed to toggle reaction');
      }

      return {
        success: true,
        action: data?.action,
        emoji: data?.emoji
      };
    } catch (error) {
      console.error('Toggle reaction error:', error);
      throw error;
    }
  },

  /**
   * Get message reactions with user details
   * @param {string} messageId - Message ID
   * @returns {Promise<Array>} - Array of reactions with user details
   */
  async getMessageReactions(messageId) {
    try {
      const { data, error } = await supabase?.rpc('get_message_reactions', {
          message_uuid: messageId
        });

      if (error) throw error;
      return data || [];
    } catch (error) {
      console.error('Get reactions error:', error);
      return [];
    }
  },

  /**
   * Get audio message URL with signed access
   */
  async getAudioUrl(audioPath) {
    try {
      if (!audioPath) return null;

      const { data, error } = await supabase?.storage?.from('audio-messages')?.createSignedUrl(audioPath, 3600); // 1 hour expiry

      if (error) throw error;

      return data?.signedUrl;
    } catch (error) {
      console.error('Error getting audio URL:', error);
      return null;
    }
  },

  /**
   * Add a reaction to a message
   * @param {string} messageId - Message ID
   * @param {string} emoji - Reaction emoji
   * @param {string} userId - User ID adding the reaction
   * @returns {Promise<Object>} - Add reaction result
   */
  async addMessageReaction(messageId, emoji, userId) {
    try {
      const { data, error } = await supabase
        ?.from('message_reactions')
        ?.insert({
          message_id: messageId,
          user_id: userId,
          emoji: emoji
        })
        ?.select()
        ?.single();

      if (error) {
        // Check if this is a duplicate reaction (user already reacted with this emoji)
        if (error?.code === '23505') {
          // Remove the reaction instead
          return await this.removeMessageReaction(messageId, emoji, userId);
        }
        throw error;
      }

      return {
        success: true,
        action: 'added',
        reaction: data
      };
    } catch (error) {
      console.error('Add reaction error:', error);
      return {
        success: false,
        error: error?.message
      };
    }
  },

  /**
   * Remove a reaction from a message
   * @param {string} messageId - Message ID
   * @param {string} emoji - Reaction emoji
   * @param {string} userId - User ID removing the reaction
   * @returns {Promise<Object>} - Remove reaction result
   */
  async removeMessageReaction(messageId, emoji, userId) {
    try {
      const { error } = await supabase
        ?.from('message_reactions')
        ?.delete()
        ?.eq('message_id', messageId)
        ?.eq('user_id', userId)
        ?.eq('emoji', emoji);

      if (error) throw error;

      return {
        success: true,
        action: 'removed'
      };
    } catch (error) {
      console.error('Remove reaction error:', error);
      return {
        success: false,
        error: error?.message
      };
    }
  },

  /**
   * Get reactions for a message with user details
   * @param {string} messageId - Message ID
   * @returns {Promise<Array>} - Array of reactions grouped by emoji with user details
   */
  async getReactionsForMessage(messageId) {
    try {
      const { data, error } = await supabase
        ?.from('message_reactions')
        ?.select(`
          id,
          emoji,
          created_at,
          user:user_id (
            id,
            full_name,
            avatar_url
          )
        `)
        ?.eq('message_id', messageId)
        ?.order('created_at', { ascending: true });

      if (error) throw error;

      // Group reactions by emoji
      const groupedReactions = {};
      
      data?.forEach(reaction => {
        if (!groupedReactions?.[reaction?.emoji]) {
          groupedReactions[reaction?.emoji] = {
            emoji: reaction?.emoji,
            count: 0,
            users: []
          };
        }
        groupedReactions[reaction?.emoji].count++;
        groupedReactions?.[reaction?.emoji]?.users?.push({
          id: reaction?.user?.id,
          name: reaction?.user?.full_name,
          avatar: reaction?.user?.avatar_url
        });
      });

      return Object.values(groupedReactions);
    } catch (error) {
      console.error('Get reactions error:', error);
      return [];
    }
  },

  /**
   * Retry sending a queued message
   * @param {string} queueId - Queue ID of the message to retry
   * @returns {Promise<Object>} - Retry result
   */
  async retryQueuedMessage(queueId) {
    try {
      const queuedMessages = await offlineStorageService?.getQueuedMessages();
      const message = queuedMessages?.find(m => m?.queueId === queueId);

      if (!message) {
        throw new Error('Queued message not found');
      }

      // Get recipient's public key
      const recipientPublicKey = await this.getRecipientPublicKey(message?.recipient_id);
      
      if (!recipientPublicKey) {
        throw new Error('Recipient public key not found. Cannot encrypt message.');
      }

      // Encrypt the message
      const encryptedData = encryptionService?.encryptMessage(
        message?.originalMessage,
        message?.recipient_id
      );

      const messageData = {
        sender_id: message?.sender_id,
        recipient_id: message?.recipient_id,
        message: encryptedData?.encryptedMessage,
        nonce: encryptedData?.nonce,
        is_encrypted: true,
        status: 'sent'
      };

      // Attempt to send
      const { data, error } = await supabase
        ?.from('chat_messages')
        ?.insert(messageData)
        ?.select()
        ?.single();

      if (error) throw error;

      // Remove from queue on success
      await offlineStorageService?.removeFromQueue(queueId);

      return {
        success: true,
        message: {
          id: data?.id,
          status: 'sent'
        }
      };
    } catch (error) {
      console.error('Retry message error:', error);
      
      // Update retry count
      await offlineStorageService?.updateQueuedMessage(queueId, {
        retryCount: (message?.retryCount || 0) + 1,
        lastError: error?.message
      });

      return {
        success: false,
        error: error?.message
      };
    }
  },

  /**
   * Subscribe to message delivery status updates
   * @param {string} messageId - Message ID to watch
   * @param {Function} onStatusUpdate - Callback when status changes
   * @returns {Function} Cleanup function
   */
  subscribeToDeliveryStatus(messageId, onStatusUpdate) {
    const channelName = realtimeService?.subscribeToDeliveryStatus(
      messageId,
      (updatedMessage) => {
        if (onStatusUpdate) {
          onStatusUpdate({
            id: updatedMessage?.id,
            status: updatedMessage?.status,
            delivered_at: updatedMessage?.delivered_at,
            read_at: updatedMessage?.read_at
          });
        }
      }
    );

    return () => {
      realtimeService?.unsubscribe(channelName);
    };
  },

  /**
   * Subscribe to new messages in a conversation
   * @param {string} conversationId - Conversation ID
   * @param {Function} onNewMessage - Callback when new message arrives
   * @returns {Function} Cleanup function
   */
  subscribeToNewMessages(conversationId, onNewMessage) {
    const channelName = realtimeService?.subscribeToMessages(
      conversationId,
      async (newMessage) => {
        // Decrypt message if encrypted
        let decryptedContent = newMessage?.message;
        
        if (newMessage?.is_encrypted && newMessage?.nonce) {
          try {
            const { data: sender } = await supabase
              ?.from('users')
              ?.select('public_key')
              ?.eq('id', newMessage?.sender_id)
              ?.single();
            
            if (sender?.public_key) {
              decryptedContent = encryptionService?.decryptMessage(
                { encryptedMessage: newMessage?.message, nonce: newMessage?.nonce },
                sender?.public_key
              );
            }
          } catch (error) {
            console.error('Error decrypting message:', error);
            decryptedContent = '[Encrypted message - decryption failed]';
          }
        }

        if (onNewMessage) {
          onNewMessage({
            id: newMessage?.id,
            content: decryptedContent,
            timestamp: new Date(newMessage?.created_at),
            status: newMessage?.status,
            isSent: false,
            isEncrypted: newMessage?.is_encrypted || false,
            sender: {
              id: newMessage?.sender_id
            }
          });
        }
      }
    );

    return () => {
      realtimeService?.unsubscribe(channelName);
    };
  }
};