// WebRTC service for peer-to-peer voice and video calling
import SimplePeer from 'simple-peer';
import { supabase } from '../lib/supabase';

class WebRTCService {
  constructor() {
    this.peer = null;
    this.localStream = null;
    this.remoteStream = null;
    this.channel = null;
    this.isRecording = false;
    this.mediaRecorder = null;
    this.recordedChunks = [];
  }

  // Initialize local media stream
  async initializeLocalStream(isVideo = false) {
    try {
      this.localStream = await navigator.mediaDevices?.getUserMedia({
        video: isVideo,
        audio: true
      });
      return this.localStream;
    } catch (error) {
      console.error('Error accessing media devices:', error);
      throw new Error('Could not access camera/microphone');
    }
  }

  // Create peer connection (initiator)
  async createPeerConnection(callId, isVideo = false) {
    await this.initializeLocalStream(isVideo);

    this.peer = new SimplePeer({
      initiator: true,
      trickle: false,
      stream: this.localStream
    });

    // Setup signaling channel
    this.channel = supabase?.channel(`call-signal:${callId}`);

    return new Promise((resolve, reject) => {
      this.peer.on('signal', async (signal) => {
        // Send offer to recipient via Supabase realtime
        await this.channel.send({
          type: 'broadcast',
          event: 'offer',
          payload: { signal }
        });
      });

      this.peer.on('stream', (stream) => {
        this.remoteStream = stream;
        resolve(stream);
      });

      this.peer.on('error', (error) => {
        console.error('Peer connection error:', error);
        reject(error);
      });

      // Listen for answer
      this.channel
        .on('broadcast', { event: 'answer' }, ({ payload }) => {
          this.peer.signal(payload.signal);
        })
        .subscribe();
    });
  }

  // Accept peer connection (receiver)
  async acceptPeerConnection(callId, offer, isVideo = false) {
    await this.initializeLocalStream(isVideo);

    this.peer = new SimplePeer({
      initiator: false,
      trickle: false,
      stream: this.localStream
    });

    // Setup signaling channel
    this.channel = supabase?.channel(`call-signal:${callId}`);

    return new Promise((resolve, reject) => {
      this.peer.on('signal', async (signal) => {
        // Send answer back
        await this.channel.send({
          type: 'broadcast',
          event: 'answer',
          payload: { signal }
        });
      });

      this.peer.on('stream', (stream) => {
        this.remoteStream = stream;
        resolve(stream);
      });

      this.peer.on('error', (error) => {
        console.error('Peer connection error:', error);
        reject(error);
      });

      // Signal the peer with the offer
      this.peer.signal(offer);

      this.channel.subscribe();
    });
  }

  // Toggle mute
  toggleMute() {
    if (this.localStream) {
      const audioTrack = this.localStream?.getAudioTracks()?.[0];
      if (audioTrack) {
        audioTrack.enabled = !audioTrack?.enabled;
        return !audioTrack?.enabled; // Return muted state
      }
    }
    return false;
  }

  // Toggle video
  toggleVideo() {
    if (this.localStream) {
      const videoTrack = this.localStream?.getVideoTracks()?.[0];
      if (videoTrack) {
        videoTrack.enabled = !videoTrack?.enabled;
        return videoTrack?.enabled; // Return video on state
      }
    }
    return false;
  }

  // Switch camera (front/back on mobile)
  async switchCamera() {
    if (this.localStream) {
      const videoTrack = this.localStream?.getVideoTracks()?.[0];
      if (videoTrack) {
        const currentFacingMode = videoTrack?.getSettings()?.facingMode;
        const newFacingMode = currentFacingMode === 'user' ? 'environment' : 'user';

        // Stop current track
        videoTrack?.stop();

        // Get new stream with switched camera
        try {
          const newStream = await navigator.mediaDevices?.getUserMedia({
            video: { facingMode: newFacingMode },
            audio: false
          });

          const newVideoTrack = newStream?.getVideoTracks()?.[0];
          
          // Replace track in peer connection
          if (this.peer) {
            const sender = this.peer?._pc?.getSenders()?.find(s => s?.track?.kind === 'video');
            if (sender) {
              sender?.replaceTrack(newVideoTrack);
            }
          }

          // Replace in local stream
          this.localStream?.removeTrack(videoTrack);
          this.localStream?.addTrack(newVideoTrack);

          return this.localStream;
        } catch (error) {
          console.error('Error switching camera:', error);
          throw error;
        }
      }
    }
  }

  // Start call recording
  startRecording() {
    if (!this.localStream) return;

    try {
      // Create mixed stream with both local and remote audio
      const audioContext = new AudioContext();
      const destination = audioContext?.createMediaStreamDestination();

      // Add local audio
      if (this.localStream) {
        const localSource = audioContext?.createMediaStreamSource(this.localStream);
        localSource?.connect(destination);
      }

      // Add remote audio
      if (this.remoteStream) {
        const remoteSource = audioContext?.createMediaStreamSource(this.remoteStream);
        remoteSource?.connect(destination);
      }

      this.mediaRecorder = new MediaRecorder(destination.stream, {
        mimeType: 'audio/webm'
      });

      this.recordedChunks = [];

      this.mediaRecorder.ondataavailable = (event) => {
        if (event?.data?.size > 0) {
          this.recordedChunks?.push(event?.data);
        }
      };

      this.mediaRecorder?.start();
      this.isRecording = true;
    } catch (error) {
      console.error('Error starting recording:', error);
      throw error;
    }
  }

  // Stop call recording
  async stopRecording() {
    return new Promise((resolve, reject) => {
      if (!this.mediaRecorder || !this.isRecording) {
        reject(new Error('No recording in progress'));
        return;
      }

      this.mediaRecorder.onstop = async () => {
        const blob = new Blob(this.recordedChunks, { type: 'audio/webm' });
        this.isRecording = false;
        resolve(blob);
      };

      this.mediaRecorder.stop();
    });
  }

  // Save recording to Supabase storage
  async saveRecording(callId, recordingBlob) {
    const { data: { user } } = await supabase?.auth?.getUser();
    if (!user) throw new Error('Not authenticated');

    const fileName = `${user?.id}/recordings/${callId}_${Date.now()}.webm`;

    const { data, error } = await supabase?.storage?.from('call-recordings')?.upload(fileName, recordingBlob, {
        contentType: 'audio/webm',
        cacheControl: '3600'
      });

    if (error) throw error;
    return data?.path;
  }

  // End call and cleanup
  endCall() {
    // Stop all tracks
    if (this.localStream) {
      this.localStream?.getTracks()?.forEach(track => track?.stop());
    }
    if (this.remoteStream) {
      this.remoteStream?.getTracks()?.forEach(track => track?.stop());
    }

    // Close peer connection
    if (this.peer) {
      this.peer?.destroy();
    }

    // Unsubscribe from channel
    if (this.channel) {
      supabase?.removeChannel(this.channel);
    }

    // Stop recording if active
    if (this.isRecording && this.mediaRecorder) {
      this.mediaRecorder?.stop();
    }

    // Clear references
    this.peer = null;
    this.localStream = null;
    this.remoteStream = null;
    this.channel = null;
    this.isRecording = false;
    this.mediaRecorder = null;
    this.recordedChunks = [];
  }

  // Check if browser supports WebRTC
  static isSupported() {
    return !!(navigator.mediaDevices && 
              navigator.mediaDevices?.getUserMedia && 
              window.RTCPeerConnection);
  }
}

export const webrtcService = new WebRTCService();