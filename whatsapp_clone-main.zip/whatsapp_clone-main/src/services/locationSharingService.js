import { supabase } from '../lib/supabase';

/**
 * Location Sharing Service
 * Manages real-time location sharing with live tracking and coordinate updates
 */

export const locationSharingService = {
  /**
   * Start sharing live location
   * @param {string} conversationId - Conversation ID to share location with
   * @param {number} durationMinutes - Duration in minutes (default: 60)
   * @returns {Promise<Object>} Location share details
   */
  async startLocationSharing(conversationId, durationMinutes = 60) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      // Get current position
      const position = await this.getCurrentPosition();

      const expiresAt = new Date(Date.now() + durationMinutes * 60 * 1000);

      const { data, error } = await supabase
        ?.from('location_shares')
        ?.insert({
          user_id: user?.id,
          conversation_id: conversationId,
          latitude: position?.latitude,
          longitude: position?.longitude,
          accuracy: position?.accuracy,
          altitude: position?.altitude,
          heading: position?.heading,
          speed: position?.speed,
          is_live: true,
          duration_minutes: durationMinutes,
          expires_at: expiresAt?.toISOString()
        })
        ?.select()
        ?.single();

      if (error) throw error;

      return {
        success: true,
        locationShare: this.convertToLocationShare(data)
      };
    } catch (error) {
      console.error('Start location sharing error:', error);
      throw error;
    }
  },

  /**
   * Update live location coordinates
   * @param {string} locationId - Location share ID
   * @param {Object} position - Position data
   * @returns {Promise<Object>} Update result
   */
  async updateLocationCoordinates(locationId, position) {
    try {
      const { data, error } = await supabase?.rpc('update_location_coordinates', {
        p_location_id: locationId,
        p_latitude: position?.latitude,
        p_longitude: position?.longitude,
        p_accuracy: position?.accuracy,
        p_altitude: position?.altitude,
        p_heading: position?.heading,
        p_speed: position?.speed
      });

      if (error) throw error;

      if (!data?.success) {
        throw new Error(data?.error || 'Failed to update location');
      }

      return data;
    } catch (error) {
      console.error('Update location error:', error);
      throw error;
    }
  },

  /**
   * Stop live location sharing
   * @param {string} locationId - Location share ID
   * @returns {Promise<Object>} Stop result
   */
  async stopLocationSharing(locationId) {
    try {
      const { data, error } = await supabase?.rpc('stop_location_sharing', {
        p_location_id: locationId
      });

      if (error) throw error;

      if (!data?.success) {
        throw new Error(data?.error || 'Failed to stop location sharing');
      }

      return data;
    } catch (error) {
      console.error('Stop location sharing error:', error);
      throw error;
    }
  },

  /**
   * Get active location shares for a conversation
   * @param {string} conversationId - Conversation ID
   * @returns {Promise<Array>} Active location shares
   */
  async getActiveLocationShares(conversationId) {
    try {
      const { data, error } = await supabase
        ?.from('location_shares')
        ?.select(`
          *,
          user:user_id (
            id,
            full_name,
            avatar_url
          )
        `)
        ?.eq('conversation_id', conversationId)
        ?.eq('is_live', true)
        ?.gt('expires_at', new Date()?.toISOString())
        ?.order('created_at', { ascending: false });

      if (error) throw error;

      return data?.map(share => this.convertToLocationShare(share)) || [];
    } catch (error) {
      console.error('Get active location shares error:', error);
      return [];
    }
  },

  /**
   * Subscribe to location updates for a conversation
   * @param {string} conversationId - Conversation ID
   * @param {Function} onLocationUpdate - Callback for location updates
   * @returns {Function} Cleanup function
   */
  subscribeToLocationUpdates(conversationId, onLocationUpdate) {
    const channel = supabase
      ?.channel(`location-updates-${conversationId}`)
      ?.on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'location_shares',
          filter: `conversation_id=eq.${conversationId}`
        },
        (payload) => {
          if (onLocationUpdate) {
            onLocationUpdate({
              type: 'new',
              location: this.convertToLocationShare(payload?.new)
            });
          }
        }
      )
      ?.on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'location_shares',
          filter: `conversation_id=eq.${conversationId}`
        },
        (payload) => {
          if (onLocationUpdate) {
            onLocationUpdate({
              type: 'update',
              location: this.convertToLocationShare(payload?.new)
            });
          }
        }
      )
      ?.on(
        'postgres_changes',
        {
          event: 'DELETE',
          schema: 'public',
          table: 'location_shares',
          filter: `conversation_id=eq.${conversationId}`
        },
        (payload) => {
          if (onLocationUpdate) {
            onLocationUpdate({
              type: 'stopped',
              locationId: payload?.old?.id
            });
          }
        }
      )
      ?.subscribe();

    return () => {
      supabase?.removeChannel(channel);
    };
  },

  /**
   * Get current position using Geolocation API
   * @returns {Promise<Object>} Position data
   */
  getCurrentPosition() {
    return new Promise((resolve, reject) => {
      if (!navigator?.geolocation) {
        reject(new Error('Geolocation is not supported by this browser'));
        return;
      }

      navigator?.geolocation?.getCurrentPosition(
        (position) => {
          resolve({
            latitude: position?.coords?.latitude,
            longitude: position?.coords?.longitude,
            accuracy: position?.coords?.accuracy,
            altitude: position?.coords?.altitude,
            heading: position?.coords?.heading,
            speed: position?.coords?.speed
          });
        },
        (error) => {
          reject(new Error(`Geolocation error: ${error?.message}`));
        },
        {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 0
        }
      );
    });
  },

  /**
   * Watch position changes for live tracking
   * @param {Function} onPositionUpdate - Callback for position updates
   * @returns {number} Watch ID for clearing
   */
  watchPosition(onPositionUpdate) {
    if (!navigator?.geolocation) {
      throw new Error('Geolocation is not supported');
    }

    return navigator?.geolocation?.watchPosition(
      (position) => {
        onPositionUpdate({
          latitude: position?.coords?.latitude,
          longitude: position?.coords?.longitude,
          accuracy: position?.coords?.accuracy,
          altitude: position?.coords?.altitude,
          heading: position?.coords?.heading,
          speed: position?.coords?.speed,
          timestamp: position?.timestamp
        });
      },
      (error) => {
        console.error('Watch position error:', error);
      },
      {
        enableHighAccuracy: true,
        timeout: 5000,
        maximumAge: 0
      }
    );
  },

  /**
   * Clear position watch
   * @param {number} watchId - Watch ID to clear
   */
  clearWatch(watchId) {
    if (navigator?.geolocation && watchId) {
      navigator?.geolocation?.clearWatch(watchId);
    }
  },

  /**
   * Calculate distance between two coordinates (Haversine formula)
   * @param {number} lat1 - Latitude 1
   * @param {number} lon1 - Longitude 1
   * @param {number} lat2 - Latitude 2
   * @param {number} lon2 - Longitude 2
   * @returns {number} Distance in meters
   */
  calculateDistance(lat1, lon1, lat2, lon2) {
    const R = 6371e3; // Earth radius in meters
    const φ1 = (lat1 * Math.PI) / 180;
    const φ2 = (lat2 * Math.PI) / 180;
    const Δφ = ((lat2 - lat1) * Math.PI) / 180;
    const Δλ = ((lon2 - lon1) * Math.PI) / 180;

    const a =
      Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
      Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));

    return R * c;
  },

  /**
   * Format distance for display
   * @param {number} meters - Distance in meters
   * @returns {string} Formatted distance
   */
  formatDistance(meters) {
    if (meters < 1000) {
      return `${Math.round(meters)}m`;
    }
    return `${(meters / 1000)?.toFixed(1)}km`;
  },

  /**
   * Convert database record to camelCase
   * @param {Object} data - Database record
   * @returns {Object} Converted object
   */
  convertToLocationShare(data) {
    if (!data) return null;

    return {
      id: data?.id,
      userId: data?.user_id,
      conversationId: data?.conversation_id,
      latitude: parseFloat(data?.latitude),
      longitude: parseFloat(data?.longitude),
      accuracy: data?.accuracy ? parseFloat(data?.accuracy) : null,
      altitude: data?.altitude ? parseFloat(data?.altitude) : null,
      heading: data?.heading ? parseFloat(data?.heading) : null,
      speed: data?.speed ? parseFloat(data?.speed) : null,
      isLive: data?.is_live,
      durationMinutes: data?.duration_minutes,
      expiresAt: data?.expires_at,
      lastUpdatedAt: data?.last_updated_at,
      createdAt: data?.created_at,
      user: data?.user ? {
        id: data?.user?.id,
        fullName: data?.user?.full_name,
        avatarUrl: data?.user?.avatar_url
      } : null
    };
  }
};