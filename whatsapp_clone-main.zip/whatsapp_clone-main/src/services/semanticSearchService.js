import axios from 'axios';
import { supabase } from '../lib/supabase';

/**
 * Maps Anthropic API error status codes to user-friendly error messages.
 * @param {number} statusCode - The HTTP status code from Anthropic API.
 * @param {Object} errorData - The error data from API response.
 * @returns {Object} Object with isInternal flag and error message.
 */
function getErrorMessage(statusCode, errorData) {
  if (statusCode === 401) {
    return { isInternal: true, message: 'Invalid API key or authentication failed. Please check your Anthropic API key.' };
  } else if (statusCode === 403) {
    return { isInternal: true, message: 'Permission denied. Your API key does not have access to the specified resource.' };
  } else if (statusCode === 404) {
    return { isInternal: true, message: 'Resource not found. The requested endpoint or model may not exist.' };
  } else if (statusCode === 429) {
    return { isInternal: true, message: 'Rate limit exceeded. You are sending requests too quickly. Please wait a moment and try again.' };
  } else if (statusCode === 500) {
    return { isInternal: true, message: 'Anthropic service error. An unexpected error occurred on their servers. Please try again later.' };
  } else if (statusCode === 529) {
    return { isInternal: true, message: 'Anthropic service is temporarily overloaded. Please try again in a few moments.' };
  } else {
    return { isInternal: false, message: errorData?.error?.message || 'An unexpected error occurred. Please try again.' };
  }
}

export const semanticSearchService = {
  /**
   * Perform semantic search using Claude AI
   * @param {string} query - Natural language search query
   * @param {Object} options - Search options
   * @returns {Promise<Object>} Search results with context and insights
   */
  async performSemanticSearch(query, options = {}) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      // Fetch recent messages for context
      const { data: messages, error: messagesError } = await supabase
        ?.from('chat_messages')
        ?.select(`
          id,
          content,
          message_type,
          created_at,
          sender:profiles!chat_messages_sender_id_fkey(id, full_name),
          conversation_id
        `)
        ?.order('created_at', { ascending: false })
        ?.limit(options?.limit || 100);

      if (messagesError) throw messagesError;

      // Prepare context for Claude
      const messageContext = messages?.map(msg => ({
        id: msg?.id,
        content: msg?.content,
        sender: msg?.sender?.full_name,
        type: msg?.message_type,
        timestamp: msg?.created_at
      }));

      // Call Claude API for semantic analysis
      const apiKey = import.meta.env?.VITE_ANTHROPIC_API_KEY;
      if (!apiKey) {
        throw new Error('Anthropic API key not configured. Please add VITE_ANTHROPIC_API_KEY to your .env file.');
      }

      const url = 'https://api.anthropic.com/v1/messages';
      const headers = {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
        'anthropic-dangerous-direct-browser-access': 'true',
      };

      const prompt = `You are a semantic search assistant analyzing chat messages. Given the user's query and message history, identify the most relevant messages based on context, intent, sentiment, and meaning (not just keywords).

User Query: "${query}"

Message History:
${JSON.stringify(messageContext, null, 2)}

Provide a JSON response with:
1. "relevantMessages": Array of message IDs ranked by relevance (most relevant first)
2. "insights": Object with: -"summary": Brief summary of findings -"sentiment": Overall sentiment detected -"topics": Key topics identified
   - "actionItems": Any action items found 3."relatedQueries": Array of 3-5 suggested follow-up queries

Return ONLY valid JSON, no additional text.`;

      const data = {
        model: 'claude-sonnet-4-5-20250929',
        messages: [{ role: 'user', content: prompt }],
        max_tokens: 2048,
        temperature: 0.3
      };

      const response = await axios?.post(url, data, { headers });
      
      // Parse Claude's response
      const claudeResponse = response?.data?.content?.[0]?.text;
      let analysisResult;
      
      try {
        analysisResult = JSON.parse(claudeResponse);
      } catch (parseError) {
        console.error('Failed to parse Claude response:', parseError);
        analysisResult = {
          relevantMessages: [],
          insights: {
            summary: 'Unable to parse semantic analysis',
            sentiment: 'neutral',
            topics: [],
            actionItems: []
          },
          relatedQueries: []
        };
      }

      // Map relevant message IDs to full message objects
      const relevantMessageIds = analysisResult?.relevantMessages || [];
      const rankedMessages = relevantMessageIds
        ?.map(id => messages?.find(msg => msg?.id === id))
        ?.filter(Boolean);

      return {
        query,
        results: rankedMessages?.map((msg, index) => ({
          messageId: msg?.id,
          content: msg?.content,
          messageType: msg?.message_type,
          senderName: msg?.sender?.full_name,
          createdAt: msg?.created_at,
          conversationId: msg?.conversation_id,
          relevanceScore: 1 - (index / rankedMessages?.length)
        })),
        insights: {
          summary: analysisResult?.insights?.summary || '',
          sentiment: analysisResult?.insights?.sentiment || 'neutral',
          topics: analysisResult?.insights?.topics || [],
          actionItems: analysisResult?.insights?.actionItems || []
        },
        relatedQueries: analysisResult?.relatedQueries || [],
        totalResults: rankedMessages?.length || 0
      };
    } catch (error) {
      if (error?.response?.status) {
        const errorInfo = getErrorMessage(error?.response?.status, error?.response?.data);
        const err = new Error(errorInfo.message);
        err.statusCode = error?.response?.status;
        
        if (!errorInfo?.isInternal) {
          console.error('Anthropic API error:', err);
        }
        throw err;
      }
      console.error('Semantic search error:', error);
      throw error;
    }
  },

  /**
   * Get conversation summary using Claude
   * @param {string} conversationId - Conversation ID
   * @returns {Promise<Object>} Conversation summary and insights
   */
  async getConversationSummary(conversationId) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      // Fetch conversation messages
      const { data: messages, error } = await supabase
        ?.from('chat_messages')
        ?.select(`
          content,
          message_type,
          created_at,
          sender:profiles!chat_messages_sender_id_fkey(full_name)
        `)
        ?.eq('conversation_id', conversationId)
        ?.order('created_at', { ascending: true });

      if (error) throw error;

      const apiKey = import.meta.env?.VITE_ANTHROPIC_API_KEY;
      if (!apiKey) {
        throw new Error('Anthropic API key not configured.');
      }

      const url = 'https://api.anthropic.com/v1/messages';
      const headers = {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
        'anthropic-dangerous-direct-browser-access': 'true',
      };

      const conversationText = messages?.map(msg => 
        `${msg?.sender?.full_name}: ${msg?.content}`
      )?.join('\n');

      const prompt = `Summarize this conversation and extract key insights:\n\n${conversationText}\n\nProvide JSON with: {"summary": "brief summary", "keyPoints": ["point1", "point2"], "decisions": ["decision1"], "actionItems": ["action1"]}`;

      const data = {
        model: 'claude-sonnet-4-5-20250929',
        messages: [{ role: 'user', content: prompt }],
        max_tokens: 1024
      };

      const response = await axios?.post(url, data, { headers });
      const result = JSON.parse(response?.data?.content?.[0]?.text || '{}');

      return {
        conversationId,
        summary: result?.summary || '',
        keyPoints: result?.keyPoints || [],
        decisions: result?.decisions || [],
        actionItems: result?.actionItems || []
      };
    } catch (error) {
      if (error?.response?.status) {
        const errorInfo = getErrorMessage(error?.response?.status, error?.response?.data);
        const err = new Error(errorInfo.message);
        err.statusCode = error?.response?.status;
        
        if (!errorInfo?.isInternal) {
          console.error('Anthropic API error:', err);
        }
        throw err;
      }
      console.error('Conversation summary error:', error);
      throw error;
    }
  },

  /**
   * Save semantic search history
   * @param {string} query - Search query
   * @param {Object} results - Search results
   * @returns {Promise<void>}
   */
  async saveSearchHistory(query, results) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      const { error } = await supabase
        ?.from('saved_search_queries')
        ?.insert({
          user_id: user?.id,
          query_name: query?.substring(0, 50),
          search_text: query,
          filters: { semantic: true, resultCount: results?.totalResults }
        });

      if (error) throw error;
    } catch (error) {
      console.error('Save search history error:', error);
    }
  }
};