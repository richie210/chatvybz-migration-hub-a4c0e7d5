import { supabase } from '../lib/supabase';

/**
 * Withdrawal Request Service - Manages payout withdrawals, bank accounts, and scheduling
 */

export const withdrawalRequestService = {
  /**
   * Get user's bank accounts
   */
  async getBankAccounts() {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data, error } = await supabase
        ?.from('bank_accounts')?.select('*')?.eq('user_id', user?.id)?.order('is_primary', { ascending: false })
        ?.order('created_at', { ascending: false });

      if (error) throw error;

      return { data, error: null };
    } catch (error) {
      console.error('Error fetching bank accounts:', error);
      return { data: null, error };
    }
  },

  /**
   * Add new bank account
   */
  async addBankAccount(accountData) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      // Simple encryption (in production, use proper encryption)
      const encryptedAccountNumber = btoa(accountData?.accountNumber);
      const last4 = accountData?.accountNumber?.slice(-4);

      const { data, error } = await supabase
        ?.from('bank_accounts')
        ?.insert([{
          user_id: user?.id,
          account_nickname: accountData?.nickname,
          bank_name: accountData?.bankName,
          account_type: accountData?.accountType,
          routing_number: accountData?.routingNumber,
          account_number_last4: last4,
          account_number_encrypted: encryptedAccountNumber,
          is_primary: accountData?.isPrimary || false,
          is_verified: false,
          verification_status: 'pending'
        }])
        ?.select()
        ?.single();

      if (error) throw error;

      return { data, error: null };
    } catch (error) {
      console.error('Error adding bank account:', error);
      return { data: null, error };
    }
  },

  /**
   * Update bank account
   */
  async updateBankAccount(accountId, updates) {
    try {
      const { data, error } = await supabase
        ?.from('bank_accounts')
        ?.update(updates)
        ?.eq('id', accountId)
        ?.select()
        ?.single();

      if (error) throw error;

      return { data, error: null };
    } catch (error) {
      console.error('Error updating bank account:', error);
      return { data: null, error };
    }
  },

  /**
   * Delete bank account
   */
  async deleteBankAccount(accountId) {
    try {
      const { error } = await supabase
        ?.from('bank_accounts')
        ?.delete()
        ?.eq('id', accountId);

      if (error) throw error;

      return { error: null };
    } catch (error) {
      console.error('Error deleting bank account:', error);
      return { error };
    }
  },

  /**
   * Get available balance for withdrawal
   */
  async getAvailableBalance() {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      // Get completed payouts that haven't been withdrawn
      const { data: payouts, error } = await supabase
        ?.from('creator_payouts')
        ?.select('amount')
        ?.eq('creator_id', user?.id)
        ?.eq('status', 'paid');

      if (error) throw error;

      // Get total withdrawn amount
      const { data: withdrawals, error: withdrawalError } = await supabase
        ?.from('withdrawal_requests')
        ?.select('amount')
        ?.eq('user_id', user?.id)
        ?.in('status', ['completed', 'processing', 'under_review']);

      if (withdrawalError) throw withdrawalError;

      const totalEarned = payouts?.reduce((sum, p) => sum + (parseFloat(p?.amount) || 0), 0) || 0;
      const totalWithdrawn = withdrawals?.reduce((sum, w) => sum + (parseFloat(w?.amount) || 0), 0) || 0;

      return { data: totalEarned - totalWithdrawn, error: null };
    } catch (error) {
      console.error('Error fetching available balance:', error);
      return { data: 0, error };
    }
  },

  /**
   * Get withdrawal limits and usage
   */
  async getWithdrawalLimits() {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data, error } = await supabase
        ?.from('withdrawal_limits')
        ?.select('*')
        ?.eq('user_id', user?.id)
        ?.single();

      if (error && error?.code !== 'PGRST116') throw error;

      // If no limits exist, return defaults
      if (!data) {
        return {
          data: {
            daily_limit: 1000,
            weekly_limit: 5000,
            monthly_limit: 20000,
            daily_used: 0,
            weekly_used: 0,
            monthly_used: 0
          },
          error: null
        };
      }

      return { data, error: null };
    } catch (error) {
      console.error('Error fetching withdrawal limits:', error);
      return { data: null, error };
    }
  },

  /**
   * Create withdrawal request
   */
  async createWithdrawalRequest(requestData) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      // Calculate processing fee
      const amount = parseFloat(requestData?.amount);
      const processingFee = Math.min(Math.max(amount * 0.01, 1.00), 10.00);
      const netAmount = amount - processingFee;

      // Calculate estimated arrival date (3-5 business days)
      const estimatedArrival = new Date();
      estimatedArrival?.setDate(estimatedArrival?.getDate() + 5);

      const { data, error } = await supabase
        ?.from('withdrawal_requests')
        ?.insert([{
          user_id: user?.id,
          bank_account_id: requestData?.bankAccountId,
          amount: amount,
          currency: requestData?.currency || 'USD',
          processing_fee: processingFee,
          net_amount: netAmount,
          status: 'submitted',
          withdrawal_type: requestData?.withdrawalType || 'one_time',
          schedule_frequency: requestData?.scheduleFrequency,
          schedule_date: requestData?.scheduleDate,
          estimated_arrival_date: estimatedArrival?.toISOString()?.split('T')?.[0],
          notes: requestData?.notes
        }])
        ?.select()
        ?.single();

      if (error) throw error;

      return { data, error: null };
    } catch (error) {
      console.error('Error creating withdrawal request:', error);
      return { data: null, error };
    }
  },

  /**
   * Get withdrawal requests history
   */
  async getWithdrawalHistory(filters = {}) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      let query = supabase
        ?.from('withdrawal_requests')
        ?.select(`
          *,
          bank_account:bank_accounts(
            account_nickname,
            bank_name,
            account_number_last4
          )
        `)
        ?.eq('user_id', user?.id);

      // Apply filters
      if (filters?.status) {
        query = query?.eq('status', filters?.status);
      }

      if (filters?.startDate) {
        query = query?.gte('created_at', filters?.startDate);
      }

      if (filters?.endDate) {
        query = query?.lte('created_at', filters?.endDate);
      }

      query = query?.order('created_at', { ascending: false });

      const { data, error } = await query;

      if (error) throw error;

      return { data, error: null };
    } catch (error) {
      console.error('Error fetching withdrawal history:', error);
      return { data: null, error };
    }
  },

  /**
   * Cancel withdrawal request
   */
  async cancelWithdrawalRequest(requestId) {
    try {
      const { data, error } = await supabase
        ?.from('withdrawal_requests')
        ?.update({ status: 'cancelled', updated_at: new Date()?.toISOString() })
        ?.eq('id', requestId)
        ?.eq('status', 'submitted')
        ?.select()
        ?.single();

      if (error) throw error;

      return { data, error: null };
    } catch (error) {
      console.error('Error cancelling withdrawal request:', error);
      return { data: null, error };
    }
  },

  /**
   * Format currency amount
   */
  formatAmount(amount, currency = 'USD') {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency?.toUpperCase()
    })?.format(amount);
  },

  /**
   * Get status badge color
   */
  getStatusColor(status) {
    const colors = {
      submitted: 'blue',
      under_review: 'yellow',
      processing: 'purple',
      completed: 'green',
      failed: 'red',
      cancelled: 'gray'
    };
    return colors?.[status] || 'gray';
  },

  /**
   * Get status display text
   */
  getStatusText(status) {
    const texts = {
      submitted: 'Submitted',
      under_review: 'Under Review',
      processing: 'Processing',
      completed: 'Completed',
      failed: 'Failed',
      cancelled: 'Cancelled'
    };
    return texts?.[status] || status;
  }
};