import { supabase } from '../lib/supabase';
import { creatorRevenueService } from './creatorRevenueService';
import { callAnalyticsService } from './callAnalyticsService';
import { channelAnalyticsService } from './channelAnalyticsService';

/**
 * Analytics Report Service
 * Handles scheduled email delivery of analytics reports via Resend
 */

export const analyticsReportService = {
  /**
   * Generate and send creator revenue report
   */
  async sendCreatorRevenueReport(recipientEmail, dateRange) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      // Fetch revenue data
      const revenueData = await creatorRevenueService?.getCreatorRevenue();
      
      if (!revenueData?.data) {
        throw new Error('Failed to fetch revenue data');
      }

      // Format report data
      const reportData = {
        totalRevenue: revenueData?.data?.totalRevenue,
        subscriptionRevenue: revenueData?.data?.subscriptionRevenue,
        adRevenue: revenueData?.data?.adRevenue,
        channelCount: revenueData?.data?.channels?.length || 0,
        topChannels: revenueData?.data?.revenueByChannel
          ?.sort((a, b) => b?.totalRevenue - a?.totalRevenue)
          ?.slice(0, 5)
          ?.map(ch => ({
            name: ch?.channelName,
            revenue: ch?.totalRevenue
          }))
      };

      // Send via Resend Edge Function
      const { data, error } = await supabase?.functions?.invoke('send-analytics-report', {
        body: {
          to: recipientEmail,
          reportType: 'creator_revenue',
          reportData,
          dateRange: this.formatDateRange(dateRange)
        }
      });

      if (error) throw error;

      // Log report delivery
      await this.logReportDelivery({
        userId: user?.id,
        reportType: 'creator_revenue',
        recipientEmail,
        deliveryStatus: 'sent',
        messageId: data?.messageId
      });

      return { success: true, data };
    } catch (error) {
      console.error('Error sending creator revenue report:', error);
      return { success: false, error: error?.message };
    }
  },

  /**
   * Generate and send call metrics report
   */
  async sendCallMetricsReport(recipientEmail, dateRange) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      // Fetch call analytics data
      const callData = await callAnalyticsService?.getCallVolumeMetrics(dateRange);
      
      // Format report data
      const reportData = {
        totalCalls: callData?.totalCalls,
        completedCalls: callData?.completedCalls,
        avgDuration: callData?.avgDuration,
        answerRate: callData?.answerRate,
        voiceCalls: callData?.callsByType?.voice,
        videoCalls: callData?.callsByType?.video,
        conferenceCalls: callData?.callsByType?.conference,
        peakTime: this.calculatePeakTime(callData?.trendData)
      };

      // Send via Resend Edge Function
      const { data, error } = await supabase?.functions?.invoke('send-analytics-report', {
        body: {
          to: recipientEmail,
          reportType: 'call_metrics',
          reportData,
          dateRange: this.formatDateRange(dateRange)
        }
      });

      if (error) throw error;

      // Log report delivery
      await this.logReportDelivery({
        userId: user?.id,
        reportType: 'call_metrics',
        recipientEmail,
        deliveryStatus: 'sent',
        messageId: data?.messageId
      });

      return { success: true, data };
    } catch (error) {
      console.error('Error sending call metrics report:', error);
      return { success: false, error: error?.message };
    }
  },

  /**
   * Generate and send subscriber insights report
   */
  async sendSubscriberInsightsReport(recipientEmail, channelId, dateRange) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      // Fetch subscriber analytics
      const subscriberData = await channelAnalyticsService?.getSubscriberAnalytics(
        channelId,
        { days: dateRange?.days || 30 }
      );
      
      if (!subscriberData?.data) {
        throw new Error('Failed to fetch subscriber data');
      }

      // Format report data
      const reportData = {
        totalSubscribers: subscriberData?.data?.totalSubscribers,
        newSubscribers: subscriberData?.data?.newSubscribers,
        churnRate: subscriberData?.data?.churnRate,
        engagementRate: subscriberData?.data?.engagementRate,
        avgSessionDuration: subscriberData?.data?.avgSessionDuration,
        demographics: {
          topCountries: subscriberData?.data?.topCountries,
          ageGroups: subscriberData?.data?.ageDistribution
        }
      };

      // Send via Resend Edge Function
      const { data, error } = await supabase?.functions?.invoke('send-analytics-report', {
        body: {
          to: recipientEmail,
          reportType: 'subscriber_insights',
          reportData,
          dateRange: this.formatDateRange(dateRange)
        }
      });

      if (error) throw error;

      // Log report delivery
      await this.logReportDelivery({
        userId: user?.id,
        reportType: 'subscriber_insights',
        recipientEmail,
        deliveryStatus: 'sent',
        messageId: data?.messageId
      });

      return { success: true, data };
    } catch (error) {
      console.error('Error sending subscriber insights report:', error);
      return { success: false, error: error?.message };
    }
  },

  /**
   * Schedule recurring report delivery
   */
  async scheduleReport(scheduleData) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data, error } = await supabase?.from('scheduled_reports')?.insert({
        user_id: user?.id,
        report_type: scheduleData?.reportType,
        recipient_email: scheduleData?.recipientEmail,
        frequency: scheduleData?.frequency, // 'daily', 'weekly', 'monthly'
        schedule_time: scheduleData?.scheduleTime,
        timezone: scheduleData?.timezone || 'UTC',
        channel_id: scheduleData?.channelId || null,
        is_active: true
      })?.select()?.single();

      if (error) throw error;

      return {
        success: true,
        schedule: {
          id: data?.id,
          reportType: data?.report_type,
          recipientEmail: data?.recipient_email,
          frequency: data?.frequency,
          scheduleTime: data?.schedule_time,
          timezone: data?.timezone,
          isActive: data?.is_active
        }
      };
    } catch (error) {
      console.error('Error scheduling report:', error);
      return { success: false, error: error?.message };
    }
  },

  /**
   * Get all scheduled reports for user
   */
  async getScheduledReports() {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data, error } = await supabase
        ?.from('scheduled_reports')
        ?.select('*')
        ?.eq('user_id', user?.id)
        ?.order('created_at', { ascending: false });

      if (error) throw error;

      return {
        success: true,
        schedules: data?.map(s => ({
          id: s?.id,
          reportType: s?.report_type,
          recipientEmail: s?.recipient_email,
          frequency: s?.frequency,
          scheduleTime: s?.schedule_time,
          timezone: s?.timezone,
          channelId: s?.channel_id,
          isActive: s?.is_active,
          lastSent: s?.last_sent_at,
          createdAt: s?.created_at
        }))
      };
    } catch (error) {
      console.error('Error fetching scheduled reports:', error);
      return { success: false, error: error?.message };
    }
  },

  /**
   * Update scheduled report
   */
  async updateScheduledReport(scheduleId, updates) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      const updateData = {};
      if (updates?.frequency) updateData.frequency = updates?.frequency;
      if (updates?.scheduleTime) updateData.schedule_time = updates?.scheduleTime;
      if (updates?.recipientEmail) updateData.recipient_email = updates?.recipientEmail;
      if (updates?.isActive !== undefined) updateData.is_active = updates?.isActive;

      const { error } = await supabase
        ?.from('scheduled_reports')
        ?.update(updateData)
        ?.eq('id', scheduleId)
        ?.eq('user_id', user?.id);

      if (error) throw error;
      return { success: true };
    } catch (error) {
      console.error('Error updating scheduled report:', error);
      return { success: false, error: error?.message };
    }
  },

  /**
   * Delete scheduled report
   */
  async deleteScheduledReport(scheduleId) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      const { error } = await supabase
        ?.from('scheduled_reports')
        ?.delete()
        ?.eq('id', scheduleId)
        ?.eq('user_id', user?.id);

      if (error) throw error;
      return { success: true };
    } catch (error) {
      console.error('Error deleting scheduled report:', error);
      return { success: false, error: error?.message };
    }
  },

  /**
   * Log report delivery
   */
  async logReportDelivery(logData) {
    try {
      const { error } = await supabase?.from('report_delivery_logs')?.insert({
        user_id: logData?.userId,
        report_type: logData?.reportType,
        recipient_email: logData?.recipientEmail,
        delivery_status: logData?.deliveryStatus,
        message_id: logData?.messageId,
        error_message: logData?.errorMessage || null
      });

      if (error) throw error;
      return { success: true };
    } catch (error) {
      console.error('Error logging report delivery:', error);
      return { success: false, error: error?.message };
    }
  },

  /**
   * Helper: Format date range for display
   */
  formatDateRange(dateRange) {
    if (!dateRange) return 'Latest';
    if (dateRange?.start && dateRange?.end) {
      return `${new Date(dateRange.start)?.toLocaleDateString()} - ${new Date(dateRange.end)?.toLocaleDateString()}`;
    }
    if (dateRange?.days) {
      return `Last ${dateRange?.days} days`;
    }
    return 'Latest';
  },

  /**
   * Helper: Calculate peak time from trend data
   */
  calculatePeakTime(trendData) {
    if (!trendData || trendData?.length === 0) return 'N/A';
    const peak = trendData?.reduce((max, item) => 
      item?.count > max?.count ? item : max
    , trendData?.[0]);
    return peak?.date ? new Date(peak.date)?.toLocaleDateString() : 'N/A';
  }
};