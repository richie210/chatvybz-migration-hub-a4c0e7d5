import { supabase } from '../lib/supabase';
import { stripePaymentService } from './stripePaymentService';

/**
 * Creator Revenue Service - Analytics for channel subscription revenue, ad revenue, and payouts
 */

export const creatorRevenueService = {
  /**
   * Get comprehensive revenue analytics for a creator
   */
  async getCreatorRevenue(creatorId = null) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      const targetCreatorId = creatorId || user?.id;

      // Get all channels owned by creator
      const { data: channels, error: channelsError } = await supabase
        ?.from('channels')
        ?.select('id, name')
        ?.eq('created_by', targetCreatorId);

      if (channelsError) throw channelsError;

      if (!channels || channels?.length === 0) {
        return {
          data: {
            totalRevenue: 0,
            subscriptionRevenue: 0,
            adRevenue: 0,
            channels: [],
            revenueByChannel: []
          },
          error: null
        };
      }

      const channelIds = channels?.map(c => c?.id);

      // Get subscription revenue
      const subscriptionRevenue = await this.getSubscriptionRevenue(channelIds);

      // Get ad revenue
      const adRevenue = await this.getAdRevenue(channelIds);

      // Get revenue breakdown by channel
      const revenueByChannel = await Promise.all(
        channels?.map(async (channel) => {
          const subRev = await this.getSubscriptionRevenue([channel?.id]);
          const adRev = await this.getAdRevenue([channel?.id]);
          return {
            channelId: channel?.id,
            channelName: channel?.name,
            subscriptionRevenue: subRev?.data?.totalRevenue || 0,
            adRevenue: adRev?.data?.totalRevenue || 0,
            totalRevenue: (subRev?.data?.totalRevenue || 0) + (adRev?.data?.totalRevenue || 0)
          };
        })
      );

      const totalRevenue = (subscriptionRevenue?.data?.totalRevenue || 0) + (adRevenue?.data?.totalRevenue || 0);

      return {
        data: {
          totalRevenue,
          subscriptionRevenue: subscriptionRevenue?.data?.totalRevenue || 0,
          adRevenue: adRevenue?.data?.totalRevenue || 0,
          channels,
          revenueByChannel,
          subscriptionDetails: subscriptionRevenue?.data,
          adDetails: adRevenue?.data
        },
        error: null
      };
    } catch (error) {
      console.error('Error fetching creator revenue:', error);
      return { data: null, error };
    }
  },

  /**
   * Get subscription revenue for channels
   */
  async getSubscriptionRevenue(channelIds) {
    try {
      // Get active subscriptions
      const { data: subscriptions, error: subsError } = await supabase
        ?.from('channel_subscriptions')
        ?.select(`
          *,
          tier:channel_subscription_tiers(price, name, billing_interval)
        `)
        ?.in('channel_id', channelIds)
        ?.eq('status', 'active');

      if (subsError) throw subsError;

      // Calculate MRR (Monthly Recurring Revenue)
      let mrr = 0;
      let totalSubscribers = subscriptions?.length || 0;

      subscriptions?.forEach(sub => {
        const price = sub?.tier?.price || 0;
        const interval = sub?.tier?.billing_interval || 'month';

        // Normalize to monthly
        if (interval === 'month') {
          mrr += price;
        } else if (interval === 'year') {
          mrr += price / 12;
        }
      });

      // Get subscription history for trends
      const { data: history, error: historyError } = await supabase
        ?.from('channel_subscriptions')
        ?.select('created_at, status')
        ?.in('channel_id', channelIds)
        ?.order('created_at', { ascending: true });

      if (historyError) throw historyError;

      // Calculate growth trends
      const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
      const newSubscribers = history?.filter(s => new Date(s?.created_at) >= thirtyDaysAgo)?.length || 0;
      const churnedSubscribers = history?.filter(s => s?.status === 'cancelled' && new Date(s?.updated_at) >= thirtyDaysAgo)?.length || 0;

      return {
        data: {
          totalRevenue: mrr,
          mrr,
          totalSubscribers,
          newSubscribers,
          churnedSubscribers,
          growthRate: totalSubscribers > 0 ? ((newSubscribers - churnedSubscribers) / totalSubscribers * 100) : 0
        },
        error: null
      };
    } catch (error) {
      console.error('Error fetching subscription revenue:', error);
      return { data: null, error };
    }
  },

  /**
   * Get ad revenue for channels
   */
  async getAdRevenue(channelIds) {
    try {
      // Get ad impressions
      const { data: impressions, error: impError } = await supabase
        ?.from('ad_impression_tracking')
        ?.select('*')
        ?.in('channel_id', channelIds);

      if (impError) throw impError;

      // Get ad clicks
      const { data: clicks, error: clickError } = await supabase
        ?.from('ad_click_tracking')
        ?.select('*')
        ?.in('channel_id', channelIds);

      if (clickError) throw clickError;

      // Calculate revenue (example rates - adjust based on actual platform rates)
      const impressionRate = 0.002; // $0.002 per impression (CPM model)
      const clickRate = 0.50; // $0.50 per click (CPC model)

      const totalImpressions = impressions?.length || 0;
      const totalClicks = clicks?.length || 0;

      const impressionRevenue = totalImpressions * impressionRate;
      const clickRevenue = totalClicks * clickRate;
      const totalAdRevenue = impressionRevenue + clickRevenue;

      // Calculate CTR (Click-Through Rate)
      const ctr = totalImpressions > 0 ? (totalClicks / totalImpressions * 100) : 0;

      // Platform split (example: 70% creator, 30% platform)
      const creatorShare = totalAdRevenue * 0.7;
      const platformShare = totalAdRevenue * 0.3;

      return {
        data: {
          totalRevenue: creatorShare,
          totalImpressions,
          totalClicks,
          ctr,
          impressionRevenue,
          clickRevenue,
          creatorShare,
          platformShare,
          splitPercentage: 70
        },
        error: null
      };
    } catch (error) {
      console.error('Error fetching ad revenue:', error);
      return { data: null, error };
    }
  },

  /**
   * Get Stripe payout history with tax documentation
   */
  async getPayoutHistory(creatorId = null) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      const targetCreatorId = creatorId || user?.id;

      const { data: payouts, error } = await supabase
        ?.from('stripe_payouts')
        ?.select(`
          *,
          channel:channels(id, name)
        `)
        ?.eq('creator_id', targetCreatorId)
        ?.order('created_at', { ascending: false });

      if (error) throw error;

      // Calculate totals
      const totalPaidOut = payouts?.filter(p => p?.status === 'paid')?.reduce((sum, p) => sum + (p?.amount || 0), 0) || 0;
      const totalPending = payouts?.filter(p => p?.status === 'pending')?.reduce((sum, p) => sum + (p?.amount || 0), 0) || 0;

      return {
        data: {
          payouts,
          totalPaidOut,
          totalPending,
          totalPayouts: payouts?.length || 0
        },
        error: null
      };
    } catch (error) {
      console.error('Error fetching payout history:', error);
      return { data: null, error };
    }
  },

  /**
   * Generate tax documentation (1099 form data)
   */
  async generateTaxDocumentation(year, creatorId = null) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      const targetCreatorId = creatorId || user?.id;

      // Get all payouts for the year
      const startDate = `${year}-01-01`;
      const endDate = `${year}-12-31`;

      const { data: payouts, error } = await supabase
        ?.from('stripe_payouts')
        ?.select('*')
        ?.eq('creator_id', targetCreatorId)
        ?.eq('status', 'paid')
        ?.gte('created_at', startDate)
        ?.lte('created_at', endDate);

      if (error) throw error;

      const totalEarnings = payouts?.reduce((sum, p) => sum + (p?.amount || 0), 0) || 0;
      const totalFees = payouts?.reduce((sum, p) => sum + (p?.stripe_fee || 0), 0) || 0;
      const netEarnings = totalEarnings - totalFees;

      // Get creator profile for tax info
      const { data: profile } = await supabase
        ?.from('profiles')
        ?.select('full_name, email, country_code')
        ?.eq('id', targetCreatorId)
        ?.single();

      return {
        data: {
          year,
          creatorName: profile?.full_name,
          creatorEmail: profile?.email,
          country: profile?.country_code,
          totalEarnings,
          totalFees,
          netEarnings,
          payoutCount: payouts?.length,
          payouts,
          formType: profile?.country_code === 'US' ? '1099-MISC' : 'International Tax Report'
        },
        error: null
      };
    } catch (error) {
      console.error('Error generating tax documentation:', error);
      return { data: null, error };
    }
  },

  /**
   * Get revenue forecasting based on trends
   */
  async getRevenueForecast(channelIds, months = 3) {
    try {
      // Get historical revenue data
      const { data: subscriptions } = await supabase
        ?.from('channel_subscriptions')
        ?.select('created_at, tier:channel_subscription_tiers(price)')
        ?.in('channel_id', channelIds)
        ?.order('created_at', { ascending: true });

      // Calculate monthly revenue for past 6 months
      const monthlyRevenue = [];
      for (let i = 5; i >= 0; i--) {
        const date = new Date();
        date?.setMonth(date?.getMonth() - i);
        const monthStart = new Date(date.getFullYear(), date.getMonth(), 1);
        const monthEnd = new Date(date.getFullYear(), date.getMonth() + 1, 0);

        const monthSubs = subscriptions?.filter(s => {
          const subDate = new Date(s?.created_at);
          return subDate >= monthStart && subDate <= monthEnd;
        });

        const revenue = monthSubs?.reduce((sum, s) => sum + (s?.tier?.price || 0), 0) || 0;
        monthlyRevenue?.push({
          month: monthStart?.toISOString()?.slice(0, 7),
          revenue
        });
      }

      // Simple linear regression for forecast
      const avgGrowth = monthlyRevenue?.length > 1
        ? (monthlyRevenue?.[monthlyRevenue?.length - 1]?.revenue - monthlyRevenue?.[0]?.revenue) / monthlyRevenue?.length
        : 0;

      const forecast = [];
      let lastRevenue = monthlyRevenue?.[monthlyRevenue?.length - 1]?.revenue || 0;

      for (let i = 1; i <= months; i++) {
        const date = new Date();
        date?.setMonth(date?.getMonth() + i);
        const projectedRevenue = lastRevenue + (avgGrowth * i);

        forecast?.push({
          month: date?.toISOString()?.slice(0, 7),
          projectedRevenue: Math.max(0, projectedRevenue)
        });
      }

      return {
        data: {
          historical: monthlyRevenue,
          forecast,
          avgMonthlyGrowth: avgGrowth
        },
        error: null
      };
    } catch (error) {
      console.error('Error generating revenue forecast:', error);
      return { data: null, error };
    }
  },

  /**
   * Request payout via Stripe
   */
  async requestPayout(channelId, amount) {
    try {
      return await stripePaymentService?.requestPayout(channelId, amount);
    } catch (error) {
      console.error('Error requesting payout:', error);
      return { data: null, error };
    }
  }
};
