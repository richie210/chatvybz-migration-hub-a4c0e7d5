import { supabase } from '../lib/supabase';

export const searchService = {
  // Search messages with filters
  async searchMessages(query, filters = {}) {
    const { data: { user } } = await supabase?.auth?.getUser();
    if (!user) throw new Error('Not authenticated');

    // Call the PostgreSQL search function
    const { data, error } = await supabase?.rpc('search_messages', {
      search_query: query,
      filter_conversation_id: filters?.conversationId || null,
      filter_message_type: filters?.messageType || null,
      filter_date_from: filters?.dateFrom || null,
      filter_date_to: filters?.dateTo || null,
      result_limit: filters?.limit || 50
    });

    if (error) throw error;

    // Convert snake_case to camelCase
    return data?.map(item => ({
      messageId: item?.message_id,
      conversationId: item?.conversation_id,
      messagePreview: item?.message_preview,
      messageType: item?.message_type,
      senderName: item?.sender_name,
      createdAt: item?.created_at,
      rank: item?.rank
    })) || [];
  },

  // Archive a chat
  async archiveChat(conversationId, conversationData) {
    const { data: { user } } = await supabase?.auth?.getUser();
    if (!user) throw new Error('Not authenticated');

    // Convert camelCase to snake_case
    const dbData = {
      user_id: user?.id,
      conversation_id: conversationId,
      conversation_name: conversationData?.conversationName,
      conversation_type: conversationData?.conversationType || 'private',
      last_message_preview: conversationData?.lastMessagePreview,
      message_count: conversationData?.messageCount || 0,
      category: conversationData?.category,
      tags: conversationData?.tags || [],
      is_pinned: conversationData?.isPinned || false,
      custom_folder: conversationData?.customFolder
    };

    const { data, error } = await supabase?.from('archived_chats')?.insert(dbData)?.select()?.single();

    if (error) throw error;

    // Convert snake_case to camelCase
    return {
      id: data?.id,
      userId: data?.user_id,
      conversationId: data?.conversation_id,
      conversationName: data?.conversation_name,
      conversationType: data?.conversation_type,
      lastMessagePreview: data?.last_message_preview,
      messageCount: data?.message_count,
      archivedAt: data?.archived_at,
      category: data?.category,
      tags: data?.tags,
      isPinned: data?.is_pinned,
      customFolder: data?.custom_folder,
      createdAt: data?.created_at,
      updatedAt: data?.updated_at
    };
  },

  // Get archived chats
  async getArchivedChats(filters = {}) {
    const { data: { user } } = await supabase?.auth?.getUser();
    if (!user) throw new Error('Not authenticated');

    let query = supabase?.from('archived_chats')?.select('*')?.eq('user_id', user?.id);

    if (filters?.category) {
      query = query?.eq('category', filters?.category);
    }

    if (filters?.isPinned !== undefined) {
      query = query?.eq('is_pinned', filters?.isPinned);
    }

    query = query?.order('archived_at', { ascending: false });

    const { data, error } = await query;

    if (error) throw error;

    // Convert snake_case to camelCase
    return data?.map(item => ({
      id: item?.id,
      userId: item?.user_id,
      conversationId: item?.conversation_id,
      conversationName: item?.conversation_name,
      conversationType: item?.conversation_type,
      lastMessagePreview: item?.last_message_preview,
      messageCount: item?.message_count,
      archivedAt: item?.archived_at,
      category: item?.category,
      tags: item?.tags,
      isPinned: item?.is_pinned,
      customFolder: item?.custom_folder,
      createdAt: item?.created_at,
      updatedAt: item?.updated_at
    })) || [];
  },

  // Unarchive a chat
  async unarchiveChat(archivedChatId) {
    const { data: { user } } = await supabase?.auth?.getUser();
    if (!user) throw new Error('Not authenticated');

    const { error } = await supabase?.from('archived_chats')?.delete()?.eq('id', archivedChatId)?.eq('user_id', user?.id);

    if (error) throw error;
  },

  // Update archived chat
  async updateArchivedChat(archivedChatId, updates) {
    const { data: { user } } = await supabase?.auth?.getUser();
    if (!user) throw new Error('Not authenticated');

    // Convert camelCase to snake_case
    const dbUpdates = {};
    if (updates?.category !== undefined) dbUpdates.category = updates?.category;
    if (updates?.tags !== undefined) dbUpdates.tags = updates?.tags;
    if (updates?.isPinned !== undefined) dbUpdates.is_pinned = updates?.isPinned;
    if (updates?.customFolder !== undefined) dbUpdates.custom_folder = updates?.customFolder;

    const { data, error } = await supabase?.from('archived_chats')?.update(dbUpdates)?.eq('id', archivedChatId)?.eq('user_id', user?.id)?.select()?.single();

    if (error) throw error;

    // Convert snake_case to camelCase
    return {
      id: data?.id,
      userId: data?.user_id,
      conversationId: data?.conversation_id,
      conversationName: data?.conversation_name,
      conversationType: data?.conversation_type,
      lastMessagePreview: data?.last_message_preview,
      messageCount: data?.message_count,
      archivedAt: data?.archived_at,
      category: data?.category,
      tags: data?.tags,
      isPinned: data?.is_pinned,
      customFolder: data?.custom_folder,
      createdAt: data?.created_at,
      updatedAt: data?.updated_at
    };
  },

  // Save a search query
  async saveSearch(queryName, searchText, filters = {}) {
    const { data: { user } } = await supabase?.auth?.getUser();
    if (!user) throw new Error('Not authenticated');

    const { data, error } = await supabase?.from('saved_search_queries')?.insert({
        user_id: user?.id,
        query_name: queryName,
        search_text: searchText,
        filters: filters,
        is_notification_enabled: false
      })?.select()?.single();

    if (error) throw error;

    // Convert snake_case to camelCase
    return {
      id: data?.id,
      userId: data?.user_id,
      queryName: data?.query_name,
      searchText: data?.search_text,
      filters: data?.filters,
      isNotificationEnabled: data?.is_notification_enabled,
      lastUsedAt: data?.last_used_at,
      createdAt: data?.created_at,
      updatedAt: data?.updated_at
    };
  },

  // Get saved searches
  async getSavedSearches() {
    const { data: { user } } = await supabase?.auth?.getUser();
    if (!user) throw new Error('Not authenticated');

    const { data, error } = await supabase?.from('saved_search_queries')?.select('*')?.eq('user_id', user?.id)?.order('last_used_at', { ascending: false, nullsFirst: false });

    if (error) throw error;

    // Convert snake_case to camelCase
    return data?.map(item => ({
      id: item?.id,
      userId: item?.user_id,
      queryName: item?.query_name,
      searchText: item?.search_text,
      filters: item?.filters,
      isNotificationEnabled: item?.is_notification_enabled,
      lastUsedAt: item?.last_used_at,
      createdAt: item?.created_at,
      updatedAt: item?.updated_at
    })) || [];
  },

  // Delete saved search
  async deleteSavedSearch(searchId) {
    const { data: { user } } = await supabase?.auth?.getUser();
    if (!user) throw new Error('Not authenticated');

    const { error } = await supabase?.from('saved_search_queries')?.delete()?.eq('id', searchId)?.eq('user_id', user?.id);

    if (error) throw error;
  },

  // Update last used timestamp
  async updateSearchLastUsed(searchId) {
    const { data: { user } } = await supabase?.auth?.getUser();
    if (!user) throw new Error('Not authenticated');

    const { error } = await supabase?.from('saved_search_queries')?.update({ last_used_at: new Date()?.toISOString() })?.eq('id', searchId)?.eq('user_id', user?.id);

    if (error) throw error;
  }
};