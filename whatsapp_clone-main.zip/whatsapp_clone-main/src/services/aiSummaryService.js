import axios from 'axios';
import { supabase } from '../lib/supabase';

/**
 * AI Summary Service
 * Handles AI-powered transcript analysis using Anthropic's Claude API
 */

const ANTHROPIC_API_KEY = import.meta.env?.VITE_ANTHROPIC_API_KEY;
const ANTHROPIC_API_URL = 'https://api.anthropic.com/v1/messages';

/**
 * Maps Anthropic API error status codes to user-friendly error messages
 * @param {number} statusCode - The HTTP status code from Anthropic API
 * @param {Object} errorData - The error data from API response
 * @returns {Object} Object with isInternal flag and error message
 */
function getErrorMessage(statusCode, errorData) {
  if (statusCode === 401) {
    return { isInternal: true, message: 'Invalid API key or authentication failed. Please check your Anthropic API key.' };
  } else if (statusCode === 403) {
    return { isInternal: true, message: 'Permission denied. Your API key does not have access to the specified resource.' };
  } else if (statusCode === 404) {
    return { isInternal: true, message: 'Resource not found. The requested endpoint or model may not exist.' };
  } else if (statusCode === 429) {
    return { isInternal: true, message: 'Rate limit exceeded. You are sending requests too quickly. Please wait a moment and try again.' };
  } else if (statusCode === 500) {
    return { isInternal: true, message: 'Anthropic service error. An unexpected error occurred on their servers. Please try again later.' };
  } else if (statusCode === 529) {
    return { isInternal: true, message: 'Anthropic service is temporarily overloaded. Please try again in a few moments.' };
  } else {
    return { isInternal: false, message: errorData?.error?.message || 'An unexpected error occurred. Please try again.' };
  }
}

/**
 * Processes a transcript with Anthropic's Claude to generate summary and insights
 * @param {string} transcript - Call/meeting transcript text
 * @returns {Promise<Object>} Processed results with summary, action items, and key points
 */
export const processTranscript = async (transcript) => {
  try {
    if (!ANTHROPIC_API_KEY) {
      throw new Error('Anthropic API key is not configured. Please add VITE_ANTHROPIC_API_KEY to your environment variables.');
    }

    if (!transcript || transcript?.trim()?.length === 0) {
      throw new Error('Transcript is empty. Cannot process empty transcript.');
    }

    const prompt = `Analyze the following call/meeting transcript and provide:

1. A concise summary (2-3 sentences) of the main discussion points
2. A list of action items with assigned person (if mentioned) and due dates (if mentioned)
3. Key discussion points with timestamps (if available)

Format your response as JSON with this structure:
{
  "summary": "Brief summary text",
  "action_items": [
    {
      "text": "Action item description",
      "assigned_to": "Person name or null",
      "due_date": "Date string or null"
    }
  ],
  "key_points": [
    {
      "timestamp": "00:00:00 or null",
      "text": "Key point description"
    }
  ]
}

Transcript:
${transcript}`;

    const response = await axios?.post(
      ANTHROPIC_API_URL,
      {
        model: 'claude-sonnet-4-20250514',
        messages: [
          {
            role: 'user',
            content: prompt
          }
        ],
        max_tokens: 2048,
        temperature: 0.3
      },
      {
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': ANTHROPIC_API_KEY,
          'anthropic-version': '2023-06-01',
          'anthropic-dangerous-direct-browser-access': 'true'
        }
      }
    );

    if (!response?.data || !response?.data?.content || !response?.data?.content?.[0]) {
      throw new Error('Invalid response from Anthropic API');
    }

    const content = response?.data?.content?.[0]?.text;
    
    // Extract JSON from response (Claude might wrap it in markdown)
    const jsonMatch = content?.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      throw new Error('Failed to extract JSON from AI response');
    }

    const result = JSON.parse(jsonMatch?.[0]);

    return {
      summary: result?.summary || '',
      action_items: result?.action_items || [],
      key_points: result?.key_points || []
    };
  } catch (error) {
    if (error?.response) {
      const errorInfo = getErrorMessage(error?.response?.status, error?.response?.data);
      const err = new Error(errorInfo.message);
      err.statusCode = error?.response?.status;
      
      if (!errorInfo?.isInternal) {
        console.error('Anthropic API error:', err);
      }
      throw err;
    }
    
    console.error('Process transcript error:', error);
    throw error;
  }
};

/**
 * Processes a recording's transcript and updates the database
 * @param {string} recordingId - Recording UUID
 * @param {string} transcript - Transcript text
 * @returns {Promise<Object>} Updated recording with AI insights
 */
export const processRecordingTranscript = async (recordingId, transcript) => {
  try {
    // Update recording status to processing
    const { error: updateError1 } = await supabase?.from('meeting_recordings')?.update({ 
        is_processing: true,
        processing_error: null 
      })?.eq('id', recordingId);

    if (updateError1) {
      console.error('Update processing status error:', updateError1);
      throw updateError1;
    }

    // Process with AI
    const aiResults = await processTranscript(transcript);

    // Update recording with AI results
    const { data, error } = await supabase?.from('meeting_recordings')?.update({
        transcript,
        ai_summary: aiResults?.summary,
        action_items: aiResults?.action_items,
        key_points: aiResults?.key_points,
        is_processing: false,
        processed_at: new Date()?.toISOString()
      })?.eq('id', recordingId)?.select()?.single();

    if (error) {
      console.error('Update AI results error:', error);
      throw error;
    }

    return data;
  } catch (error) {
    // Update recording with error
    await supabase?.from('meeting_recordings')?.update({
        is_processing: false,
        processing_error: error?.message
      })?.eq('id', recordingId);

    throw error;
  }
};

/**
 * Regenerates AI insights for an existing recording
 * @param {string} recordingId - Recording UUID
 * @returns {Promise<Object>} Updated recording with new AI insights
 */
export const regenerateAIInsights = async (recordingId) => {
  try {
    // Get existing recording
    const { data: recording, error: fetchError } = await supabase?.from('meeting_recordings')?.select('transcript')?.eq('id', recordingId)?.single();

    if (fetchError) {
      console.error('Fetch recording error:', fetchError);
      throw fetchError;
    }

    if (!recording?.transcript) {
      throw new Error('No transcript found for this recording');
    }

    return await processRecordingTranscript(recordingId, recording?.transcript);
  } catch (error) {
    console.error('Regenerate AI insights error:', error);
    throw error;
  }
};