import { supabase } from '../lib/supabase';

export const scheduledMessageService = {
  // Create scheduled message
  async create(messageData) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data, error } = await supabase?.from('scheduled_messages')?.insert({
          sender_id: user?.id,
          recipient_id: messageData?.recipientId,
          message: messageData?.message,
          scheduled_time: messageData?.scheduledTime,
          timezone: messageData?.timezone || 'UTC',
          recurring_pattern: messageData?.recurringPattern || null,
          is_encrypted: messageData?.isEncrypted || false,
          nonce: messageData?.nonce || null,
          attachments: messageData?.attachments || []
        })?.select()?.single();

      if (error) throw error;

      return {
        id: data?.id,
        senderId: data?.sender_id,
        recipientId: data?.recipient_id,
        message: data?.message,
        scheduledTime: data?.scheduled_time,
        timezone: data?.timezone,
        deliveryStatus: data?.delivery_status,
        deliveryConfirmation: data?.delivery_confirmation,
        recurringPattern: data?.recurring_pattern,
        createdAt: data?.created_at,
        updatedAt: data?.updated_at
      };
    } catch (error) {
      console.error('Error creating scheduled message:', error);
      throw error;
    }
  },

  // Get all scheduled messages for current user
  async getAll() {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data, error } = await supabase?.from('scheduled_messages')?.select(`
          *,
          recipient:profiles!scheduled_messages_recipient_id_fkey(id, full_name, avatar_url)
        `)?.eq('sender_id', user?.id)?.order('scheduled_time', { ascending: true });

      if (error) throw error;

      return data?.map(item => ({
        id: item?.id,
        senderId: item?.sender_id,
        recipientId: item?.recipient_id,
        recipient: {
          id: item?.recipient?.id,
          fullName: item?.recipient?.full_name,
          avatarUrl: item?.recipient?.avatar_url
        },
        message: item?.message,
        scheduledTime: item?.scheduled_time,
        timezone: item?.timezone,
        deliveryStatus: item?.delivery_status,
        deliveryConfirmation: item?.delivery_confirmation,
        recurringPattern: item?.recurring_pattern,
        attachments: item?.attachments,
        createdAt: item?.created_at,
        updatedAt: item?.updated_at,
        deliveredAt: item?.delivered_at,
        cancelledAt: item?.cancelled_at,
        editHistory: item?.edit_history
      })) || [];
    } catch (error) {
      console.error('Error fetching scheduled messages:', error);
      throw error;
    }
  },

  // Get pending scheduled messages
  async getPending() {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data, error } = await supabase?.from('scheduled_messages')?.select(`
          *,
          recipient:profiles!scheduled_messages_recipient_id_fkey(id, full_name, avatar_url)
        `)?.eq('sender_id', user?.id)?.eq('delivery_status', 'pending')?.is('cancelled_at', null)?.order('scheduled_time', { ascending: true });

      if (error) throw error;

      return data?.map(item => ({
        id: item?.id,
        recipientId: item?.recipient_id,
        recipient: {
          id: item?.recipient?.id,
          fullName: item?.recipient?.full_name,
          avatarUrl: item?.recipient?.avatar_url
        },
        message: item?.message,
        scheduledTime: item?.scheduled_time,
        timezone: item?.timezone,
        recurringPattern: item?.recurring_pattern,
        attachments: item?.attachments,
        createdAt: item?.created_at
      })) || [];
    } catch (error) {
      console.error('Error fetching pending scheduled messages:', error);
      throw error;
    }
  },

  // Edit scheduled message
  async edit(messageId, updates) {
    try {
      const { data, error } = await supabase?.rpc('edit_scheduled_message', {
        message_uuid: messageId,
        new_message: updates?.message,
        new_scheduled_time: updates?.scheduledTime
      });

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error editing scheduled message:', error);
      throw error;
    }
  },

  // Cancel scheduled message
  async cancel(messageId) {
    try {
      const { data, error } = await supabase?.rpc('cancel_scheduled_message', {
        message_uuid: messageId
      });

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error cancelling scheduled message:', error);
      throw error;
    }
  },

  // Delete scheduled message
  async delete(messageId) {
    try {
      const { error } = await supabase?.from('scheduled_messages')?.delete()?.eq('id', messageId);

      if (error) throw error;
      return { success: true };
    } catch (error) {
      console.error('Error deleting scheduled message:', error);
      throw error;
    }
  },

  // Subscribe to scheduled message changes
  subscribeToChanges(callback) {
    const channel = supabase?.channel('scheduled_messages_changes')?.on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'scheduled_messages'
        },
        (payload) => {
          callback(payload);
        }
      )?.subscribe();

    return () => {
      supabase?.removeChannel(channel);
    };
  }
};