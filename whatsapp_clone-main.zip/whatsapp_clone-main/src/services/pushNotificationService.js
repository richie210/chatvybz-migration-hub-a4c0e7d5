import { supabase } from '../lib/supabase';

/**
 * Push Notification Service
 * Handles browser push notifications using Supabase real-time
 */

class PushNotificationService {
  constructor() {
    this.subscription = null;
    this.channel = null;
  }

  /**
   * Check if push notifications are supported
   */
  isSupported() {
    return 'Notification' in window && 'serviceWorker' in navigator;
  }

  /**
   * Request notification permission
   */
  async requestPermission() {
    if (!this.isSupported()) {
      return {
        success: false,
        error: 'Push notifications not supported'
      };
    }

    try {
      const permission = await Notification.requestPermission();
      
      return {
        success: permission === 'granted',
        permission
      };
    } catch (error) {
      console.error('Error requesting notification permission:', error);
      return {
        success: false,
        error: error?.message
      };
    }
  }

  /**
   * Initialize push notification subscription
   */
  async initialize(userId) {
    try {
      if (!this.isSupported()) {
        throw new Error('Push notifications not supported');
      }

      // Request permission first
      const permissionResult = await this.requestPermission();
      if (!permissionResult?.success) {
        return permissionResult;
      }

      // Subscribe to Supabase real-time for new messages
      await this.subscribeToMessages(userId);

      // Store subscription info
      await this.saveSubscription(userId);

      return {
        success: true,
        message: 'Push notifications enabled'
      };
    } catch (error) {
      console.error('Error initializing push notifications:', error);
      return {
        success: false,
        error: error?.message
      };
    }
  }

  /**
   * Subscribe to real-time message notifications
   */
  async subscribeToMessages(userId) {
    // Remove existing subscription
    if (this.channel) {
      await supabase?.removeChannel(this.channel);
    }

    // Subscribe to new messages for this user
    this.channel = supabase?.channel('message-notifications')?.on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'chat_messages',
          filter: `receiver_id=eq.${userId}`
        },
        async (payload) => {
          await this.showNotification(payload?.new);
        }
      )?.subscribe();

    return this.channel;
  }

  /**
   * Show browser notification
   */
  async showNotification(message) {
    try {
      if (Notification.permission !== 'granted') {
        return;
      }

      // Don't show notification if page is focused
      if (document.hasFocus()) {
        return;
      }

      // Get sender info
      const { data: sender } = await supabase?.from('profiles')?.select('username, avatar_url')?.eq('id', message?.sender_id)?.single();

      const title = sender?.username || 'New Message';
      let body = '';

      if (message?.audio_url) {
        body = '🎤 Audio message';
      } else if (message?.is_encrypted) {
        body = '🔒 Encrypted message';
      } else {
        body = message?.content?.substring(0, 100);
      }

      const notification = new Notification(title, {
        body,
        icon: sender?.avatar_url || '/favicon.ico',
        badge: '/favicon.ico',
        tag: `message-${message.id}`,
        requireInteraction: false,
        silent: false
      });

      notification.onclick = () => {
        window.focus();
        notification?.close();
        // Navigate to chat if needed
        window.location.hash = `#/chat/${message?.sender_id}`;
      };

      // Auto-close after 5 seconds
      setTimeout(() => notification?.close(), 5000);
    } catch (error) {
      console.error('Error showing notification:', error);
    }
  }

  /**
   * Save subscription to database
   */
  async saveSubscription(userId) {
    try {
      // Create a pseudo-subscription object for database
      const subscriptionData = {
        user_id: userId,
        endpoint: `supabase-realtime-${userId}`,
        keys: {
          p256dh: 'supabase',
          auth: 'realtime'
        },
        user_agent: navigator.userAgent
      };

      const { error } = await supabase?.from('push_subscriptions')?.upsert(subscriptionData, {
          onConflict: 'user_id,endpoint'
        });

      if (error) throw error;

      this.subscription = subscriptionData;

      return {
        success: true
      };
    } catch (error) {
      console.error('Error saving subscription:', error);
      return {
        success: false,
        error: error?.message
      };
    }
  }

  /**
   * Unsubscribe from push notifications
   */
  async unsubscribe(userId) {
    try {
      // Remove real-time subscription
      if (this.channel) {
        await supabase?.removeChannel(this.channel);
        this.channel = null;
      }

      // Remove from database
      if (this.subscription) {
        await supabase?.from('push_subscriptions')?.delete()?.eq('user_id', userId)?.eq('endpoint', this.subscription?.endpoint);

        this.subscription = null;
      }

      return {
        success: true,
        message: 'Push notifications disabled'
      };
    } catch (error) {
      console.error('Error unsubscribing:', error);
      return {
        success: false,
        error: error?.message
      };
    }
  }

  /**
   * Check if user has active subscription
   */
  async hasSubscription(userId) {
    try {
      const { data, error } = await supabase?.from('push_subscriptions')?.select('*')?.eq('user_id', userId)?.maybeSingle();

      if (error) throw error;

      return !!data;
    } catch (error) {
      console.error('Error checking subscription:', error);
      return false;
    }
  }
}

export const pushNotificationService = new PushNotificationService();