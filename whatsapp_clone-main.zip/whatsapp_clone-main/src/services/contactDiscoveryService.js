import { supabase } from '../lib/supabase';
import phoneValidationService from './phoneValidationService';

export const contactDiscoveryService = {
  /**
   * Sync contacts with platform users
   * Normalizes all phone numbers to E.164 format before syncing
   */
  async syncContacts(userId, contacts) {
    try {
      // Normalize contacts to E.164 format
      const normalizedContacts = phoneValidationService?.normalizeContactList(contacts);

      // Prepare contacts for insertion
      const contactsToInsert = normalizedContacts?.map(contact => ({
        user_id: userId,
        contact_phone: contact?.phoneNumber, // Already in E.164 format
        contact_name: contact?.name,
        contact_country_code: contact?.countryCode,
        sync_status: 'pending'
      }));

      // Delete existing contacts for this user
      await supabase?.from('user_contacts')?.delete()?.eq('user_id', userId);

      // Insert new contacts
      const { error: insertError } = await supabase?.from('user_contacts')?.insert(contactsToInsert);

      if (insertError) throw insertError;

      // Update or create sync status
      const { error: syncStatusError } = await supabase?.from('contact_sync_status')?.upsert({
          user_id: userId,
          total_contacts: normalizedContacts?.length,
          last_sync_at: new Date()?.toISOString()
        });

      if (syncStatusError) throw syncStatusError;

      // Call function to match contacts with platform users
      const { error: matchError } = await supabase?.rpc(
        'match_contacts_with_platform_users',
        { p_user_id: userId }
      );

      if (matchError) throw matchError;

      return await this.getDiscoveredUsers(userId);
    } catch (error) {
      console.error('Error syncing contacts:', error);
      throw error;
    }
  },

  /**
   * Get discovered platform users from contacts
   */
  async getDiscoveredUsers(userId) {
    try {
      const { data, error } = await supabase?.from('user_contacts')?.select(`
          id,
          contact_name,
          contact_phone,
          contact_country_code,
          is_platform_user,
          platform_user_id,
          created_at,
          profiles:platform_user_id (
            id,
            display_name,
            full_name,
            avatar_url,
            bio
          )
        `)?.eq('user_id', userId)?.eq('is_platform_user', true)?.order('created_at', { ascending: false });

      if (error) throw error;

      return data?.map(contact => ({
        id: contact?.id,
        contactName: contact?.contact_name,
        contactPhone: contact?.contact_phone,
        countryCode: contact?.contact_country_code,
        isPlatformUser: contact?.is_platform_user,
        platformUserId: contact?.platform_user_id,
        profile: contact?.profiles ? {
          id: contact?.profiles?.id,
          displayName: contact?.profiles?.display_name,
          fullName: contact?.profiles?.full_name,
          avatarUrl: contact?.profiles?.avatar_url,
          bio: contact?.profiles?.bio
        } : null
      })) || [];
    } catch (error) {
      console.error('Error getting discovered users:', error);
      throw error;
    }
  },

  /**
   * Get all synced contacts
   */
  async getAllContacts(userId) {
    try {
      const { data, error } = await supabase?.from('user_contacts')?.select(`
          id,
          contact_name,
          contact_phone,
          contact_country_code,
          is_platform_user,
          platform_user_id,
          sync_status,
          profiles:platform_user_id (
            display_name,
            avatar_url
          )
        `)?.eq('user_id', userId)?.order('is_platform_user', { ascending: false })?.order('contact_name', { ascending: true });

      if (error) throw error;

      return data?.map(contact => ({
        id: contact?.id,
        contactName: contact?.contact_name,
        contactPhone: contact?.contact_phone,
        countryCode: contact?.contact_country_code,
        isPlatformUser: contact?.is_platform_user,
        platformUserId: contact?.platform_user_id,
        syncStatus: contact?.sync_status,
        profile: contact?.profiles ? {
          displayName: contact?.profiles?.display_name,
          avatarUrl: contact?.profiles?.avatar_url
        } : null
      })) || [];
    } catch (error) {
      console.error('Error getting all contacts:', error);
      throw error;
    }
  },

  /**
   * Get contact sync status
   */
  async getSyncStatus(userId) {
    try {
      const { data, error } = await supabase?.from('contact_sync_status')?.select('*')?.eq('user_id', userId)?.maybeSingle();

      if (error) throw error;

      if (!data) {
        return {
          totalContacts: 0,
          platformUsersFound: 0,
          lastSyncAt: null,
          syncEnabled: true
        };
      }

      return {
        totalContacts: data?.total_contacts,
        platformUsersFound: data?.platform_users_found,
        lastSyncAt: data?.last_sync_at,
        syncEnabled: data?.sync_enabled
      };
    } catch (error) {
      console.error('Error getting sync status:', error);
      throw error;
    }
  },

  /**
   * Update sync enabled status
   */
  async updateSyncEnabled(userId, enabled) {
    try {
      const { error } = await supabase?.from('contact_sync_status')?.upsert({
          user_id: userId,
          sync_enabled: enabled,
          updated_at: new Date()?.toISOString()
        });

      if (error) throw error;
    } catch (error) {
      console.error('Error updating sync status:', error);
      throw error;
    }
  }
};