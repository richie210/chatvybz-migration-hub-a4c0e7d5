import { supabase } from '../lib/supabase';

/**
 * Advanced Call Search Service
 * Provides comprehensive search capabilities across call history
 */
export const callSearchService = {
  /**
   * Search call history with advanced filters
   * @param {Object} filters - Search filters
   * @param {string} filters.searchText - Text to search in transcripts
   * @param {string[]} filters.participantIds - Filter by participant user IDs
   * @param {number} filters.minDuration - Minimum call duration in seconds
   * @param {number} filters.maxDuration - Maximum call duration in seconds
   * @param {Date} filters.startDate - Start date for date range
   * @param {Date} filters.endDate - End date for date range
   * @param {string[]} filters.callTypes - Filter by call types (voice, video, conference)
   * @param {number} filters.limit - Number of results to return
   * @param {number} filters.offset - Pagination offset
   * @returns {Promise<Array>} Array of call history results with relevance scores
   */
  async searchCalls(filters = {}) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data, error } = await supabase?.rpc('search_call_history', {
        p_user_id: user?.id,
        p_search_text: filters?.searchText || null,
        p_participant_ids: filters?.participantIds || null,
        p_min_duration: filters?.minDuration || null,
        p_max_duration: filters?.maxDuration || null,
        p_start_date: filters?.startDate ? filters?.startDate?.toISOString() : null,
        p_end_date: filters?.endDate ? filters?.endDate?.toISOString() : null,
        p_call_types: filters?.callTypes || null,
        p_limit: filters?.limit || 50,
        p_offset: filters?.offset || 0
      });

      if (error) throw error;

      // Convert snake_case to camelCase
      return data?.map(call => ({
        callId: call?.call_id,
        callType: call?.call_type,
        callStatus: call?.call_status,
        duration: call?.duration,
        startedAt: call?.started_at,
        endedAt: call?.ended_at,
        initiatorName: call?.initiator_name,
        initiatorAvatar: call?.initiator_avatar,
        participantCount: call?.participant_count,
        participants: call?.participants,
        hasRecording: call?.has_recording,
        recordingId: call?.recording_id,
        transcriptSnippet: call?.transcript_snippet,
        relevanceScore: call?.relevance_score
      }));
    } catch (error) {
      console.error('Error searching calls:', error);
      throw error;
    }
  },

  /**
   * Get search suggestions based on user's search history
   * @param {string} partialText - Partial search text for autocomplete
   * @returns {Promise<Array>} Array of search suggestions
   */
  async getSearchSuggestions(partialText) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data, error } = await supabase?.rpc('get_search_suggestions', {
        p_user_id: user?.id,
        p_partial_text: partialText,
        p_limit: 10
      });

      if (error) throw error;

      return data?.map(item => ({
        suggestion: item?.suggestion,
        searchCount: item?.search_count,
        lastUsed: item?.last_used
      }));
    } catch (error) {
      console.error('Error getting search suggestions:', error);
      throw error;
    }
  },

  /**
   * Save a search query for future use
   * @param {string} queryName - Name for the saved search
   * @param {string} searchText - Search text
   * @param {Object} filters - Search filters to save
   * @param {boolean} enableNotifications - Whether to enable notifications for new matches
   * @returns {Promise<Object>} Saved search query object
   */
  async saveSearchQuery(queryName, searchText, filters, enableNotifications = false) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data, error } = await supabase?.from('saved_search_queries')?.insert({
          user_id: user?.id,
          query_name: queryName,
          search_text: searchText,
          filters: filters,
          is_notification_enabled: enableNotifications,
          last_used_at: new Date()?.toISOString()
        })?.select()?.single();

      if (error) throw error;

      return {
        id: data?.id,
        queryName: data?.query_name,
        searchText: data?.search_text,
        filters: data?.filters,
        isNotificationEnabled: data?.is_notification_enabled,
        lastUsedAt: data?.last_used_at,
        createdAt: data?.created_at
      };
    } catch (error) {
      console.error('Error saving search query:', error);
      throw error;
    }
  },

  /**
   * Get all saved search queries for the current user
   * @returns {Promise<Array>} Array of saved search queries
   */
  async getSavedSearches() {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data, error } = await supabase?.from('saved_search_queries')?.select('*')?.eq('user_id', user?.id)?.order('last_used_at', { ascending: false });

      if (error) throw error;

      return data?.map(query => ({
        id: query?.id,
        queryName: query?.query_name,
        searchText: query?.search_text,
        filters: query?.filters,
        isNotificationEnabled: query?.is_notification_enabled,
        lastUsedAt: query?.last_used_at,
        createdAt: query?.created_at
      }));
    } catch (error) {
      console.error('Error fetching saved searches:', error);
      throw error;
    }
  },

  /**
   * Update the last used timestamp for a saved search
   * @param {string} searchId - ID of the saved search
   * @returns {Promise<void>}
   */
  async updateSearchUsage(searchId) {
    try {
      const { error } = await supabase?.from('saved_search_queries')?.update({ last_used_at: new Date()?.toISOString() })?.eq('id', searchId);

      if (error) throw error;
    } catch (error) {
      console.error('Error updating search usage:', error);
      throw error;
    }
  },

  /**
   * Delete a saved search query
   * @param {string} searchId - ID of the saved search to delete
   * @returns {Promise<void>}
   */
  async deleteSavedSearch(searchId) {
    try {
      const { error } = await supabase?.from('saved_search_queries')?.delete()?.eq('id', searchId);

      if (error) throw error;
    } catch (error) {
      console.error('Error deleting saved search:', error);
      throw error;
    }
  },

  /**
   * Get all participants who have been in calls with the current user
   * @returns {Promise<Array>} Array of participant profiles
   */
  async getCallParticipants() {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      // Get all unique participants from calls
      const { data, error } = await supabase?.from('call_participants')?.select(`
          user_id,
          profiles!call_participants_user_id_fkey (
            id,
            display_name,
            avatar_url,
            email
          )
        `)?.neq('user_id', user?.id);

      if (error) throw error;

      // Remove duplicates and format
      const uniqueParticipants = data?.reduce((acc, item) => {
        const profile = item?.profiles;
        if (profile && !acc?.find(p => p?.userId === profile?.id)) {
          acc?.push({
            userId: profile?.id,
            displayName: profile?.display_name,
            avatarUrl: profile?.avatar_url,
            email: profile?.email
          });
        }
        return acc;
      }, []);

      return uniqueParticipants;
    } catch (error) {
      console.error('Error fetching call participants:', error);
      throw error;
    }
  },

  /**
   * Export search results to a file format
   * @param {Array} results - Search results to export
   * @param {string} format - Export format (json, csv)
   * @returns {string} Formatted export data
   */
  exportResults(results, format = 'json') {
    if (format === 'json') {
      return JSON.stringify(results, null, 2);
    } else if (format === 'csv') {
      if (results?.length === 0) return '';
      
      const headers = Object.keys(results?.[0])?.join(',');
      const rows = results?.map(result => 
        Object.values(result)?.map(val => 
          typeof val === 'object' ? JSON.stringify(val) : val
        )?.join(',')
      );
      
      return [headers, ...rows]?.join('\n');
    }
    
    throw new Error('Unsupported export format');
  }
};