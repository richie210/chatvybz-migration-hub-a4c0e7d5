import { supabase } from '../lib/supabase';

export const autoDeleteService = {
  // Get auto-delete settings for a conversation
  async getSettings(conversationId) {
    try {
      // Check authentication first
      const { data: { user }, error: authError } = await supabase?.auth?.getUser();
      
      if (authError) {
        throw new Error(`Authentication error: ${authError?.message}`);
      }
      
      if (!user) {
        throw new Error('Not authenticated. Please sign in to access this feature.');
      }

      const { data, error } = await supabase
        ?.from('message_auto_delete_settings')
        ?.select('*')
        ?.eq('user_id', user?.id)
        ?.eq('conversation_id', conversationId)
        ?.single();

      if (error && error?.code !== 'PGRST116') {
        throw new Error(`Database error: ${error?.message}`);
      }
      
      // Convert snake_case to camelCase
      if (data) {
        return {
          id: data?.id,
          userId: data?.user_id,
          conversationId: data?.conversation_id,
          isEnabled: data?.is_enabled,
          durationType: data?.duration_type,
          customDurationHours: data?.custom_duration_hours,
          applyToMedia: data?.apply_to_media,
          applyToDocuments: data?.apply_to_documents,
          applyToText: data?.apply_to_text,
          isEncrypted: data?.is_encrypted,
          createdAt: data?.created_at,
          updatedAt: data?.updated_at
        };
      }
      
      return null;
    } catch (error) {
      console.error('AutoDeleteService getSettings error:', error);
      throw error;
    }
  },

  // Create or update auto-delete settings
  async upsertSettings(conversationId, settings) {
    try {
      // Check authentication first
      const { data: { user }, error: authError } = await supabase?.auth?.getUser();
      
      if (authError) {
        throw new Error(`Authentication error: ${authError?.message}`);
      }
      
      if (!user) {
        throw new Error('Not authenticated. Please sign in to save settings.');
      }

      // Convert camelCase to snake_case
      const dbSettings = {
        user_id: user?.id,
        conversation_id: conversationId,
        is_enabled: settings?.isEnabled,
        duration_type: settings?.durationType,
        custom_duration_hours: settings?.customDurationHours,
        apply_to_media: settings?.applyToMedia,
        apply_to_documents: settings?.applyToDocuments,
        apply_to_text: settings?.applyToText,
        is_encrypted: settings?.isEncrypted
      };

      const { data, error } = await supabase?.from('message_auto_delete_settings')?.upsert(dbSettings, { onConflict: 'user_id,conversation_id' })?.select()?.single();

      if (error) throw error;

      // Convert snake_case to camelCase
      return {
        id: data?.id,
        userId: data?.user_id,
        conversationId: data?.conversation_id,
        isEnabled: data?.is_enabled,
        durationType: data?.duration_type,
        customDurationHours: data?.custom_duration_hours,
        applyToMedia: data?.apply_to_media,
        applyToDocuments: data?.apply_to_documents,
        applyToText: data?.apply_to_text,
        isEncrypted: data?.is_encrypted,
        createdAt: data?.created_at,
        updatedAt: data?.updated_at
      };
    } catch (error) {
      console.error('AutoDeleteService upsertSettings error:', error);
      throw error;
    }
  },

  // Delete auto-delete settings
  async deleteSettings(conversationId) {
    try {
      // Check authentication first
      const { data: { user }, error: authError } = await supabase?.auth?.getUser();
      
      if (authError) {
        throw new Error(`Authentication error: ${authError?.message}`);
      }
      
      if (!user) {
        throw new Error('Not authenticated. Please sign in to delete settings.');
      }

      const { error } = await supabase?.from('message_auto_delete_settings')?.delete()?.eq('user_id', user?.id)?.eq('conversation_id', conversationId);

      if (error) throw error;
    } catch (error) {
      console.error('AutoDeleteService deleteSettings error:', error);
      throw error;
    }
  },

  // Get all conversations with auto-delete enabled
  async getEnabledConversations() {
    try {
      // Check authentication first
      const { data: { user }, error: authError } = await supabase?.auth?.getUser();
      
      if (authError) {
        throw new Error(`Authentication error: ${authError?.message}`);
      }
      
      if (!user) {
        throw new Error('Not authenticated. Please sign in to view enabled conversations.');
      }

      const { data, error } = await supabase?.from('message_auto_delete_settings')?.select('*')?.eq('user_id', user?.id)?.eq('is_enabled', true);

      if (error) throw error;

      // Convert snake_case to camelCase
      return data?.map(item => ({
        id: item?.id,
        userId: item?.user_id,
        conversationId: item?.conversation_id,
        isEnabled: item?.is_enabled,
        durationType: item?.duration_type,
        customDurationHours: item?.custom_duration_hours,
        applyToMedia: item?.apply_to_media,
        applyToDocuments: item?.apply_to_documents,
        applyToText: item?.apply_to_text,
        isEncrypted: item?.is_encrypted,
        createdAt: item?.created_at,
        updatedAt: item?.updated_at
      })) || [];
    } catch (error) {
      console.error('AutoDeleteService getEnabledConversations error:', error);
      throw error;
    }
  },

  // Calculate delete timestamp for a duration type
  getDurationLabel(durationType, customHours) {
    switch (durationType) {
      case '24h':
        return '24 hours';
      case '7d':
        return '7 days';
      case '30d':
        return '30 days';
      case '90d':
        return '90 days';
      case 'custom':
        return `${customHours || 24} hours`;
      default:
        return '24 hours';
    }
  }
};