import { supabase } from '../lib/supabase';

/**
 * Service for managing incoming call alerts and operations
 */
export const incomingCallService = {
  /**
   * Subscribe to incoming calls for the current user
   * @param {string} userId - Current user's ID
   * @param {Function} onCallReceived - Callback when call is received
   * @returns {Function} Unsubscribe function
   */
  subscribeToIncomingCalls(userId, onCallReceived) {
    const channel = supabase?.channel('incoming-calls')?.on('postgres_changes',
        {
          event: 'INSERT',schema: 'public',table: 'calls',
          filter: `recipient_id=eq.${userId}`,
        },
        async (payload) => {
          const call = payload?.new;
          
          // Fetch caller profile information
          const { data: callerProfile } = await supabase?.from('profiles')?.select('id, display_name, full_name, avatar_url')?.eq('id', call?.initiator_id)?.single();

          onCallReceived({
            ...call,
            caller: callerProfile,
          });
        }
      )?.subscribe();

    return () => {
      supabase?.removeChannel(channel);
    };
  },

  /**
   * Get current user's active incoming calls
   * @param {string} userId - Current user's ID
   * @returns {Promise<Array>} Array of incoming calls
   */
  async getIncomingCalls(userId) {
    const { data, error } = await supabase?.from('calls')?.select(`
        *,
        caller:profiles!calls_initiator_id_fkey(
          id,
          display_name,
          full_name,
          avatar_url
        )
      `)?.eq('recipient_id', userId)?.eq('call_status', 'ringing')?.order('created_at', { ascending: false });

    if (error) throw error;
    return data || [];
  },

  /**
   * Accept an incoming call
   * @param {string} callId - Call ID to accept
   * @returns {Promise<Object>} Updated call data
   */
  async acceptCall(callId) {
    const { data, error } = await supabase?.from('calls')?.update({
        call_status: 'ongoing',
        started_at: new Date()?.toISOString(),
      })?.eq('id', callId)?.select()?.single();

    if (error) throw error;
    return data;
  },

  /**
   * Decline an incoming call
   * @param {string} callId - Call ID to decline
   * @returns {Promise<Object>} Updated call data
   */
  async declineCall(callId) {
    const { data, error } = await supabase?.from('calls')?.update({
        call_status: 'declined',
        ended_at: new Date()?.toISOString(),
      })?.eq('id', callId)?.select()?.single();

    if (error) throw error;
    return data;
  },

  /**
   * End an ongoing call
   * @param {string} callId - Call ID to end
   * @returns {Promise<Object>} Updated call data
   */
  async endCall(callId) {
    const { data, error } = await supabase?.from('calls')?.update({
        call_status: 'ended',
        ended_at: new Date()?.toISOString(),
      })?.eq('id', callId)?.select()?.single();

    if (error) throw error;
    return data;
  },
};