import localforage from 'localforage';

class OfflineStorageService {
  constructor() {
    // Configure localforage for message queue
    this.messageQueue = localforage?.createInstance({
      name: 'chatvybz',
      storeName: 'message_queue',
      description: 'Queue for unsent messages'
    });

    // Configure localforage for encryption keys
    this.keyStore = localforage?.createInstance({
      name: 'chatvybz',
      storeName: 'encryption_keys',
      description: 'Storage for encryption keys'
    });

    // Configure localforage for recipient public keys
    this.recipientKeyStore = localforage?.createInstance({
      name: 'chatvybz',
      storeName: 'recipient_keys',
      description: 'Storage for recipient public keys'
    });
  }

  // Queue a message for sending when online
  async queueMessage(message) {
    try {
      const queueId = `msg_${Date.now()}_${Math.random()?.toString(36)?.substr(2, 9)}`;
      const queuedMessage = {
        ...message,
        queueId,
        queuedAt: new Date()?.toISOString(),
        retryCount: 0,
        status: 'queued'
      };
      
      await this.messageQueue?.setItem(queueId, queuedMessage);
      return queueId;
    } catch (error) {
      console.error('Error queuing message:', error);
      throw error;
    }
  }

  // Get all queued messages
  async getQueuedMessages() {
    try {
      const messages = [];
      await this.messageQueue?.iterate((value, key) => {
        messages?.push(value);
      });
      return messages?.sort((a, b) => 
        new Date(a.queuedAt)?.getTime() - new Date(b.queuedAt)?.getTime()
      );
    } catch (error) {
      console.error('Error getting queued messages:', error);
      return [];
    }
  }

  // Remove a message from queue
  async removeFromQueue(queueId) {
    try {
      await this.messageQueue?.removeItem(queueId);
    } catch (error) {
      console.error('Error removing message from queue:', error);
    }
  }

  // Update message status in queue
  async updateQueuedMessage(queueId, updates) {
    try {
      const message = await this.messageQueue?.getItem(queueId);
      if (message) {
        await this.messageQueue?.setItem(queueId, { ...message, ...updates });
      }
    } catch (error) {
      console.error('Error updating queued message:', error);
    }
  }

  // Clear all queued messages
  async clearQueue() {
    try {
      await this.messageQueue?.clear();
    } catch (error) {
      console.error('Error clearing queue:', error);
    }
  }

  // Store user's encryption keys
  async storeEncryptionKeys(publicKey, privateKey) {
    try {
      await this.keyStore?.setItem('userKeys', { publicKey, privateKey });
    } catch (error) {
      console.error('Error storing encryption keys:', error);
      throw error;
    }
  }

  // Retrieve user's encryption keys
  async getEncryptionKeys() {
    try {
      return await this.keyStore?.getItem('userKeys');
    } catch (error) {
      console.error('Error retrieving encryption keys:', error);
      return null;
    }
  }

  // Store recipient's public key
  async storeRecipientPublicKey(recipientId, publicKey) {
    try {
      await this.recipientKeyStore?.setItem(recipientId?.toString(), publicKey);
    } catch (error) {
      console.error('Error storing recipient public key:', error);
    }
  }

  // Get recipient's public key
  async getRecipientPublicKey(recipientId) {
    try {
      return await this.recipientKeyStore?.getItem(recipientId?.toString());
    } catch (error) {
      console.error('Error getting recipient public key:', error);
      return null;
    }
  }

  // Get all recipient public keys
  async getAllRecipientPublicKeys() {
    try {
      const keys = {};
      await this.recipientKeyStore?.iterate((value, key) => {
        keys[key] = value;
      });
      return keys;
    } catch (error) {
      console.error('Error getting all recipient public keys:', error);
      return {};
    }
  }

  // Clear all stored data (for logout)
  async clearAllData() {
    try {
      await Promise.all([
        this.messageQueue?.clear(),
        this.keyStore?.clear(),
        this.recipientKeyStore?.clear()
      ]);
    } catch (error) {
      console.error('Error clearing all data:', error);
    }
  }
}

export const offlineStorageService = new OfflineStorageService();