import { supabase } from '../lib/supabase';

/**
 * Audio Recording Service
 * Handles audio recording, waveform generation, and storage upload
 */

class AudioRecordingService {
  constructor() {
    this.mediaRecorder = null;
    this.audioChunks = [];
    this.audioContext = null;
    this.analyser = null;
    this.dataArray = null;
    this.animationId = null;
    this.stream = null;
  }

  /**
   * Start audio recording with waveform analysis
   */
  async startRecording() {
    try {
      // Request microphone access
      this.stream = await navigator.mediaDevices?.getUserMedia({ audio: true });

      // Setup audio analysis for waveform
      this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
      this.analyser = this.audioContext?.createAnalyser();
      const source = this.audioContext?.createMediaStreamSource(this.stream);
      source?.connect(this.analyser);
      this.analyser.fftSize = 2048;
      const bufferLength = this.analyser?.frequencyBinCount;
      this.dataArray = new Uint8Array(bufferLength);

      // Setup MediaRecorder
      const mimeType = this.getSupportedMimeType();
      this.mediaRecorder = new MediaRecorder(this.stream, { mimeType });
      this.audioChunks = [];

      this.mediaRecorder.ondataavailable = (event) => {
        if (event?.data?.size > 0) {
          this.audioChunks?.push(event?.data);
        }
      };

      this.mediaRecorder?.start();

      return {
        success: true,
        message: 'Recording started'
      };
    } catch (error) {
      console.error('Error starting recording:', error);
      return {
        success: false,
        error: error?.message
      };
    }
  }

  /**
   * Get waveform data for visualization
   */
  getWaveformData() {
    if (!this.analyser || !this.dataArray) return [];

    this.analyser?.getByteTimeDomainData(this.dataArray);
    
    // Sample the data to get ~50 points for visualization
    const samples = 50;
    const blockSize = Math.floor(this.dataArray?.length / samples);
    const waveform = [];

    for (let i = 0; i < samples; i++) {
      const start = blockSize * i;
      let sum = 0;
      for (let j = 0; j < blockSize; j++) {
        sum += Math.abs(this.dataArray?.[start + j] - 128);
      }
      waveform?.push(sum / blockSize / 128); // Normalize to 0-1
    }

    return waveform;
  }

  /**
   * Stop recording and return audio blob
   */
  async stopRecording() {
    return new Promise((resolve, reject) => {
      if (!this.mediaRecorder || this.mediaRecorder.state === 'inactive') {
        reject(new Error('No active recording'));
        return;
      }

      this.mediaRecorder.onstop = async () => {
        try {
          const audioBlob = new Blob(this.audioChunks, { 
            type: this.getSupportedMimeType() 
          });
          
          // Get final waveform
          const waveform = this.getWaveformData();

          // Calculate duration
          const duration = await this.getAudioDuration(audioBlob);

          // Cleanup
          this.cleanup();

          resolve({
            blob: audioBlob,
            waveform,
            duration,
            mimeType: this.getSupportedMimeType()
          });
        } catch (error) {
          reject(error);
        }
      };

      this.mediaRecorder.stop();
    });
  }

  /**
   * Cancel recording without saving
   */
  cancelRecording() {
    if (this.mediaRecorder && this.mediaRecorder?.state !== 'inactive') {
      this.mediaRecorder?.stop();
    }
    this.cleanup();
  }

  /**
   * Get audio duration from blob
   */
  async getAudioDuration(blob) {
    return new Promise((resolve) => {
      const audio = new Audio();
      audio.addEventListener('loadedmetadata', () => {
        resolve(Math.round(audio.duration));
        audio.remove();
      });
      audio.src = URL.createObjectURL(blob);
    });
  }

  /**
   * Upload audio to Supabase storage
   */
  async uploadAudio(blob, userId) {
    try {
      const timestamp = Date.now();
      const extension = this.getExtensionFromMimeType(blob?.type);
      const fileName = `${userId}/${timestamp}.${extension}`;

      const { data, error } = await supabase?.storage?.from('audio-messages')?.upload(fileName, blob, {
          contentType: blob?.type,
          cacheControl: '3600',
          upsert: false
        });

      if (error) throw error;

      return {
        success: true,
        path: data?.path
      };
    } catch (error) {
      console.error('Error uploading audio:', error);
      return {
        success: false,
        error: error?.message
      };
    }
  }

  /**
   * Get signed URL for private audio file
   */
  async getAudioUrl(path) {
    try {
      const { data, error } = await supabase?.storage?.from('audio-messages')?.createSignedUrl(path, 3600); // 1 hour expiry

      if (error) throw error;

      return {
        success: true,
        url: data?.signedUrl
      };
    } catch (error) {
      console.error('Error getting audio URL:', error);
      return {
        success: false,
        error: error?.message
      };
    }
  }

  /**
   * Get supported MIME type for recording
   */
  getSupportedMimeType() {
    const types = [
      'audio/webm',
      'audio/ogg',
      'audio/wav',
      'audio/mp4'
    ];

    for (const type of types) {
      if (MediaRecorder.isTypeSupported(type)) {
        return type;
      }
    }

    return 'audio/webm'; // fallback
  }

  /**
   * Get file extension from MIME type
   */
  getExtensionFromMimeType(mimeType) {
    const map = {
      'audio/webm': 'webm',
      'audio/ogg': 'ogg',
      'audio/wav': 'wav',
      'audio/mp4': 'm4a',
      'audio/mpeg': 'mp3'
    };
    return map?.[mimeType] || 'webm';
  }

  /**
   * Cleanup resources
   */
  cleanup() {
    if (this.stream) {
      this.stream?.getTracks()?.forEach(track => track?.stop());
      this.stream = null;
    }

    if (this.audioContext) {
      this.audioContext?.close();
      this.audioContext = null;
    }

    if (this.animationId) {
      cancelAnimationFrame(this.animationId);
      this.animationId = null;
    }

    this.mediaRecorder = null;
    this.audioChunks = [];
    this.analyser = null;
    this.dataArray = null;
  }
}

export const audioRecordingService = new AudioRecordingService();