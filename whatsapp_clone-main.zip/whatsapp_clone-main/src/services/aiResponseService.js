import openai from '../lib/openai';
import { 
  APIConnectionError,
  AuthenticationError,
  PermissionDeniedError,
  RateLimitError,
  InternalServerError
} from 'openai';
import { supabase } from '../lib/supabase';

/**
 * Maps OpenAI API error types to user-friendly error messages.
 * @param {Error} error - The error object from OpenAI API.
 * @returns {Object} Error information with isInternal flag and message.
 */
function getErrorMessage(error) {
  if (error instanceof AuthenticationError) {
    return { isInternal: true, message: 'Invalid API key or authentication failed. Please check your OpenAI API key.' };
  } else if (error instanceof PermissionDeniedError) {
    return { isInternal: true, message: 'Quota exceeded or authorization failed. You may have exceeded your usage limits or do not have access to this resource.' };
  } else if (error instanceof RateLimitError) {
    return { isInternal: true, message: 'Rate limit exceeded. You are sending requests too quickly. Please wait a moment and try again.' };
  } else if (error instanceof InternalServerError) {
    return { isInternal: true, message: 'OpenAI service is currently unavailable. Please try again later.' };
  } else if (error instanceof APIConnectionError) {
    return { isInternal: true, message: 'Unable to connect to OpenAI service. Please check your API key and internet connection.' };
  } else {
    return { isInternal: false, message: error?.message || 'An unexpected error occurred. Please try again.' };
  }
}

/**
 * Generates context-aware quick response suggestions for group chat messages.
 * @param {string} messageContent - The message content to analyze.
 * @param {string} conversationId - The conversation/group ID.
 * @param {string} userId - The current user's ID.
 * @returns {Promise<Array>} Array of suggested quick responses.
 */
export async function generateQuickResponses(messageContent, conversationId, userId) {
  try {
    // Fetch recent conversation context
    const { data: recentMessages } = await supabase?.from('chat_messages')?.select('message, sender_name')?.eq('recipient_id', conversationId)?.order('created_at', { ascending: false })?.limit(5);

    const contextMessages = recentMessages?.reverse()?.map(msg => 
      `${msg?.sender_name}: ${msg?.message}`
    )?.join('\n') || '';

    const response = await openai?.chat?.completions?.create({
      model: 'gpt-5-mini',
      messages: [
        { 
          role: 'system', 
          content: `You are a helpful assistant that generates contextually appropriate quick reply suggestions for group chats. 
                   Generate 3-4 short, natural responses that would be appropriate given the conversation context.
                   Keep responses concise (under 50 characters each), friendly, and relevant to the message content.` 
        },
        { 
          role: 'user', 
          content: `Recent conversation:\n${contextMessages}\n\nLatest message: "${messageContent}"\n\nGenerate appropriate quick responses.` 
        },
      ],
      response_format: {
        type: 'json_schema',
        json_schema: {
          name: 'quick_responses',
          schema: {
            type: 'object',
            properties: {
              suggestions: {
                type: 'array',
                items: {
                  type: 'object',
                  properties: {
                    text: { type: 'string', description: 'The suggested response text' },
                    type: { type: 'string', enum: ['acknowledgment', 'question', 'agreement', 'emoji'], description: 'Type of response' }
                  },
                  required: ['text', 'type']
                },
                minItems: 3,
                maxItems: 4
              }
            },
            required: ['suggestions'],
            additionalProperties: false,
          },
        },
      },
      reasoning_effort: 'minimal',
      verbosity: 'low',
    });

    const result = JSON.parse(response?.choices?.[0]?.message?.content);
    return result?.suggestions || [];
  } catch (error) {
    const errorInfo = getErrorMessage(error);
    if (errorInfo?.isInternal) {
      console.log(errorInfo?.message);
    } else {
      console.error('Error generating quick responses:', error);
    }
    throw new Error(errorInfo?.message);
  }
}

/**
 * Analyzes message sentiment and context to provide better suggestions.
 * @param {string} messageContent - The message to analyze.
 * @returns {Promise<Object>} Analysis result with sentiment and topics.
 */
export async function analyzeMessageContext(messageContent) {
  try {
    const response = await openai?.chat?.completions?.create({
      model: 'gpt-5-nano',
      messages: [
        { 
          role: 'system', 
          content: 'Analyze the sentiment and main topics of the message. Be concise.' 
        },
        { role: 'user', content: messageContent },
      ],
      response_format: {
        type: 'json_schema',
        json_schema: {
          name: 'message_analysis',
          schema: {
            type: 'object',
            properties: {
              sentiment: { 
                type: 'string', 
                enum: ['positive', 'negative', 'neutral', 'question'],
                description: 'Overall sentiment of the message'
              },
              topics: { 
                type: 'array', 
                items: { type: 'string' },
                description: 'Main topics discussed'
              },
              urgency: {
                type: 'string',
                enum: ['low', 'medium', 'high'],
                description: 'Urgency level of the message'
              }
            },
            required: ['sentiment', 'topics', 'urgency'],
            additionalProperties: false,
          },
        },
      },
      reasoning_effort: 'minimal',
      verbosity: 'low',
    });

    return JSON.parse(response?.choices?.[0]?.message?.content);
  } catch (error) {
    const errorInfo = getErrorMessage(error);
    if (errorInfo?.isInternal) {
      console.log(errorInfo?.message);
    } else {
      console.error('Error analyzing message context:', error);
    }
    throw new Error(errorInfo?.message);
  }
}