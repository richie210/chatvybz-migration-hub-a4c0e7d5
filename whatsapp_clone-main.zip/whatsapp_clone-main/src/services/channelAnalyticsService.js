import { supabase } from '../lib/supabase';

/**
 * Channel Analytics Service - Handles subscriber analytics and engagement metrics
 */

export const channelAnalyticsService = {
  /**
   * Get comprehensive subscriber analytics for a channel
   */
  async getSubscriberAnalytics(channelId, dateRange = { days: 30 }) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('User not authenticated');

      // Get channel details
      const { data: channel, error: channelError } = await supabase
        ?.from('channels')
        ?.select('*')
        ?.eq('id', channelId)
        ?.single();

      if (channelError) throw channelError;

      // Calculate date range
      const endDate = new Date();
      const startDate = new Date();
      startDate?.setDate(startDate?.getDate() - (dateRange?.days || 30));

      // Get subscriber growth data
      const { data: subscriberGrowth, error: growthError } = await supabase
        ?.from('channel_users')
        ?.select('joined_at, role')
        ?.eq('channel_id', channelId)
        ?.gte('joined_at', startDate?.toISOString())
        ?.order('joined_at', { ascending: true });

      if (growthError) throw growthError;

      // Get all subscribers for demographic analysis
      const { data: subscribers, error: subscribersError } = await supabase
        ?.from('channel_users')
        ?.select(`
          *,
          user:user_id(
            id,
            full_name,
            avatar_url,
            country_code,
            created_at
          )
        `)
        ?.eq('channel_id', channelId);

      if (subscribersError) throw subscribersError;

      // Get message engagement data
      const { data: messages, error: messagesError } = await supabase
        ?.from('channel_messages')
        ?.select('id, views_count, sent_at, media_type')
        ?.eq('channel_id', channelId)
        ?.gte('sent_at', startDate?.toISOString())
        ?.order('sent_at', { ascending: false });

      if (messagesError) throw messagesError;

      // Get message views for engagement analysis
      const { data: messageViews, error: viewsError } = await supabase
        ?.from('channel_message_views')
        ?.select(`
          *,
          message:message_id(channel_id, sent_at)
        `)
        ?.gte('viewed_at', startDate?.toISOString());

      if (viewsError) throw viewsError;

      // Filter views for this channel
      const channelViews = messageViews?.filter(
        view => view?.message?.channel_id === channelId
      );

      // Calculate metrics
      const analytics = this.calculateAnalytics({
        channel,
        subscriberGrowth,
        subscribers,
        messages,
        messageViews: channelViews,
        dateRange
      });

      return { data: analytics, error: null };
    } catch (error) {
      console.error('Error fetching subscriber analytics:', error);
      return { data: null, error };
    }
  },

  /**
   * Calculate comprehensive analytics from raw data
   */
  calculateAnalytics({ channel, subscriberGrowth, subscribers, messages, messageViews, dateRange }) {
    // Subscriber growth metrics
    const totalSubscribers = channel?.subscribers_count || 0;
    const newSubscribers = subscriberGrowth?.length || 0;
    const previousPeriodSubscribers = totalSubscribers - newSubscribers;
    const growthRate = previousPeriodSubscribers > 0
      ? ((newSubscribers / previousPeriodSubscribers) * 100)?.toFixed(1)
      : 0;

    // Engagement metrics
    const totalMessages = messages?.length || 0;
    const totalViews = messageViews?.length || 0;
    const avgViewsPerMessage = totalMessages > 0
      ? (totalViews / totalMessages)?.toFixed(1)
      : 0;
    const engagementRate = totalSubscribers > 0
      ? ((totalViews / (totalMessages * totalSubscribers)) * 100)?.toFixed(1)
      : 0;

    // Demographic breakdown
    const demographics = this.calculateDemographics(subscribers);

    // Content performance
    const contentPerformance = this.calculateContentPerformance(messages);

    // Growth trend data for charts
    const growthTrend = this.calculateGrowthTrend(subscriberGrowth, dateRange);

    // Engagement trend
    const engagementTrend = this.calculateEngagementTrend(messageViews, dateRange);

    // Top performing messages
    const topMessages = messages
      ?.sort((a, b) => (b?.views_count || 0) - (a?.views_count || 0))
      ?.slice(0, 5)
      ?.map(msg => ({
        id: msg?.id,
        viewsCount: msg?.views_count || 0,
        sentAt: msg?.sent_at,
        mediaType: msg?.media_type
      }));

    // Subscriber lifecycle analysis
    const lifecycle = this.calculateLifecycle(subscribers, messageViews);

    // Optimal posting times
    const optimalTimes = this.calculateOptimalPostingTimes(messageViews);

    return {
      overview: {
        totalSubscribers,
        newSubscribers,
        growthRate: parseFloat(growthRate),
        engagementRate: parseFloat(engagementRate),
        totalMessages,
        totalViews,
        avgViewsPerMessage: parseFloat(avgViewsPerMessage)
      },
      demographics,
      contentPerformance,
      growthTrend,
      engagementTrend,
      topMessages,
      lifecycle,
      optimalTimes,
      dateRange
    };
  },

  /**
   * Calculate demographic breakdown
   */
  calculateDemographics(subscribers) {
    const countryDistribution = {};
    const roleDistribution = {
      subscriber: 0,
      administrator: 0,
      owner: 0
    };

    subscribers?.forEach(sub => {
      // Country distribution
      const country = sub?.user?.country_code || 'Unknown';
      countryDistribution[country] = (countryDistribution?.[country] || 0) + 1;

      // Role distribution
      if (sub?.role) {
        roleDistribution[sub.role] = (roleDistribution?.[sub?.role] || 0) + 1;
      }
    });

    // Convert to array format for charts
    const countries = Object.entries(countryDistribution)?.map(([country, count]) => ({ country, count }))?.sort((a, b) => b?.count - a?.count)?.slice(0, 10);

    return {
      countries,
      roles: [
        { role: 'Subscribers', count: roleDistribution?.subscriber },
        { role: 'Administrators', count: roleDistribution?.administrator },
        { role: 'Owners', count: roleDistribution?.owner }
      ]
    };
  },

  /**
   * Calculate content performance by media type
   */
  calculateContentPerformance(messages) {
    const typePerformance = {};

    messages?.forEach(msg => {
      const type = msg?.media_type || 'text';
      if (!typePerformance?.[type]) {
        typePerformance[type] = {
          count: 0,
          totalViews: 0
        };
      }
      typePerformance[type].count += 1;
      typePerformance[type].totalViews += msg?.views_count || 0;
    });

    return Object.entries(typePerformance)?.map(([type, data]) => ({
      type,
      count: data?.count,
      avgViews: data?.count > 0 ? (data?.totalViews / data?.count)?.toFixed(1) : 0
    }));
  },

  /**
   * Calculate growth trend over time
   */
  calculateGrowthTrend(subscriberGrowth, dateRange) {
    const days = dateRange?.days || 30;
    const trend = [];
    const endDate = new Date();

    for (let i = days - 1; i >= 0; i--) {
      const date = new Date(endDate);
      date?.setDate(date?.getDate() - i);
      const dateStr = date?.toISOString()?.split('T')?.[0];

      const count = subscriberGrowth?.filter(sub => {
        const subDate = new Date(sub?.joined_at)?.toISOString()?.split('T')?.[0];
        return subDate === dateStr;
      })?.length || 0;

      trend?.push({
        date: dateStr,
        subscribers: count
      });
    }

    return trend;
  },

  /**
   * Calculate engagement trend over time
   */
  calculateEngagementTrend(messageViews, dateRange) {
    const days = dateRange?.days || 30;
    const trend = [];
    const endDate = new Date();

    for (let i = days - 1; i >= 0; i--) {
      const date = new Date(endDate);
      date?.setDate(date?.getDate() - i);
      const dateStr = date?.toISOString()?.split('T')?.[0];

      const views = messageViews?.filter(view => {
        const viewDate = new Date(view?.viewed_at)?.toISOString()?.split('T')?.[0];
        return viewDate === dateStr;
      })?.length || 0;

      trend?.push({
        date: dateStr,
        views
      });
    }

    return trend;
  },

  /**
   * Calculate subscriber lifecycle stages
   */
  calculateLifecycle(subscribers, messageViews) {
    const now = new Date();
    const lifecycle = {
      new: 0,        // Joined within 7 days
      active: 0,     // Viewed messages in last 7 days
      inactive: 0,   // No views in 7-30 days
      dormant: 0     // No views in 30+ days
    };

    subscribers?.forEach(sub => {
      const joinedDate = new Date(sub?.joined_at);
      const daysSinceJoin = (now - joinedDate) / (1000 * 60 * 60 * 24);

      // Check if new subscriber
      if (daysSinceJoin <= 7) {
        lifecycle.new += 1;
        return;
      }

      // Check last view activity
      const userViews = messageViews?.filter(view => view?.user_id === sub?.user_id);
      if (userViews?.length === 0) {
        lifecycle.dormant += 1;
        return;
      }

      const lastView = userViews?.sort((a, b) => 
        new Date(b?.viewed_at) - new Date(a?.viewed_at)
      )?.[0];
      const daysSinceLastView = (now - new Date(lastView?.viewed_at)) / (1000 * 60 * 60 * 24);

      if (daysSinceLastView <= 7) {
        lifecycle.active += 1;
      } else if (daysSinceLastView <= 30) {
        lifecycle.inactive += 1;
      } else {
        lifecycle.dormant += 1;
      }
    });

    return [
      { stage: 'New', count: lifecycle?.new },
      { stage: 'Active', count: lifecycle?.active },
      { stage: 'Inactive', count: lifecycle?.inactive },
      { stage: 'Dormant', count: lifecycle?.dormant }
    ];
  },

  /**
   * Calculate optimal posting times based on engagement
   */
  calculateOptimalPostingTimes(messageViews) {
    const hourlyEngagement = Array(24)?.fill(0);

    messageViews?.forEach(view => {
      const hour = new Date(view?.viewed_at)?.getHours();
      hourlyEngagement[hour] += 1;
    });

    // Find top 3 hours
    const topHours = hourlyEngagement?.map((count, hour) => ({ hour, count }))?.sort((a, b) => b?.count - a?.count)?.slice(0, 3);

    return topHours?.map(({ hour, count }) => ({
      time: `${hour?.toString()?.padStart(2, '0')}:00`,
      engagement: count
    }));
  },

  /**
   * Get cohort analysis for retention
   */
  async getCohortAnalysis(channelId) {
    try {
      const { data: subscribers, error } = await supabase
        ?.from('channel_users')
        ?.select(`
          joined_at,
          user_id
        `)
        ?.eq('channel_id', channelId)
        ?.order('joined_at', { ascending: true });

      if (error) throw error;

      // Group by month
      const cohorts = {};
      subscribers?.forEach(sub => {
        const month = new Date(sub?.joined_at)?.toISOString()?.slice(0, 7);
        if (!cohorts?.[month]) {
          cohorts[month] = [];
        }
        cohorts?.[month]?.push(sub?.user_id);
      });

      return { data: cohorts, error: null };
    } catch (error) {
      console.error('Error fetching cohort analysis:', error);
      return { data: null, error };
    }
  },

  /**
   * Export analytics report
   */
  async exportReport(channelId, format = 'json') {
    try {
      const { data: analytics, error } = await this.getSubscriberAnalytics(channelId);
      if (error) throw error;

      if (format === 'json') {
        const blob = new Blob([JSON.stringify(analytics, null, 2)], {
          type: 'application/json'
        });
        return { data: blob, error: null };
      }

      // CSV format
      let csv = this.convertToCSV(analytics);
      const blob = new Blob([csv], { type: 'text/csv' });
      return { data: blob, error: null };
    } catch (error) {
      console.error('Error exporting report:', error);
      return { data: null, error };
    }
  },

  /**
   * Convert analytics to CSV format
   */
  convertToCSV(analytics) {
    let csv = 'Channel Subscriber Analytics Report\n\n';
    
    // Overview section
    csv += 'Overview\n';
    csv += 'Metric,Value\n';
    Object.entries(analytics?.overview || {})?.forEach(([key, value]) => {
      csv += `${key},${value}\n`;
    });
    
    csv += '\n';
    return csv;
  }
};

export default channelAnalyticsService;