import { account } from '../lib/appwrite';
import { ID } from 'appwrite';
import { supabase } from '../lib/supabase';
import appwriteSessionService from './appwriteSessionService';

/**
 * Appwrite OTP Authentication Service
 * Handles phone-based authentication using Appwrite's built-in OTP system
 */

const appwriteAuthService = {
  /**
   * Send OTP to phone number
   * @param {string} phoneNumber - Phone number in E.164 format (e.g., +1234567890)
   * @returns {Promise<Object>} - Result with userId and success status
   */
  async sendOTP(phoneNumber) {
    try {
      console.log('📱 Appwrite: Sending OTP to:', phoneNumber);
      
      // Create phone session (sends OTP automatically)
      const token = await account?.createPhoneToken(
        ID?.unique(),
        phoneNumber
      );
      
      console.log('✅ Appwrite: OTP sent successfully');
      
      return {
        success: true,
        userId: token?.userId,
        deliveryMethod: 'sms',
        message: 'OTP sent successfully'
      };
    } catch (error) {
      console.error('❌ Appwrite: Send OTP error:', error);
      
      // Handle specific Appwrite errors
      let errorMessage = 'Failed to send OTP';
      let errorCode = 'SEND_FAILED';
      
      if (error?.code === 401) {
        errorMessage = 'Invalid project credentials';
        errorCode = 'INVALID_CREDENTIALS';
      } else if (error?.code === 429) {
        errorMessage = 'Too many requests. Please try again later';
        errorCode = 'RATE_LIMIT';
      } else if (error?.message?.includes('Invalid phone number')) {
        errorMessage = 'Invalid phone number format. Use E.164 format (+1234567890)';
        errorCode = 'INVALID_PHONE';
      } else if (error?.message) {
        errorMessage = error?.message;
      }
      
      return {
        success: false,
        error: errorMessage,
        code: errorCode
      };
    }
  },

  /**
   * Verify OTP and create session
   * @param {string} userId - User ID from sendOTP response
   * @param {string} otp - 6-digit OTP code
   * @returns {Promise<Object>} - Result with session and user data
   */
  async verifyOTP(userId, otp) {
    try {
      console.log('🔐 Appwrite: Verifying OTP for user:', userId);
      
      // Verify OTP and create session
      const session = await account?.createSession(
        userId,
        otp
      );
      
      console.log('✅ Appwrite: OTP verified, session created');
      
      // Get user details
      const user = await account?.get();
      
      // Track session creation with device and location info
      if (session?.$id && user?.$id) {
        await appwriteSessionService?.trackSessionCreation(session?.$id, user?.$id);
      }
      
      return {
        success: true,
        session,
        user,
        phone: user?.phone
      };
    } catch (error) {
      console.error('❌ Appwrite: Verify OTP error:', error);
      
      let errorMessage = 'Invalid or expired OTP';
      let errorCode = 'INVALID_OTP';
      
      if (error?.code === 401) {
        errorMessage = 'Invalid OTP code';
        errorCode = 'INVALID_OTP';
      } else if (error?.code === 404) {
        errorMessage = 'Session expired. Please request a new OTP';
        errorCode = 'EXPIRED_OTP';
      } else if (error?.message) {
        errorMessage = error?.message;
      }
      
      return {
        success: false,
        error: errorMessage,
        code: errorCode
      };
    }
  },

  /**
   * Check if user exists in Supabase by phone number
   * @param {string} phoneNumber - Phone number in E.164 format
   * @returns {Promise<Object>} - Result with userExists flag
   */
  async checkUserExists(phoneNumber) {
    try {
      const { data, error } = await supabase?.from('user_profiles')?.select('id, phone_number')?.eq('phone_number', phoneNumber)?.single();
      
      if (error && error?.code !== 'PGRST116') {
        console.error('Error checking user:', error);
        return { userExists: false };
      }
      
      return { userExists: !!data };
    } catch (error) {
      console.error('Error checking user existence:', error);
      return { userExists: false };
    }
  },

  /**
   * Get current session
   * @returns {Promise<Object>} - Current session or null
   */
  async getCurrentSession() {
    try {
      const session = await account?.getSession('current');
      return { success: true, session };
    } catch (error) {
      return { success: false, session: null };
    }
  },

  /**
   * Logout current session
   * @returns {Promise<Object>} - Logout result
   */
  async logout() {
    try {
      await account?.deleteSession('current');
      return { success: true };
    } catch (error) {
      console.error('Logout error:', error);
      return { success: false, error: error?.message };
    }
  },

  /**
   * Format phone number to E.164
   * @param {string} countryCode - Country code (e.g., '+1')
   * @param {string} phoneNumber - Local phone number
   * @returns {string} - Formatted phone number
   */
  formatPhoneE164(countryCode, phoneNumber) {
    // Remove all non-digit characters
    const cleanPhone = phoneNumber?.replace(/\D/g, '');
    const cleanCode = countryCode?.replace(/\D/g, '');
    
    // Format to E.164: +{country_code}{phone_number}
    return `+${cleanCode}${cleanPhone}`;
  }
};

export default appwriteAuthService;