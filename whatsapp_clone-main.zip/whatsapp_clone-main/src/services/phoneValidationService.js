/**
 * Phone Validation Service
 * Handles comprehensive phone number validation using libphonenumber-js
 * Ensures E.164 format compliance for international numbers
 * Enhanced support for Caribbean regions including Martinique (+596)
 */

import { 
  parsePhoneNumber, 
  isValidPhoneNumber, 
  getCountries, 
  getCountryCallingCode 
} from 'libphonenumber-js';

/**
 * Caribbean region country codes that require special handling
 * Martinique: +596 (9 digits)
 * Guadeloupe: +590 (9 digits)
 * French Guiana: +594 (9 digits)
 * Réunion/Mayotte: +262 (9 digits)
 */
const CARIBBEAN_REGIONS = {
  '596': { name: 'Martinique', expectedLength: 9, format: '+596 696 XX XX XX' },
  '590': { name: 'Guadeloupe', expectedLength: 9, format: '+590 690 XX XX XX' },
  '594': { name: 'French Guiana', expectedLength: 9, format: '+594 694 XX XX XX' },
  '262': { name: 'Réunion/Mayotte', expectedLength: 9, format: '+262 692 XX XX XX' },
};

const phoneValidationService = {
  /**
   * Validate and parse phone number to E.164 format
   * Enhanced with Caribbean region support
   * @param {string} phoneNumber - Phone number in any format
   * @param {string} defaultCountry - Default country code (ISO 3166-1 alpha-2)
   * @returns {Object} Validation result with E.164 format
   */
  validateAndFormat(phoneNumber, defaultCountry = 'US') {
    try {
      if (!phoneNumber) {
        return {
          isValid: false,
          error: 'Phone number is required'
        };
      }

      // Extract country code if present
      const match = phoneNumber?.match(/^\+(\d{1,4})/);
      const countryCode = match ? match?.[1] : null;
      
      // Special validation for Caribbean regions
      if (countryCode && CARIBBEAN_REGIONS?.[countryCode]) {
        const region = CARIBBEAN_REGIONS?.[countryCode];
        const cleanPhone = phoneNumber?.replace(/\D/g, '')?.substring(countryCode?.length);
        
        if (cleanPhone?.length !== region?.expectedLength) {
          return {
            isValid: false,
            error: `${region?.name} phone numbers should have ${region?.expectedLength} digits after the country code`,
            hint: `Expected format: ${region?.format}`,
            countryCode: `+${countryCode}`,
            region: region?.name
          };
        }
      }

      // Check if number is valid using libphonenumber-js
      const isValid = isValidPhoneNumber(phoneNumber, defaultCountry);
      
      if (!isValid) {
        return {
          isValid: false,
          error: 'Invalid phone number format',
          hint: countryCode && CARIBBEAN_REGIONS?.[countryCode] 
            ? `For ${CARIBBEAN_REGIONS?.[countryCode]?.name}, use format: ${CARIBBEAN_REGIONS?.[countryCode]?.format}`
            : 'Please include country code (e.g., +1 for US, +596 for Martinique)'
        };
      }

      // Parse the phone number
      const parsed = parsePhoneNumber(phoneNumber, defaultCountry);
      
      return {
        isValid: true,
        e164: parsed?.number,
        national: parsed?.formatNational(),
        international: parsed?.formatInternational(),
        countryCode: `+${parsed?.countryCallingCode}`,
        nationalNumber: parsed?.nationalNumber,
        country: parsed?.country,
        isPossible: parsed?.isPossible(),
        type: parsed?.getType(),
        isCaribbean: CARIBBEAN_REGIONS?.[parsed?.countryCallingCode] !== undefined,
        regionInfo: CARIBBEAN_REGIONS?.[parsed?.countryCallingCode]
      };
    } catch (error) {
      console.error('Phone validation error:', error);
      return {
        isValid: false,
        error: error?.message || 'Failed to validate phone number'
      };
    }
  },

  /**
   * Validate phone number length for specific country
   * @param {string} phoneNumber - Phone number
   * @param {string} countryCode - ISO country code
   * @returns {boolean} True if length is valid
   */
  validateLength(phoneNumber, countryCode) {
    try {
      const parsed = parsePhoneNumber(phoneNumber, countryCode);
      return parsed?.isPossible();
    } catch (error) {
      return false;
    }
  },

  /**
   * Get all supported countries
   * @returns {Array} List of country codes
   */
  getSupportedCountries() {
    try {
      return getCountries();
    } catch (error) {
      return [];
    }
  },

  /**
   * Get country calling code
   * @param {string} countryCode - ISO country code (e.g., 'MQ')
   * @returns {string} Calling code (e.g., '596')
   */
  getCallingCode(countryCode) {
    try {
      return getCountryCallingCode(countryCode);
    } catch (error) {
      return null;
    }
  },

  /**
   * Format phone number for display
   * @param {string} phoneNumber - Phone number in E.164 format
   * @param {string} format - 'national' or 'international'
   * @returns {string} Formatted phone number
   */
  formatForDisplay(phoneNumber, format = 'international') {
    try {
      const parsed = parsePhoneNumber(phoneNumber);
      return format === 'national' 
        ? parsed?.formatNational() 
        : parsed?.formatInternational();
    } catch (error) {
      return phoneNumber;
    }
  },

  /**
   * Normalize contact list to E.164 format
   * Used for contact discovery
   * @param {Array} contacts - Array of contact objects with phone numbers
   * @param {string} userCountry - User's country code for context
   * @returns {Array} Normalized contacts in E.164 format
   */
  normalizeContactList(contacts, userCountry = 'US') {
    const normalized = [];
    
    for (const contact of contacts || []) {
      try {
        const validation = this.validateAndFormat(contact?.phoneNumber, userCountry);
        
        if (validation?.isValid) {
          normalized?.push({
            ...contact,
            phoneNumber: validation?.e164,
            countryCode: validation?.countryCode,
            nationalNumber: validation?.nationalNumber,
            country: validation?.country,
            isValid: true
          });
        }
      } catch (error) {
        console.error('Failed to normalize contact:', error);
      }
    }
    
    return normalized;
  },

  /**
   * Check if phone number matches E.164 format
   * @param {string} phoneNumber - Phone number to check
   * @returns {boolean} True if E.164 format
   */
  isE164Format(phoneNumber) {
    if (!phoneNumber || typeof phoneNumber !== 'string') {
      return false;
    }
    const e164Regex = /^\+[1-9]\d{1,14}$/;
    return e164Regex?.test(phoneNumber);
  },

  /**
   * Extract country code from E.164 number
   * @param {string} e164Number - Phone number in E.164 format
   * @returns {string|null} Country code or null
   */
  extractCountryCode(e164Number) {
    try {
      const parsed = parsePhoneNumber(e164Number);
      return `+${parsed?.countryCallingCode}`;
    } catch (error) {
      return null;
    }
  },
  
  /**
   * Get Caribbean region info for a country code
   * @param {string} countryCode - Country calling code (e.g., '596')
   * @returns {Object|null} Region info or null
   */
  getCaribbeanRegionInfo(countryCode) {
    const cleanCode = countryCode?.replace(/\D/g, '');
    return CARIBBEAN_REGIONS?.[cleanCode] || null;
  },
  
  /**
   * Validate Martinique phone number specifically
   * @param {string} phoneNumber - Phone number to validate
   * @returns {Object} Validation result
   */
  validateMartiniqueNumber(phoneNumber) {
    const validation = this.validateAndFormat(phoneNumber, 'MQ');
    
    if (!validation?.isValid) {
      return validation;
    }
    
    // Additional Martinique-specific validation
    if (validation?.countryCode !== '+596') {
      return {
        isValid: false,
        error: 'Not a Martinique phone number',
        hint: 'Martinique numbers start with +596'
      };
    }
    
    return validation;
  }
};

export default phoneValidationService;
