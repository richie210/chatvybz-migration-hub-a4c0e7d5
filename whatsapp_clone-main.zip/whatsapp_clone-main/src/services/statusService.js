import { supabase } from '../lib/supabase';
import { encryptionService } from './encryptionService';

/**
 * Status Service - Handles ephemeral status updates with 24-hour auto-delete
 */

/**
 * Create a new status update (photo/video)
 * @param {Object} statusData - { media_url, media_type, caption, duration }
 */
export const createStatus = async (statusData) => {
  try {
    const { data: { user } } = await supabase?.auth?.getUser();
    if (!user) throw new Error('User not authenticated');

    // Encrypt caption if provided
    let encryptedCaption = null;
    let encryptionNonce = null;
    
    if (statusData?.caption) {
      const encrypted = await encryptionService?.encryptMessage(statusData?.caption);
      encryptedCaption = encrypted?.encryptedData;
      encryptionNonce = encrypted?.nonce;
    }

    const { data, error } = await supabase?.from('status_updates')?.insert([{
        user_id: user?.id,
        media_url: statusData?.media_url,
        media_type: statusData?.media_type,
        caption: encryptedCaption,
        encryption_nonce: encryptionNonce,
        duration: statusData?.duration || 24, // Default 24 hours
        expires_at: new Date(Date.now() + (statusData.duration || 24) * 60 * 60 * 1000)?.toISOString()
      }])?.select(`
        *,
        user:user_profiles!status_updates_user_id_fkey(
          id,
          username,
          avatar_url,
          full_name
        )
      `)?.single();

    if (error) throw error;

    // Decrypt caption for return
    if (data?.caption && data?.encryption_nonce) {
      data.decrypted_caption = await encryptionService?.decryptMessage(
        data?.caption,
        data?.encryption_nonce
      );
    }

    return { data, error: null };
  } catch (error) {
    console.error('Error creating status:', error);
    return { data: null, error };
  }
};

/**
 * Get all active statuses from contacts (not expired)
 */
export const getContactStatuses = async () => {
  try {
    const { data: { user } } = await supabase?.auth?.getUser();
    if (!user) throw new Error('User not authenticated');

    // Get statuses from contacts, grouped by user
    const { data, error } = await supabase?.from('status_updates')?.select(`
        *,
        user:user_profiles!status_updates_user_id_fkey(
          id,
          username,
          avatar_url,
          full_name
        ),
        views:status_views(count)
      `)?.gt('expires_at', new Date()?.toISOString())?.order('created_at', { ascending: false });

    if (error) throw error;

    // Decrypt captions
    const decryptedData = await Promise.all(
      (data || [])?.map(async (status) => {
        if (status?.caption && status?.encryption_nonce) {
          status.decrypted_caption = await encryptionService?.decryptMessage(
            status?.caption,
            status?.encryption_nonce
          );
        }
        return status;
      })
    );

    // Group by user
    const groupedStatuses = decryptedData?.reduce((acc, status) => {
      const userId = status?.user_id;
      if (!acc?.[userId]) {
        acc[userId] = {
          user: status?.user,
          statuses: [],
          lastStatusTime: status?.created_at,
          totalViews: 0
        };
      }
      acc?.[userId]?.statuses?.push(status);
      acc[userId].totalViews += status?.views?.[0]?.count || 0;
      return acc;
    }, {});

    return { data: Object.values(groupedStatuses), error: null };
  } catch (error) {
    console.error('Error fetching contact statuses:', error);
    return { data: null, error };
  }
};

/**
 * Get my own statuses
 */
export const getMyStatuses = async () => {
  try {
    const { data: { user } } = await supabase?.auth?.getUser();
    if (!user) throw new Error('User not authenticated');

    const { data, error } = await supabase?.from('status_updates')?.select(`
        *,
        views:status_views(
          id,
          viewer:user_profiles!status_views_viewer_id_fkey(
            id,
            username,
            avatar_url,
            full_name
          ),
          viewed_at
        )
      `)?.eq('user_id', user?.id)?.gt('expires_at', new Date()?.toISOString())?.order('created_at', { ascending: false });

    if (error) throw error;

    // Decrypt captions
    const decryptedData = await Promise.all(
      (data || [])?.map(async (status) => {
        if (status?.caption && status?.encryption_nonce) {
          status.decrypted_caption = await encryptionService?.decryptMessage(
            status?.caption,
            status?.encryption_nonce
          );
        }
        return status;
      })
    );

    return { data: decryptedData, error: null };
  } catch (error) {
    console.error('Error fetching my statuses:', error);
    return { data: null, error };
  }
};

/**
 * Mark a status as viewed
 */
export const markStatusAsViewed = async (statusId) => {
  try {
    const { data: { user } } = await supabase?.auth?.getUser();
    if (!user) throw new Error('User not authenticated');

    const { data, error } = await supabase?.from('status_views')?.insert([{
        status_id: statusId,
        viewer_id: user?.id
      }])?.select()?.single();

    if (error) throw error;
    return { data, error: null };
  } catch (error) {
    console.error('Error marking status as viewed:', error);
    return { data: null, error };
  }
};

/**
 * Get view count for a status
 */
export const getStatusViewCount = async (statusId) => {
  try {
    const { count, error } = await supabase?.from('status_views')?.select('*', { count: 'exact', head: true })?.eq('status_id', statusId);

    if (error) throw error;
    return { count, error: null };
  } catch (error) {
    console.error('Error getting status view count:', error);
    return { count: 0, error };
  }
};

/**
 * Delete a status (before expiration)
 */
export const deleteStatus = async (statusId) => {
  try {
    const { data: { user } } = await supabase?.auth?.getUser();
    if (!user) throw new Error('User not authenticated');

    const { error } = await supabase?.from('status_updates')?.delete()?.eq('id', statusId)?.eq('user_id', user?.id);

    if (error) throw error;
    return { error: null };
  } catch (error) {
    console.error('Error deleting status:', error);
    return { error };
  }
};

/**
 * Clean up expired statuses (called automatically by database trigger)
 * This function can be called manually if needed
 */
export const cleanupExpiredStatuses = async () => {
  try {
    const { error } = await supabase?.from('status_updates')?.delete()?.lt('expires_at', new Date()?.toISOString());

    if (error) throw error;
    return { error: null };
  } catch (error) {
    console.error('Error cleaning up expired statuses:', error);
    return { error };
  }
};
function statusService(...args) {
  // eslint-disable-next-line no-console
  console.warn('Placeholder: statusService is not implemented yet.', args);
  return null;
}

export { statusService };