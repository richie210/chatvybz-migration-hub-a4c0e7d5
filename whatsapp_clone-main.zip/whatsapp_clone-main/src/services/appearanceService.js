import { supabase } from '../lib/supabase';

export const appearanceService = {
  // Get appearance settings
  async getAppearanceSettings(userId) {
    try {
      const { data, error } = await supabase?.from('appearance_settings')?.select('*')?.eq('user_id', userId)?.single();

      if (error && error?.code !== 'PGRST116') throw error;

      // Return default if not found
      if (!data) {
        return {
          theme: 'system',
          font_size: 'medium',
          wallpaper_url: null,
          wallpaper_type: 'default',
          language: 'en',
          compact_mode: false,
          show_animations: true
        };
      }

      return data;
    } catch (error) {
      console.error('Error fetching appearance settings:', error);
      throw error;
    }
  },

  // Update appearance settings
  async updateAppearanceSettings(userId, settings) {
    try {
      const { data, error } = await supabase?.from('appearance_settings')?.upsert({
          user_id: userId,
          ...settings,
          updated_at: new Date()?.toISOString()
        }, {
          onConflict: 'user_id'
        })?.select()?.single();

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error updating appearance settings:', error);
      throw error;
    }
  },

  // Upload custom wallpaper
  async uploadWallpaper(userId, file) {
    try {
      const fileExt = file?.name?.split('.')?.pop();
      const fileName = `${userId}/wallpaper-${Date.now()}.${fileExt}`;

      const { data, error } = await supabase?.storage?.from('chat-wallpapers')?.upload(fileName, file, {
          cacheControl: '3600',
          upsert: false
        });

      if (error) throw error;

      // Get signed URL
      const { data: urlData } = await supabase?.storage?.from('chat-wallpapers')?.createSignedUrl(fileName, 60 * 60 * 24 * 365); // 1 year

      return {
        path: data?.path,
        url: urlData?.signedUrl
      };
    } catch (error) {
      console.error('Error uploading wallpaper:', error);
      throw error;
    }
  },

  // Delete wallpaper
  async deleteWallpaper(filePath) {
    try {
      const { error } = await supabase?.storage?.from('chat-wallpapers')?.remove([filePath]);

      if (error) throw error;
    } catch (error) {
      console.error('Error deleting wallpaper:', error);
      throw error;
    }
  },

  // Get wallpaper signed URL
  async getWallpaperUrl(filePath) {
    try {
      const { data, error } = await supabase?.storage?.from('chat-wallpapers')?.createSignedUrl(filePath, 60 * 60 * 24 * 365); // 1 year

      if (error) throw error;
      return data?.signedUrl;
    } catch (error) {
      console.error('Error getting wallpaper URL:', error);
      throw error;
    }
  },

  // Apply theme
  applyTheme(theme) {
    if (theme === 'dark') {
      document.documentElement?.classList?.add('dark');
    } else if (theme === 'light') {
      document.documentElement?.classList?.remove('dark');
    } else {
      // System default
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)')?.matches;
      if (prefersDark) {
        document.documentElement?.classList?.add('dark');
      } else {
        document.documentElement?.classList?.remove('dark');
      }
    }
  },

  // Apply font size
  applyFontSize(fontSize) {
    const root = document.documentElement;
    const fontSizes = {
      small: '14px',
      medium: '16px',
      large: '18px',
      'extra-large': '20px'
    };

    if (root && fontSizes?.[fontSize]) {
      root.style.fontSize = fontSizes?.[fontSize];
    }
  }
};

export default appearanceService;