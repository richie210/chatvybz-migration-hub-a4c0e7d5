import { supabase } from '../lib/supabase';

/**
 * Creator Payout Withdrawal Service
 * Manages bank accounts, withdrawal requests, and payout tracking
 */

export const creatorPayoutWithdrawalService = {
  /**
   * Get available balance for withdrawal
   */
  async getAvailableBalance() {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      // Get completed payouts that haven't been withdrawn
      const { data: payouts, error } = await supabase
        ?.from('creator_payouts')?.select('amount, currency')?.eq('creator_id', user?.id)?.eq('status', 'paid');

      if (error) throw error;

      const totalAvailable = payouts?.reduce((sum, p) => sum + (parseFloat(p?.amount) || 0), 0) || 0;

      return { data: { available: totalAvailable, currency: 'USD' }, error: null };
    } catch (error) {
      console.error('Error fetching available balance:', error);
      return { data: null, error };
    }
  },

  /**
   * Get all bank accounts for user
   */
  async getBankAccounts() {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data, error } = await supabase
        ?.from('bank_accounts')
        ?.select('*')
        ?.eq('user_id', user?.id)
        ?.order('is_primary', { ascending: false })
        ?.order('created_at', { ascending: false });

      if (error) throw error;

      return { data, error: null };
    } catch (error) {
      console.error('Error fetching bank accounts:', error);
      return { data: null, error };
    }
  },

  /**
   * Add new bank account
   */
  async addBankAccount(accountData) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      // Simple encryption (in production, use proper encryption service)
      const encryptedRouting = btoa(accountData?.routingNumber);
      const encryptedAccount = btoa(accountData?.accountNumber);
      const last4 = accountData?.accountNumber?.slice(-4);

      const { data, error } = await supabase
        ?.from('bank_accounts')
        ?.insert({
          user_id: user?.id,
          account_holder_name: accountData?.accountHolderName,
          bank_name: accountData?.bankName,
          account_number_last4: last4,
          routing_number_encrypted: encryptedRouting,
          account_number_encrypted: encryptedAccount,
          account_type: accountData?.accountType || 'checking',
          is_primary: accountData?.isPrimary || false
        })
        ?.select()
        ?.single();

      if (error) throw error;

      return { data, error: null };
    } catch (error) {
      console.error('Error adding bank account:', error);
      return { data: null, error };
    }
  },

  /**
   * Set primary bank account
   */
  async setPrimaryBankAccount(accountId) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data, error } = await supabase
        ?.from('bank_accounts')
        ?.update({ is_primary: true })
        ?.eq('id', accountId)
        ?.eq('user_id', user?.id)
        ?.select()
        ?.single();

      if (error) throw error;

      return { data, error: null };
    } catch (error) {
      console.error('Error setting primary bank account:', error);
      return { data: null, error };
    }
  },

  /**
   * Delete bank account
   */
  async deleteBankAccount(accountId) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      const { error } = await supabase
        ?.from('bank_accounts')
        ?.delete()
        ?.eq('id', accountId)
        ?.eq('user_id', user?.id);

      if (error) throw error;

      return { data: { success: true }, error: null };
    } catch (error) {
      console.error('Error deleting bank account:', error);
      return { data: null, error };
    }
  },

  /**
   * Calculate withdrawal fee
   */
  calculateFee(amount) {
    const fee = Math.max(amount * 0.025, 1.0);
    return parseFloat(fee?.toFixed(2));
  },

  /**
   * Request withdrawal
   */
  async requestWithdrawal(withdrawalData) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      const amount = parseFloat(withdrawalData?.amount);
      const feeAmount = this.calculateFee(amount);
      const netAmount = amount - feeAmount;

      // Validate minimum withdrawal
      if (amount < 10) {
        throw new Error('Minimum withdrawal amount is $10.00');
      }

      // Check available balance
      const balanceResult = await this.getAvailableBalance();
      if (balanceResult?.error) throw balanceResult?.error;
      
      if (amount > balanceResult?.data?.available) {
        throw new Error('Insufficient balance for withdrawal');
      }

      const { data, error } = await supabase
        ?.from('withdrawal_requests')
        ?.insert({
          user_id: user?.id,
          bank_account_id: withdrawalData?.bankAccountId,
          amount,
          fee_amount: feeAmount,
          net_amount: netAmount,
          processing_time_estimate: '3-5 business days',
          scheduled_date: withdrawalData?.scheduledDate || null,
          is_recurring: withdrawalData?.isRecurring || false,
          recurring_frequency: withdrawalData?.recurringFrequency || null
        })
        ?.select()
        ?.single();

      if (error) throw error;

      return { data, error: null };
    } catch (error) {
      console.error('Error requesting withdrawal:', error);
      return { data: null, error };
    }
  },

  /**
   * Get withdrawal history
   */
  async getWithdrawalHistory() {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data, error } = await supabase
        ?.from('withdrawal_requests')
        ?.select(`
          *,
          bank_account:bank_accounts(
            account_holder_name,
            bank_name,
            account_number_last4
          )
        `)
        ?.eq('user_id', user?.id)
        ?.order('created_at', { ascending: false });

      if (error) throw error;

      return { data, error: null };
    } catch (error) {
      console.error('Error fetching withdrawal history:', error);
      return { data: null, error };
    }
  },

  /**
   * Cancel withdrawal request
   */
  async cancelWithdrawal(withdrawalId) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data, error } = await supabase
        ?.from('withdrawal_requests')
        ?.update({ status: 'cancelled' })
        ?.eq('id', withdrawalId)
        ?.eq('user_id', user?.id)
        ?.eq('status', 'pending')
        ?.select()
        ?.single();

      if (error) throw error;

      return { data, error: null };
    } catch (error) {
      console.error('Error cancelling withdrawal:', error);
      return { data: null, error };
    }
  },

  /**
   * Get withdrawal statistics
   */
  async getWithdrawalStats() {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data: withdrawals, error } = await supabase
        ?.from('withdrawal_requests')
        ?.select('amount, status, fee_amount')
        ?.eq('user_id', user?.id);

      if (error) throw error;

      const stats = {
        totalWithdrawn: 0,
        totalFees: 0,
        pendingAmount: 0,
        completedCount: 0,
        pendingCount: 0
      };

      withdrawals?.forEach(w => {
        if (w?.status === 'completed') {
          stats.totalWithdrawn += parseFloat(w?.amount) || 0;
          stats.totalFees += parseFloat(w?.fee_amount) || 0;
          stats.completedCount++;
        } else if (w?.status === 'pending' || w?.status === 'processing') {
          stats.pendingAmount += parseFloat(w?.amount) || 0;
          stats.pendingCount++;
        }
      });

      return { data: stats, error: null };
    } catch (error) {
      console.error('Error fetching withdrawal stats:', error);
      return { data: null, error };
    }
  }
};

export default creatorPayoutWithdrawalService;