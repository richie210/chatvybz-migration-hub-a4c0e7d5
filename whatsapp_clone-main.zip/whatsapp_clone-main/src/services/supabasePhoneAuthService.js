import { supabase } from '../lib/supabase';

/**
 * Simplified Supabase Phone Authentication Service
 * Uses Twilio via Supabase Edge Functions for reliable SMS OTP delivery
 */

const supabasePhoneAuthService = {
  /**
   * Send OTP to phone number
   * @param {string} phoneNumber - Phone number without country code
   * @param {string} countryCode - Country code (e.g., '+1', '+596')
   * @returns {Promise<Object>} Result with success status
   */
  async sendPhoneOTP(phoneNumber, countryCode) {
    try {
      console.log('📞 Sending OTP:', { phoneNumber, countryCode });

      // Validate inputs
      if (!phoneNumber || typeof phoneNumber !== 'string') {
        return {
          data: null,
          error: {
            message: 'Phone number is required',
            code: 'INVALID_INPUT'
          }
        };
      }

      if (!countryCode || typeof countryCode !== 'string') {
        return {
          data: null,
          error: {
            message: 'Country code is required',
            code: 'INVALID_INPUT'
          }
        };
      }

      // Clean inputs
      const cleanPhone = phoneNumber?.replace(/\D/g, '');
      const cleanCode = countryCode?.replace(/\D/g, '');

      console.log(`📱 Sending to: +${cleanCode}${cleanPhone}`);

      // Call Edge Function
      const { data, error } = await supabase?.functions?.invoke('send-sms-otp', {
        body: {
          phoneNumber: cleanPhone,
          countryCode: `+${cleanCode}`
        }
      });

      // Handle Edge Function errors
      if (error) {
        console.error('❌ Edge Function error:', error);
        
        // Provide user-friendly error messages
        return {
          data: null,
          error: {
            message: 'Unable to send verification code',
            code: 'SERVICE_ERROR',
            hint: 'Please try again or use Email/QR Code authentication'
          }
        };
      }

      // Handle response errors (from Edge Function)
      if (data?.error) {
        console.error('❌ SMS error:', data?.error);
        return {
          data: null,
          error: {
            message: data?.error,
            code: 'SMS_FAILED',
            hint: data?.hint || 'Please check your phone number'
          }
        };
      }

      // Success
      console.log('✅ OTP sent successfully');
      return {
        data: {
          success: true,
          attemptId: data?.attemptId,
          expiresAt: data?.expiresAt,
          phoneNumber: data?.phoneNumber
        },
        error: null
      };

    } catch (error) {
      console.error('❌ Unexpected error:', error);
      return {
        data: null,
        error: {
          message: 'An unexpected error occurred',
          code: 'UNKNOWN_ERROR',
          hint: 'Please try again or contact support'
        }
      };
    }
  },

  /**
   * Verify OTP code
   * @param {string} phoneNumber - Phone number without country code
   * @param {string} countryCode - Country code
   * @param {string} otpCode - 6-digit OTP code
   * @returns {Promise<Object>} Verification result
   */
  async verifyPhoneOTP(phoneNumber, countryCode, otpCode) {
    try {
      console.log('🔐 Verifying OTP');

      // Validate inputs
      if (!phoneNumber || !countryCode || !otpCode) {
        return {
          data: null,
          error: {
            message: 'Phone number, country code, and OTP are required',
            code: 'INVALID_INPUT'
          }
        };
      }

      // Clean inputs
      const cleanPhone = phoneNumber?.replace(/\D/g, '');
      const cleanCode = countryCode?.replace(/\D/g, '');
      const e164Phone = `+${cleanCode}${cleanPhone}`;

      console.log(`🔍 Verifying for: ${e164Phone}`);

      // Query the database for the OTP
      const { data: attempts, error: queryError } = await supabase?.from('phone_verification_attempts')?.select('*')?.eq('phone_number', e164Phone)?.eq('otp_code', otpCode)?.eq('is_verified', false)?.gte('expires_at', new Date()?.toISOString())?.order('created_at', { ascending: false })?.limit(1);

      if (queryError) {
        console.error('❌ Query error:', queryError);
        return {
          data: null,
          error: {
            message: 'Failed to verify code',
            code: 'QUERY_ERROR'
          }
        };
      }

      // Check if OTP exists and is valid
      if (!attempts || attempts?.length === 0) {
        return {
          data: null,
          error: {
            message: 'Invalid or expired verification code',
            code: 'INVALID_OTP'
          }
        };
      }

      const attempt = attempts?.[0];

      // Check attempt count (max 5 attempts)
      if (attempt?.attempts_count >= 5) {
        return {
          data: null,
          error: {
            message: 'Too many failed attempts. Please request a new code.',
            code: 'MAX_ATTEMPTS_EXCEEDED'
          }
        };
      }

      // Mark as verified
      const { error: updateError } = await supabase?.from('phone_verification_attempts')?.update({
          is_verified: true,
          verified_at: new Date()?.toISOString()
        })?.eq('id', attempt?.id);

      if (updateError) {
        console.error('❌ Update error:', updateError);
        return {
          data: null,
          error: {
            message: 'Failed to verify code',
            code: 'UPDATE_ERROR'
          }
        };
      }

      console.log('✅ OTP verified successfully');

      // Check if user exists
      const { data: existingUser } = await supabase?.from('user_profiles')?.select('user_id')?.eq('phone_number', e164Phone)?.single();

      return {
        data: {
          verified: true,
          phoneNumber: e164Phone,
          userExists: !!existingUser,
          userId: existingUser?.user_id || null
        },
        error: null
      };

    } catch (error) {
      console.error('❌ Verification error:', error);
      return {
        data: null,
        error: {
          message: 'An unexpected error occurred',
          code: 'UNKNOWN_ERROR'
        }
      };
    }
  },

  /**
   * Create or sign in user after OTP verification
   * @param {string} phoneNumber - Verified phone number in E.164 format
   * @returns {Promise<Object>} Auth result
   */
  async signInWithPhone(phoneNumber) {
    try {
      console.log('🔑 Signing in with phone:', phoneNumber);

      // Check if user exists
      const { data: profile } = await supabase?.from('user_profiles')?.select('user_id')?.eq('phone_number', phoneNumber)?.single();

      if (profile) {
        // User exists - sign in
        console.log('✅ User exists, signing in');
        
        // For existing users, we need to use Supabase Auth
        // Since we're using phone verification, create a session
        const { data: authData, error: authError } = await supabase?.auth?.signInWithOtp({
          phone: phoneNumber
        });

        if (authError) {
          console.error('❌ Auth error:', authError);
          return {
            data: null,
            error: {
              message: 'Failed to sign in',
              code: 'AUTH_ERROR'
            }
          };
        }

        return {
          data: {
            user: authData?.user,
            session: authData?.session,
            isNewUser: false
          },
          error: null
        };
      } else {
        // New user - create account
        console.log('📝 New user, creating account');
        
        const { data: authData, error: authError } = await supabase?.auth?.signInWithOtp({
          phone: phoneNumber
        });

        if (authError) {
          console.error('❌ Auth error:', authError);
          return {
            data: null,
            error: {
              message: 'Failed to create account',
              code: 'AUTH_ERROR'
            }
          };
        }

        return {
          data: {
            user: authData?.user,
            session: authData?.session,
            isNewUser: true
          },
          error: null
        };
      }

    } catch (error) {
      console.error('❌ Sign in error:', error);
      return {
        data: null,
        error: {
          message: 'An unexpected error occurred',
          code: 'UNKNOWN_ERROR'
        }
      };
    }
  }
};

export default supabasePhoneAuthService;