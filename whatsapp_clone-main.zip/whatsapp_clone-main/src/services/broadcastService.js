import { supabase } from '../lib/supabase';
import { encryptionService } from './encryptionService';

/**
 * Broadcast Service - Handles broadcast lists and messages to multiple contacts
 */

/**
 * Create a new broadcast list
 */
export const createBroadcastList = async (name, description, contactIds) => {
  try {
    const { data: { user } } = await supabase?.auth?.getUser();
    if (!user) throw new Error('User not authenticated');

    // Create broadcast list
    const { data: list, error: listError } = await supabase
      ?.from('broadcast_lists')
      ?.insert([{
        user_id: user?.id,
        name,
        description
      }])
      ?.select()
      ?.single();

    if (listError) throw listError;

    // Add members to the list
    if (contactIds?.length > 0) {
      const members = contactIds?.map(contactId => ({
        broadcast_list_id: list?.id,
        contact_id: contactId
      }));

      const { error: membersError } = await supabase
        ?.from('broadcast_list_members')
        ?.insert(members);

      if (membersError) throw membersError;
    }

    return { data: list, error: null };
  } catch (error) {
    console.error('Error creating broadcast list:', error);
    return { data: null, error };
  }
};

/**
 * Get all broadcast lists for current user
 */
export const getBroadcastLists = async () => {
  try {
    const { data: { user } } = await supabase?.auth?.getUser();
    if (!user) throw new Error('User not authenticated');

    const { data, error } = await supabase
      ?.from('broadcast_lists')
      ?.select(`
        *,
        members:broadcast_list_members(
          id,
          contact:contact_id(
            id,
            full_name,
            avatar_url,
            email
          )
        )
      `)
      ?.eq('user_id', user?.id)
      ?.order('created_at', { ascending: false });

    if (error) throw error;

    return { data, error: null };
  } catch (error) {
    console.error('Error fetching broadcast lists:', error);
    return { data: null, error };
  }
};

/**
 * Get a single broadcast list with members
 */
export const getBroadcastList = async (listId) => {
  try {
    const { data: { user } } = await supabase?.auth?.getUser();
    if (!user) throw new Error('User not authenticated');

    const { data, error } = await supabase
      ?.from('broadcast_lists')
      ?.select(`
        *,
        members:broadcast_list_members(
          id,
          contact:contact_id(
            id,
            full_name,
            avatar_url,
            email,
            phone
          )
        )
      `)
      ?.eq('id', listId)
      ?.eq('user_id', user?.id)
      ?.single();

    if (error) throw error;

    return { data, error: null };
  } catch (error) {
    console.error('Error fetching broadcast list:', error);
    return { data: null, error };
  }
};

/**
 * Update broadcast list
 */
export const updateBroadcastList = async (listId, updates) => {
  try {
    const { data: { user } } = await supabase?.auth?.getUser();
    if (!user) throw new Error('User not authenticated');

    const { data, error } = await supabase
      ?.from('broadcast_lists')
      ?.update(updates)
      ?.eq('id', listId)
      ?.eq('user_id', user?.id)
      ?.select()
      ?.single();

    if (error) throw error;

    return { data, error: null };
  } catch (error) {
    console.error('Error updating broadcast list:', error);
    return { data: null, error };
  }
};

/**
 * Delete broadcast list
 */
export const deleteBroadcastList = async (listId) => {
  try {
    const { data: { user } } = await supabase?.auth?.getUser();
    if (!user) throw new Error('User not authenticated');

    const { error } = await supabase
      ?.from('broadcast_lists')
      ?.delete()
      ?.eq('id', listId)
      ?.eq('user_id', user?.id);

    if (error) throw error;

    return { error: null };
  } catch (error) {
    console.error('Error deleting broadcast list:', error);
    return { error };
  }
};

/**
 * Add members to broadcast list
 */
export const addMembersToBroadcastList = async (listId, contactIds) => {
  try {
    const members = contactIds?.map(contactId => ({
      broadcast_list_id: listId,
      contact_id: contactId
    }));

    const { data, error } = await supabase
      ?.from('broadcast_list_members')
      ?.insert(members)
      ?.select();

    if (error) throw error;

    return { data, error: null };
  } catch (error) {
    console.error('Error adding members to broadcast list:', error);
    return { data: null, error };
  }
};

/**
 * Remove member from broadcast list
 */
export const removeMemberFromBroadcastList = async (memberId) => {
  try {
    const { error } = await supabase
      ?.from('broadcast_list_members')
      ?.delete()
      ?.eq('id', memberId);

    if (error) throw error;

    return { error: null };
  } catch (error) {
    console.error('Error removing member from broadcast list:', error);
    return { error };
  }
};

/**
 * Send broadcast message to all members of a list
 */
export const sendBroadcastMessage = async (listId, messageContent) => {
  try {
    const { data: { user } } = await supabase?.auth?.getUser();
    if (!user) throw new Error('User not authenticated');

    // Get list members
    const { data: list, error: listError } = await getBroadcastList(listId);
    if (listError) throw listError;

    if (!list?.members || list?.members?.length === 0) {
      throw new Error('No members in broadcast list');
    }

    // Encrypt message
    let encryptedContent = messageContent;
    let nonce = null;
    
    if (encryptionService) {
      const encrypted = await encryptionService?.encryptMessage(messageContent);
      encryptedContent = encrypted?.encryptedData || messageContent;
      nonce = encrypted?.nonce;
    }

    // Create broadcast message
    const { data: broadcastMessage, error: messageError } = await supabase
      ?.from('broadcast_messages')
      ?.insert([{
        sender_id: user?.id,
        broadcast_list_id: listId,
        message_content: encryptedContent,
        is_encrypted: !!nonce,
        nonce
      }])
      ?.select()
      ?.single();

    if (messageError) throw messageError;

    // Create delivery tracking for each recipient
    const deliveryTracking = list?.members?.map(member => ({
      broadcast_message_id: broadcastMessage?.id,
      recipient_id: member?.contact?.id,
      status: 'sent'
    }));

    const { error: trackingError } = await supabase
      ?.from('broadcast_delivery_tracking')
      ?.insert(deliveryTracking);

    if (trackingError) throw trackingError;

    return { data: broadcastMessage, error: null };
  } catch (error) {
    console.error('Error sending broadcast message:', error);
    return { data: null, error };
  }
};

/**
 * Get broadcast messages for a list
 */
export const getBroadcastMessages = async (listId) => {
  try {
    const { data: { user } } = await supabase?.auth?.getUser();
    if (!user) throw new Error('User not authenticated');

    const { data, error } = await supabase
      ?.from('broadcast_messages')
      ?.select(`
        *,
        sender:sender_id(
          id,
          full_name,
          avatar_url
        ),
        delivery_tracking:broadcast_delivery_tracking(
          id,
          recipient_id,
          status,
          delivered_at,
          read_at,
          recipient:recipient_id(
            id,
            full_name,
            avatar_url
          )
        )
      `)
      ?.eq('broadcast_list_id', listId)
      ?.order('created_at', { ascending: false });

    if (error) throw error;

    // Decrypt messages
    const decryptedData = await Promise.all(
      (data || [])?.map(async (message) => {
        if (message?.is_encrypted && message?.nonce && encryptionService) {
          message.decrypted_content = await encryptionService?.decryptMessage(
            message?.message_content,
            message?.nonce
          );
        } else {
          message.decrypted_content = message?.message_content;
        }
        return message;
      })
    );

    return { data: decryptedData, error: null };
  } catch (error) {
    console.error('Error fetching broadcast messages:', error);
    return { data: null, error };
  }
};

/**
 * Update delivery status
 */
export const updateDeliveryStatus = async (trackingId, status) => {
  try {
    const updates = { status };
    
    if (status === 'delivered') {
      updates.delivered_at = new Date()?.toISOString();
    } else if (status === 'read') {
      updates.read_at = new Date()?.toISOString();
    }

    const { data, error } = await supabase
      ?.from('broadcast_delivery_tracking')
      ?.update(updates)
      ?.eq('id', trackingId)
      ?.select()
      ?.single();

    if (error) throw error;

    return { data, error: null };
  } catch (error) {
    console.error('Error updating delivery status:', error);
    return { data: null, error };
  }
};

/**
 * Get delivery statistics for a broadcast message
 */
export const getBroadcastMessageStats = async (messageId) => {
  try {
    const { data, error } = await supabase
      ?.from('broadcast_delivery_tracking')
      ?.select('status')
      ?.eq('broadcast_message_id', messageId);

    if (error) throw error;

    const stats = {
      total: data?.length || 0,
      sent: data?.filter(d => d?.status === 'sent')?.length || 0,
      delivered: data?.filter(d => d?.status === 'delivered')?.length || 0,
      read: data?.filter(d => d?.status === 'read')?.length || 0,
      failed: data?.filter(d => d?.status === 'failed')?.length || 0
    };

    return { data: stats, error: null };
  } catch (error) {
    console.error('Error fetching broadcast message stats:', error);
    return { data: null, error };
  }
};

export const broadcastService = {
  createBroadcastList,
  getBroadcastLists,
  getBroadcastList,
  updateBroadcastList,
  deleteBroadcastList,
  addMembersToBroadcastList,
  removeMemberFromBroadcastList,
  sendBroadcastMessage,
  getBroadcastMessages,
  updateDeliveryStatus,
  getBroadcastMessageStats
};
function getBroadcastDeliveryStats(...args) {
  // eslint-disable-next-line no-console
  console.warn('Placeholder: getBroadcastDeliveryStats is not implemented yet.', args);
  return null;
}

export { getBroadcastDeliveryStats };