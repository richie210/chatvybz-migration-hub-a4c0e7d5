import { supabase } from '../lib/supabase';

/**
 * Admin Authentication Service - Handles admin-specific authentication
 */

export const adminAuthService = {
  /**
   * Check if user is admin
   */
  async isAdmin(userId = null) {
    try {
      let targetUserId = userId;

      if (!targetUserId) {
        const { data: { user } } = await supabase?.auth?.getUser();
        if (!user) return false;
        targetUserId = user?.id;
      }

      const { data, error } = await supabase
        ?.from('profiles')
        ?.select('is_admin')
        ?.eq('id', targetUserId)
        ?.single();

      if (error) throw error;

      return data?.is_admin === true;
    } catch (error) {
      console.error('Error checking admin status:', error);
      return false;
    }
  },

  /**
   * Admin login with email and password
   */
  async adminLogin(email, password) {
    try {
      // First, authenticate with Supabase
      const { data: authData, error: authError } = await supabase?.auth?.signInWithPassword({
        email,
        password
      });

      if (authError) throw authError;

      // Verify user is admin
      const isAdminUser = await this.isAdmin(authData?.user?.id);

      if (!isAdminUser) {
        // Sign out non-admin user
        await supabase?.auth?.signOut();
        throw new Error('Access denied. Admin privileges required.');
      }

      return { data: authData, error: null };
    } catch (error) {
      console.error('Error during admin login:', error);
      return { data: null, error };
    }
  },

  /**
   * Get admin profile
   */
  async getAdminProfile() {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data, error } = await supabase
        ?.from('profiles')
        ?.select('*')
        ?.eq('id', user?.id)
        ?.eq('is_admin', true)
        ?.single();

      if (error) throw error;

      return { data, error: null };
    } catch (error) {
      console.error('Error fetching admin profile:', error);
      return { data: null, error };
    }
  },

  /**
   * Verify admin session
   */
  async verifyAdminSession() {
    try {
      const { data: { session } } = await supabase?.auth?.getSession();
      
      if (!session) {
        return { valid: false, error: 'No active session' };
      }

      const isAdminUser = await this.isAdmin(session?.user?.id);

      if (!isAdminUser) {
        return { valid: false, error: 'Not an admin user' };
      }

      return { valid: true, session, error: null };
    } catch (error) {
      console.error('Error verifying admin session:', error);
      return { valid: false, error };
    }
  }
};