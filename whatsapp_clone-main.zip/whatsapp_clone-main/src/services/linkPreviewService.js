import { supabase } from '../lib/supabase';

/**
 * Link Preview Service - Fetches metadata for URLs in messages
 * Uses Open Graph protocol and fallback meta tags
 */

export const linkPreviewService = {
  /**
   * Extract URLs from text
   * @param {string} text - Text to extract URLs from
   * @returns {Array} Array of URLs
   */
  extractUrls(text) {
    if (!text) return [];
    
    const urlRegex = /(https?:\/\/[^\s]+)/g;
    const matches = text?.match(urlRegex);
    return matches || [];
  },

  /**
   * Fetch link preview metadata
   * @param {string} url - URL to fetch preview for
   * @returns {Object} Preview data with title, description, image
   */
  async fetchPreview(url) {
    try {
      // Use Supabase Edge Function for link preview (avoids CORS issues)
      const { data, error } = await supabase?.functions?.invoke('link-preview', {
        body: { url }
      });

      if (error) {
        console.error('Error fetching link preview:', error);
        return this.createFallbackPreview(url);
      }

      return {
        url,
        title: data?.title || this.extractDomainName(url),
        description: data?.description || '',
        image: data?.image || null,
        siteName: data?.siteName || this.extractDomainName(url),
        favicon: data?.favicon || null
      };
    } catch (error) {
      console.error('Error in fetchPreview:', error);
      return this.createFallbackPreview(url);
    }
  },

  /**
   * Create fallback preview when metadata fetch fails
   * @param {string} url - URL
   * @returns {Object} Fallback preview data
   */
  createFallbackPreview(url) {
    return {
      url,
      title: this.extractDomainName(url),
      description: url,
      image: null,
      siteName: this.extractDomainName(url),
      favicon: null
    };
  },

  /**
   * Extract domain name from URL
   * @param {string} url - URL
   * @returns {string} Domain name
   */
  extractDomainName(url) {
    try {
      const urlObj = new URL(url);
      return urlObj?.hostname?.replace('www.', '');
    } catch {
      return 'Link';
    }
  },

  /**
   * Cache link previews in local storage
   * @param {string} url - URL
   * @param {Object} previewData - Preview data to cache
   */
  cachePreview(url, previewData) {
    try {
      const cacheKey = `link_preview_${btoa(url)}`;
      const cacheData = {
        ...previewData,
        cachedAt: Date.now()
      };
      localStorage?.setItem(cacheKey, JSON.stringify(cacheData));
    } catch (error) {
      console.error('Error caching preview:', error);
    }
  },

  /**
   * Get cached link preview
   * @param {string} url - URL
   * @returns {Object|null} Cached preview data or null
   */
  getCachedPreview(url) {
    try {
      const cacheKey = `link_preview_${btoa(url)}`;
      const cached = localStorage?.getItem(cacheKey);
      
      if (cached) {
        const data = JSON.parse(cached);
        // Cache valid for 7 days
        const isValid = Date.now() - data?.cachedAt < 7 * 24 * 60 * 60 * 1000;
        
        if (isValid) {
          return data;
        } else {
          localStorage?.removeItem(cacheKey);
        }
      }
    } catch (error) {
      console.error('Error getting cached preview:', error);
    }
    return null;
  },

  /**
   * Fetch preview with caching
   * @param {string} url - URL
   * @returns {Object} Preview data
   */
  async fetchPreviewWithCache(url) {
    // Check cache first
    const cached = this.getCachedPreview(url);
    if (cached) {
      return cached;
    }

    // Fetch new preview
    const preview = await this.fetchPreview(url);
    
    // Cache the result
    this.cachePreview(url, preview);
    
    return preview;
  }
};

export default linkPreviewService;
