import { supabase } from '../lib/supabase';

/**
 * Real-time Subscription Service for Supabase
 * Manages live updates for messages, reactions, status views, typing indicators, and mentions
 */

class RealtimeService {
  constructor() {
    this.subscriptions = new Map();
  }

  /**
   * Subscribe to message reactions in real-time
   * @param {string} messageId - Message ID to watch for reactions
   * @param {Function} onReactionAdded - Callback when reaction is added
   * @param {Function} onReactionRemoved - Callback when reaction is removed
   */
  subscribeToMessageReactions(messageId, onReactionAdded, onReactionRemoved) {
    const channelName = `message-reactions-${messageId}`;
    
    const channel = supabase?.channel(channelName)?.on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'message_reactions',
          filter: `message_id=eq.${messageId}`
        },
        (payload) => {
          if (onReactionAdded) {
            onReactionAdded(payload?.new);
          }
        }
      )?.on(
        'postgres_changes',
        {
          event: 'DELETE',
          schema: 'public',
          table: 'message_reactions',
          filter: `message_id=eq.${messageId}`
        },
        (payload) => {
          if (onReactionRemoved) {
            onReactionRemoved(payload?.old);
          }
        }
      )?.subscribe();

    this.subscriptions?.set(channelName, channel);
    return channelName;
  }

  /**
   * Subscribe to status view counts in real-time
   * @param {string} statusId - Status ID to watch for views
   * @param {Function} onViewAdded - Callback when view is added
   */
  subscribeToStatusViews(statusId, onViewAdded) {
    const channelName = `status-views-${statusId}`;
    
    const channel = supabase?.channel(channelName)?.on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'status_views',
          filter: `status_id=eq.${statusId}`
        },
        (payload) => {
          if (onViewAdded) {
            onViewAdded(payload?.new);
          }
        }
      )?.subscribe();

    this.subscriptions?.set(channelName, channel);
    return channelName;
  }

  /**
   * Subscribe to typing indicators in a conversation
   * @param {string} conversationId - Conversation ID to watch
   * @param {Function} onTypingStart - Callback when user starts typing
   * @param {Function} onTypingStop - Callback when user stops typing
   */
  subscribeToTypingIndicators(conversationId, onTypingStart, onTypingStop) {
    const channelName = `typing-${conversationId}`;
    
    const channel = supabase?.channel(channelName)?.on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'typing_indicators',
          filter: `conversation_id=eq.${conversationId}`
        },
        (payload) => {
          if (onTypingStart) {
            onTypingStart(payload?.new);
          }
        }
      )?.on(
        'postgres_changes',
        {
          event: 'DELETE',
          schema: 'public',
          table: 'typing_indicators',
          filter: `conversation_id=eq.${conversationId}`
        },
        (payload) => {
          if (onTypingStop) {
            onTypingStop(payload?.old);
          }
        }
      )?.subscribe();

    this.subscriptions?.set(channelName, channel);
    return channelName;
  }

  /**
   * Subscribe to @mention notifications for current user
   * @param {string} userId - User ID to watch for mentions
   * @param {Function} onMentionReceived - Callback when user is mentioned
   */
  subscribeToMentions(userId, onMentionReceived) {
    const channelName = `mentions-${userId}`;
    
    const channel = supabase?.channel(channelName)?.on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'message_mentions',
          filter: `mentioned_user_id=eq.${userId}`
        },
        (payload) => {
          if (onMentionReceived) {
            onMentionReceived(payload?.new);
          }
        }
      )?.subscribe();

    this.subscriptions?.set(channelName, channel);
    return channelName;
  }

  /**
   * Subscribe to new messages in a conversation
   * @param {string} conversationId - Conversation ID to watch
   * @param {Function} onNewMessage - Callback when new message arrives
   */
  subscribeToMessages(conversationId, onNewMessage) {
    const channelName = `messages-${conversationId}`;
    
    const channel = supabase?.channel(channelName)?.on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'messages',
          filter: `conversation_id=eq.${conversationId}`
        },
        (payload) => {
          if (onNewMessage) {
            onNewMessage(payload?.new);
          }
        }
      )?.subscribe();

    this.subscriptions?.set(channelName, channel);
    return channelName;
  }

  /**
   * Subscribe to message delivery status updates
   * @param {string} messageId - Message ID to watch
   * @param {Function} onStatusUpdate - Callback when delivery status changes
   */
  subscribeToDeliveryStatus(messageId, onStatusUpdate) {
    const channelName = `delivery-${messageId}`;
    
    const channel = supabase?.channel(channelName)?.on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'messages',
          filter: `id=eq.${messageId}`
        },
        (payload) => {
          if (onStatusUpdate && payload?.new?.delivery_status !== payload?.old?.delivery_status) {
            onStatusUpdate(payload?.new);
          }
        }
      )?.subscribe();

    this.subscriptions?.set(channelName, channel);
    return channelName;
  }

  /**
   * Subscribe to status updates (new statuses posted by contacts)
   * @param {Function} onNewStatus - Callback when new status is posted
   */
  subscribeToStatusUpdates(onNewStatus) {
    const channelName = 'status-updates-all';
    
    const channel = supabase?.channel(channelName)?.on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'status_updates'
        },
        (payload) => {
          if (onNewStatus) {
            onNewStatus(payload?.new);
          }
        }
      )?.subscribe();

    this.subscriptions?.set(channelName, channel);
    return channelName;
  }

  /**
   * Unsubscribe from a specific channel
   * @param {string} channelName - Channel name to unsubscribe from
   */
  async unsubscribe(channelName) {
    const channel = this.subscriptions?.get(channelName);
    if (channel) {
      await supabase?.removeChannel(channel);
      this.subscriptions?.delete(channelName);
    }
  }

  /**
   * Unsubscribe from all active channels
   */
  async unsubscribeAll() {
    const promises = Array.from(this.subscriptions?.keys())?.map(channelName =>
      this.unsubscribe(channelName)
    );
    await Promise.all(promises);
  }

  /**
   * Get active subscription count
   */
  getActiveSubscriptionsCount() {
    return this.subscriptions?.size;
  }

  /**
   * Check if a specific channel is subscribed
   */
  isSubscribed(channelName) {
    return this.subscriptions?.has(channelName);
  }
}

export const realtimeService = new RealtimeService();
export default realtimeService;