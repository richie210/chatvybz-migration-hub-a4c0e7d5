import { supabase } from '../lib/supabase';


/**
 * Creates a backup of all chat messages for the current user.
 * @param {string} userId - The user ID to backup messages for.
 * @returns {Promise<Object>} Backup result with file URL.
 */
export async function createChatBackup(userId) {
  try {
    // Fetch all messages for user
    const { data: messages, error: messagesError } = await supabase?.from('chat_messages')?.select(`
        *,
        sender:sender_id(id, full_name, email),
        recipient:recipient_id(id, full_name, email),
        attachments:message_attachments(*),
        reactions:message_reactions(*)
      `)?.or(`sender_id.eq.${userId},recipient_id.eq.${userId}`)?.order('created_at', { ascending: true });

    if (messagesError) throw messagesError;

    // Fetch user profile
    const { data: profile, error: profileError } = await supabase?.from('profiles')?.select('*')?.eq('id', userId)?.single();

    if (profileError) throw profileError;

    // Create backup object
    const backup = {
      version: '1.0',
      createdAt: new Date()?.toISOString(),
      userId,
      profile,
      messageCount: messages?.length,
      messages: messages?.map(msg => ({
        id: msg?.id,
        message: msg?.message,
        sender_id: msg?.sender_id,
        recipient_id: msg?.recipient_id,
        created_at: msg?.created_at,
        is_encrypted: msg?.is_encrypted,
        nonce: msg?.nonce,
        status: msg?.status,
        attachments: msg?.attachments || [],
        reactions: msg?.reactions || [],
        sender: msg?.sender,
        recipient: msg?.recipient
      }))
    };

    // Convert to JSON
    const backupJson = JSON.stringify(backup, null, 2);
    const backupBlob = new Blob([backupJson], { type: 'application/json' });
    const fileName = `chat_backup_${userId}_${Date.now()}.json`;

    // Upload to Supabase Storage
    const { data: uploadData, error: uploadError } = await supabase?.storage?.from('chat-backups')?.upload(`${userId}/${fileName}`, backupBlob, {
        contentType: 'application/json',
        upsert: false
      });

    if (uploadError) throw uploadError;

    // Get public URL
    const { data: urlData } = supabase?.storage?.from('chat-backups')?.getPublicUrl(`${userId}/${fileName}`);

    // Store backup metadata
    const { data: metadata, error: metadataError } = await supabase?.from('chat_backups')?.insert({
        user_id: userId,
        file_name: fileName,
        file_path: uploadData?.path,
        file_url: urlData?.publicUrl,
        message_count: messages?.length,
        file_size: backupBlob?.size,
        backup_type: 'full'
      })?.select()?.single();

    if (metadataError) throw metadataError;

    return {
      success: true,
      backupId: metadata?.id,
      fileName,
      fileUrl: urlData?.publicUrl,
      messageCount: messages?.length,
      fileSize: backupBlob?.size
    };
  } catch (error) {
    console.error('Error creating chat backup:', error);
    throw new Error('Failed to create backup');
  }
}

/**
 * Restores chat messages from a backup file.
 * @param {string} userId - The user ID restoring the backup.
 * @param {File} backupFile - The backup file to restore from.
 * @returns {Promise<Object>} Restore result.
 */
export async function restoreChatBackup(userId, backupFile) {
  try {
    // Read backup file
    const backupText = await backupFile?.text();
    const backup = JSON.parse(backupText);

    // Validate backup format
    if (!backup?.version || !backup?.messages || !Array.isArray(backup?.messages)) {
      throw new Error('Invalid backup file format');
    }

    // Check if backup belongs to user
    if (backup?.userId !== userId) {
      throw new Error('Backup file does not belong to this user');
    }

    let restoredCount = 0;
    let skippedCount = 0;
    const errors = [];

    // Restore messages
    for (const msg of backup?.messages) {
      try {
        // Check if message already exists
        const { data: existing } = await supabase?.from('chat_messages')?.select('id')?.eq('id', msg?.id)?.single();

        if (existing) {
          skippedCount++;
          continue;
        }

        // Insert message
        const { error: insertError } = await supabase?.from('chat_messages')?.insert({
            id: msg?.id,
            message: msg?.message,
            sender_id: msg?.sender_id,
            recipient_id: msg?.recipient_id,
            created_at: msg?.created_at,
            is_encrypted: msg?.is_encrypted,
            nonce: msg?.nonce,
            status: msg?.status || 'sent'
          });

        if (insertError) {
          errors?.push({ messageId: msg?.id, error: insertError?.message });
        } else {
          restoredCount++;
        }
      } catch (msgError) {
        errors?.push({ messageId: msg?.id, error: msgError?.message });
      }
    }

    // Store restore metadata
    await supabase?.from('chat_backups')?.insert({
        user_id: userId,
        file_name: backupFile?.name,
        message_count: restoredCount,
        file_size: backupFile?.size,
        backup_type: 'restore'
      });

    return {
      success: true,
      restoredCount,
      skippedCount,
      totalMessages: backup?.messages?.length,
      errors: errors?.length > 0 ? errors : null
    };
  } catch (error) {
    console.error('Error restoring chat backup:', error);
    throw error;
  }
}

/**
 * Lists all backups for a user.
 * @param {string} userId - The user ID.
 * @returns {Promise<Array>} List of backups.
 */
export async function listBackups(userId) {
  try {
    const { data, error } = await supabase?.from('chat_backups')?.select('*')?.eq('user_id', userId)?.eq('backup_type', 'full')?.order('created_at', { ascending: false });

    if (error) throw error;

    return data || [];
  } catch (error) {
    console.error('Error listing backups:', error);
    throw error;
  }
}

/**
 * Deletes a backup file.
 * @param {string} backupId - The backup ID to delete.
 * @param {string} userId - The user ID.
 * @returns {Promise<Object>} Deletion result.
 */
export async function deleteBackup(backupId, userId) {
  try {
    // Get backup metadata
    const { data: backup, error: fetchError } = await supabase?.from('chat_backups')?.select('*')?.eq('id', backupId)?.eq('user_id', userId)?.single();

    if (fetchError) throw fetchError;

    // Delete from storage
    const { error: storageError } = await supabase?.storage?.from('chat-backups')?.remove([backup?.file_path]);

    if (storageError) throw storageError;

    // Delete metadata
    const { error: deleteError } = await supabase?.from('chat_backups')?.delete()?.eq('id', backupId);

    if (deleteError) throw deleteError;

    return { success: true };
  } catch (error) {
    console.error('Error deleting backup:', error);
    throw error;
  }
}

export const chatBackupService = {
  createChatBackup,
  restoreChatBackup,
  listBackups,
  deleteBackup
};