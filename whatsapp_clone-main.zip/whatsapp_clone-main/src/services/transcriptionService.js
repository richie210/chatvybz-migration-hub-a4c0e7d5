import openai from '../lib/openai';
import { 
  APIConnectionError,
  AuthenticationError,
  PermissionDeniedError,
  RateLimitError,
  InternalServerError
} from 'openai';

/**
 * Maps OpenAI API error types to user-friendly error messages.
 * @param {Error} error - The error object from OpenAI API.
 * @returns {Object} Error information with isInternal flag and message.
 */
function getErrorMessage(error) {
  if (error instanceof AuthenticationError) {
    return { isInternal: true, message: 'Invalid API key or authentication failed. Please check your OpenAI API key.' };
  } else if (error instanceof PermissionDeniedError) {
    return { isInternal: true, message: 'Quota exceeded or authorization failed. You may have exceeded your usage limits or do not have access to this resource.' };
  } else if (error instanceof RateLimitError) {
    return { isInternal: true, message: 'Rate limit exceeded. You are sending requests too quickly. Please wait a moment and try again.' };
  } else if (error instanceof InternalServerError) {
    return { isInternal: true, message: 'OpenAI service is currently unavailable. Please try again later.' };
  } else if (error instanceof APIConnectionError) {
    return { isInternal: true, message: 'Unable to connect to OpenAI service. Please check your API key and internet connection.' };
  } else {
    return { isInternal: false, message: error?.message || 'An unexpected error occurred. Please try again.' };
  }
}

/**
 * Transcribes audio to text using OpenAI Whisper.
 * @param {Blob} audioBlob - The audio blob to transcribe.
 * @param {Object} options - Transcription options.
 * @returns {Promise<Object>} Transcription result with text, language, and confidence.
 */
export async function transcribeAudio(audioBlob, options = {}) {
  try {
    const file = new File([audioBlob], 'audio.webm', { type: 'audio/webm' });
    
    const response = await openai?.audio?.transcriptions?.create({
      model: 'whisper-1',
      file: file,
      language: options?.language || 'en',
      response_format: 'verbose_json',
      temperature: 0.2,
    });

    return {
      text: response?.text,
      language: response?.language,
      duration: response?.duration,
      segments: response?.segments || [],
      confidence: calculateAverageConfidence(response?.segments || []),
    };
  } catch (error) {
    const errorInfo = getErrorMessage(error);
    if (errorInfo?.isInternal) {
      console.log(errorInfo?.message);
    } else {
      console.error('Error transcribing audio:', error);
    }
    throw new Error(errorInfo.message);
  }
}

/**
 * Transcribes audio with real-time streaming (simulated for client-side).
 * @param {Blob} audioBlob - The audio blob to transcribe.
 * @param {Function} onChunk - Callback for each transcription chunk.
 * @param {Object} options - Transcription options.
 */
export async function transcribeAudioStream(audioBlob, onChunk, options = {}) {
  try {
    const result = await transcribeAudio(audioBlob, options);
    
    // Simulate streaming by splitting text into chunks
    const words = result?.text?.split(' ');
    for (let i = 0; i < words?.length; i++) {
      await new Promise(resolve => setTimeout(resolve, 50));
      onChunk({
        text: words?.[i] + ' ',
        isFinal: i === words?.length - 1,
        confidence: result?.confidence,
      });
    }
  } catch (error) {
    const errorInfo = getErrorMessage(error);
    throw new Error(errorInfo.message);
  }
}

/**
 * Detects the language of the audio.
 * @param {Blob} audioBlob - The audio blob to analyze.
 * @returns {Promise<Object>} Detected language information.
 */
export async function detectLanguage(audioBlob) {
  try {
    const file = new File([audioBlob], 'audio.webm', { type: 'audio/webm' });
    
    const response = await openai?.audio?.transcriptions?.create({
      model: 'whisper-1',
      file: file,
      response_format: 'verbose_json',
    });

    return {
      language: response?.language,
      languageCode: response?.language,
      confidence: 0.9,
    };
  } catch (error) {
    const errorInfo = getErrorMessage(error);
    if (errorInfo?.isInternal) {
      console.log(errorInfo?.message);
    } else {
      console.error('Error detecting language:', error);
    }
    throw new Error(errorInfo.message);
  }
}

/**
 * Translates audio from any language to English.
 * @param {Blob} audioBlob - The audio blob to translate.
 * @returns {Promise<Object>} Translation result.
 */
export async function translateAudioToEnglish(audioBlob) {
  try {
    const file = new File([audioBlob], 'audio.webm', { type: 'audio/webm' });
    
    const response = await openai?.audio?.translations?.create({
      model: 'whisper-1',
      file: file,
      response_format: 'verbose_json',
    });

    return {
      text: response?.text,
      originalLanguage: response?.language || 'unknown',
      duration: response?.duration,
    };
  } catch (error) {
    const errorInfo = getErrorMessage(error);
    if (errorInfo?.isInternal) {
      console.log(errorInfo?.message);
    } else {
      console.error('Error translating audio:', error);
    }
    throw new Error(errorInfo.message);
  }
}

/**
 * Analyzes transcript for sentiment and key topics.
 * @param {string} transcript - The transcript text to analyze.
 * @returns {Promise<Object>} Analysis results.
 */
export async function analyzeTranscript(transcript) {
  try {
    const response = await openai?.chat?.completions?.create({
      model: 'gpt-5-mini',
      messages: [
        {
          role: 'system',
          content: 'You are a transcript analyzer. Analyze the sentiment and extract key topics from the transcript.',
        },
        {
          role: 'user',
          content: `Analyze this transcript:\n\n${transcript}`,
        },
      ],
      response_format: {
        type: 'json_schema',
        json_schema: {
          name: 'transcript_analysis',
          schema: {
            type: 'object',
            properties: {
              sentiment: { type: 'string', description: 'Overall sentiment: positive, negative, or neutral' },
              topics: { type: 'array', items: { type: 'string' }, description: 'Key topics discussed' },
              keywords: { type: 'array', items: { type: 'string' }, description: 'Important keywords' },
              summary: { type: 'string', description: 'Brief summary of the transcript' },
            },
            required: ['sentiment', 'topics', 'keywords', 'summary'],
            additionalProperties: false,
          },
        },
      },
      reasoning_effort: 'low',
      verbosity: 'low',
    });

    return JSON.parse(response?.choices?.[0]?.message?.content);
  } catch (error) {
    const errorInfo = getErrorMessage(error);
    if (errorInfo?.isInternal) {
      console.log(errorInfo?.message);
    } else {
      console.error('Error analyzing transcript:', error);
    }
    throw new Error(errorInfo.message);
  }
}

/**
 * Exports transcript in various formats.
 * @param {Array} transcripts - Array of transcript objects.
 * @param {string} format - Export format (txt, json, srt, vtt, docx).
 * @returns {string} Formatted transcript string.
 */
export function exportTranscript(transcripts, format) {
  switch (format) {
    case 'txt':
      return transcripts?.map(t => `[${new Date(t.timestamp)?.toLocaleTimeString()}] ${t?.speaker}: ${t?.text}`)?.join('\n');
    
    case 'json':
      return JSON.stringify(transcripts, null, 2);
    
    case 'srt':
      return transcripts?.map((t, i) => {
          const start = formatTimestamp(new Date(t.timestamp));
          const end = formatTimestamp(new Date(t.timestamp)?.getTime() + 3000);
          return `${i + 1}\n${start} --> ${end}\n${t?.speaker}: ${t?.text}\n`;
        })?.join('\n');
    
    case 'vtt':
      return `WEBVTT\n\n${transcripts?.map((t, i) => {
          const start = formatTimestamp(new Date(t.timestamp));
          const end = formatTimestamp(new Date(t.timestamp)?.getTime() + 3000);
          return `${i + 1}\n${start} --> ${end}\n${t?.speaker}: ${t?.text}`;
        })?.join('\n\n')}`;
    
    default:
      return exportTranscript(transcripts, 'txt');
  }
}

/**
 * Calculates average confidence from segments.
 * @param {Array} segments - Whisper segments with confidence scores.
 * @returns {number} Average confidence (0-1).
 */
function calculateAverageConfidence(segments) {
  if (!segments || segments?.length === 0) return 0.95;
  const sum = segments?.reduce((acc, seg) => acc + (seg?.confidence || 0.95), 0);
  return sum / segments?.length;
}

/**
 * Formats timestamp for SRT/VTT format.
 * @param {Date|number} time - Timestamp to format.
 * @returns {string} Formatted timestamp.
 */
function formatTimestamp(time) {
  const date = new Date(time);
  const hours = String(date?.getHours())?.padStart(2, '0');
  const minutes = String(date?.getMinutes())?.padStart(2, '0');
  const seconds = String(date?.getSeconds())?.padStart(2, '0');
  const ms = String(date?.getMilliseconds())?.padStart(3, '0');
  return `${hours}:${minutes}:${seconds},${ms}`;
}