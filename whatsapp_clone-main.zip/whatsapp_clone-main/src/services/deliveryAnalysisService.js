import claude from '../lib/claude';
import { supabase } from '../lib/supabase';

/**
 * Maps Anthropic API error status codes to user-friendly error messages.
 * @param {number} statusCode - The HTTP status code from Anthropic API.
 * @param {Object} errorData - The error data from API response.
 * @returns {Object} Object with isInternal flag and error message.
 */
function getErrorMessage(statusCode, errorData) {
  if (statusCode === 401) {
    return { isInternal: true, message: 'Invalid API key or authentication failed. Please check your Anthropic API key.' };
  } else if (statusCode === 403) {
    return { isInternal: true, message: 'Permission denied. Your API key does not have access to the specified resource.' };
  } else if (statusCode === 404) {
    return { isInternal: true, message: 'Resource not found. The requested endpoint or model may not exist.' };
  } else if (statusCode === 429) {
    return { isInternal: true, message: 'Rate limit exceeded. You are sending requests too quickly. Please wait a moment and try again.' };
  } else if (statusCode === 500) {
    return { isInternal: true, message: 'Anthropic service error. An unexpected error occurred on their servers. Please try again later.' };
  } else if (statusCode === 529) {
    return { isInternal: true, message: 'Anthropic service is temporarily overloaded. Please try again in a few moments.' };
  } else {
    return { isInternal: false, message: errorData?.error?.message || 'An unexpected error occurred. Please try again.' };
  }
}

/**
 * Delivery Analysis Service
 * Uses Claude AI to analyze message delivery failures and suggest improvements
 */

export const deliveryAnalysisService = {
  /**
   * Analyze message delivery failure and suggest resend strategy
   * @param {string} messageId - Message ID that failed
   * @returns {Promise<Object>} Analysis with suggestions
   */
  async analyzeDeliveryFailure(messageId) {
    try {
      // Get message details and failure history
      const { data: message, error } = await supabase
        ?.from('chat_messages')
        ?.select(`
          id,
          message,
          status,
          delivery_attempts,
          delivery_failure_reason,
          last_delivery_attempt,
          created_at,
          sender_id,
          recipient_id
        `)
        ?.eq('id', messageId)
        ?.single();

      if (error) throw error;

      if (!message) {
        throw new Error('Message not found');
      }

      // Get recipient's recent activity
      const { data: recentActivity } = await supabase
        ?.from('chat_messages')?.select('created_at, status')?.eq('recipient_id', message?.recipient_id)?.order('created_at', { ascending: false })
        ?.limit(10);

      // Analyze with Claude
      const analysis = await this.analyzeWithClaude(message, recentActivity);

      // Store suggested resend time
      if (analysis?.suggestedResendTime) {
        await supabase
          ?.from('chat_messages')
          ?.update({
            suggested_resend_time: analysis?.suggestedResendTime
          })
          ?.eq('id', messageId);
      }

      return analysis;
    } catch (error) {
      console.error('Analyze delivery failure error:', error);
      throw error;
    }
  },

  /**
   * Use Claude to analyze failure and generate suggestions
   * @param {Object} message - Message data
   * @param {Array} recentActivity - Recent recipient activity
   * @returns {Promise<Object>} Analysis result
   */
  async analyzeWithClaude(message, recentActivity) {
    try {
      const activitySummary = recentActivity
        ?.map(a => `${new Date(a?.created_at)?.toLocaleString()}: ${a?.status}`)
        ?.join('\n') || 'No recent activity';

      const response = await claude?.messages?.create({
        model: 'claude-haiku-4-5-20251001',
        max_tokens: 1024,
        messages: [
          {
            role: 'user',
            content: `You are a messaging delivery expert. Analyze this failed message delivery and provide actionable recommendations.

Message Details:
- Content: "${message?.message}"
- Delivery Attempts: ${message?.delivery_attempts}
- Failure Reason: ${message?.delivery_failure_reason || 'Unknown'}
- Last Attempt: ${message?.last_delivery_attempt ? new Date(message?.last_delivery_attempt)?.toLocaleString() : 'N/A'}
- Original Send Time: ${new Date(message?.created_at)?.toLocaleString()}

Recipient Recent Activity:
${activitySummary}

Provide analysis in JSON format:
{
  "failureCategory": "network" | "recipient_offline" | "content_issue" | "rate_limit" | "unknown",
  "suggestedResendTime": "ISO timestamp for optimal resend time",
  "resendDelayMinutes": number,
  "formatSuggestions": ["suggestion1", "suggestion2"],
  "contentRecommendations": ["recommendation1", "recommendation2"],
  "reasoning": "Brief explanation of analysis",
  "confidence": "high" | "medium" | "low"
}`
          }
        ]
      });

      const content = response?.content?.[0]?.text;
      if (!content) {
        throw new Error('No response from Claude API');
      }

      // Parse JSON from response
      const jsonMatch = content?.match(/\{[\s\S]*\}/);
      if (!jsonMatch) {
        throw new Error('Invalid JSON response from Claude');
      }

      const analysis = JSON.parse(jsonMatch?.[0]);

      return {
        failureCategory: analysis?.failureCategory,
        suggestedResendTime: analysis?.suggestedResendTime,
        resendDelayMinutes: analysis?.resendDelayMinutes,
        formatSuggestions: analysis?.formatSuggestions || [],
        contentRecommendations: analysis?.contentRecommendations || [],
        reasoning: analysis?.reasoning,
        confidence: analysis?.confidence,
        analyzedAt: new Date()?.toISOString()
      };
    } catch (error) {
      // Handle Anthropic API errors
      if (error?.status) {
        const errorInfo = getErrorMessage(error?.status, error);
        if (!errorInfo?.isInternal) {
          console.error('Claude API error:', error);
        }
        throw new Error(errorInfo?.message);
      }

      // Handle other errors
      console.error('Error analyzing with Claude:', error);
      throw error;
    }
  },

  /**
   * Record delivery failure
   * @param {string} messageId - Message ID
   * @param {string} failureReason - Reason for failure
   * @returns {Promise<Object>} Record result
   */
  async recordDeliveryFailure(messageId, failureReason) {
    try {
      const { data, error } = await supabase?.rpc('record_delivery_failure', {
        p_message_id: messageId,
        p_failure_reason: failureReason
      });

      if (error) throw error;

      return data;
    } catch (error) {
      console.error('Record delivery failure error:', error);
      throw error;
    }
  },

  /**
   * Get failed messages for a user
   * @param {string} userId - User ID
   * @returns {Promise<Array>} Failed messages
   */
  async getFailedMessages(userId) {
    try {
      const { data, error } = await supabase
        ?.from('chat_messages')
        ?.select(`
          id,
          message,
          status,
          delivery_attempts,
          delivery_failure_reason,
          suggested_resend_time,
          last_delivery_attempt,
          created_at,
          recipient_id
        `)
        ?.eq('sender_id', userId)
        ?.eq('status', 'failed')
        ?.order('last_delivery_attempt', { ascending: false });

      if (error) throw error;

      return data || [];
    } catch (error) {
      console.error('Get failed messages error:', error);
      return [];
    }
  },

  /**
   * Check if message should be retried based on analysis
   * @param {string} messageId - Message ID
   * @returns {Promise<Object>} Retry recommendation
   */
  async shouldRetryMessage(messageId) {
    try {
      const { data: message } = await supabase
        ?.from('chat_messages')
        ?.select('suggested_resend_time, delivery_attempts')
        ?.eq('id', messageId)
        ?.single();

      if (!message) {
        return { shouldRetry: false, reason: 'Message not found' };
      }

      if (message?.delivery_attempts >= 5) {
        return { shouldRetry: false, reason: 'Maximum retry attempts reached' };
      }

      if (message?.suggested_resend_time) {
        const suggestedTime = new Date(message?.suggested_resend_time);
        const now = new Date();

        if (now >= suggestedTime) {
          return {
            shouldRetry: true,
            reason: 'Optimal resend time reached',
            suggestedTime: message?.suggested_resend_time
          };
        } else {
          const waitMinutes = Math.ceil((suggestedTime - now) / 60000);
          return {
            shouldRetry: false,
            reason: `Wait ${waitMinutes} more minutes for optimal delivery`,
            suggestedTime: message?.suggested_resend_time
          };
        }
      }

      return { shouldRetry: true, reason: 'No specific timing constraint' };
    } catch (error) {
      console.error('Should retry message error:', error);
      return { shouldRetry: false, reason: 'Error checking retry status' };
    }
  },

  /**
   * Format time until suggested resend
   * @param {string} suggestedTime - ISO timestamp
   * @returns {string} Formatted time
   */
  formatTimeUntilResend(suggestedTime) {
    if (!suggestedTime) return 'Unknown';

    const now = new Date();
    const suggested = new Date(suggestedTime);
    const diffMs = suggested - now;

    if (diffMs <= 0) return 'Now';

    const minutes = Math.floor(diffMs / 60000);
    const hours = Math.floor(minutes / 60);

    if (hours > 0) {
      return `${hours}h ${minutes % 60}m`;
    }
    return `${minutes}m`;
  }
};