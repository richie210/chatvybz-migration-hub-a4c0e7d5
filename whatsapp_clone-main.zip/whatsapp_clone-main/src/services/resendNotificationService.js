import { supabase } from '../lib/supabase';

/**
 * Resend Notification Service
 * Handles email notifications via Resend for messages, mentions, calls, and analytics reports
 */

export const resendNotificationService = {
  /**
   * Send push notification via email
   */
  async sendPushNotification(notificationType, recipientEmail, recipientName, data) {
    try {
      const { data: result, error } = await supabase?.functions?.invoke('send-push-notification', {
        body: {
          notificationType,
          recipientEmail,
          recipientName,
          data
        }
      });

      if (error) throw error;

      return {
        success: true,
        data: result
      };
    } catch (error) {
      console.error('Error sending push notification:', error);
      return {
        success: false,
        error: error?.message
      };
    }
  },

  /**
   * Send message notification
   */
  async sendMessageNotification(recipientEmail, recipientName, senderName, messagePreview, chatUrl) {
    return await this.sendPushNotification('message', recipientEmail, recipientName, {
      senderName,
      messagePreview,
      chatUrl
    });
  },

  /**
   * Send mention notification
   */
  async sendMentionNotification(recipientEmail, recipientName, mentionerName, messagePreview, messageUrl) {
    return await this.sendPushNotification('mention', recipientEmail, recipientName, {
      mentionerName,
      messagePreview,
      messageUrl
    });
  },

  /**
   * Send call notification
   */
  async sendCallNotification(recipientEmail, recipientName, callerName, callType, callStatus, callUrl) {
    return await this.sendPushNotification('call', recipientEmail, recipientName, {
      callerName,
      callType,
      callStatus,
      callUrl
    });
  },

  /**
   * Send analytics report via email
   */
  async sendAnalyticsReport(reportType, recipientEmail, recipientName, data) {
    try {
      const { data: result, error } = await supabase?.functions?.invoke('send-analytics-report', {
        body: {
          reportType,
          recipientEmail,
          recipientName,
          data
        }
      });

      if (error) throw error;

      return {
        success: true,
        data: result
      };
    } catch (error) {
      console.error('Error sending analytics report:', error);
      return {
        success: false,
        error: error?.message
      };
    }
  },

  /**
   * Send creator revenue report
   */
  async sendCreatorRevenueReport(recipientEmail, recipientName, revenueData) {
    return await this.sendAnalyticsReport('creator_revenue', recipientEmail, recipientName, revenueData);
  },

  /**
   * Send call metrics report
   */
  async sendCallMetricsReport(recipientEmail, recipientName, callData) {
    return await this.sendAnalyticsReport('call_metrics', recipientEmail, recipientName, callData);
  },

  /**
   * Send subscriber insights report
   */
  async sendSubscriberInsightsReport(recipientEmail, recipientName, subscriberData) {
    return await this.sendAnalyticsReport('subscriber_insights', recipientEmail, recipientName, subscriberData);
  },

  /**
   * Schedule analytics report (stores preference in database)
   */
  async scheduleAnalyticsReport(userId, reportType, frequency, enabled = true) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      // Get or create notification preferences
      const { data: prefs, error: fetchError } = await supabase
        ?.from('notification_preferences')
        ?.select('*')
        ?.eq('user_id', userId)
        ?.single();

      let emailReportPreferences = prefs?.email_report_preferences || {};

      // Update report schedule
      emailReportPreferences[reportType] = {
        enabled,
        frequency, // 'daily', 'weekly', 'monthly'
        lastSent: null
      };

      const { data, error } = await supabase
        ?.from('notification_preferences')
        ?.upsert({
          user_id: userId,
          email_report_preferences: emailReportPreferences
        }, {
          onConflict: 'user_id'
        })
        ?.select()
        ?.single();

      if (error) throw error;

      return {
        success: true,
        data
      };
    } catch (error) {
      console.error('Error scheduling analytics report:', error);
      return {
        success: false,
        error: error?.message
      };
    }
  },

  /**
   * Get scheduled report preferences
   */
  async getScheduledReports(userId) {
    try {
      const { data, error } = await supabase
        ?.from('notification_preferences')
        ?.select('email_report_preferences')
        ?.eq('user_id', userId)
        ?.single();

      if (error && error?.code !== 'PGRST116') throw error;

      return {
        success: true,
        data: data?.email_report_preferences || {}
      };
    } catch (error) {
      console.error('Error fetching scheduled reports:', error);
      return {
        success: false,
        error: error?.message
      };
    }
  }
};