import genAI, { handleGeminiError } from '../lib/gemini';
import { supabase } from '../lib/supabase';

/**
 * Analyzes conversation patterns from call transcript
 * @param {string} transcript - Call transcript text
 * @returns {Promise<Object>} Conversation patterns analysis
 */
export async function analyzeConversationPatterns(transcript) {
  try {
    if (!transcript || transcript?.trim()?.length === 0) {
      throw new Error('Transcript is empty. Cannot analyze empty transcript.');
    }

    const model = genAI?.getGenerativeModel({ model: 'gemini-2.5-pro' });
    
    const prompt = `Analyze the following call transcript and identify conversation patterns:

1. Speaking time distribution (percentage for each participant)
2. Turn-taking patterns (who initiated topics, who responded)
3. Interruption frequency
4. Question-to-statement ratio
5. Topic transitions and flow

Format your response as JSON:
{
  "speaking_distribution": [{"participant": "name", "percentage": 45}],
  "turn_taking": {"initiator": "name", "responder": "name", "balance_score": 0-100},
  "interruptions": {"count": 5, "primary_interrupter": "name"},
  "question_ratio": 0.3,
  "topic_flow": ["topic1", "topic2"],
  "engagement_indicators": ["indicator1", "indicator2"]
}

Transcript:
${transcript}`;

    const result = await model?.generateContent(prompt);
    const response = await result?.response;
    const content = response?.text();
    
    const jsonMatch = content?.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      throw new Error('Failed to extract JSON from AI response');
    }

    return JSON.parse(jsonMatch?.[0]);
  } catch (error) {
    const errorInfo = handleGeminiError(error);
    if (!errorInfo?.isInternal) {
      console.error('Analyze conversation patterns error:', error);
    }
    throw new Error(errorInfo.message);
  }
}

/**
 * Analyzes participant sentiment throughout the call
 * @param {string} transcript - Call transcript text
 * @returns {Promise<Object>} Sentiment analysis results
 */
export async function analyzeParticipantSentiment(transcript) {
  try {
    if (!transcript || transcript?.trim()?.length === 0) {
      throw new Error('Transcript is empty. Cannot analyze sentiment.');
    }

    const model = genAI?.getGenerativeModel({ model: 'gemini-2.5-pro' });
    
    const prompt = `Analyze the sentiment of each participant in this call transcript:

1. Overall sentiment (positive, neutral, negative) with confidence score
2. Sentiment progression (how it changed during the call)
3. Emotional tone indicators
4. Engagement level (high, medium, low)
5. Key sentiment shifts and triggers

Format your response as JSON:
{
  "participants": [
    {
      "name": "participant name",
      "overall_sentiment": "positive/neutral/negative",
      "confidence": 0.85,
      "sentiment_score": 75,
      "progression": ["positive", "neutral", "positive"],
      "emotional_tone": ["enthusiastic", "professional"],
      "engagement_level": "high"
    }
  ],
  "sentiment_shifts": [{"timestamp": "00:05:30", "trigger": "topic change", "shift": "neutral to positive"}],
  "overall_call_sentiment": "positive",
  "sentiment_balance": 0.7
}

Transcript:
${transcript}`;

    const result = await model?.generateContent(prompt);
    const response = await result?.response;
    const content = response?.text();
    
    const jsonMatch = content?.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      throw new Error('Failed to extract JSON from AI response');
    }

    return JSON.parse(jsonMatch?.[0]);
  } catch (error) {
    const errorInfo = handleGeminiError(error);
    if (!errorInfo?.isInternal) {
      console.error('Analyze participant sentiment error:', error);
    }
    throw new Error(errorInfo.message);
  }
}

/**
 * Calculates meeting effectiveness score
 * @param {string} transcript - Call transcript text
 * @returns {Promise<Object>} Effectiveness scoring results
 */
export async function calculateMeetingEffectiveness(transcript) {
  try {
    if (!transcript || transcript?.trim()?.length === 0) {
      throw new Error('Transcript is empty. Cannot calculate effectiveness.');
    }

    const model = genAI?.getGenerativeModel({ model: 'gemini-2.5-pro' });
    
    const prompt = `Evaluate the effectiveness of this meeting/call based on the transcript:

1. Overall effectiveness score (0-100)
2. Goal achievement (were objectives met?)
3. Participation quality (balanced, productive)
4. Decision-making clarity
5. Action items identified
6. Time efficiency
7. Communication clarity

Format your response as JSON:
{
  "effectiveness_score": 85,
  "goal_achievement": {"score": 90, "objectives_met": true, "details": "Clear outcomes"},
  "participation_quality": {"score": 80, "balance": "good", "notes": "All engaged"},
  "decision_making": {"score": 85, "clarity": "high", "decisions_count": 3},
  "action_items": {"count": 5, "clarity": "high"},
  "time_efficiency": {"score": 75, "notes": "Some tangents"},
  "communication_clarity": {"score": 90, "notes": "Clear and professional"},
  "strengths": ["strength1", "strength2"],
  "improvements": ["improvement1", "improvement2"]
}

Transcript:
${transcript}`;

    const result = await model?.generateContent(prompt);
    const response = await result?.response;
    const content = response?.text();
    
    const jsonMatch = content?.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      throw new Error('Failed to extract JSON from AI response');
    }

    return JSON.parse(jsonMatch?.[0]);
  } catch (error) {
    const errorInfo = handleGeminiError(error);
    if (!errorInfo?.isInternal) {
      console.error('Calculate meeting effectiveness error:', error);
    }
    throw new Error(errorInfo.message);
  }
}

/**
 * Generates automated insights from transcript
 * @param {string} transcript - Call transcript text
 * @returns {Promise<Object>} Generated insights
 */
export async function generateAutomatedInsights(transcript) {
  try {
    if (!transcript || transcript?.trim()?.length === 0) {
      throw new Error('Transcript is empty. Cannot generate insights.');
    }

    const model = genAI?.getGenerativeModel({ model: 'gemini-2.5-flash' });
    
    const prompt = `Generate actionable insights from this call transcript:

1. Key takeaways (3-5 main points)
2. Action items with owners and deadlines
3. Follow-up recommendations
4. Risk factors or concerns identified
5. Opportunities mentioned
6. Next steps

Format your response as JSON:
{
  "key_takeaways": ["takeaway1", "takeaway2", "takeaway3"],
  "action_items": [{"task": "description", "owner": "name", "deadline": "date or null", "priority": "high/medium/low"}],
  "follow_ups": ["follow-up1", "follow-up2"],
  "risks": [{"risk": "description", "severity": "high/medium/low"}],
  "opportunities": ["opportunity1", "opportunity2"],
  "next_steps": ["step1", "step2"],
  "summary": "Brief 2-3 sentence summary"
}

Transcript:
${transcript}`;

    const result = await model?.generateContent(prompt);
    const response = await result?.response;
    const content = response?.text();
    
    const jsonMatch = content?.match(/\{[\s\S]*\}/);
    if (!jsonMatch) {
      throw new Error('Failed to extract JSON from AI response');
    }

    return JSON.parse(jsonMatch?.[0]);
  } catch (error) {
    const errorInfo = handleGeminiError(error);
    if (!errorInfo?.isInternal) {
      console.error('Generate automated insights error:', error);
    }
    throw new Error(errorInfo.message);
  }
}

/**
 * Processes a call recording with comprehensive AI analysis
 * @param {string} callId - Call UUID
 * @param {string} transcript - Call transcript text
 * @returns {Promise<Object>} Complete AI analysis results
 */
export async function processCallWithAI(callId, transcript) {
  try {
    const { data: { user } } = await supabase?.auth?.getUser();
    if (!user) throw new Error('Not authenticated');

    const [patterns, sentiment, effectiveness, insights] = await Promise.all([
      analyzeConversationPatterns(transcript),
      analyzeParticipantSentiment(transcript),
      calculateMeetingEffectiveness(transcript),
      generateAutomatedInsights(transcript)
    ]);

    const analysisResults = {
      call_id: callId,
      conversation_patterns: patterns,
      participant_sentiment: sentiment,
      effectiveness_score: effectiveness?.effectiveness_score,
      effectiveness_details: effectiveness,
      automated_insights: insights,
      analyzed_at: new Date()?.toISOString()
    };

    return analysisResults;
  } catch (error) {
    console.error('Process call with AI error:', error);
    throw error;
  }
}

function geminiAnalyticsService(...args) {
  // eslint-disable-next-line no-console
  console.warn('Placeholder: geminiAnalyticsService is not implemented yet.', args);
  return null;
}

export { geminiAnalyticsService };