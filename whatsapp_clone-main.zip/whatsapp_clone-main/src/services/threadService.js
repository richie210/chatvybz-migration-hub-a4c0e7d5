import { supabase } from '../lib/supabase';
import { encryptionService } from './encryptionService';

/**
 * Service for managing message reply threads
 */
export const threadService = {
  /**
   * Get all messages in a thread
   * @param {string} threadRootId - ID of the root message
   * @returns {Promise<Array>} Thread messages with decryption
   */
  async getThreadMessages(threadRootId) {
    try {
      const { data, error } = await supabase?.rpc('get_thread_messages', {
        thread_root_id: threadRootId
      });

      if (error) throw error;

      // Decrypt messages if needed
      return data?.map(msg => {
        let decryptedContent = msg?.message;

        if (msg?.is_encrypted && msg?.nonce) {
          try {
            const { data: { user } } = supabase?.auth?.getSession();
            if (user) {
              decryptedContent = encryptionService?.decryptMessage(
                { encryptedMessage: msg?.message, nonce: msg?.nonce },
                msg?.sender_id
              );
            }
          } catch (error) {
            console.error('Thread message decryption failed:', error);
            decryptedContent = '[Encrypted message]';
          }
        }

        return {
          id: msg?.id,
          content: decryptedContent,
          senderId: msg?.sender_id,
          parentMessageId: msg?.parent_message_id,
          timestamp: new Date(msg.created_at),
          isEncrypted: msg?.is_encrypted || false,
          sender: {
            name: msg?.sender_name,
            avatar: msg?.sender_avatar
          }
        };
      }) || [];
    } catch (error) {
      console.error('Error fetching thread messages:', error);
      throw error;
    }
  },

  /**
   * Reply to a message (creates a thread)
   * @param {string} parentMessageId - ID of message to reply to
   * @param {string} content - Reply content
   * @param {string} senderId - User ID of sender
   * @param {string} recipientId - User ID of recipient
   * @returns {Promise<Object>} Created reply message
   */
  async replyToMessage(parentMessageId, content, senderId, recipientId) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      // Encrypt the reply
      const encryptedData = encryptionService?.encryptMessage(content, recipientId);

      const { data, error } = await supabase?.from('chat_messages')?.insert({
        parent_message_id: parentMessageId,
        sender_id: senderId,
        recipient_id: recipientId,
        message: encryptedData?.encryptedMessage || content,
        is_encrypted: !!encryptedData?.encryptedMessage,
        nonce: encryptedData?.nonce || null,
        sender_name: user?.email?.split('@')?.[0] || 'User',
        status: 'sent'
      })?.select()?.single();

      if (error) throw error;

      return {
        success: true,
        message: {
          id: data?.id,
          content: content,
          parentMessageId: data?.parent_message_id,
          threadId: data?.thread_id,
          timestamp: new Date(data.created_at),
          isEncrypted: data?.is_encrypted
        }
      };
    } catch (error) {
      console.error('Error replying to message:', error);
      throw error;
    }
  },

  /**
   * Get reply count for a message
   * @param {string} messageId - Message ID
   * @returns {Promise<number>} Number of replies
   */
  async getReplyCount(messageId) {
    try {
      const { data, error } = await supabase?.rpc('get_thread_count', {
        message_id: messageId
      });

      if (error) throw error;
      return data || 0;
    } catch (error) {
      console.error('Error getting reply count:', error);
      return 0;
    }
  },

  /**
   * Get thread preview (first few replies)
   * @param {string} threadRootId - Root message ID
   * @param {number} limit - Number of preview messages
   * @returns {Promise<Array>} Preview messages
   */
  async getThreadPreview(threadRootId, limit = 3) {
    try {
      const allMessages = await this.getThreadMessages(threadRootId);
      
      // Return first N messages excluding root
      return allMessages?.filter(msg => msg?.id !== threadRootId)?.slice(0, limit);
    } catch (error) {
      console.error('Error getting thread preview:', error);
      return [];
    }
  },

  /**
   * Subscribe to thread updates
   * @param {string} threadId - Thread ID to watch
   * @param {Function} onUpdate - Callback for updates
   * @returns {Function} Unsubscribe function
   */
  subscribeToThread(threadId, onUpdate) {
    const channel = supabase?.channel(`thread:${threadId}`)?.on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'chat_messages',
          filter: `thread_id=eq.${threadId}`
        },
        async (payload) => {
          // Decrypt new message if needed
          let content = payload?.new?.message;
          if (payload?.new?.is_encrypted && payload?.new?.nonce) {
            try {
              content = encryptionService?.decryptMessage(
                { encryptedMessage: payload?.new?.message, nonce: payload?.new?.nonce },
                payload?.new?.sender_id
              );
            } catch (error) {
              console.error('Real-time thread message decryption failed:', error);
              content = '[Encrypted message]';
            }
          }

          onUpdate({
            type: 'new_reply',
            message: {
              id: payload?.new?.id,
              content: content,
              senderId: payload?.new?.sender_id,
              parentMessageId: payload?.new?.parent_message_id,
              threadId: payload?.new?.thread_id,
              timestamp: new Date(payload.new.created_at),
              isEncrypted: payload?.new?.is_encrypted
            }
          });
        }
      )?.subscribe();

    return () => {
      supabase?.removeChannel(channel);
    };
  }
};

export default threadService;