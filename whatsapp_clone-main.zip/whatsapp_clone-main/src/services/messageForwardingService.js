import { supabase } from '../lib/supabase';


/**
 * Service for forwarding messages between chats.
 * Handles message duplication with forwarding metadata.
 */
export const messageForwardingService = {
  /**
   * Forward a message to one or more recipients.
   * @param {string} messageId - The original message ID to forward.
   * @param {Array<string>} recipientIds - Array of recipient user IDs.
   * @param {string} senderId - The current user's ID (forwarder).
   * @param {boolean} includeAttachments - Whether to include attachments (default: true).
   * @returns {Promise<Array>} Array of created forwarded messages.
   */
  async forwardMessage(messageId, recipientIds, senderId, includeAttachments = true) {
    try {
      // Get original message
      const { data: originalMessage, error: fetchError } = await supabase
        ?.from('chat_messages')?.select(`*,sender:sender_id(id, full_name, avatar_url),attachments:message_attachments(*)`)?.eq('id', messageId)
        ?.single();

      if (fetchError) throw fetchError;

      const forwardedMessages = [];

      // Create forwarded message for each recipient
      for (const recipientId of recipientIds) {
        // Create new message with forwarding metadata
        const { data: newMessage, error: insertError } = await supabase
          ?.from('chat_messages')
          ?.insert({
            sender_id: senderId,
            recipient_id: recipientId,
            message: originalMessage?.message,
            is_forwarded: true,
            forwarded_from_message_id: messageId,
            forwarded_from_user_id: originalMessage?.sender_id,
            forwarded_at: new Date()?.toISOString(),
            is_encrypted: originalMessage?.is_encrypted,
            nonce: originalMessage?.nonce,
            status: 'sent'
          })
          ?.select()
          ?.single();

        if (insertError) throw insertError;

        // Copy attachments if requested
        if (includeAttachments && originalMessage?.attachments?.length > 0) {
          const attachmentCopies = originalMessage?.attachments?.map(att => ({
            message_id: newMessage?.id,
            file_name: att?.file_name,
            file_type: att?.file_type,
            file_size: att?.file_size,
            file_url: att?.file_url,
            thumbnail_url: att?.thumbnail_url,
            mime_type: att?.mime_type,
            duration: att?.duration,
            width: att?.width,
            height: att?.height
          }));

          const { error: attachError } = await supabase
            ?.from('message_attachments')
            ?.insert(attachmentCopies);

          if (attachError) throw attachError;
        }

        forwardedMessages?.push(newMessage);
      }

      return forwardedMessages;
    } catch (error) {
      console.error('Error forwarding message:', error);
      throw error;
    }
  },

  /**
   * Get forwarding information for a message.
   * @param {string} messageId - The message ID.
   * @returns {Promise<Object>} Forwarding metadata.
   */
  async getForwardingInfo(messageId) {
    try {
      const { data, error } = await supabase
        ?.from('chat_messages')
        ?.select(`
          is_forwarded,
          forwarded_at,
          forwarded_from_user:forwarded_from_user_id(id, full_name, avatar_url),
          original_message:forwarded_from_message_id(id, message, created_at)
        `)
        ?.eq('id', messageId)
        ?.single();

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error fetching forwarding info:', error);
      throw error;
    }
  },

  /**
   * Check if a message can be forwarded.
   * @param {string} messageId - The message ID.
   * @param {string} userId - The current user's ID.
   * @returns {Promise<boolean>} Whether the message can be forwarded.
   */
  async canForwardMessage(messageId, userId) {
    try {
      const { data, error } = await supabase
        ?.from('chat_messages')
        ?.select('sender_id, recipient_id, deleted_by_sender, deleted_for')
        ?.eq('id', messageId)
        ?.single();

      if (error) throw error;

      // Check if user has access to the message
      const hasAccess = data?.sender_id === userId || data?.recipient_id === userId;
      
      // Check if message is not deleted for this user
      const isDeleted = data?.deleted_by_sender || data?.deleted_for?.includes(userId);

      return hasAccess && !isDeleted;
    } catch (error) {
      console.error('Error checking forward permission:', error);
      return false;
    }
  },

  /**
   * Get forwarding chain for a message (if it was forwarded multiple times).
   * @param {string} messageId - The message ID.
   * @returns {Promise<Array>} Array of messages in the forwarding chain.
   */
  async getForwardingChain(messageId) {
    try {
      const chain = [];
      let currentId = messageId;

      // Follow the chain backwards to the original message
      while (currentId) {
        const { data, error } = await supabase
          ?.from('chat_messages')
          ?.select(`
            id,
            message,
            created_at,
            is_forwarded,
            forwarded_at,
            forwarded_from_message_id,
            sender:sender_id(id, full_name, avatar_url)
          `)
          ?.eq('id', currentId)
          ?.single();

        if (error) break;

        chain?.unshift(data);
        currentId = data?.forwarded_from_message_id;
      }

      return chain;
    } catch (error) {
      console.error('Error fetching forwarding chain:', error);
      return [];
    }
  }
};