import { supabase } from '../lib/supabase';

/**
 * Stripe Payment Service - Handles channel subscriptions and payment processing
 */

export const stripePaymentService = {
  /**
   * Create or get Stripe customer
   */
  async getOrCreateStripeCustomer() {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('User not authenticated');

      // Check if customer already exists
      const { data: existingCustomer, error: fetchError } = await supabase
        ?.from('stripe_customers')
        ?.select('*')
        ?.eq('user_id', user?.id)
        ?.single();

      if (existingCustomer) {
        return { data: existingCustomer, error: null };
      }

      // Get user profile for customer details
      const { data: profile } = await supabase
        ?.from('profiles')
        ?.select('email, full_name')
        ?.eq('id', user?.id)
        ?.single();

      // Create new Stripe customer via Edge Function
      const { data: newCustomer, error: createError } = await supabase?.functions?.invoke('create-stripe-customer', {
        body: {
          userId: user?.id,
          email: profile?.email || user?.email,
          name: profile?.full_name
        }
      });

      if (createError) throw createError;

      return { data: newCustomer, error: null };
    } catch (error) {
      console.error('Error getting/creating Stripe customer:', error);
      return { data: null, error };
    }
  },

  /**
   * Get channel subscription tiers
   */
  async getChannelSubscriptionTiers(channelId) {
    try {
      const { data, error } = await supabase
        ?.from('channel_subscription_tiers')
        ?.select('*')
        ?.eq('channel_id', channelId)
        ?.eq('is_active', true)
        ?.order('price', { ascending: true });

      if (error) throw error;

      return { data, error: null };
    } catch (error) {
      console.error('Error fetching subscription tiers:', error);
      return { data: null, error };
    }
  },

  /**
   * Create subscription tier for channel
   */
  async createSubscriptionTier(channelId, tierData) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('User not authenticated');

      // Create Stripe price via Edge Function
      const { data: stripePrice, error: priceError } = await supabase?.functions?.invoke('create-stripe-price', {
        body: {
          channelId,
          tierData: {
            name: tierData?.name,
            amount: Math.round(tierData?.price * 100), // Convert to cents
            currency: tierData?.currency || 'USD',
            interval: tierData?.billingInterval || 'month'
          }
        }
      });

      if (priceError) throw priceError;

      // Create tier in database
      const { data, error } = await supabase
        ?.from('channel_subscription_tiers')
        ?.insert([{
          channel_id: channelId,
          tier: tierData?.tier,
          name: tierData?.name,
          description: tierData?.description,
          price: tierData?.price,
          currency: tierData?.currency || 'USD',
          billing_interval: tierData?.billingInterval || 'month',
          features: tierData?.features || [],
          stripe_price_id: stripePrice?.priceId
        }])
        ?.select()
        ?.single();

      if (error) throw error;

      return { data, error: null };
    } catch (error) {
      console.error('Error creating subscription tier:', error);
      return { data: null, error };
    }
  },

  /**
   * Subscribe to channel premium tier
   */
  async subscribeToChannel(channelId, tierId) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('User not authenticated');

      // Get or create Stripe customer
      const { data: customer, error: customerError } = await this.getOrCreateStripeCustomer();
      if (customerError) throw customerError;

      // Get tier details
      const { data: tier, error: tierError } = await supabase
        ?.from('channel_subscription_tiers')
        ?.select('*')
        ?.eq('id', tierId)
        ?.single();

      if (tierError) throw tierError;

      // Create Stripe subscription via Edge Function
      const { data: subscription, error: subscriptionError } = await supabase?.functions?.invoke('create-stripe-subscription', {
        body: {
          customerId: customer?.stripe_customer_id,
          priceId: tier?.stripe_price_id,
          channelId,
          tierId,
          userId: user?.id
        }
      });

      if (subscriptionError) throw subscriptionError;

      return { data: subscription, error: null };
    } catch (error) {
      console.error('Error subscribing to channel:', error);
      return { data: null, error };
    }
  },

  /**
   * Cancel channel subscription
   */
  async cancelSubscription(subscriptionId) {
    try {
      const { data, error } = await supabase?.functions?.invoke('cancel-stripe-subscription', {
        body: { subscriptionId }
      });

      if (error) throw error;

      return { data, error: null };
    } catch (error) {
      console.error('Error canceling subscription:', error);
      return { data: null, error };
    }
  },

  /**
   * Get user's channel subscriptions
   */
  async getUserSubscriptions() {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('User not authenticated');

      const { data, error } = await supabase
        ?.from('channel_subscriptions')
        ?.select(`
          *,
          channel:channel_id(
            id,
            name,
            username,
            avatar_url
          ),
          tier:tier_id(
            name,
            price,
            currency,
            billing_interval
          )
        `)
        ?.eq('user_id', user?.id)
        ?.order('created_at', { ascending: false });

      if (error) throw error;

      return { data, error: null };
    } catch (error) {
      console.error('Error fetching user subscriptions:', error);
      return { data: null, error };
    }
  },

  /**
   * Get channel revenue analytics
   */
  async getChannelRevenue(channelId, dateRange = { days: 30 }) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('User not authenticated');

      const endDate = new Date();
      const startDate = new Date();
      startDate?.setDate(startDate?.getDate() - (dateRange?.days || 30));

      // Get revenue splits
      const { data: revenueSplits, error: revenueError } = await supabase
        ?.from('channel_revenue_splits')
        ?.select('*')
        ?.eq('channel_id', channelId)
        ?.gte('period_start', startDate?.toISOString())
        ?.order('period_start', { ascending: false });

      if (revenueError) throw revenueError;

      // Get ad revenue
      const { data: adRevenue, error: adError } = await supabase
        ?.from('ad_revenue_distribution')
        ?.select('*')
        ?.eq('channel_id', channelId)
        ?.gte('date', startDate?.toISOString()?.split('T')?.[0])
        ?.order('date', { ascending: false });

      if (adError) throw adError;

      // Get active subscriptions count
      const { data: subscriptions, error: subsError } = await supabase
        ?.from('channel_subscriptions')
        ?.select('id, tier_id(price, currency)')
        ?.eq('channel_id', channelId)
        ?.eq('status', 'active');

      if (subsError) throw subsError;

      // Calculate totals
      const totalSubscriptionRevenue = revenueSplits
        ?.filter(r => r?.revenue_type === 'subscription')
        ?.reduce((sum, r) => sum + parseFloat(r?.creator_earnings || 0), 0);

      const totalAdRevenue = adRevenue
        ?.reduce((sum, r) => sum + parseFloat(r?.creator_share || 0), 0);

      const monthlyRecurringRevenue = subscriptions
        ?.reduce((sum, s) => sum + parseFloat(s?.tier_id?.price || 0), 0);

      return {
        data: {
          revenueSplits,
          adRevenue,
          subscriptions,
          totals: {
            subscriptionRevenue: totalSubscriptionRevenue,
            adRevenue: totalAdRevenue,
            monthlyRecurringRevenue,
            totalEarnings: totalSubscriptionRevenue + totalAdRevenue
          }
        },
        error: null
      };
    } catch (error) {
      console.error('Error fetching channel revenue:', error);
      return { data: null, error };
    }
  },

  /**
   * Get creator payouts
   */
  async getCreatorPayouts(channelId) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('User not authenticated');

      const { data, error } = await supabase
        ?.from('creator_payouts')
        ?.select('*')
        ?.eq('channel_id', channelId)
        ?.eq('creator_id', user?.id)
        ?.order('created_at', { ascending: false });

      if (error) throw error;

      return { data, error: null };
    } catch (error) {
      console.error('Error fetching creator payouts:', error);
      return { data: null, error };
    }
  },

  /**
   * Setup Stripe Connect for creator payouts
   */
  async setupStripeConnect() {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('User not authenticated');

      const { data, error } = await supabase?.functions?.invoke('create-stripe-connect-account', {
        body: { userId: user?.id }
      });

      if (error) throw error;

      return { data, error: null };
    } catch (error) {
      console.error('Error setting up Stripe Connect:', error);
      return { data: null, error };
    }
  },

  /**
   * Request payout
   */
  async requestPayout(channelId, amount) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('User not authenticated');

      const { data, error } = await supabase?.functions?.invoke('create-stripe-payout', {
        body: {
          channelId,
          creatorId: user?.id,
          amount
        }
      });

      if (error) throw error;

      return { data, error: null };
    } catch (error) {
      console.error('Error requesting payout:', error);
      return { data: null, error };
    }
  },

  /**
   * Track ad revenue for channel
   */
  async trackAdRevenue(channelId, adId, impressions, clicks, revenueAmount) {
    try {
      const today = new Date()?.toISOString()?.split('T')?.[0];
      const creatorShare = parseFloat((revenueAmount * 0.80)?.toFixed(2));
      const platformShare = parseFloat((revenueAmount * 0.20)?.toFixed(2));

      const { data, error } = await supabase
        ?.from('ad_revenue_distribution')
        ?.upsert({
          channel_id: channelId,
          ad_id: adId,
          date: today,
          impressions_count: impressions,
          clicks_count: clicks,
          revenue_amount: revenueAmount,
          creator_share: creatorShare,
          platform_share: platformShare
        }, {
          onConflict: 'channel_id,ad_id,date'
        })
        ?.select()
        ?.single();

      if (error) throw error;

      return { data, error: null };
    } catch (error) {
      console.error('Error tracking ad revenue:', error);
      return { data: null, error };
    }
  },

  /**
   * Format currency amount
   */
  formatAmount(amount, currency = 'USD') {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency?.toUpperCase()
    })?.format(amount);
  }
};