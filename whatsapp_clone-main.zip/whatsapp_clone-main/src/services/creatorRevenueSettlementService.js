import { supabase } from '../lib/supabase';
import { stripePaymentService } from './stripePaymentService';

/**
 * Creator Revenue Settlement Service - Stripe Connect payout tracking and settlement management
 */

export const creatorRevenueSettlementService = {
  /**
   * Get comprehensive settlement data for creator
   */
  async getSettlementData(creatorId = null) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      const targetCreatorId = creatorId || user?.id;

      // Get all payouts with detailed breakdown
      const { data: payouts, error: payoutsError } = await supabase
        ?.from('creator_payouts')
        ?.select(`
          *,
          channel:channels(id, name)
        `)
        ?.eq('creator_id', targetCreatorId)
        ?.order('created_at', { ascending: false });

      if (payoutsError) throw payoutsError;

      // Calculate settlement metrics
      const pendingSettlements = payouts?.filter(p => p?.status === 'pending') || [];
      const processingSettlements = payouts?.filter(p => p?.status === 'processing') || [];
      const completedSettlements = payouts?.filter(p => p?.status === 'paid') || [];
      const failedSettlements = payouts?.filter(p => p?.status === 'failed') || [];

      const pendingAmount = pendingSettlements?.reduce((sum, p) => sum + (p?.amount || 0), 0);
      const processingAmount = processingSettlements?.reduce((sum, p) => sum + (p?.amount || 0), 0);
      const completedAmount = completedSettlements?.reduce((sum, p) => sum + (p?.amount || 0), 0);

      // Get real-time earnings analytics
      const earningsAnalytics = await this.getEarningsAnalytics(targetCreatorId);

      return {
        data: {
          payouts,
          pendingSettlements,
          processingSettlements,
          completedSettlements,
          failedSettlements,
          metrics: {
            pendingAmount,
            processingAmount,
            completedAmount,
            totalPaidOut: completedAmount,
            totalPending: pendingAmount + processingAmount
          },
          earningsAnalytics: earningsAnalytics?.data
        },
        error: null
      };
    } catch (error) {
      console.error('Error fetching settlement data:', error);
      return { data: null, error };
    }
  },

  /**
   * Get real-time earnings analytics with revenue breakdown
   */
  async getEarningsAnalytics(creatorId) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      const targetCreatorId = creatorId || user?.id;

      // Get channels owned by creator
      const { data: channels, error: channelsError } = await supabase
        ?.from('channels')
        ?.select('id, name')
        ?.eq('created_by', targetCreatorId);

      if (channelsError) throw channelsError;

      if (!channels || channels?.length === 0) {
        return {
          data: {
            daily: [],
            weekly: [],
            monthly: [],
            revenueBySource: {
              subscriptions: 0,
              adRevenue: 0,
              tips: 0
            }
          },
          error: null
        };
      }

      const channelIds = channels?.map(c => c?.id);

      // Get revenue splits for analytics
      const { data: revenueSplits, error: splitsError } = await supabase
        ?.from('channel_revenue_splits')
        ?.select('*')
        ?.in('channel_id', channelIds)
        ?.order('period_start', { ascending: false })
        ?.limit(90); // Last 90 days

      if (splitsError) throw splitsError;

      // Calculate revenue by source
      const subscriptionRevenue = revenueSplits
        ?.filter(s => s?.revenue_type === 'subscription')
        ?.reduce((sum, s) => sum + (s?.creator_earnings || 0), 0) || 0;

      const adRevenue = revenueSplits
        ?.filter(s => s?.revenue_type === 'ad_revenue')
        ?.reduce((sum, s) => sum + (s?.creator_earnings || 0), 0) || 0;

      const tipRevenue = revenueSplits
        ?.filter(s => s?.revenue_type === 'donation')
        ?.reduce((sum, s) => sum + (s?.creator_earnings || 0), 0) || 0;

      // Group by time periods
      const daily = this.groupByPeriod(revenueSplits, 'day', 30);
      const weekly = this.groupByPeriod(revenueSplits, 'week', 12);
      const monthly = this.groupByPeriod(revenueSplits, 'month', 6);

      return {
        data: {
          daily,
          weekly,
          monthly,
          revenueBySource: {
            subscriptions: subscriptionRevenue,
            adRevenue: adRevenue,
            tips: tipRevenue
          },
          totalRevenue: subscriptionRevenue + adRevenue + tipRevenue
        },
        error: null
      };
    } catch (error) {
      console.error('Error fetching earnings analytics:', error);
      return { data: null, error };
    }
  },

  /**
   * Group revenue data by time period
   */
  groupByPeriod(revenueSplits, period, limit) {
    const grouped = {};
    const now = new Date();

    revenueSplits?.forEach(split => {
      const date = new Date(split?.period_start);
      let key;

      if (period === 'day') {
        key = date?.toISOString()?.split('T')?.[0];
      } else if (period === 'week') {
        const weekStart = new Date(date);
        weekStart?.setDate(date?.getDate() - date?.getDay());
        key = weekStart?.toISOString()?.split('T')?.[0];
      } else if (period === 'month') {
        key = `${date?.getFullYear()}-${String(date?.getMonth() + 1)?.padStart(2, '0')}`;
      }

      if (!grouped?.[key]) {
        grouped[key] = {
          period: key,
          subscriptions: 0,
          adRevenue: 0,
          tips: 0,
          total: 0
        };
      }

      const earnings = split?.creator_earnings || 0;
      grouped[key].total += earnings;

      if (split?.revenue_type === 'subscription') {
        grouped[key].subscriptions += earnings;
      } else if (split?.revenue_type === 'ad_revenue') {
        grouped[key].adRevenue += earnings;
      } else if (split?.revenue_type === 'donation') {
        grouped[key].tips += earnings;
      }
    });

    return Object.values(grouped)
      ?.sort((a, b) => b?.period?.localeCompare(a?.period))
      ?.slice(0, limit);
  },

  /**
   * Get tax documentation for a specific year
   */
  async getTaxDocumentation(year, creatorId = null) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      const targetCreatorId = creatorId || user?.id;

      // Get profile for tax information
      const { data: profile, error: profileError } = await supabase
        ?.from('profiles')
        ?.select('*')
        ?.eq('id', targetCreatorId)
        ?.single();

      if (profileError) throw profileError;

      // Get all payouts for the year
      const startDate = `${year}-01-01`;
      const endDate = `${year}-12-31`;

      const { data: payouts, error: payoutsError } = await supabase
        ?.from('creator_payouts')
        ?.select('*')
        ?.eq('creator_id', targetCreatorId)
        ?.eq('status', 'paid')
        ?.gte('paid_at', startDate)
        ?.lte('paid_at', endDate);

      if (payoutsError) throw payoutsError;

      // Calculate totals by revenue type
      const totals = {
        subscriptions: 0,
        adRevenue: 0,
        tips: 0,
        total: 0
      };

      payouts?.forEach(payout => {
        const breakdown = payout?.revenue_breakdown || {};
        totals.subscriptions += breakdown?.subscription_revenue || 0;
        totals.adRevenue += breakdown?.ad_revenue || 0;
        totals.tips += breakdown?.donation_revenue || 0;
        totals.total += payout?.amount || 0;
      });

      // Generate quarterly breakdown
      const quarters = [
        { name: 'Q1', start: `${year}-01-01`, end: `${year}-03-31` },
        { name: 'Q2', start: `${year}-04-01`, end: `${year}-06-30` },
        { name: 'Q3', start: `${year}-07-01`, end: `${year}-09-30` },
        { name: 'Q4', start: `${year}-10-01`, end: `${year}-12-31` }
      ];

      const quarterlyBreakdown = quarters?.map(quarter => {
        const quarterPayouts = payouts?.filter(p => {
          const paidDate = p?.paid_at;
          return paidDate >= quarter?.start && paidDate <= quarter?.end;
        });

        const quarterTotal = quarterPayouts?.reduce((sum, p) => sum + (p?.amount || 0), 0);

        return {
          quarter: quarter?.name,
          amount: quarterTotal,
          payoutCount: quarterPayouts?.length
        };
      });

      return {
        data: {
          year,
          creatorInfo: {
            name: profile?.full_name,
            email: profile?.email,
            stripeConnectId: profile?.stripe_connect_account_id
          },
          totals,
          quarterlyBreakdown,
          payouts,
          generatedAt: new Date()?.toISOString()
        },
        error: null
      };
    } catch (error) {
      console.error('Error generating tax documentation:', error);
      return { data: null, error };
    }
  },

  /**
   * Request a new payout
   */
  async requestPayout(channelId, amount) {
    try {
      const result = await stripePaymentService?.requestPayout(channelId, amount);
      return result;
    } catch (error) {
      console.error('Error requesting payout:', error);
      return { data: null, error };
    }
  },

  /**
   * Setup Stripe Connect account
   */
  async setupStripeConnect() {
    try {
      const result = await stripePaymentService?.setupStripeConnect();
      return result;
    } catch (error) {
      console.error('Error setting up Stripe Connect:', error);
      return { data: null, error };
    }
  },

  /**
   * Get payout processing timeline
   */
  getPayoutTimeline(payout) {
    const created = new Date(payout?.created_at);
    const estimatedArrival = new Date(created);
    estimatedArrival?.setDate(created?.getDate() + 7); // Standard 7-day processing

    return {
      created: created?.toISOString(),
      estimatedArrival: estimatedArrival?.toISOString(),
      actualArrival: payout?.paid_at,
      status: payout?.status,
      daysRemaining: payout?.status === 'pending' || payout?.status === 'processing'
        ? Math.max(0, Math.ceil((estimatedArrival - new Date()) / (1000 * 60 * 60 * 24)))
        : 0
    };
  },

  /**
   * Format currency amount
   */
  formatAmount(amount, currency = 'USD') {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency?.toUpperCase()
    })?.format(amount);
  }
};