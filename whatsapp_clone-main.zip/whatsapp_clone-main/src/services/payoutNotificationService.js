import { supabase } from '../lib/supabase';

/**
 * Payout Notification Service - Real-time notification system for payment events
 */

export const payoutNotificationService = {
  /**
   * Get all notifications for current user
   */
  async getNotifications(limit = 50) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data, error } = await supabase
        ?.from('payout_notifications')
        ?.select('*')
        ?.eq('user_id', user?.id)
        ?.order('created_at', { ascending: false })
        ?.limit(limit);

      if (error) throw error;

      return { data, error: null };
    } catch (error) {
      console.error('Error fetching notifications:', error);
      return { data: null, error };
    }
  },

  /**
   * Get unread notification count
   */
  async getUnreadCount() {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      const { count, error } = await supabase
        ?.from('payout_notifications')
        ?.select('*', { count: 'exact', head: true })
        ?.eq('user_id', user?.id)
        ?.eq('read', false);

      if (error) throw error;

      return { data: count || 0, error: null };
    } catch (error) {
      console.error('Error fetching unread count:', error);
      return { data: 0, error };
    }
  },

  /**
   * Mark notification as read
   */
  async markAsRead(notificationId) {
    try {
      const { error } = await supabase
        ?.from('payout_notifications')
        ?.update({
          read: true,
          read_at: new Date()?.toISOString()
        })
        ?.eq('id', notificationId);

      if (error) throw error;

      return { data: true, error: null };
    } catch (error) {
      console.error('Error marking notification as read:', error);
      return { data: false, error };
    }
  },

  /**
   * Mark all notifications as read
   */
  async markAllAsRead() {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      const { error } = await supabase
        ?.from('payout_notifications')
        ?.update({
          read: true,
          read_at: new Date()?.toISOString()
        })
        ?.eq('user_id', user?.id)
        ?.eq('read', false);

      if (error) throw error;

      return { data: true, error: null };
    } catch (error) {
      console.error('Error marking all notifications as read:', error);
      return { data: false, error };
    }
  },

  /**
   * Subscribe to real-time notification updates
   */
  subscribeToNotifications(userId, callback) {
    const channel = supabase
      ?.channel('payout_notifications')
      ?.on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'payout_notifications',
          filter: `user_id=eq.${userId}`
        },
        (payload) => {
          console.log('New notification received:', payload);
          callback(payload?.new);
        }
      )
      ?.subscribe();

    return channel;
  },

  /**
   * Unsubscribe from notifications
   */
  unsubscribeFromNotifications(channel) {
    if (channel) {
      supabase?.removeChannel(channel);
    }
  },

  /**
   * Get notification icon based on type
   */
  getNotificationIcon(type) {
    const icons = {
      payout_created: 'Clock',
      payout_processing: 'TrendingUp',
      payout_paid: 'CheckCircle',
      payout_failed: 'XCircle',
      payout_updated: 'Bell'
    };
    return icons?.[type] || 'Bell';
  },

  /**
   * Get notification color based on type
   */
  getNotificationColor(type) {
    const colors = {
      payout_created: 'blue',
      payout_processing: 'yellow',
      payout_paid: 'green',
      payout_failed: 'red',
      payout_updated: 'gray'
    };
    return colors?.[type] || 'gray';
  }
};