import claude from '../lib/claude';
import { supabase } from '../lib/supabase';

/**
 * Content Moderation Service - AI-powered content flagging using Anthropic Claude
 */

export const contentModerationService = {
  /**
   * Analyze content for violations using Claude AI
   */
  async analyzeContent(content, contentType = 'message', contentId = null, authorId = null) {
    try {
      const response = await claude?.messages?.create({
        model: 'claude-sonnet-4-5-20250929',
        max_tokens: 1024,
        messages: [
          {
            role: 'user',
            content: `You are a content moderation AI. Analyze the following ${contentType} for policy violations.

Content: "${content}"

Check for:
1. Spam (repetitive, promotional, unsolicited)
2. Harassment (bullying, threats, hate speech)
3. ToS violations (illegal content, explicit material, violence)

Respond with a JSON object in this exact format:
{
  "isViolation": true or false,
  "violationType": "spam" or "harassment" or "tos_violation" or "none",
  "confidence": 0.0 to 1.0,
  "severity": "low" or "medium" or "high" or "critical",
  "reasoning": "Brief explanation of why this content was flagged",
  "recommendedAction": "approve" or "review" or "remove" or "ban_user"
}`
          }
        ]
      });

      const responseText = response?.content?.[0]?.text;
      if (!responseText) {
        throw new Error('No response from Claude API');
      }

      // Parse JSON from response
      const jsonMatch = responseText?.match(/\{[\s\S]*\}/);
      if (!jsonMatch) {
        throw new Error('Invalid JSON response from Claude');
      }

      const analysis = JSON.parse(jsonMatch?.[0]);

      // If violation detected, create flagged content record
      if (analysis?.isViolation && contentId && authorId) {
        await this.createFlaggedContent({
          contentId,
          contentType,
          content,
          authorId,
          violationType: analysis?.violationType,
          confidence: analysis?.confidence,
          severity: analysis?.severity,
          aiReasoning: analysis?.reasoning,
          recommendedAction: analysis?.recommendedAction
        });
      }

      return { data: analysis, error: null };
    } catch (error) {
      console.error('Error analyzing content with Claude:', error);
      return { data: null, error };
    }
  },

  /**
   * Create flagged content record in database
   */
  async createFlaggedContent(flagData) {
    try {
      const { data, error } = await supabase
        ?.from('flagged_content')
        ?.insert([{
          content_id: flagData?.contentId,
          content_type: flagData?.contentType,
          content: flagData?.content,
          author_id: flagData?.authorId,
          violation_type: flagData?.violationType,
          ai_confidence: flagData?.confidence,
          severity: flagData?.severity,
          ai_reasoning: flagData?.aiReasoning,
          recommended_action: flagData?.recommendedAction,
          status: 'pending',
          flagged_at: new Date()?.toISOString()
        }])
        ?.select()
        ?.single();

      if (error) throw error;
      return { data, error: null };
    } catch (error) {
      console.error('Error creating flagged content:', error);
      return { data: null, error };
    }
  },

  /**
   * Get flagged content for admin review
   */
  async getFlaggedContent(filters = {}) {
    try {
      let query = supabase
        ?.from('flagged_content')
        ?.select(`
          *,
          author:profiles!flagged_content_author_id_fkey(id, full_name, email, phone_number),
          reviewed_by_profile:profiles!flagged_content_reviewed_by_fkey(id, full_name)
        `);

      // Apply filters
      if (filters?.status) {
        query = query?.eq('status', filters?.status);
      }
      if (filters?.violationType) {
        query = query?.eq('violation_type', filters?.violationType);
      }
      if (filters?.severity) {
        query = query?.eq('severity', filters?.severity);
      }
      if (filters?.contentType) {
        query = query?.eq('content_type', filters?.contentType);
      }

      // Pagination
      const page = filters?.page || 1;
      const limit = filters?.limit || 20;
      const from = (page - 1) * limit;
      const to = from + limit - 1;

      query = query
        ?.order('flagged_at', { ascending: false })
        ?.range(from, to);

      const { data, error, count } = await query;

      if (error) throw error;

      return {
        data,
        totalPages: Math.ceil(count / limit),
        totalCount: count,
        error: null
      };
    } catch (error) {
      console.error('Error fetching flagged content:', error);
      return { data: null, error };
    }
  },

  /**
   * Review flagged content (admin action)
   */
  async reviewFlaggedContent(flagId, action, adminNotes = '') {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data, error } = await supabase
        ?.from('flagged_content')
        ?.update({
          status: action === 'approve' ? 'approved' : action === 'remove' ? 'removed' : 'reviewed',
          reviewed_by: user?.id,
          reviewed_at: new Date()?.toISOString(),
          admin_notes: adminNotes,
          action_taken: action
        })
        ?.eq('id', flagId)
        ?.select()
        ?.single();

      if (error) throw error;

      // If action is remove or ban, delete the actual content
      if (action === 'remove' || action === 'ban_user') {
        await this.executeContentRemoval(data);
      }

      return { data, error: null };
    } catch (error) {
      console.error('Error reviewing flagged content:', error);
      return { data: null, error };
    }
  },

  /**
   * Execute content removal
   */
  async executeContentRemoval(flaggedContent) {
    try {
      const contentType = flaggedContent?.content_type;
      const contentId = flaggedContent?.content_id;

      if (contentType === 'message') {
        await supabase
          ?.from('chat_messages')
          ?.delete()
          ?.eq('id', contentId);
      } else if (contentType === 'channel_post') {
        await supabase
          ?.from('channel_messages')
          ?.delete()
          ?.eq('id', contentId);
      } else if (contentType === 'status') {
        await supabase
          ?.from('statuses')
          ?.delete()
          ?.eq('id', contentId);
      }

      return { success: true, error: null };
    } catch (error) {
      console.error('Error executing content removal:', error);
      return { success: false, error };
    }
  },

  /**
   * Get moderation statistics
   */
  async getModerationStats() {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      // Total flagged content
      const { count: totalFlagged } = await supabase
        ?.from('flagged_content')
        ?.select('*', { count: 'exact', head: true });

      // Pending review
      const { count: pendingReview } = await supabase
        ?.from('flagged_content')
        ?.select('*', { count: 'exact', head: true })
        ?.eq('status', 'pending');

      // By violation type
      const { data: byViolationType } = await supabase
        ?.from('flagged_content')
        ?.select('violation_type');

      const violationCounts = {};
      byViolationType?.forEach(item => {
        const type = item?.violation_type || 'unknown';
        violationCounts[type] = (violationCounts?.[type] || 0) + 1;
      });

      // By severity
      const { data: bySeverity } = await supabase
        ?.from('flagged_content')
        ?.select('severity');

      const severityCounts = {};
      bySeverity?.forEach(item => {
        const severity = item?.severity || 'unknown';
        severityCounts[severity] = (severityCounts?.[severity] || 0) + 1;
      });

      // Recent activity (last 7 days)
      const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)?.toISOString();
      const { count: recentFlags } = await supabase
        ?.from('flagged_content')
        ?.select('*', { count: 'exact', head: true })
        ?.gte('flagged_at', sevenDaysAgo);

      return {
        data: {
          totalFlagged: totalFlagged || 0,
          pendingReview: pendingReview || 0,
          byViolationType: violationCounts,
          bySeverity: severityCounts,
          recentFlags: recentFlags || 0
        },
        error: null
      };
    } catch (error) {
      console.error('Error fetching moderation stats:', error);
      return { data: null, error };
    }
  },

  /**
   * Bulk review flagged content
   */
  async bulkReview(flagIds, action, adminNotes = '') {
    try {
      const results = await Promise.all(
        flagIds?.map(id => this.reviewFlaggedContent(id, action, adminNotes))
      );

      const successful = results?.filter(r => !r?.error)?.length;
      const failed = results?.filter(r => r?.error)?.length;

      return {
        data: { successful, failed, total: flagIds?.length },
        error: null
      };
    } catch (error) {
      console.error('Error bulk reviewing content:', error);
      return { data: null, error };
    }
  }
};
