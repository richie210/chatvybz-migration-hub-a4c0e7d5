import { supabase } from '../lib/supabase';
import phoneValidationService from './phoneValidationService';
import twilioVerifyService from './twilioVerifyService';
import phoneAuthService from './phoneAuthService';

/**
 * Registration Service
 * Handles complete unified registration flow for email/phone with profile setup
 * Uses libphonenumber-js for E.164 validation and Twilio Verify for OTP
 */
const registrationService = {
  /**
   * Validate and format phone number using libphonenumber-js
   */
  validatePhoneNumber(phoneNumber, countryCode = null) {
    try {
      // If phoneNumber is already in E.164 format
      const fullNumber = phoneNumber?.startsWith('+') ? phoneNumber : `${countryCode}${phoneNumber}`;
      
      return phoneValidationService?.validateAndFormat(fullNumber);
    } catch (error) {
      console.error('Phone validation error:', error);
      return {
        isValid: false,
        error: error?.message || 'Invalid phone number'
      };
    }
  },

  /**
   * Upload profile picture to Supabase Storage
   * Uses profile-photos bucket (private)
   */
  async uploadProfilePicture(file, userId) {
    try {
      if (!file) return null;
      
      // Convert base64 to File if needed
      let uploadFile = file;
      if (typeof file === 'string' && file?.startsWith('data:')) {
        const response = await fetch(file);
        const blob = await response?.blob();
        const fileName = `profile-${userId}-${Date?.now()}.jpg`;
        uploadFile = new File([blob], fileName, { type: 'image/jpeg' });
      }
      
      // Upload to Supabase Storage
      const fileName = `${userId}/${Date?.now()}-${uploadFile?.name}`;
      const { data, error } = await supabase?.storage
        ?.from('profile-photos')
        ?.upload(fileName, uploadFile);
      
      if (error) {
        console.error('Profile picture upload error:', error);
        throw error;
      }
      
      // Get signed URL for private bucket
      const { data: urlData, error: urlError } = await supabase?.storage
        ?.from('profile-photos')
        ?.createSignedUrl(data?.path, 31536000); // 1 year expiry
      
      if (urlError) {
        console.error('Error getting signed URL:', urlError);
        throw urlError;
      }
      
      return {
        path: data?.path,
        url: urlData?.signedUrl
      };
    } catch (error) {
      console.error('Upload profile picture error:', error);
      throw error;
    }
  },

  /**
   * Send verification code - handles both email and phone
   * Uses Twilio Verify for phone numbers
   */
  async sendVerificationCode(registrationType, identifier, countryCode = null) {
    try {
      if (registrationType === 'phone') {
        // Validate phone number first
        const validation = this.validatePhoneNumber(identifier, countryCode);
        if (!validation?.isValid) {
          throw new Error(validation?.error);
        }

        // Use Twilio Verify service with automatic fallback
        const result = await twilioVerifyService?.sendWithFallback(validation?.e164);
        
        return {
          success: true,
          status: result?.status,
          channel: result?.channel,
          fallbackUsed: result?.fallbackUsed,
          e164Number: validation?.e164,
          message: result?.message
        };
      } else {
        // Send OTP via email using Supabase
        const { error } = await supabase?.auth?.signInWithOtp({
          email: identifier,
          options: {
            shouldCreateUser: true
          }
        });
        
        if (error) throw error;
        
        return {
          success: true,
          message: 'Verification code sent to email'
        };
      }
    } catch (error) {
      console.error('Send verification code error:', error);
      throw error;
    }
  },

  /**
   * Verify OTP code - handles both email and phone
   * Uses Twilio Verify for phone verification
   */
  async verifyCode(registrationType, identifier, code, countryCode = null) {
    try {
      if (registrationType === 'phone') {
        // Validate phone number
        const validation = this.validatePhoneNumber(identifier, countryCode);
        if (!validation?.isValid) {
          throw new Error(validation?.error);
        }

        // Verify via Twilio Verify
        const result = await twilioVerifyService?.verifyCode(validation?.e164, code);
        
        if (!result?.success) {
          throw new Error('Invalid or expired verification code');
        }
        
        return {
          success: true,
          message: 'Phone number verified successfully'
        };
      } else {
        // Verify email OTP
        const { data, error } = await supabase?.auth?.verifyOtp({
          email: identifier,
          token: code,
          type: 'email'
        });
        
        if (error) {
          throw new Error(error?.message || 'Invalid OTP code');
        }
        
        return {
          success: true,
          user: data?.user
        };
      }
    } catch (error) {
      console.error('Verify code error:', error);
      throw error;
    }
  },

  /**
   * Complete registration - creates user account and profile
   */
  async completeRegistration(formData) {
    try {
      const {
        registrationType,
        phoneNumber,
        countryCode,
        email,
        fullName,
        profilePicture,
        statusMessage
      } = formData;

      let authResult;
      let userId;

      // Step 1: Create authentication account
      if (registrationType === 'phone') {
        // Phone registration
        const validation = this?.validatePhoneNumber(phoneNumber, countryCode);
        if (!validation?.isValid) {
          throw new Error(validation?.error);
        }

        // Sign up with phone number
        authResult = await phoneAuthService?.signUpWithPhone(
          phoneNumber,
          countryCode,
          fullName,
          {
            status_message: statusMessage || 'Hey there! I am using ChatVybz'
          }
        );

        if (!authResult?.success) {
          throw new Error(authResult?.error || 'Failed to create account');
        }

        userId = authResult?.user?.id;
      } else {
        // Email registration
        const { data, error } = await supabase?.auth?.signUp({
          email,
          password: `temp_${Date?.now()}`, // Temporary password, will be OTP-based login
          options: {
            data: {
              full_name: fullName,
              status_message: statusMessage || 'Hey there! I am using ChatVybz'
            }
          }
        });

        if (error) throw error;
        userId = data?.user?.id;
      }

      // Step 2: Upload profile picture if provided
      let avatarUrl = null;
      if (profilePicture && userId) {
        const uploadResult = await this?.uploadProfilePicture(profilePicture, userId);
        avatarUrl = uploadResult?.url;
      }

      // Step 3: Update profile with avatar URL
      if (avatarUrl && userId) {
        const { error: updateError } = await supabase
          ?.from('profiles')
          ?.update({
            avatar_url: avatarUrl,
            bio: statusMessage || 'Hey there! I am using ChatVybz',
            profile_setup_completed: true
          })
          ?.eq('id', userId);

        if (updateError) {
          console.error('Error updating profile:', updateError);
          // Don't fail registration, just log the error
        }
      }

      return {
        success: true,
        userId,
        message: 'Registration completed successfully'
      };
    } catch (error) {
      console.error('Complete registration error:', error);
      throw error;
    }
  },

  /**
   * Check if email or phone already exists
   */
  async checkExistingUser(registrationType, identifier) {
    try {
      if (registrationType === 'phone') {
        const { data, error } = await supabase
          ?.from('profiles')
          ?.select('id')
          ?.eq('phone', identifier)
          ?.single();
        
        return { exists: !!data, error };
      } else {
        const { data, error } = await supabase
          ?.from('profiles')
          ?.select('id')
          ?.eq('email', identifier)
          ?.single();
        
        return { exists: !!data, error };
      }
    } catch (error) {
      console.error('Check existing user error:', error);
      return { exists: false, error };
    }
  }
};

export default registrationService;