import { supabase } from '../lib/supabase';

/**
 * Pins a conversation to the top of the chat list.
 * @param {string} userId - The user ID.
 * @param {string} conversationId - The conversation ID to pin.
 * @param {string} conversationType - Type of conversation (direct, group).
 * @returns {Promise<Object>} Pin result.
 */
export async function pinConversation(userId, conversationId, conversationType = 'direct') {
  try {
    // Get current max pin order
    const { data: maxOrder } = await supabase?.from('pinned_conversations')?.select('pin_order')?.eq('user_id', userId)?.order('pin_order', { ascending: false })?.limit(1)?.single();

    const newOrder = maxOrder ? maxOrder?.pin_order + 1 : 0;

    const { data, error } = await supabase?.from('pinned_conversations')?.insert({
        user_id: userId,
        conversation_id: conversationId,
        conversation_type: conversationType,
        pin_order: newOrder
      })?.select()?.single();

    if (error) throw error;

    return { success: true, data };
  } catch (error) {
    // Check if already pinned
    if (error?.code === '23505') {
      throw new Error('Conversation is already pinned');
    }
    console.error('Error pinning conversation:', error);
    throw error;
  }
}

/**
 * Unpins a conversation.
 * @param {string} userId - The user ID.
 * @param {string} conversationId - The conversation ID to unpin.
 * @returns {Promise<Object>} Unpin result.
 */
export async function unpinConversation(userId, conversationId) {
  try {
    const { error } = await supabase?.from('pinned_conversations')?.delete()?.eq('user_id', userId)?.eq('conversation_id', conversationId);

    if (error) throw error;

    // Reorder remaining pins
    await reorderPins(userId);

    return { success: true };
  } catch (error) {
    console.error('Error unpinning conversation:', error);
    throw error;
  }
}

/**
 * Gets all pinned conversations for a user.
 * @param {string} userId - The user ID.
 * @returns {Promise<Array>} List of pinned conversations.
 */
export async function getPinnedConversations(userId) {
  try {
    const { data, error } = await supabase?.from('pinned_conversations')?.select('*')?.eq('user_id', userId)?.order('pin_order', { ascending: true });

    if (error) throw error;

    return data || [];
  } catch (error) {
    console.error('Error getting pinned conversations:', error);
    return [];
  }
}

/**
 * Checks if a conversation is pinned.
 * @param {string} userId - The user ID.
 * @param {string} conversationId - The conversation ID.
 * @returns {Promise<boolean>} Whether the conversation is pinned.
 */
export async function isConversationPinned(userId, conversationId) {
  try {
    const { data, error } = await supabase?.from('pinned_conversations')?.select('id')?.eq('user_id', userId)?.eq('conversation_id', conversationId)?.single();

    return !!data && !error;
  } catch (error) {
    return false;
  }
}

/**
 * Gets the count of pinned conversations.
 * @param {string} userId - The user ID.
 * @returns {Promise<number>} Count of pinned conversations.
 */
export async function getPinnedCount(userId) {
  try {
    const { count, error } = await supabase?.from('pinned_conversations')?.select('*', { count: 'exact', head: true })?.eq('user_id', userId);

    if (error) throw error;

    return count || 0;
  } catch (error) {
    console.error('Error getting pinned count:', error);
    return 0;
  }
}

/**
 * Reorders pins after unpinning.
 * @param {string} userId - The user ID.
 */
async function reorderPins(userId) {
  try {
    const { data: pins } = await supabase?.from('pinned_conversations')?.select('*')?.eq('user_id', userId)?.order('pin_order', { ascending: true });

    if (!pins || pins?.length === 0) return;

    // Update pin orders sequentially
    for (let i = 0; i < pins?.length; i++) {
      await supabase?.from('pinned_conversations')?.update({ pin_order: i })?.eq('id', pins?.[i]?.id);
    }
  } catch (error) {
    console.error('Error reordering pins:', error);
  }
}

/**
 * Toggles pin status for a conversation.
 * @param {string} userId - The user ID.
 * @param {string} conversationId - The conversation ID.
 * @param {string} conversationType - Type of conversation.
 * @returns {Promise<Object>} Toggle result with new pin status.
 */
export async function togglePin(userId, conversationId, conversationType = 'direct') {
  try {
    const isPinned = await isConversationPinned(userId, conversationId);

    if (isPinned) {
      await unpinConversation(userId, conversationId);
      return { success: true, pinned: false };
    } else {
      await pinConversation(userId, conversationId, conversationType);
      return { success: true, pinned: true };
    }
  } catch (error) {
    console.error('Error toggling pin:', error);
    throw error;
  }
}

export const conversationPinService = {
  pinConversation,
  unpinConversation,
  getPinnedConversations,
  isConversationPinned,
  getPinnedCount,
  togglePin
};