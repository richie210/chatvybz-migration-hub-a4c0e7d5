import { supabase } from '../lib/supabase';
import { autoDeleteService } from './autoDeleteService';

/**
 * Disappearing Messages Service
 * Manages message expiration, auto-deletion, and user notifications
 */

export const disappearingMessagesService = {
  /**
   * Enable disappearing messages for a conversation
   * @param {string} conversationId - Conversation ID
   * @param {string} durationType - Duration type (24h, 7d, 30d, 90d, custom)
   * @param {number} customHours - Custom duration in hours (if durationType is 'custom')
   * @returns {Promise<Object>} Settings result
   */
  async enableDisappearingMessages(conversationId, durationType = '24h', customHours = null) {
    try {
      const settings = {
        isEnabled: true,
        durationType: durationType,
        customDurationHours: customHours,
        applyToMedia: true,
        applyToDocuments: true,
        applyToText: true,
        isEncrypted: true
      };

      const result = await autoDeleteService?.upsertSettings(conversationId, settings);
      return result;
    } catch (error) {
      console.error('Enable disappearing messages error:', error);
      throw error;
    }
  },

  /**
   * Disable disappearing messages for a conversation
   * @param {string} conversationId - Conversation ID
   * @returns {Promise<void>}
   */
  async disableDisappearingMessages(conversationId) {
    try {
      await autoDeleteService?.deleteSettings(conversationId);
    } catch (error) {
      console.error('Disable disappearing messages error:', error);
      throw error;
    }
  },

  /**
   * Get messages expiring soon (within next hour)
   * @param {string} conversationId - Conversation ID
   * @returns {Promise<Array>} Messages expiring soon
   */
  async getMessagesExpiringSoon(conversationId) {
    try {
      const oneHourFromNow = new Date(Date.now() + 60 * 60 * 1000);

      const { data, error } = await supabase
        ?.from('chat_messages')
        ?.select('id, message, expires_at, sender_id, recipient_id')
        ?.or(`and(sender_id.eq.${conversationId},auto_delete_enabled.eq.true),and(recipient_id.eq.${conversationId},auto_delete_enabled.eq.true)`)
        ?.not('expires_at', 'is', null)
        ?.lte('expires_at', oneHourFromNow?.toISOString())
        ?.gte('expires_at', new Date()?.toISOString())
        ?.order('expires_at', { ascending: true });

      if (error) throw error;

      return data?.map(msg => ({
        id: msg?.id,
        message: msg?.message,
        expiresAt: msg?.expires_at,
        senderId: msg?.sender_id,
        recipientId: msg?.recipient_id,
        timeRemaining: this.calculateTimeRemaining(msg?.expires_at)
      })) || [];
    } catch (error) {
      console.error('Get messages expiring soon error:', error);
      return [];
    }
  },

  /**
   * Delete expired messages manually
   * @returns {Promise<Object>} Deletion result
   */
  async deleteExpiredMessages() {
    try {
      const { data, error } = await supabase?.rpc('delete_expired_messages');

      if (error) throw error;

      return {
        success: true,
        deletedCount: data || 0
      };
    } catch (error) {
      console.error('Delete expired messages error:', error);
      throw error;
    }
  },

  /**
   * Get expiration info for a message
   * @param {string} messageId - Message ID
   * @returns {Promise<Object>} Expiration info
   */
  async getMessageExpirationInfo(messageId) {
    try {
      const { data, error } = await supabase
        ?.from('chat_messages')
        ?.select('id, expires_at, auto_delete_enabled, created_at')
        ?.eq('id', messageId)
        ?.single();

      if (error) throw error;

      if (!data?.auto_delete_enabled || !data?.expires_at) {
        return {
          isExpiring: false,
          expiresAt: null,
          timeRemaining: null
        };
      }

      return {
        isExpiring: true,
        expiresAt: data?.expires_at,
        timeRemaining: this.calculateTimeRemaining(data?.expires_at),
        createdAt: data?.created_at
      };
    } catch (error) {
      console.error('Get message expiration info error:', error);
      return {
        isExpiring: false,
        expiresAt: null,
        timeRemaining: null
      };
    }
  },

  /**
   * Calculate time remaining until expiration
   * @param {string} expiresAt - ISO timestamp
   * @returns {Object} Time remaining
   */
  calculateTimeRemaining(expiresAt) {
    if (!expiresAt) return null;

    const now = new Date();
    const expires = new Date(expiresAt);
    const diffMs = expires - now;

    if (diffMs <= 0) {
      return {
        expired: true,
        totalMinutes: 0,
        formatted: 'Expired'
      };
    }

    const totalMinutes = Math.floor(diffMs / 60000);
    const hours = Math.floor(totalMinutes / 60);
    const minutes = totalMinutes % 60;
    const days = Math.floor(hours / 24);

    let formatted = '';
    if (days > 0) {
      formatted = `${days}d ${hours % 24}h`;
    } else if (hours > 0) {
      formatted = `${hours}h ${minutes}m`;
    } else {
      formatted = `${minutes}m`;
    }

    return {
      expired: false,
      totalMinutes,
      hours,
      minutes,
      days,
      formatted
    };
  },

  /**
   * Subscribe to message expiration events
   * @param {string} conversationId - Conversation ID
   * @param {Function} onExpiring - Callback when message is about to expire
   * @returns {Function} Cleanup function
   */
  subscribeToExpirations(conversationId, onExpiring) {
    // Check for expiring messages every minute
    const intervalId = setInterval(async () => {
      try {
        const expiringMessages = await this.getMessagesExpiringSoon(conversationId);
        
        if (expiringMessages?.length > 0 && onExpiring) {
          onExpiring(expiringMessages);
        }
      } catch (error) {
        console.error('Expiration check error:', error);
      }
    }, 60000); // Check every minute

    return () => {
      clearInterval(intervalId);
    };
  },

  /**
   * Get disappearing messages statistics for a conversation
   * @param {string} conversationId - Conversation ID
   * @returns {Promise<Object>} Statistics
   */
  async getDisappearingMessagesStats(conversationId) {
    try {
      const { data: { user } } = await supabase?.auth?.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data, error } = await supabase
        ?.from('chat_messages')
        ?.select('id, expires_at, auto_delete_enabled')
        ?.or(`and(sender_id.eq.${user?.id},recipient_id.eq.${conversationId}),and(sender_id.eq.${conversationId},recipient_id.eq.${user?.id})`)
        ?.eq('auto_delete_enabled', true);

      if (error) throw error;

      const now = new Date();
      const active = data?.filter(m => m?.expires_at && new Date(m?.expires_at) > now)?.length || 0;
      const expired = data?.filter(m => m?.expires_at && new Date(m?.expires_at) <= now)?.length || 0;

      return {
        total: data?.length || 0,
        active,
        expired
      };
    } catch (error) {
      console.error('Get disappearing messages stats error:', error);
      return {
        total: 0,
        active: 0,
        expired: 0
      };
    }
  },

  /**
   * Format expiration time for display
   * @param {string} expiresAt - ISO timestamp
   * @returns {string} Formatted expiration
   */
  formatExpirationTime(expiresAt) {
    if (!expiresAt) return 'Never';

    const timeRemaining = this.calculateTimeRemaining(expiresAt);
    
    if (timeRemaining?.expired) {
      return 'Expired';
    }

    return `Expires in ${timeRemaining?.formatted}`;
  }
};