import React, { createContext, useContext, useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import supabasePhoneAuthService from '../services/supabasePhoneAuthService';
import fallbackAuthService from '../services/fallbackAuthService';

const AuthContext = createContext({})

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error('useAuth must be used within AuthProvider')
  }
  return context
}

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null)
  const [userProfile, setUserProfile] = useState(null)
  const [loading, setLoading] = useState(true)
  const [profileLoading, setProfileLoading] = useState(false)

  // Isolated async operations - never called from auth callbacks
  const profileOperations = {
    async load(userId) {
      if (!userId) return
      setProfileLoading(true)
      try {
        const { data, error } = await supabase?.from('user_profiles')?.select('*')?.eq('id', userId)?.single()
        if (!error) setUserProfile(data)
      } catch (error) {
        console.error('Profile load error:', error)
      } finally {
        setProfileLoading(false)
      }
    },

    clear() {
      setUserProfile(null)
      setProfileLoading(false)
    }
  }

  // Auth state handlers - PROTECTED from async modification
  const authStateHandlers = {
    // This handler MUST remain synchronous - Supabase requirement
    onChange: (event, session) => {
      setUser(session?.user ?? null)
      setLoading(false)
      
      if (session?.user) {
        profileOperations?.load(session?.user?.id) // Fire-and-forget
      } else {
        profileOperations?.clear()
      }
    }
  }

  useEffect(() => {
    // Initial session check
    supabase?.auth?.getSession()?.then(({ data: { session } }) => {
      authStateHandlers?.onChange(null, session)
    })

    // CRITICAL: This must remain synchronous
    const { data: { subscription } } = supabase?.auth?.onAuthStateChange(
      authStateHandlers?.onChange
    )

    return () => subscription?.unsubscribe()
  }, [])

  // Auth methods
  const signIn = async (email, password) => {
    try {
      const { data, error } = await supabase?.auth?.signInWithPassword({ email, password })
      return { data, error }
    } catch (error) {
      return { error: { message: 'Network error. Please try again.' } }
    }
  }

  // Phone authentication methods
  const sendPhoneOTP = async (phoneNumber, countryCode, email = null) => {
    console.log('🔍 AuthContext sendPhoneOTP called');
    console.log('🔍 fallbackAuthService:', fallbackAuthService);
    
    try {
      // Use fallback authentication service for automatic SMS → Email → Voice fallback
      if (!fallbackAuthService) {
        throw new Error('Fallback authentication service is not available');
      }
      
      if (typeof fallbackAuthService?.sendOTPWithFallback !== 'function') {
        throw new Error('sendOTPWithFallback method is not available');
      }
      
      // fallbackAuthService returns {data, error} format
      const result = await fallbackAuthService?.sendOTPWithFallback(phoneNumber, countryCode, email);
      
      // If there's an error in the result, return it directly
      if (result?.error) {
        return { data: null, error: result?.error };
      }
      
      // Return the data directly
      return { data: result?.data, error: null };
    } catch (error) {
      console.error('❌ AuthContext sendPhoneOTP error:', error);
      return { data: null, error: { message: error?.message || 'Failed to send OTP' } };
    }
  };

  const verifyPhoneOTP = async (phoneNumber, countryCode, otpCode) => {
    try {
      // Use fallback service for verification (works with any delivery method)
      const result = await fallbackAuthService?.verifyOTP(phoneNumber, countryCode, otpCode);
      
      if (result?.error) {
        return { data: null, error: result?.error };
      }
      
      return { data: result?.data, error: null };
    } catch (error) {
      return { data: null, error: { message: error?.message } };
    }
  };

  const signInWithPhone = async (phoneNumber, countryCode, otpCode) => {
    try {
      // First verify OTP
      const verifyResult = await supabasePhoneAuthService?.verifyPhoneOTP(phoneNumber, countryCode, otpCode);
      if (!verifyResult?.success) {
        throw new Error(verifyResult.message);
      }

      // Then sign in
      const signInResult = await supabasePhoneAuthService?.signInWithPhone(phoneNumber, countryCode);
      return { data: signInResult, error: null };
    } catch (error) {
      return { data: null, error: { message: error?.message } };
    }
  };

  const signUpWithPhone = async (phoneNumber, countryCode, fullName, otpCode) => {
    try {
      // First verify OTP
      const verifyResult = await supabasePhoneAuthService?.verifyPhoneOTP(phoneNumber, countryCode, otpCode);
      if (!verifyResult?.success) {
        throw new Error(verifyResult.message);
      }

      // Then sign up
      const signUpResult = await supabasePhoneAuthService?.signUpWithPhone(phoneNumber, countryCode, fullName);
      return { data: signUpResult, error: null };
    } catch (error) {
      return { data: null, error: { message: error?.message } };
    }
  };

  const signOut = async () => {
    try {
      const { error } = await supabase?.auth?.signOut()
      if (!error) {
        setUser(null)
        profileOperations?.clear()
      }
      return { error }
    } catch (error) {
      return { error: { message: 'Network error. Please try again.' } }
    }
  }

  const updateProfile = async (updates) => {
    if (!user) return { error: { message: 'No user logged in' } }
    
    try {
      const { data, error } = await supabase?.from('profiles')?.update(updates)?.eq('id', user?.id)?.select()?.single()
      if (!error) setUserProfile(data)
      return { data, error }
    } catch (error) {
      return { error: { message: 'Network error. Please try again.' } }
    }
  }

  const value = {
    user,
    userProfile,
    loading,
    profileLoading,
    signIn,
    signOut,
    updateProfile,
    sendPhoneOTP,
    verifyPhoneOTP,
    signInWithPhone,
    signUpWithPhone,
    isAuthenticated: !!user
  }

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
}