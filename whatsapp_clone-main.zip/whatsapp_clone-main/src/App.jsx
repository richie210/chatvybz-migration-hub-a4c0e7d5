import React from 'react';
import Routes from './Routes';
import { StripeProvider } from './contexts/StripeContext';

function App() {
  return (
    <StripeProvider>
      <Routes />
    </StripeProvider>
  );
}

export default App;