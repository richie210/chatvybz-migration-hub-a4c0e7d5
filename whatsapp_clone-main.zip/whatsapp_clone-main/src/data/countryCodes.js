/**
 * Complete Global Country Codes Database (240+ countries)
 * E.164 Format with flags, regions, and dial codes
 * 
 * Usage: For phone number registration and validation
 * Priority: User location > Major countries > Alphabetical
 */

export const countryCodes = [
  // Priority: Major International Countries (Top 20 by population/usage)
  { name: "United States", code: "US", dialCode: "+1", flag: "🇺🇸", region: "North America", priority: 1 },
  { name: "India", code: "IN", dialCode: "+91", flag: "🇮🇳", region: "Asia", priority: 2 },
  { name: "China", code: "CN", dialCode: "+86", flag: "🇨🇳", region: "Asia", priority: 3 },
  { name: "United Kingdom", code: "GB", dialCode: "+44", flag: "🇬🇧", region: "Europe", priority: 4 },
  { name: "Germany", code: "DE", dialCode: "+49", flag: "🇩🇪", region: "Europe", priority: 5 },
  { name: "France", code: "FR", dialCode: "+33", flag: "🇫🇷", region: "Europe", priority: 6 },
  { name: "Canada", code: "CA", dialCode: "+1", flag: "🇨🇦", region: "North America", priority: 7 },
  { name: "Australia", code: "AU", dialCode: "+61", flag: "🇦🇺", region: "Oceania", priority: 8 },
  { name: "Brazil", code: "BR", dialCode: "+55", flag: "🇧🇷", region: "South America", priority: 9 },
  { name: "Japan", code: "JP", dialCode: "+81", flag: "🇯🇵", region: "Asia", priority: 10 },
  { name: "Mexico", code: "MX", dialCode: "+52", flag: "🇲🇽", region: "North America", priority: 11 },
  { name: "South Korea", code: "KR", dialCode: "+82", flag: "🇰🇷", region: "Asia", priority: 12 },
  { name: "Spain", code: "ES", dialCode: "+34", flag: "🇪🇸", region: "Europe", priority: 13 },
  { name: "Italy", code: "IT", dialCode: "+39", flag: "🇮🇹", region: "Europe", priority: 14 },
  { name: "Russia", code: "RU", dialCode: "+7", flag: "🇷🇺", region: "Europe/Asia", priority: 15 },
  { name: "Nigeria", code: "NG", dialCode: "+234", flag: "🇳🇬", region: "Africa", priority: 16 },
  { name: "South Africa", code: "ZA", dialCode: "+27", flag: "🇿🇦", region: "Africa", priority: 17 },
  { name: "Saudi Arabia", code: "SA", dialCode: "+966", flag: "🇸🇦", region: "Middle East", priority: 18 },
  { name: "United Arab Emirates", code: "AE", dialCode: "+971", flag: "🇦🇪", region: "Middle East", priority: 19 },
  { name: "Indonesia", code: "ID", dialCode: "+62", flag: "🇮🇩", region: "Asia", priority: 20 },

  // Complete Alphabetical List (A-Z)
  { name: "Afghanistan", code: "AF", dialCode: "+93", flag: "🇦🇫", region: "Asia" },
  { name: "Albania", code: "AL", dialCode: "+355", flag: "🇦🇱", region: "Europe" },
  { name: "Algeria", code: "DZ", dialCode: "+213", flag: "🇩🇿", region: "Africa" },
  { name: "American Samoa", code: "AS", dialCode: "+1-684", flag: "🇦🇸", region: "Oceania" },
  { name: "Andorra", code: "AD", dialCode: "+376", flag: "🇦🇩", region: "Europe" },
  { name: "Angola", code: "AO", dialCode: "+244", flag: "🇦🇴", region: "Africa" },
  { name: "Anguilla", code: "AI", dialCode: "+1-264", flag: "🇦🇮", region: "Caribbean" },
  { name: "Antarctica", code: "AQ", dialCode: "+672", flag: "🇦🇶", region: "Antarctica" },
  { name: "Antigua and Barbuda", code: "AG", dialCode: "+1-268", flag: "🇦🇬", region: "Caribbean" },
  { name: "Argentina", code: "AR", dialCode: "+54", flag: "🇦🇷", region: "South America" },
  { name: "Armenia", code: "AM", dialCode: "+374", flag: "🇦🇲", region: "Asia" },
  { name: "Aruba", code: "AW", dialCode: "+297", flag: "🇦🇼", region: "Caribbean" },
  { name: "Austria", code: "AT", dialCode: "+43", flag: "🇦🇹", region: "Europe" },
  { name: "Azerbaijan", code: "AZ", dialCode: "+994", flag: "🇦🇿", region: "Asia" },
  { name: "Bahamas", code: "BS", dialCode: "+1-242", flag: "🇧🇸", region: "Caribbean" },
  { name: "Bahrain", code: "BH", dialCode: "+973", flag: "🇧🇭", region: "Middle East" },
  { name: "Bangladesh", code: "BD", dialCode: "+880", flag: "🇧🇩", region: "Asia" },
  { name: "Barbados", code: "BB", dialCode: "+1-246", flag: "🇧🇧", region: "Caribbean" },
  { name: "Belarus", code: "BY", dialCode: "+375", flag: "🇧🇾", region: "Europe" },
  { name: "Belgium", code: "BE", dialCode: "+32", flag: "🇧🇪", region: "Europe" },
  { name: "Belize", code: "BZ", dialCode: "+501", flag: "🇧🇿", region: "Central America" },
  { name: "Benin", code: "BJ", dialCode: "+229", flag: "🇧🇯", region: "Africa" },
  { name: "Bermuda", code: "BM", dialCode: "+1-441", flag: "🇧🇲", region: "North America" },
  { name: "Bhutan", code: "BT", dialCode: "+975", flag: "🇧🇹", region: "Asia" },
  { name: "Bolivia", code: "BO", dialCode: "+591", flag: "🇧🇴", region: "South America" },
  { name: "Bosnia and Herzegovina", code: "BA", dialCode: "+387", flag: "🇧🇦", region: "Europe" },
  { name: "Botswana", code: "BW", dialCode: "+267", flag: "🇧🇼", region: "Africa" },
  { name: "British Indian Ocean Territory", code: "IO", dialCode: "+246", flag: "🇮🇴", region: "Indian Ocean" },
  { name: "British Virgin Islands", code: "VG", dialCode: "+1-284", flag: "🇻🇬", region: "Caribbean" },
  { name: "Brunei", code: "BN", dialCode: "+673", flag: "🇧🇳", region: "Asia" },
  { name: "Bulgaria", code: "BG", dialCode: "+359", flag: "🇧🇬", region: "Europe" },
  { name: "Burkina Faso", code: "BF", dialCode: "+226", flag: "🇧🇫", region: "Africa" },
  { name: "Burundi", code: "BI", dialCode: "+257", flag: "🇧🇮", region: "Africa" },
  { name: "Cambodia", code: "KH", dialCode: "+855", flag: "🇰🇭", region: "Asia" },
  { name: "Cameroon", code: "CM", dialCode: "+237", flag: "🇨🇲", region: "Africa" },
  { name: "Cape Verde", code: "CV", dialCode: "+238", flag: "🇨🇻", region: "Africa" },
  { name: "Cayman Islands", code: "KY", dialCode: "+1-345", flag: "🇰🇾", region: "Caribbean" },
  { name: "Central African Republic", code: "CF", dialCode: "+236", flag: "🇨🇫", region: "Africa" },
  { name: "Chad", code: "TD", dialCode: "+235", flag: "🇹🇩", region: "Africa" },
  { name: "Chile", code: "CL", dialCode: "+56", flag: "🇨🇱", region: "South America" },
  { name: "Christmas Island", code: "CX", dialCode: "+61", flag: "🇨🇽", region: "Indian Ocean" },
  { name: "Cocos Islands", code: "CC", dialCode: "+61", flag: "🇨🇨", region: "Indian Ocean" },
  { name: "Colombia", code: "CO", dialCode: "+57", flag: "🇨🇴", region: "South America" },
  { name: "Comoros", code: "KM", dialCode: "+269", flag: "🇰🇲", region: "Africa" },
  { name: "Cook Islands", code: "CK", dialCode: "+682", flag: "🇨🇰", region: "Oceania" },
  { name: "Costa Rica", code: "CR", dialCode: "+506", flag: "🇨🇷", region: "Central America" },
  { name: "Croatia", code: "HR", dialCode: "+385", flag: "🇭🇷", region: "Europe" },
  { name: "Cuba", code: "CU", dialCode: "+53", flag: "🇨🇺", region: "Caribbean" },
  { name: "Curacao", code: "CW", dialCode: "+599", flag: "🇨🇼", region: "Caribbean" },
  { name: "Cyprus", code: "CY", dialCode: "+357", flag: "🇨🇾", region: "Europe" },
  { name: "Czech Republic", code: "CZ", dialCode: "+420", flag: "🇨🇿", region: "Europe" },
  { name: "Democratic Republic of the Congo", code: "CD", dialCode: "+243", flag: "🇨🇩", region: "Africa" },
  { name: "Denmark", code: "DK", dialCode: "+45", flag: "🇩🇰", region: "Europe" },
  { name: "Djibouti", code: "DJ", dialCode: "+253", flag: "🇩🇯", region: "Africa" },
  { name: "Dominica", code: "DM", dialCode: "+1-767", flag: "🇩🇲", region: "Caribbean" },
  { name: "Dominican Republic", code: "DO", dialCode: "+1-809", flag: "🇩🇴", region: "Caribbean" },
  { name: "East Timor", code: "TL", dialCode: "+670", flag: "🇹🇱", region: "Asia" },
  { name: "Ecuador", code: "EC", dialCode: "+593", flag: "🇪🇨", region: "South America" },
  { name: "Egypt", code: "EG", dialCode: "+20", flag: "🇪🇬", region: "Africa" },
  { name: "El Salvador", code: "SV", dialCode: "+503", flag: "🇸🇻", region: "Central America" },
  { name: "Equatorial Guinea", code: "GQ", dialCode: "+240", flag: "🇬🇶", region: "Africa" },
  { name: "Eritrea", code: "ER", dialCode: "+291", flag: "🇪🇷", region: "Africa" },
  { name: "Estonia", code: "EE", dialCode: "+372", flag: "🇪🇪", region: "Europe" },
  { name: "Ethiopia", code: "ET", dialCode: "+251", flag: "🇪🇹", region: "Africa" },
  { name: "Falkland Islands", code: "FK", dialCode: "+500", flag: "🇫🇰", region: "South America" },
  { name: "Faroe Islands", code: "FO", dialCode: "+298", flag: "🇫🇴", region: "Europe" },
  { name: "Fiji", code: "FJ", dialCode: "+679", flag: "🇫🇯", region: "Oceania" },
  { name: "Finland", code: "FI", dialCode: "+358", flag: "🇫🇮", region: "Europe" },
  { name: "French Polynesia", code: "PF", dialCode: "+689", flag: "🇵🇫", region: "Oceania" },
  { name: "Gabon", code: "GA", dialCode: "+241", flag: "🇬🇦", region: "Africa" },
  { name: "Gambia", code: "GM", dialCode: "+220", flag: "🇬🇲", region: "Africa" },
  { name: "Georgia", code: "GE", dialCode: "+995", flag: "🇬🇪", region: "Asia" },
  { name: "Ghana", code: "GH", dialCode: "+233", flag: "🇬🇭", region: "Africa" },
  { name: "Gibraltar", code: "GI", dialCode: "+350", flag: "🇬🇮", region: "Europe" },
  { name: "Greece", code: "GR", dialCode: "+30", flag: "🇬🇷", region: "Europe" },
  { name: "Greenland", code: "GL", dialCode: "+299", flag: "🇬🇱", region: "North America" },
  { name: "Grenada", code: "GD", dialCode: "+1-473", flag: "🇬🇩", region: "Caribbean" },
  { name: "Guam", code: "GU", dialCode: "+1-671", flag: "🇬🇺", region: "Oceania" },
  { name: "Guatemala", code: "GT", dialCode: "+502", flag: "🇬🇹", region: "Central America" },
  { name: "Guernsey", code: "GG", dialCode: "+44-1481", flag: "🇬🇬", region: "Europe" },
  { name: "Guinea", code: "GN", dialCode: "+224", flag: "🇬🇳", region: "Africa" },
  { name: "Guinea-Bissau", code: "GW", dialCode: "+245", flag: "🇬🇼", region: "Africa" },
  { name: "Guyana", code: "GY", dialCode: "+592", flag: "🇬🇾", region: "South America" },
  { name: "Haiti", code: "HT", dialCode: "+509", flag: "🇭🇹", region: "Caribbean" },
  { name: "Honduras", code: "HN", dialCode: "+504", flag: "🇭🇳", region: "Central America" },
  { name: "Hong Kong", code: "HK", dialCode: "+852", flag: "🇭🇰", region: "Asia" },
  { name: "Hungary", code: "HU", dialCode: "+36", flag: "🇭🇺", region: "Europe" },
  { name: "Iceland", code: "IS", dialCode: "+354", flag: "🇮🇸", region: "Europe" },
  { name: "Iran", code: "IR", dialCode: "+98", flag: "🇮🇷", region: "Middle East" },
  { name: "Iraq", code: "IQ", dialCode: "+964", flag: "🇮🇶", region: "Middle East" },
  { name: "Ireland", code: "IE", dialCode: "+353", flag: "🇮🇪", region: "Europe" },
  { name: "Isle of Man", code: "IM", dialCode: "+44-1624", flag: "🇮🇲", region: "Europe" },
  { name: "Israel", code: "IL", dialCode: "+972", flag: "🇮🇱", region: "Middle East" },
  { name: "Ivory Coast", code: "CI", dialCode: "+225", flag: "🇨🇮", region: "Africa" },
  { name: "Jamaica", code: "JM", dialCode: "+1-876", flag: "🇯🇲", region: "Caribbean" },
  { name: "Jersey", code: "JE", dialCode: "+44-1534", flag: "🇯🇪", region: "Europe" },
  { name: "Jordan", code: "JO", dialCode: "+962", flag: "🇯🇴", region: "Middle East" },
  { name: "Kazakhstan", code: "KZ", dialCode: "+7", flag: "🇰🇿", region: "Asia" },
  { name: "Kenya", code: "KE", dialCode: "+254", flag: "🇰🇪", region: "Africa" },
  { name: "Kiribati", code: "KI", dialCode: "+686", flag: "🇰🇮", region: "Oceania" },
  { name: "Kosovo", code: "XK", dialCode: "+383", flag: "🇽🇰", region: "Europe" },
  { name: "Kuwait", code: "KW", dialCode: "+965", flag: "🇰🇼", region: "Middle East" },
  { name: "Kyrgyzstan", code: "KG", dialCode: "+996", flag: "🇰🇬", region: "Asia" },
  { name: "Laos", code: "LA", dialCode: "+856", flag: "🇱🇦", region: "Asia" },
  { name: "Latvia", code: "LV", dialCode: "+371", flag: "🇱🇻", region: "Europe" },
  { name: "Lebanon", code: "LB", dialCode: "+961", flag: "🇱🇧", region: "Middle East" },
  { name: "Lesotho", code: "LS", dialCode: "+266", flag: "🇱🇸", region: "Africa" },
  { name: "Liberia", code: "LR", dialCode: "+231", flag: "🇱🇷", region: "Africa" },
  { name: "Libya", code: "LY", dialCode: "+218", flag: "🇱🇾", region: "Africa" },
  { name: "Liechtenstein", code: "LI", dialCode: "+423", flag: "🇱🇮", region: "Europe" },
  { name: "Lithuania", code: "LT", dialCode: "+370", flag: "🇱🇹", region: "Europe" },
  { name: "Luxembourg", code: "LU", dialCode: "+352", flag: "🇱🇺", region: "Europe" },
  { name: "Macao", code: "MO", dialCode: "+853", flag: "🇲🇴", region: "Asia" },
  { name: "Macedonia", code: "MK", dialCode: "+389", flag: "🇲🇰", region: "Europe" },
  { name: "Madagascar", code: "MG", dialCode: "+261", flag: "🇲🇬", region: "Africa" },
  { name: "Malawi", code: "MW", dialCode: "+265", flag: "🇲🇼", region: "Africa" },
  { name: "Malaysia", code: "MY", dialCode: "+60", flag: "🇲🇾", region: "Asia" },
  { name: "Maldives", code: "MV", dialCode: "+960", flag: "🇲🇻", region: "Asia" },
  { name: "Mali", code: "ML", dialCode: "+223", flag: "🇲🇱", region: "Africa" },
  { name: "Malta", code: "MT", dialCode: "+356", flag: "🇲🇹", region: "Europe" },
  { name: "Marshall Islands", code: "MH", dialCode: "+692", flag: "🇲🇭", region: "Oceania" },
  { name: "Martinique", code: "MQ", dialCode: "+596", flag: "🇲🇶", region: "Caribbean" },
  { name: "Mauritania", code: "MR", dialCode: "+222", flag: "🇲🇷", region: "Africa" },
  { name: "Mauritius", code: "MU", dialCode: "+230", flag: "🇲🇺", region: "Africa" },
  { name: "Mayotte", code: "YT", dialCode: "+262", flag: "🇾🇹", region: "Africa" },
  { name: "Micronesia", code: "FM", dialCode: "+691", flag: "🇫🇲", region: "Oceania" },
  { name: "Moldova", code: "MD", dialCode: "+373", flag: "🇲🇩", region: "Europe" },
  { name: "Monaco", code: "MC", dialCode: "+377", flag: "🇲🇨", region: "Europe" },
  { name: "Mongolia", code: "MN", dialCode: "+976", flag: "🇲🇳", region: "Asia" },
  { name: "Montenegro", code: "ME", dialCode: "+382", flag: "🇲🇪", region: "Europe" },
  { name: "Montserrat", code: "MS", dialCode: "+1-664", flag: "🇲🇸", region: "Caribbean" },
  { name: "Morocco", code: "MA", dialCode: "+212", flag: "🇲🇦", region: "Africa" },
  { name: "Mozambique", code: "MZ", dialCode: "+258", flag: "🇲🇿", region: "Africa" },
  { name: "Myanmar", code: "MM", dialCode: "+95", flag: "🇲🇲", region: "Asia" },
  { name: "Namibia", code: "NA", dialCode: "+264", flag: "🇳🇦", region: "Africa" },
  { name: "Nauru", code: "NR", dialCode: "+674", flag: "🇳🇷", region: "Oceania" },
  { name: "Nepal", code: "NP", dialCode: "+977", flag: "🇳🇵", region: "Asia" },
  { name: "Netherlands", code: "NL", dialCode: "+31", flag: "🇳🇱", region: "Europe" },
  { name: "New Caledonia", code: "NC", dialCode: "+687", flag: "🇳🇨", region: "Oceania" },
  { name: "New Zealand", code: "NZ", dialCode: "+64", flag: "🇳🇿", region: "Oceania" },
  { name: "Nicaragua", code: "NI", dialCode: "+505", flag: "🇳🇮", region: "Central America" },
  { name: "Niger", code: "NE", dialCode: "+227", flag: "🇳🇪", region: "Africa" },
  { name: "Niue", code: "NU", dialCode: "+683", flag: "🇳🇺", region: "Oceania" },
  { name: "North Korea", code: "KP", dialCode: "+850", flag: "🇰🇵", region: "Asia" },
  { name: "Northern Mariana Islands", code: "MP", dialCode: "+1-670", flag: "🇲🇵", region: "Oceania" },
  { name: "Norway", code: "NO", dialCode: "+47", flag: "🇳🇴", region: "Europe" },
  { name: "Oman", code: "OM", dialCode: "+968", flag: "🇴🇲", region: "Middle East" },
  { name: "Pakistan", code: "PK", dialCode: "+92", flag: "🇵🇰", region: "Asia" },
  { name: "Palau", code: "PW", dialCode: "+680", flag: "🇵🇼", region: "Oceania" },
  { name: "Palestine", code: "PS", dialCode: "+970", flag: "🇵🇸", region: "Middle East" },
  { name: "Panama", code: "PA", dialCode: "+507", flag: "🇵🇦", region: "Central America" },
  { name: "Papua New Guinea", code: "PG", dialCode: "+675", flag: "🇵🇬", region: "Oceania" },
  { name: "Paraguay", code: "PY", dialCode: "+595", flag: "🇵🇾", region: "South America" },
  { name: "Peru", code: "PE", dialCode: "+51", flag: "🇵🇪", region: "South America" },
  { name: "Philippines", code: "PH", dialCode: "+63", flag: "🇵🇭", region: "Asia" },
  { name: "Pitcairn", code: "PN", dialCode: "+64", flag: "🇵🇳", region: "Oceania" },
  { name: "Poland", code: "PL", dialCode: "+48", flag: "🇵🇱", region: "Europe" },
  { name: "Portugal", code: "PT", dialCode: "+351", flag: "🇵🇹", region: "Europe" },
  { name: "Puerto Rico", code: "PR", dialCode: "+1-787", flag: "🇵🇷", region: "Caribbean" },
  { name: "Qatar", code: "QA", dialCode: "+974", flag: "🇶🇦", region: "Middle East" },
  { name: "Republic of the Congo", code: "CG", dialCode: "+242", flag: "🇨🇬", region: "Africa" },
  { name: "Reunion", code: "RE", dialCode: "+262", flag: "🇷🇪", region: "Africa" },
  { name: "Romania", code: "RO", dialCode: "+40", flag: "🇷🇴", region: "Europe" },
  { name: "Rwanda", code: "RW", dialCode: "+250", flag: "🇷🇼", region: "Africa" },
  { name: "Saint Barthelemy", code: "BL", dialCode: "+590", flag: "🇧🇱", region: "Caribbean" },
  { name: "Saint Helena", code: "SH", dialCode: "+290", flag: "🇸🇭", region: "Africa" },
  { name: "Saint Kitts and Nevis", code: "KN", dialCode: "+1-869", flag: "🇰🇳", region: "Caribbean" },
  { name: "Saint Lucia", code: "LC", dialCode: "+1-758", flag: "🇱🇨", region: "Caribbean" },
  { name: "Saint Martin", code: "MF", dialCode: "+590", flag: "🇲🇫", region: "Caribbean" },
  { name: "Saint Pierre and Miquelon", code: "PM", dialCode: "+508", flag: "🇵🇲", region: "North America" },
  { name: "Saint Vincent and the Grenadines", code: "VC", dialCode: "+1-784", flag: "🇻🇨", region: "Caribbean" },
  { name: "Samoa", code: "WS", dialCode: "+685", flag: "🇼🇸", region: "Oceania" },
  { name: "San Marino", code: "SM", dialCode: "+378", flag: "🇸🇲", region: "Europe" },
  { name: "Sao Tome and Principe", code: "ST", dialCode: "+239", flag: "🇸🇹", region: "Africa" },
  { name: "Senegal", code: "SN", dialCode: "+221", flag: "🇸🇳", region: "Africa" },
  { name: "Serbia", code: "RS", dialCode: "+381", flag: "🇷🇸", region: "Europe" },
  { name: "Seychelles", code: "SC", dialCode: "+248", flag: "🇸🇨", region: "Africa" },
  { name: "Sierra Leone", code: "SL", dialCode: "+232", flag: "🇸🇱", region: "Africa" },
  { name: "Singapore", code: "SG", dialCode: "+65", flag: "🇸🇬", region: "Asia" },
  { name: "Sint Maarten", code: "SX", dialCode: "+1-721", flag: "🇸🇽", region: "Caribbean" },
  { name: "Slovakia", code: "SK", dialCode: "+421", flag: "🇸🇰", region: "Europe" },
  { name: "Slovenia", code: "SI", dialCode: "+386", flag: "🇸🇮", region: "Europe" },
  { name: "Solomon Islands", code: "SB", dialCode: "+677", flag: "🇸🇧", region: "Oceania" },
  { name: "Somalia", code: "SO", dialCode: "+252", flag: "🇸🇴", region: "Africa" },
  { name: "South Sudan", code: "SS", dialCode: "+211", flag: "🇸🇸", region: "Africa" },
  { name: "Sri Lanka", code: "LK", dialCode: "+94", flag: "🇱🇰", region: "Asia" },
  { name: "Sudan", code: "SD", dialCode: "+249", flag: "🇸🇩", region: "Africa" },
  { name: "Suriname", code: "SR", dialCode: "+597", flag: "🇸🇷", region: "South America" },
  { name: "Svalbard and Jan Mayen", code: "SJ", dialCode: "+47", flag: "🇸🇯", region: "Europe" },
  { name: "Swaziland", code: "SZ", dialCode: "+268", flag: "🇸🇿", region: "Africa" },
  { name: "Sweden", code: "SE", dialCode: "+46", flag: "🇸🇪", region: "Europe" },
  { name: "Switzerland", code: "CH", dialCode: "+41", flag: "🇨🇭", region: "Europe" },
  { name: "Syria", code: "SY", dialCode: "+963", flag: "🇸🇾", region: "Middle East" },
  { name: "Taiwan", code: "TW", dialCode: "+886", flag: "🇹🇼", region: "Asia" },
  { name: "Tajikistan", code: "TJ", dialCode: "+992", flag: "🇹🇯", region: "Asia" },
  { name: "Tanzania", code: "TZ", dialCode: "+255", flag: "🇹🇿", region: "Africa" },
  { name: "Thailand", code: "TH", dialCode: "+66", flag: "🇹🇭", region: "Asia" },
  { name: "Togo", code: "TG", dialCode: "+228", flag: "🇹🇬", region: "Africa" },
  { name: "Tokelau", code: "TK", dialCode: "+690", flag: "🇹🇰", region: "Oceania" },
  { name: "Tonga", code: "TO", dialCode: "+676", flag: "🇹🇴", region: "Oceania" },
  { name: "Trinidad and Tobago", code: "TT", dialCode: "+1-868", flag: "🇹🇹", region: "Caribbean" },
  { name: "Tunisia", code: "TN", dialCode: "+216", flag: "🇹🇳", region: "Africa" },
  { name: "Turkey", code: "TR", dialCode: "+90", flag: "🇹🇷", region: "Europe/Asia" },
  { name: "Turkmenistan", code: "TM", dialCode: "+993", flag: "🇹🇲", region: "Asia" },
  { name: "Turks and Caicos Islands", code: "TC", dialCode: "+1-649", flag: "🇹🇨", region: "Caribbean" },
  { name: "Tuvalu", code: "TV", dialCode: "+688", flag: "🇹🇻", region: "Oceania" },
  { name: "U.S. Virgin Islands", code: "VI", dialCode: "+1-340", flag: "🇻🇮", region: "Caribbean" },
  { name: "Uganda", code: "UG", dialCode: "+256", flag: "🇺🇬", region: "Africa" },
  { name: "Ukraine", code: "UA", dialCode: "+380", flag: "🇺🇦", region: "Europe" },
  { name: "Uruguay", code: "UY", dialCode: "+598", flag: "🇺🇾", region: "South America" },
  { name: "Uzbekistan", code: "UZ", dialCode: "+998", flag: "🇺🇿", region: "Asia" },
  { name: "Vanuatu", code: "VU", dialCode: "+678", flag: "🇻🇺", region: "Oceania" },
  { name: "Vatican", code: "VA", dialCode: "+379", flag: "🇻🇦", region: "Europe" },
  { name: "Venezuela", code: "VE", dialCode: "+58", flag: "🇻🇪", region: "South America" },
  { name: "Vietnam", code: "VN", dialCode: "+84", flag: "🇻🇳", region: "Asia" },
  { name: "Wallis and Futuna", code: "WF", dialCode: "+681", flag: "🇼🇫", region: "Oceania" },
  { name: "Western Sahara", code: "EH", dialCode: "+212", flag: "🇪🇭", region: "Africa" },
  { name: "Yemen", code: "YE", dialCode: "+967", flag: "🇾🇪", region: "Middle East" },
  { name: "Zambia", code: "ZM", dialCode: "+260", flag: "🇿🇲", region: "Africa" },
  { name: "Zimbabwe", code: "ZW", dialCode: "+263", flag: "🇿🇼", region: "Africa" }
];

/**
 * Get sorted country codes
 * Priority countries first, then alphabetically
 */
export const getSortedCountryCodes = () => {
  return [...countryCodes]?.sort((a, b) => {
    // Priority countries first
    if (a?.priority && !b?.priority) return -1;
    if (!a?.priority && b?.priority) return 1;
    if (a?.priority && b?.priority) return a?.priority - b?.priority;
    
    // Then alphabetically
    return a?.name?.localeCompare(b?.name);
  });
};

/**
 * Search countries by name or dial code
 */
export const searchCountries = (searchTerm) => {
  const term = searchTerm?.toLowerCase()?.trim();
  if (!term) return getSortedCountryCodes();
  
  return countryCodes?.filter(country =>
    country?.name?.toLowerCase()?.includes(term) ||
    country?.dialCode?.includes(term) ||
    country?.code?.toLowerCase()?.includes(term)
  );
};

/**
 * Get country by dial code
 */
export const getCountryByDialCode = (dialCode) => {
  return countryCodes?.find(c => c?.dialCode === dialCode);
};

/**
 * Get country by ISO code
 */
export const getCountryByCode = (code) => {
  return countryCodes?.find(c => c?.code === code);
};

export default countryCodes;