import React from 'react';
import { BrowserRouter, Routes as RouterRoutes, Route } from 'react-router-dom';

import ErrorBoundary from './components/ErrorBoundary';
import ScrollToTop from './components/ScrollToTop';
import MobileBottomNav from './components/ui/MobileBottomNav';
import NotFound from './pages/NotFound';
import { LanguageProvider } from './pages/contexts/LanguageContext';
import LandingPage from './pages/landing-page/index';
import EmailVerification from './pages/email-verification';
import ChannelSubscriptionPayment from './pages/channel-subscription-payment';
import ChannelMonetizationDashboard from './pages/channel-monetization-dashboard';

// Retry helper for lazy loading
const lazyWithRetry = (componentImport) => {
  return React.lazy(async () => {
    const pageHasAlreadyBeenForceRefreshed = JSON.parse(
      window.sessionStorage?.getItem('page-has-been-force-refreshed') || 'false'
    );

    try {
      const component = await componentImport();
      window.sessionStorage?.setItem('page-has-been-force-refreshed', 'false');
      
      // Validate that we received a proper module with default export
      if (!component || typeof component !== 'object' || !component?.default) {
        throw new Error('Invalid module: missing default export');
      }
      
      return component;
      
    } catch (error) {
      console.error('Component loading failed:', error);
      
      if (!pageHasAlreadyBeenForceRefreshed) {
        // Mark that we're about to refresh
        window.sessionStorage?.setItem('page-has-been-force-refreshed', 'true');
        
        // Reload immediately - don't return anything that React.lazy will try to process
        window.location?.reload();
        
        // Return a never-resolving promise to prevent React.lazy from accessing .default
        // This is safe because the page is reloading anyway
        return new Promise(() => {});
      }
      
      // If already refreshed once and still failing, return error component
      console.error('Component failed to load after refresh:', error);
      const ErrorComponent = () => (
        <div style={{ padding: '20px', textAlign: 'center' }}>
          <h2>Failed to load component</h2>
          <p>Please try refreshing the page manually.</p>
          <button onClick={() => window.location?.reload()}>Refresh Page</button>
        </div>
      );
      
      return { default: ErrorComponent };
    }
  });
};

// Lazy load pages with retry mechanism
const LoginLazy = lazyWithRetry(() => import('./pages/login'));
const RegisterLazy = lazyWithRetry(() => import('./pages/register'));
const WhatsAppStylePhoneAuthenticationLazy = lazyWithRetry(() => import('./pages/whats-app-style-phone-authentication'));
const SecureTwilioOTPVerificationLazy = lazyWithRetry(() => import('./pages/secure-twilio-otp-verification'));
const MainChatInterfaceLazy = lazyWithRetry(() => import('./pages/main-chat-interface'));
const GroupChatManagementLazy = lazyWithRetry(() => import('./pages/group-chat-management'));
const ContactManagementLazy = lazyWithRetry(() => import('./pages/contact-management'));
const UserProfileSettingsLazy = lazyWithRetry(() => import('./pages/user-profile-settings'));
const MediaSharingLazy = lazyWithRetry(() => import('./pages/media-sharing'));
const MessageSchedulingLazy = lazyWithRetry(() => import('./pages/message-scheduling'));
const Notifications = lazyWithRetry(() => import('./pages/notifications'));
const AdvancedSearchInterfaceLazy = lazyWithRetry(() => import('./pages/advanced-search-interface'));
const Calls = lazyWithRetry(() => import('./pages/calls'));
const StatusLazy = lazyWithRetry(() => import('./pages/status'));
const MessageAutoDeleteSettingsLazy = lazyWithRetry(() => import('./pages/message-auto-delete-settings'));
const EnhancedMultiParticipantVideoConferenceLazy = lazyWithRetry(() => import('./pages/enhanced-multi-participant-video-conference'));
const ProfileSetupLazy = lazyWithRetry(() => import('./pages/profile-setup'));
const ContactDiscoveryMatchingLazy = lazyWithRetry(() => import('./pages/contact-discovery-matching'));
const IncomingCallAlertInterfaceLazy = lazyWithRetry(() => import('./pages/incoming-call-alert-interface'));
const EnhancedNotificationSettingsLazy = lazyWithRetry(() => import('./pages/enhanced-notification-settings'));
const NotificationPreferencesDeliverySettingsLazy = lazyWithRetry(() => import('./pages/notification-preferences-delivery-settings'));
const RecordingManagementLazy = lazyWithRetry(() => import('./pages/recording-management'));
const SemanticSearchInterfaceLazy = lazyWithRetry(() => import('./pages/semantic-search-interface'));
const CallAnalyticsDashboardLazy = lazyWithRetry(() => import('./pages/call-analytics-dashboard'));
const BroadcastListsManagementLazy = lazyWithRetry(() => import('./pages/broadcast-lists-management'));
const StatusStoriesCreationManagementLazy = lazyWithRetry(() => import('./pages/status-stories-creation-management'));
const StatusStoriesViewerInterfaceLazy = lazyWithRetry(() => import('./pages/status-stories-viewer-interface'));
const GrammarToneOptimizationInterfaceLazy = lazyWithRetry(() => import('./pages/grammar-tone-optimization-interface'));
const QRCodeLoginInterfaceLazy = lazyWithRetry(() => import('./pages/qr-code-login-interface'));
const EnhancedCallAnalyticsDashboardLazy = lazyWithRetry(() => import('./pages/enhanced-call-analytics-dashboard'));
const MessageSchedulingHubLazy = lazyWithRetry(() => import('./pages/message-scheduling-hub'));
const BusinessProfileCatalogManagementLazy = lazyWithRetry(() => import('./pages/business-profile-catalog-management'));
const PostLoginEmailBackupSetupLazy = lazyWithRetry(() => import('./pages/post-login-email-backup-setup'));
const ChannelCreationSetupLazy = lazyWithRetry(() => import('./pages/channel-creation-setup'));
const ChannelManagementDashboardLazy = lazyWithRetry(() => import('./pages/channel-management-dashboard'));
const ChannelDiscoverySubscriptionHubLazy = lazyWithRetry(() => import('./pages/channel-discovery-subscription-hub'));
const ChannelBroadcastComposerLazy = lazyWithRetry(() => import('./pages/channel-broadcast-composer'));
const ChannelSubscriberAnalyticsDashboardLazy = lazyWithRetry(() => import('./pages/channel-subscriber-analytics-dashboard'));
const EnhancedSessionSecurityDashboardLazy = lazyWithRetry(() => import('./pages/enhanced-session-security-dashboard'));
const ChatVybzAdminDashboardLazy = lazyWithRetry(() => import('./pages/chat-vybz-admin-dashboard'));
const AdminAnnouncementBroadcastingSystemLazy = lazyWithRetry(() => import('./pages/admin-announcement-broadcasting-system'));
const AdminUserManagementModerationCenterLazy = lazyWithRetry(() => import('./pages/admin-user-management-moderation-center'));
const CreatorRevenueAnalyticsDashboardLazy = lazyWithRetry(() => import('./pages/creator-revenue-analytics-dashboard'));
const AIContentModerationCenterLazy = lazyWithRetry(() => import('./pages/ai-content-moderation-center'));
const PushNotificationManagementCenterLazy = lazyWithRetry(() => import('./pages/push-notification-management-center'));
const AutomatedAnalyticsReportingDashboardLazy = lazyWithRetry(() => import('./pages/automated-analytics-reporting-dashboard'));
const CreatorRevenueSettlementDashboardLazy = lazyWithRetry(() => import('./pages/creator-revenue-settlement-dashboard'));
const CreatorPayoutWithdrawalSystemLazy = lazyWithRetry(() => import('./pages/creator-payout-withdrawal-system'));
const AdminLoginSystemLazy = lazyWithRetry(() => import('./pages/admin-login-system'));

const TwoFactorAuthenticationSettingsLazy = lazyWithRetry(() => import('./pages/two-factor-authentication-settings'));

const { Suspense } = React;

const LoadingFallback = () => <div>Loading...</div>;

function Routes() {
  return (
    <LanguageProvider>
      <BrowserRouter>
        <ErrorBoundary>
          <ScrollToTop />
          <MobileBottomNav />
          <Suspense fallback={<LoadingFallback />}>
            <RouterRoutes>
              <Route path="/" element={<LandingPage />} />
              <Route path="/login" element={<LoginLazy />} />
              <Route path="/whats-app-style-phone-authentication" element={<WhatsAppStylePhoneAuthenticationLazy />} />
              <Route path="/secure-twilio-otp-verification" element={<SecureTwilioOTPVerificationLazy />} />
              <Route path="/qr-login" element={<QRCodeLoginInterfaceLazy />} />
              <Route path="/register" element={<RegisterLazy />} />
              <Route path="/chat" element={<MainChatInterfaceLazy />} />
              <Route path="/main-chat-interface" element={<MainChatInterfaceLazy />} />
              <Route path="/groups" element={<GroupChatManagementLazy />} />
              <Route path="/contacts" element={<ContactManagementLazy />} />
              <Route path="/profile" element={<UserProfileSettingsLazy />} />
              <Route path="/media" element={<MediaSharingLazy />} />
              <Route path="/schedule" element={<MessageSchedulingLazy />} />
              <Route path="/notifications" element={<Notifications />} />
              <Route path="/search" element={<AdvancedSearchInterfaceLazy />} />
              <Route path="/calls" element={<Calls />} />
              <Route path="/status" element={<StatusLazy />} />
              <Route path="/auto-delete-settings" element={<MessageAutoDeleteSettingsLazy />} />
              <Route path="/enhanced-multi-participant-video-conference" element={<EnhancedMultiParticipantVideoConferenceLazy />} />
              <Route path="/profile-setup" element={<ProfileSetupLazy />} />
              <Route path="/post-login-email-backup-setup" element={<PostLoginEmailBackupSetupLazy />} />
              <Route path="/contact-discovery-matching" element={<ContactDiscoveryMatchingLazy />} />
              <Route path="/incoming-call-alert-interface" element={<IncomingCallAlertInterfaceLazy />} />
              <Route path="/enhanced-notification-settings" element={<EnhancedNotificationSettingsLazy />} />
              <Route path="/notification-preferences-delivery-settings" element={<NotificationPreferencesDeliverySettingsLazy />} />
              <Route path="/recording-management" element={<RecordingManagementLazy />} />
              <Route path="/semantic-search-interface" element={<SemanticSearchInterfaceLazy />} />
              <Route path="/call-analytics-dashboard" element={<CallAnalyticsDashboardLazy />} />
              <Route path="/broadcast-lists-management" element={<BroadcastListsManagementLazy />} />
              <Route path="/status-stories-creation-management" element={<StatusStoriesCreationManagementLazy />} />
              <Route path="/status-stories-viewer-interface" element={<StatusStoriesViewerInterfaceLazy />} />
              <Route path="/grammar-tone-optimization-interface" element={<GrammarToneOptimizationInterfaceLazy />} />
              <Route path="/email-verification" element={<EmailVerification />} />
              <Route path="/business-profile-catalog-management" element={<BusinessProfileCatalogManagementLazy />} />
              <Route path="/channel-creation-setup" element={<ChannelCreationSetupLazy />} />
              <Route path="/channel-management-dashboard" element={<ChannelManagementDashboardLazy />} />
              <Route path="/channel-discovery-subscription-hub" element={<ChannelDiscoverySubscriptionHubLazy />} />
              <Route path="/channel-broadcast-composer" element={<ChannelBroadcastComposerLazy />} />
              <Route path="/channel-subscriber-analytics-dashboard" element={<ChannelSubscriberAnalyticsDashboardLazy />} />
              <Route path="/enhanced-session-security-dashboard" element={<EnhancedSessionSecurityDashboardLazy />} />
              <Route path="/chat-vybz-admin-dashboard" element={<ChatVybzAdminDashboardLazy />} />
              <Route path="/admin-announcement-broadcasting-system" element={<AdminAnnouncementBroadcastingSystemLazy />} />
              <Route path="/admin-user-management-moderation-center" element={<AdminUserManagementModerationCenterLazy />} />
              <Route path="/creator-revenue-analytics-dashboard" element={<CreatorRevenueAnalyticsDashboardLazy />} />
              <Route path="/ai-content-moderation-center" element={<AIContentModerationCenterLazy />} />
              <Route path="/push-notification-management-center" element={<PushNotificationManagementCenterLazy />} />
              <Route path="/automated-analytics-reporting-dashboard" element={<AutomatedAnalyticsReportingDashboardLazy />} />
              <Route path="/creator-revenue-settlement-dashboard" element={<CreatorRevenueSettlementDashboardLazy />} />
              <Route path="/creator-payout-withdrawal-system" element={<CreatorPayoutWithdrawalSystemLazy />} />
              <Route path="/admin-login-system" element={<AdminLoginSystemLazy />} />
              <Route path="/channel-subscription-payment" element={<ChannelSubscriptionPayment />} />
              <Route path="/channel-monetization-dashboard" element={<ChannelMonetizationDashboard />} />
              <Route path="*" element={<NotFound />} />
            </RouterRoutes>
          </Suspense>
        </ErrorBoundary>
      </BrowserRouter>
    </LanguageProvider>
  );
}

export default Routes;