-- ============================================================================
-- Fix Phone Verification Permissions for Anonymous Users
-- ============================================================================
-- Issue: Users cannot verify OTP during registration because they're not authenticated yet
-- Solution: Grant necessary permissions to anon role

-- Grant table permissions to anonymous users
GRANT SELECT, INSERT, UPDATE ON public.phone_verification_attempts TO anon;
GRANT SELECT, INSERT, UPDATE ON public.phone_auth_rate_limits TO anon;

-- Grant function execution permissions to anonymous users
GRANT EXECUTE ON FUNCTION public.check_phone_rate_limit TO anon;
GRANT EXECUTE ON FUNCTION public.create_phone_otp_attempt TO anon;
GRANT EXECUTE ON FUNCTION public.verify_phone_otp TO anon;

-- Add RLS policies for anonymous access to phone_verification_attempts
CREATE POLICY "Allow anon to insert verification attempts"
  ON public.phone_verification_attempts
  FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Allow anon to read own verification attempts"
  ON public.phone_verification_attempts
  FOR SELECT
  TO anon
  USING (true);

CREATE POLICY "Allow anon to update own verification attempts"
  ON public.phone_verification_attempts
  FOR UPDATE
  TO anon
  USING (true);

-- Add RLS policies for anonymous access to phone_auth_rate_limits
CREATE POLICY "Allow anon to manage rate limits"
  ON public.phone_auth_rate_limits
  FOR ALL
  TO anon
  USING (true)
  WITH CHECK (true);