-- Location: supabase/migrations/20251224145800_two_factor_authentication.sql
-- Schema Analysis: Extending existing auth system with 2FA capabilities
-- Integration Type: Addition - New tables for 2FA/TOTP functionality
-- Dependencies: profiles table

-- 1. Create TOTP secrets table for authenticator app integration
CREATE TABLE public.totp_secrets (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
    secret_key TEXT NOT NULL,
    is_verified BOOLEAN DEFAULT false,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    verified_at TIMESTAMPTZ,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 2. Create backup codes table for recovery access
CREATE TABLE public.backup_codes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
    code_hash TEXT NOT NULL,
    is_used BOOLEAN DEFAULT false,
    used_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 3. Create trusted devices table for device management
CREATE TABLE public.trusted_devices (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
    device_name TEXT NOT NULL,
    device_fingerprint TEXT NOT NULL,
    device_type TEXT,
    browser_info JSONB,
    ip_address TEXT,
    location JSONB,
    last_accessed_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    is_trusted BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMPTZ
);

-- 4. Create 2FA audit log table for security monitoring
CREATE TABLE public.two_fa_audit_log (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
    event_type TEXT NOT NULL,
    device_id UUID REFERENCES public.trusted_devices(id) ON DELETE SET NULL,
    success BOOLEAN NOT NULL,
    ip_address TEXT,
    user_agent TEXT,
    metadata JSONB,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 5. Create indexes for performance
CREATE INDEX idx_totp_secrets_user_id ON public.totp_secrets(user_id);
CREATE INDEX idx_backup_codes_user_id ON public.backup_codes(user_id);
CREATE INDEX idx_backup_codes_user_unused ON public.backup_codes(user_id, is_used) WHERE is_used = false;
CREATE INDEX idx_trusted_devices_user_id ON public.trusted_devices(user_id);
CREATE INDEX idx_trusted_devices_fingerprint ON public.trusted_devices(device_fingerprint);
CREATE INDEX idx_two_fa_audit_user_id ON public.two_fa_audit_log(user_id);
CREATE INDEX idx_two_fa_audit_created ON public.two_fa_audit_log(created_at DESC);

-- 6. Enable RLS for all tables
ALTER TABLE public.totp_secrets ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.backup_codes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.trusted_devices ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.two_fa_audit_log ENABLE ROW LEVEL SECURITY;

-- 7. Create RLS policies using Pattern 2 (Simple User Ownership)
CREATE POLICY "users_manage_own_totp_secrets"
ON public.totp_secrets
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

CREATE POLICY "users_manage_own_backup_codes"
ON public.backup_codes
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

CREATE POLICY "users_manage_own_trusted_devices"
ON public.trusted_devices
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

CREATE POLICY "users_view_own_audit_log"
ON public.two_fa_audit_log
FOR SELECT
TO authenticated
USING (user_id = auth.uid());

CREATE POLICY "users_create_audit_log"
ON public.two_fa_audit_log
FOR INSERT
TO authenticated
WITH CHECK (user_id = auth.uid());

-- 8. Create helper functions
CREATE OR REPLACE FUNCTION public.generate_backup_codes(p_user_id UUID, p_count INTEGER DEFAULT 10)
RETURNS TEXT[]
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    codes TEXT[];
    code TEXT;
    i INTEGER;
BEGIN
    codes := ARRAY[]::TEXT[];
    
    FOR i IN 1..p_count LOOP
        code := UPPER(SUBSTRING(MD5(RANDOM()::TEXT || CLOCK_TIMESTAMP()::TEXT) FROM 1 FOR 8));
        codes := array_append(codes, code);
        
        INSERT INTO public.backup_codes (user_id, code_hash)
        VALUES (p_user_id, crypt(code, gen_salt('bf', 10)));
    END LOOP;
    
    RETURN codes;
END;
$$;

CREATE OR REPLACE FUNCTION public.verify_backup_code(p_user_id UUID, p_code TEXT)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_code_id UUID;
BEGIN
    SELECT id INTO v_code_id
    FROM public.backup_codes
    WHERE user_id = p_user_id
    AND is_used = false
    AND code_hash = crypt(p_code, code_hash)
    LIMIT 1;
    
    IF v_code_id IS NOT NULL THEN
        UPDATE public.backup_codes
        SET is_used = true, used_at = CURRENT_TIMESTAMP
        WHERE id = v_code_id;
        
        RETURN true;
    END IF;
    
    RETURN false;
END;
$$;

CREATE OR REPLACE FUNCTION public.cleanup_expired_devices()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    DELETE FROM public.trusted_devices
    WHERE expires_at IS NOT NULL
    AND expires_at < CURRENT_TIMESTAMP;
END;
$$;

-- 9. Create trigger for updating updated_at
CREATE OR REPLACE FUNCTION public.update_totp_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;

CREATE TRIGGER trigger_update_totp_updated_at
    BEFORE UPDATE ON public.totp_secrets
    FOR EACH ROW
    EXECUTE FUNCTION public.update_totp_updated_at();