-- Channels Feature Migration
-- Implements Telegram-style broadcast channels with subscriber management and message broadcasting

-- 1. Create channel_type enum
CREATE TYPE public.channel_type AS ENUM ('public', 'private');

-- 2. Create channel_role enum
CREATE TYPE public.channel_role AS ENUM ('subscriber', 'administrator', 'owner');

-- 3. Create channels table
CREATE TABLE public.channels (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    description TEXT,
    type public.channel_type DEFAULT 'public'::public.channel_type,
    username TEXT UNIQUE,
    creator_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    subscribers_count INTEGER DEFAULT 0,
    messages_count INTEGER DEFAULT 0,
    avatar_url TEXT,
    is_verified BOOLEAN DEFAULT false,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT username_format CHECK (username ~ '^[a-zA-Z0-9_]{5,32}$')
);

-- 4. Create channel_users junction table
CREATE TABLE public.channel_users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    channel_id UUID NOT NULL REFERENCES public.channels(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    role public.channel_role DEFAULT 'subscriber'::public.channel_role,
    joined_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    muted BOOLEAN DEFAULT false,
    notification_enabled BOOLEAN DEFAULT true,
    UNIQUE(channel_id, user_id)
);

-- 5. Create channel_messages table
CREATE TABLE public.channel_messages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    channel_id UUID NOT NULL REFERENCES public.channels(id) ON DELETE CASCADE,
    sender_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    text_content TEXT NOT NULL,
    media_url TEXT,
    media_type TEXT,
    views_count INTEGER DEFAULT 0,
    is_pinned BOOLEAN DEFAULT false,
    is_scheduled BOOLEAN DEFAULT false,
    scheduled_for TIMESTAMPTZ,
    sent_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 6. Create channel_message_views table for tracking individual views
CREATE TABLE public.channel_message_views (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    message_id UUID NOT NULL REFERENCES public.channel_messages(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    viewed_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(message_id, user_id)
);

-- 7. Create indexes
CREATE INDEX idx_channels_creator_id ON public.channels(creator_id);
CREATE INDEX idx_channels_username ON public.channels(username);
CREATE INDEX idx_channels_type ON public.channels(type);
CREATE INDEX idx_channel_users_channel_id ON public.channel_users(channel_id);
CREATE INDEX idx_channel_users_user_id ON public.channel_users(user_id);
CREATE INDEX idx_channel_users_role ON public.channel_users(role);
CREATE INDEX idx_channel_messages_channel_id ON public.channel_messages(channel_id);
CREATE INDEX idx_channel_messages_sender_id ON public.channel_messages(sender_id);
CREATE INDEX idx_channel_messages_sent_at ON public.channel_messages(sent_at DESC);
CREATE INDEX idx_channel_message_views_message_id ON public.channel_message_views(message_id);
CREATE INDEX idx_channel_message_views_user_id ON public.channel_message_views(user_id);

-- 8. Create functions

-- Function to check if user is channel admin or owner
CREATE OR REPLACE FUNCTION public.is_channel_admin(channel_uuid UUID)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
SELECT EXISTS (
    SELECT 1 FROM public.channel_users cu
    WHERE cu.channel_id = channel_uuid
    AND cu.user_id = auth.uid()
    AND cu.role IN ('administrator', 'owner')
)
$$;

-- Function to check if user is channel subscriber
CREATE OR REPLACE FUNCTION public.is_channel_subscriber(channel_uuid UUID)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
SELECT EXISTS (
    SELECT 1 FROM public.channel_users cu
    WHERE cu.channel_id = channel_uuid
    AND cu.user_id = auth.uid()
)
$$;

-- Function to update channel subscribers count
CREATE OR REPLACE FUNCTION public.update_channel_subscribers_count()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        UPDATE public.channels
        SET subscribers_count = subscribers_count + 1
        WHERE id = NEW.channel_id;
        RETURN NEW;
    ELSIF TG_OP = 'DELETE' THEN
        UPDATE public.channels
        SET subscribers_count = GREATEST(0, subscribers_count - 1)
        WHERE id = OLD.channel_id;
        RETURN OLD;
    END IF;
    RETURN NULL;
END;
$$;

-- Function to update channel messages count
CREATE OR REPLACE FUNCTION public.update_channel_messages_count()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        UPDATE public.channels
        SET messages_count = messages_count + 1
        WHERE id = NEW.channel_id;
        RETURN NEW;
    ELSIF TG_OP = 'DELETE' THEN
        UPDATE public.channels
        SET messages_count = GREATEST(0, messages_count - 1)
        WHERE id = OLD.channel_id;
        RETURN OLD;
    END IF;
    RETURN NULL;
END;
$$;

-- Function to update message views count
CREATE OR REPLACE FUNCTION public.update_message_views_count()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        UPDATE public.channel_messages
        SET views_count = views_count + 1
        WHERE id = NEW.message_id;
        RETURN NEW;
    END IF;
    RETURN NULL;
END;
$$;

-- Function to update channel updated_at timestamp
CREATE OR REPLACE FUNCTION public.update_channel_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;

-- 9. Enable RLS
ALTER TABLE public.channels ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.channel_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.channel_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.channel_message_views ENABLE ROW LEVEL SECURITY;

-- 10. RLS Policies

-- Channels Policies
CREATE POLICY "public_can_view_public_channels"
ON public.channels
FOR SELECT
TO authenticated
USING (type = 'public'::public.channel_type);

CREATE POLICY "subscribers_can_view_private_channels"
ON public.channels
FOR SELECT
TO authenticated
USING (
    type = 'private'::public.channel_type
    AND public.is_channel_subscriber(id)
);

CREATE POLICY "users_can_create_channels"
ON public.channels
FOR INSERT
TO authenticated
WITH CHECK (creator_id = auth.uid());

CREATE POLICY "admins_can_update_channels"
ON public.channels
FOR UPDATE
TO authenticated
USING (public.is_channel_admin(id))
WITH CHECK (public.is_channel_admin(id));

CREATE POLICY "owners_can_delete_channels"
ON public.channels
FOR DELETE
TO authenticated
USING (
    EXISTS (
        SELECT 1 FROM public.channel_users cu
        WHERE cu.channel_id = id
        AND cu.user_id = auth.uid()
        AND cu.role = 'owner'::public.channel_role
    )
);

-- Channel Users Policies
CREATE POLICY "users_can_view_channel_members"
ON public.channel_users
FOR SELECT
TO authenticated
USING (public.is_channel_subscriber(channel_id));

CREATE POLICY "users_can_subscribe_to_channels"
ON public.channel_users
FOR INSERT
TO authenticated
WITH CHECK (user_id = auth.uid() AND role = 'subscriber'::public.channel_role);

CREATE POLICY "admins_can_manage_channel_members"
ON public.channel_users
FOR ALL
TO authenticated
USING (public.is_channel_admin(channel_id))
WITH CHECK (public.is_channel_admin(channel_id));

CREATE POLICY "users_can_unsubscribe_from_channels"
ON public.channel_users
FOR DELETE
TO authenticated
USING (user_id = auth.uid());

-- Channel Messages Policies
CREATE POLICY "subscribers_can_view_channel_messages"
ON public.channel_messages
FOR SELECT
TO authenticated
USING (public.is_channel_subscriber(channel_id));

CREATE POLICY "admins_can_create_channel_messages"
ON public.channel_messages
FOR INSERT
TO authenticated
WITH CHECK (
    sender_id = auth.uid()
    AND public.is_channel_admin(channel_id)
);

CREATE POLICY "admins_can_update_channel_messages"
ON public.channel_messages
FOR UPDATE
TO authenticated
USING (public.is_channel_admin(channel_id))
WITH CHECK (public.is_channel_admin(channel_id));

CREATE POLICY "admins_can_delete_channel_messages"
ON public.channel_messages
FOR DELETE
TO authenticated
USING (public.is_channel_admin(channel_id));

-- Channel Message Views Policies
CREATE POLICY "users_can_view_own_message_views"
ON public.channel_message_views
FOR SELECT
TO authenticated
USING (user_id = auth.uid());

CREATE POLICY "users_can_record_message_views"
ON public.channel_message_views
FOR INSERT
TO authenticated
WITH CHECK (user_id = auth.uid());

-- 11. Create triggers
CREATE TRIGGER channel_subscribers_count_trigger
    AFTER INSERT OR DELETE ON public.channel_users
    FOR EACH ROW
    EXECUTE FUNCTION public.update_channel_subscribers_count();

CREATE TRIGGER channel_messages_count_trigger
    AFTER INSERT OR DELETE ON public.channel_messages
    FOR EACH ROW
    EXECUTE FUNCTION public.update_channel_messages_count();

CREATE TRIGGER message_views_count_trigger
    AFTER INSERT ON public.channel_message_views
    FOR EACH ROW
    EXECUTE FUNCTION public.update_message_views_count();

CREATE TRIGGER channel_updated_at_trigger
    BEFORE UPDATE ON public.channels
    FOR EACH ROW
    EXECUTE FUNCTION public.update_channel_updated_at();

-- 12. Mock Data
DO $$
DECLARE
    existing_user_id UUID;
    second_user_id UUID;
    tech_channel_id UUID := gen_random_uuid();
    news_channel_id UUID := gen_random_uuid();
    private_channel_id UUID := gen_random_uuid();
    message_id_1 UUID := gen_random_uuid();
    message_id_2 UUID := gen_random_uuid();
    message_id_3 UUID := gen_random_uuid();
BEGIN
    -- Get existing users
    SELECT id INTO existing_user_id FROM public.profiles ORDER BY created_at LIMIT 1;
    SELECT id INTO second_user_id FROM public.profiles WHERE id != existing_user_id ORDER BY created_at LIMIT 1;

    IF existing_user_id IS NOT NULL THEN
        -- Create sample channels
        INSERT INTO public.channels (id, name, description, type, username, creator_id, is_verified)
        VALUES
            (
                tech_channel_id,
                'Tech Updates',
                'Latest technology news and updates',
                'public'::public.channel_type,
                'tech_updates',
                existing_user_id,
                true
            ),
            (
                news_channel_id,
                'Daily News',
                'Breaking news and current events',
                'public'::public.channel_type,
                'daily_news',
                existing_user_id,
                true
            ),
            (
                private_channel_id,
                'Team Announcements',
                'Private channel for team updates',
                'private'::public.channel_type,
                'team_announcements',
                existing_user_id,
                false
            );

        -- Add channel creator as owner
        INSERT INTO public.channel_users (channel_id, user_id, role)
        VALUES
            (tech_channel_id, existing_user_id, 'owner'::public.channel_role),
            (news_channel_id, existing_user_id, 'owner'::public.channel_role),
            (private_channel_id, existing_user_id, 'owner'::public.channel_role);

        -- Add second user as subscriber if exists
        IF second_user_id IS NOT NULL THEN
            INSERT INTO public.channel_users (channel_id, user_id, role)
            VALUES
                (tech_channel_id, second_user_id, 'subscriber'::public.channel_role),
                (news_channel_id, second_user_id, 'subscriber'::public.channel_role);
        END IF;

        -- Create sample channel messages
        INSERT INTO public.channel_messages (id, channel_id, sender_id, text_content)
        VALUES
            (
                message_id_1,
                tech_channel_id,
                existing_user_id,
                'Welcome to Tech Updates! Stay tuned for the latest technology news and innovations.'
            ),
            (
                message_id_2,
                tech_channel_id,
                existing_user_id,
                'Breaking: New AI breakthrough announced today. Revolutionary changes in machine learning algorithms.'
            ),
            (
                message_id_3,
                news_channel_id,
                existing_user_id,
                'Good morning! Here are today''s top headlines from around the world.'
            );

        -- Record message views if second user exists
        IF second_user_id IS NOT NULL THEN
            INSERT INTO public.channel_message_views (message_id, user_id)
            VALUES
                (message_id_1, second_user_id),
                (message_id_2, second_user_id);
        END IF;

        RAISE NOTICE 'Channels feature mock data created successfully';
    ELSE
        RAISE NOTICE 'No existing users found. Run auth migration first.';
    END IF;
END $$;