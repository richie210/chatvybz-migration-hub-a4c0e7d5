-- Stripe Channel Monetization Migration
-- Implements premium channel subscriptions, ad revenue splits, and payment processing

-- 1. Create subscription tier enum
CREATE TYPE public.subscription_tier AS ENUM ('free', 'premium', 'pro');

-- 2. Create subscription status enum
CREATE TYPE public.subscription_status AS ENUM ('active', 'canceled', 'past_due', 'trialing', 'incomplete');

-- 3. Create payout status enum
CREATE TYPE public.payout_status AS ENUM ('pending', 'processing', 'paid', 'failed');

-- 4. Channel Subscription Tiers Table
CREATE TABLE public.channel_subscription_tiers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    channel_id UUID NOT NULL REFERENCES public.channels(id) ON DELETE CASCADE,
    tier public.subscription_tier NOT NULL,
    name TEXT NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL DEFAULT 0,
    currency TEXT DEFAULT 'USD',
    billing_interval TEXT DEFAULT 'month' CHECK (billing_interval IN ('month', 'year')),
    features JSONB DEFAULT '[]',
    is_active BOOLEAN DEFAULT true,
    stripe_price_id TEXT,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(channel_id, tier)
);

-- 5. Channel Subscriptions Table (User Premium Subscriptions)
CREATE TABLE public.channel_subscriptions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    channel_id UUID NOT NULL REFERENCES public.channels(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    tier_id UUID NOT NULL REFERENCES public.channel_subscription_tiers(id) ON DELETE CASCADE,
    status public.subscription_status DEFAULT 'active',
    stripe_subscription_id TEXT UNIQUE,
    stripe_customer_id TEXT,
    current_period_start TIMESTAMPTZ,
    current_period_end TIMESTAMPTZ,
    cancel_at_period_end BOOLEAN DEFAULT false,
    canceled_at TIMESTAMPTZ,
    trial_start TIMESTAMPTZ,
    trial_end TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(channel_id, user_id)
);

-- 6. Stripe Customers Table (Mapping)
CREATE TABLE public.stripe_customers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    stripe_customer_id TEXT UNIQUE NOT NULL,
    email TEXT,
    name TEXT,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id)
);

-- 7. Channel Revenue Splits Table
CREATE TABLE public.channel_revenue_splits (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    channel_id UUID NOT NULL REFERENCES public.channels(id) ON DELETE CASCADE,
    revenue_type TEXT NOT NULL CHECK (revenue_type IN ('subscription', 'ad_revenue', 'donation')),
    total_amount DECIMAL(10, 2) NOT NULL,
    platform_fee DECIMAL(10, 2) NOT NULL,
    creator_earnings DECIMAL(10, 2) NOT NULL,
    currency TEXT DEFAULT 'USD',
    period_start TIMESTAMPTZ NOT NULL,
    period_end TIMESTAMPTZ NOT NULL,
    transaction_count INTEGER DEFAULT 0,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 8. Ad Revenue Distribution Table
CREATE TABLE public.ad_revenue_distribution (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    channel_id UUID NOT NULL REFERENCES public.channels(id) ON DELETE CASCADE,
    ad_id UUID REFERENCES public.admin_ads(id) ON DELETE SET NULL,
    impressions_count INTEGER DEFAULT 0,
    clicks_count INTEGER DEFAULT 0,
    revenue_amount DECIMAL(10, 2) DEFAULT 0,
    creator_share DECIMAL(10, 2) DEFAULT 0,
    platform_share DECIMAL(10, 2) DEFAULT 0,
    currency TEXT DEFAULT 'USD',
    date DATE NOT NULL,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(channel_id, ad_id, date)
);

-- 9. Creator Payouts Table
CREATE TABLE public.creator_payouts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    channel_id UUID NOT NULL REFERENCES public.channels(id) ON DELETE CASCADE,
    creator_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    amount DECIMAL(10, 2) NOT NULL,
    currency TEXT DEFAULT 'USD',
    status public.payout_status DEFAULT 'pending',
    stripe_payout_id TEXT,
    stripe_connect_account_id TEXT,
    period_start TIMESTAMPTZ NOT NULL,
    period_end TIMESTAMPTZ NOT NULL,
    revenue_breakdown JSONB DEFAULT '{}',
    paid_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 10. Payment Webhook Events Table
CREATE TABLE public.stripe_webhook_events (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    stripe_event_id TEXT UNIQUE NOT NULL,
    event_type TEXT NOT NULL,
    payload JSONB NOT NULL,
    processed BOOLEAN DEFAULT false,
    processed_at TIMESTAMPTZ,
    error_message TEXT,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 11. Create indexes
CREATE INDEX idx_channel_subscription_tiers_channel_id ON public.channel_subscription_tiers(channel_id);
CREATE INDEX idx_channel_subscription_tiers_tier ON public.channel_subscription_tiers(tier);
CREATE INDEX idx_channel_subscriptions_channel_id ON public.channel_subscriptions(channel_id);
CREATE INDEX idx_channel_subscriptions_user_id ON public.channel_subscriptions(user_id);
CREATE INDEX idx_channel_subscriptions_status ON public.channel_subscriptions(status);
CREATE INDEX idx_channel_subscriptions_stripe_subscription_id ON public.channel_subscriptions(stripe_subscription_id);
CREATE INDEX idx_stripe_customers_user_id ON public.stripe_customers(user_id);
CREATE INDEX idx_stripe_customers_stripe_customer_id ON public.stripe_customers(stripe_customer_id);
CREATE INDEX idx_channel_revenue_splits_channel_id ON public.channel_revenue_splits(channel_id);
CREATE INDEX idx_channel_revenue_splits_period ON public.channel_revenue_splits(period_start, period_end);
CREATE INDEX idx_ad_revenue_distribution_channel_id ON public.ad_revenue_distribution(channel_id);
CREATE INDEX idx_ad_revenue_distribution_date ON public.ad_revenue_distribution(date);
CREATE INDEX idx_creator_payouts_channel_id ON public.creator_payouts(channel_id);
CREATE INDEX idx_creator_payouts_creator_id ON public.creator_payouts(creator_id);
CREATE INDEX idx_creator_payouts_status ON public.creator_payouts(status);
CREATE INDEX idx_stripe_webhook_events_event_type ON public.stripe_webhook_events(event_type);
CREATE INDEX idx_stripe_webhook_events_processed ON public.stripe_webhook_events(processed);

-- 12. Create functions

-- Function to calculate platform fee (20% platform cut)
CREATE OR REPLACE FUNCTION public.calculate_platform_fee(amount DECIMAL)
RETURNS DECIMAL
LANGUAGE sql
IMMUTABLE
AS $$
    SELECT ROUND(amount * 0.20, 2)
$$;

-- Function to calculate creator earnings (80% to creator)
CREATE OR REPLACE FUNCTION public.calculate_creator_earnings(amount DECIMAL)
RETURNS DECIMAL
LANGUAGE sql
IMMUTABLE
AS $$
    SELECT ROUND(amount * 0.80, 2)
$$;

-- Function to update channel subscription tier on channels table
CREATE OR REPLACE FUNCTION public.update_channel_premium_status()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
    -- Add premium badge or status to channel if it has active premium tiers
    IF TG_OP = 'INSERT' OR TG_OP = 'UPDATE' THEN
        UPDATE public.channels
        SET updated_at = CURRENT_TIMESTAMP
        WHERE id = NEW.channel_id;
    END IF;
    RETURN NEW;
END;
$$;

-- Function to track subscription revenue
CREATE OR REPLACE FUNCTION public.track_subscription_revenue()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
    tier_price DECIMAL;
    tier_currency TEXT;
BEGIN
    IF TG_OP = 'INSERT' AND NEW.status = 'active' THEN
        -- Get tier price
        SELECT price, currency INTO tier_price, tier_currency
        FROM public.channel_subscription_tiers
        WHERE id = NEW.tier_id;

        -- Create revenue split record
        INSERT INTO public.channel_revenue_splits (
            channel_id,
            revenue_type,
            total_amount,
            platform_fee,
            creator_earnings,
            currency,
            period_start,
            period_end,
            transaction_count
        ) VALUES (
            NEW.channel_id,
            'subscription',
            tier_price,
            public.calculate_platform_fee(tier_price),
            public.calculate_creator_earnings(tier_price),
            tier_currency,
            NEW.current_period_start,
            NEW.current_period_end,
            1
        )
        ON CONFLICT (channel_id, period_start, period_end)
        DO UPDATE SET
            total_amount = channel_revenue_splits.total_amount + tier_price,
            platform_fee = public.calculate_platform_fee(channel_revenue_splits.total_amount + tier_price),
            creator_earnings = public.calculate_creator_earnings(channel_revenue_splits.total_amount + tier_price),
            transaction_count = channel_revenue_splits.transaction_count + 1;
    END IF;
    RETURN NEW;
END;
$$;

-- Function to update timestamps
CREATE OR REPLACE FUNCTION public.update_stripe_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;

-- 13. Create triggers

-- Trigger to update channel when subscription tier is added
CREATE TRIGGER trigger_update_channel_premium_status
AFTER INSERT OR UPDATE ON public.channel_subscription_tiers
FOR EACH ROW
EXECUTE FUNCTION public.update_channel_premium_status();

-- Trigger to track subscription revenue
CREATE TRIGGER trigger_track_subscription_revenue
AFTER INSERT OR UPDATE ON public.channel_subscriptions
FOR EACH ROW
EXECUTE FUNCTION public.track_subscription_revenue();

-- Trigger to update timestamps
CREATE TRIGGER trigger_update_channel_subscription_tiers_updated_at
BEFORE UPDATE ON public.channel_subscription_tiers
FOR EACH ROW
EXECUTE FUNCTION public.update_stripe_updated_at();

CREATE TRIGGER trigger_update_channel_subscriptions_updated_at
BEFORE UPDATE ON public.channel_subscriptions
FOR EACH ROW
EXECUTE FUNCTION public.update_stripe_updated_at();

CREATE TRIGGER trigger_update_stripe_customers_updated_at
BEFORE UPDATE ON public.stripe_customers
FOR EACH ROW
EXECUTE FUNCTION public.update_stripe_updated_at();

CREATE TRIGGER trigger_update_creator_payouts_updated_at
BEFORE UPDATE ON public.creator_payouts
FOR EACH ROW
EXECUTE FUNCTION public.update_stripe_updated_at();

-- 14. Enable RLS
ALTER TABLE public.channel_subscription_tiers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.channel_subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.stripe_customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.channel_revenue_splits ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ad_revenue_distribution ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.creator_payouts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.stripe_webhook_events ENABLE ROW LEVEL SECURITY;

-- 15. RLS Policies

-- Channel Subscription Tiers Policies
CREATE POLICY "anyone_can_view_active_subscription_tiers"
ON public.channel_subscription_tiers
FOR SELECT
TO authenticated
USING (is_active = true);

CREATE POLICY "channel_admins_can_manage_subscription_tiers"
ON public.channel_subscription_tiers
FOR ALL
TO authenticated
USING (public.is_channel_admin(channel_id))
WITH CHECK (public.is_channel_admin(channel_id));

-- Channel Subscriptions Policies
CREATE POLICY "users_can_view_own_subscriptions"
ON public.channel_subscriptions
FOR SELECT
TO authenticated
USING (user_id = auth.uid());

CREATE POLICY "channel_admins_can_view_channel_subscriptions"
ON public.channel_subscriptions
FOR SELECT
TO authenticated
USING (public.is_channel_admin(channel_id));

CREATE POLICY "users_can_create_own_subscriptions"
ON public.channel_subscriptions
FOR INSERT
TO authenticated
WITH CHECK (user_id = auth.uid());

CREATE POLICY "users_can_update_own_subscriptions"
ON public.channel_subscriptions
FOR UPDATE
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

-- Stripe Customers Policies
CREATE POLICY "users_can_view_own_stripe_customer"
ON public.stripe_customers
FOR SELECT
TO authenticated
USING (user_id = auth.uid());

CREATE POLICY "users_can_manage_own_stripe_customer"
ON public.stripe_customers
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

-- Channel Revenue Splits Policies
CREATE POLICY "channel_creators_can_view_revenue_splits"
ON public.channel_revenue_splits
FOR SELECT
TO authenticated
USING (
    EXISTS (
        SELECT 1 FROM public.channels c
        WHERE c.id = channel_id
        AND c.creator_id = auth.uid()
    )
);

-- Ad Revenue Distribution Policies
CREATE POLICY "channel_creators_can_view_ad_revenue"
ON public.ad_revenue_distribution
FOR SELECT
TO authenticated
USING (
    EXISTS (
        SELECT 1 FROM public.channels c
        WHERE c.id = channel_id
        AND c.creator_id = auth.uid()
    )
);

-- Creator Payouts Policies
CREATE POLICY "creators_can_view_own_payouts"
ON public.creator_payouts
FOR SELECT
TO authenticated
USING (creator_id = auth.uid());

-- Stripe Webhook Events Policies (Admin only - no public access)
CREATE POLICY "no_public_access_to_webhook_events"
ON public.stripe_webhook_events
FOR ALL
TO authenticated
USING (false);

-- 16. Add Stripe Connect account to profiles
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS stripe_connect_account_id TEXT;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS stripe_connect_onboarded BOOLEAN DEFAULT false;

-- 17. Add premium features to channels
ALTER TABLE public.channels ADD COLUMN IF NOT EXISTS has_premium_tiers BOOLEAN DEFAULT false;
ALTER TABLE public.channels ADD COLUMN IF NOT EXISTS premium_subscribers_count INTEGER DEFAULT 0;

-- 18. Create constraint for revenue splits uniqueness
ALTER TABLE public.channel_revenue_splits ADD CONSTRAINT unique_channel_revenue_period 
    UNIQUE (channel_id, revenue_type, period_start, period_end);

DO $$
BEGIN
    RAISE NOTICE 'Stripe Channel Monetization Migration completed successfully';
    RAISE NOTICE 'Created tables: channel_subscription_tiers, channel_subscriptions, stripe_customers, channel_revenue_splits, ad_revenue_distribution, creator_payouts, stripe_webhook_events';
    RAISE NOTICE 'Platform fee: 20%% | Creator earnings: 80%%';
END $$;