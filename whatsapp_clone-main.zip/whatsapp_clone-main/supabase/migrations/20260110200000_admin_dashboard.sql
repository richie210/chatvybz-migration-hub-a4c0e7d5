-- Admin Dashboard Migration
-- Privacy-focused analytics and administration system

-- 1. Extend profiles table with admin role support
ALTER TABLE public.profiles
ADD COLUMN IF NOT EXISTS is_admin BOOLEAN DEFAULT false;

-- Set chatvybz@gmail.com as admin
DO $$
BEGIN
    UPDATE public.profiles
    SET is_admin = true
    WHERE email = 'chatvybz@gmail.com';
    
    IF NOT FOUND THEN
        RAISE NOTICE 'Admin email chatvybz@gmail.com not found in profiles. Will be set when user registers.';
    END IF;
END $$;

-- 2. Daily Message Volume Table (Privacy-focused aggregation)
CREATE TABLE IF NOT EXISTS public.daily_message_volume (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    day DATE NOT NULL,
    country_code TEXT,
    message_count INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(day, country_code)
);

CREATE INDEX idx_daily_message_volume_day ON public.daily_message_volume(day);
CREATE INDEX idx_daily_message_volume_country ON public.daily_message_volume(country_code);

-- 3. Admin Ads Table (Broadcast announcements and advertisements)
CREATE TABLE IF NOT EXISTS public.admin_ads (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    ad_type TEXT NOT NULL CHECK (ad_type IN ('banner', 'video_30s', 'text_announcement')),
    media_url TEXT,
    target_url TEXT,
    title TEXT NOT NULL,
    description TEXT,
    start_date TIMESTAMPTZ NOT NULL,
    end_date TIMESTAMPTZ NOT NULL,
    target_countries TEXT[] DEFAULT '{}',
    impressions_count INTEGER DEFAULT 0,
    clicks_count INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT true,
    created_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    CHECK (end_date > start_date)
);

CREATE INDEX idx_admin_ads_dates ON public.admin_ads(start_date, end_date);
CREATE INDEX idx_admin_ads_active ON public.admin_ads(is_active);

-- 4. Ad Click Tracking Table
CREATE TABLE IF NOT EXISTS public.ad_click_tracking (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    ad_id UUID REFERENCES public.admin_ads(id) ON DELETE CASCADE,
    user_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    clicked_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    user_country_code TEXT,
    user_agent TEXT
);

CREATE INDEX idx_ad_click_tracking_ad_id ON public.ad_click_tracking(ad_id);
CREATE INDEX idx_ad_click_tracking_clicked_at ON public.ad_click_tracking(clicked_at);

-- 5. Ad Impression Tracking Table
CREATE TABLE IF NOT EXISTS public.ad_impression_tracking (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    ad_id UUID REFERENCES public.admin_ads(id) ON DELETE CASCADE,
    user_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    viewed_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    user_country_code TEXT
);

CREATE INDEX idx_ad_impression_tracking_ad_id ON public.ad_impression_tracking(ad_id);
CREATE INDEX idx_ad_impression_tracking_viewed_at ON public.ad_impression_tracking(viewed_at);

-- 6. User Ban Status Table
CREATE TABLE IF NOT EXISTS public.user_ban_status (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE UNIQUE,
    is_banned BOOLEAN DEFAULT false,
    is_suspended BOOLEAN DEFAULT false,
    ban_reason TEXT,
    suspension_reason TEXT,
    banned_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    suspended_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    banned_at TIMESTAMPTZ,
    suspended_at TIMESTAMPTZ,
    suspension_until TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_user_ban_status_user_id ON public.user_ban_status(user_id);
CREATE INDEX idx_user_ban_status_banned ON public.user_ban_status(is_banned);
CREATE INDEX idx_user_ban_status_suspended ON public.user_ban_status(is_suspended);

-- 7. Functions

-- Function to check if user is admin
CREATE OR REPLACE FUNCTION public.is_admin()
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
    SELECT EXISTS (
        SELECT 1 FROM public.profiles
        WHERE id = auth.uid() AND is_admin = true
    )
$$;

-- Function to increment message count (called by message service)
CREATE OR REPLACE FUNCTION public.increment_daily_message_count(
    p_country_code TEXT DEFAULT NULL
)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_today DATE := CURRENT_DATE;
BEGIN
    INSERT INTO public.daily_message_volume (day, country_code, message_count)
    VALUES (v_today, p_country_code, 1)
    ON CONFLICT (day, country_code)
    DO UPDATE SET
        message_count = public.daily_message_volume.message_count + 1,
        updated_at = CURRENT_TIMESTAMP;
END;
$$;

-- Function to get active ads for user
CREATE OR REPLACE FUNCTION public.get_active_ad_for_user(
    p_user_country_code TEXT DEFAULT NULL
)
RETURNS TABLE (
    ad_id UUID,
    ad_type TEXT,
    media_url TEXT,
    target_url TEXT,
    title TEXT,
    description TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    RETURN QUERY
    SELECT
        a.id,
        a.ad_type,
        a.media_url,
        a.target_url,
        a.title,
        a.description
    FROM public.admin_ads a
    WHERE a.is_active = true
        AND CURRENT_TIMESTAMP BETWEEN a.start_date AND a.end_date
        AND (
            a.target_countries = '{}'
            OR p_user_country_code = ANY(a.target_countries)
        )
    ORDER BY RANDOM()
    LIMIT 1;
END;
$$;

-- 8. Enable RLS
ALTER TABLE public.daily_message_volume ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.admin_ads ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ad_click_tracking ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ad_impression_tracking ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_ban_status ENABLE ROW LEVEL SECURITY;

-- 9. RLS Policies

-- Daily Message Volume: Admin only
CREATE POLICY "admin_full_access_daily_message_volume"
ON public.daily_message_volume
FOR ALL
TO authenticated
USING (public.is_admin())
WITH CHECK (public.is_admin());

-- Admin Ads: Admin can manage, users can view active ads
CREATE POLICY "admin_manage_ads"
ON public.admin_ads
FOR ALL
TO authenticated
USING (public.is_admin())
WITH CHECK (public.is_admin());

CREATE POLICY "users_view_active_ads"
ON public.admin_ads
FOR SELECT
TO authenticated
USING (
    is_active = true
    AND CURRENT_TIMESTAMP BETWEEN start_date AND end_date
);

-- Ad Click Tracking: Users can insert their own clicks, admin can view all
CREATE POLICY "users_track_own_ad_clicks"
ON public.ad_click_tracking
FOR INSERT
TO authenticated
WITH CHECK (user_id = auth.uid());

CREATE POLICY "admin_view_all_ad_clicks"
ON public.ad_click_tracking
FOR SELECT
TO authenticated
USING (public.is_admin());

-- Ad Impression Tracking: Users can insert their own impressions, admin can view all
CREATE POLICY "users_track_own_ad_impressions"
ON public.ad_impression_tracking
FOR INSERT
TO authenticated
WITH CHECK (user_id = auth.uid());

CREATE POLICY "admin_view_all_ad_impressions"
ON public.ad_impression_tracking
FOR SELECT
TO authenticated
USING (public.is_admin());

-- User Ban Status: Admin only
CREATE POLICY "admin_manage_user_bans"
ON public.user_ban_status
FOR ALL
TO authenticated
USING (public.is_admin())
WITH CHECK (public.is_admin());

-- 10. Triggers

-- Auto-update updated_at timestamp
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;

CREATE TRIGGER update_daily_message_volume_updated_at
    BEFORE UPDATE ON public.daily_message_volume
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_admin_ads_updated_at
    BEFORE UPDATE ON public.admin_ads
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_user_ban_status_updated_at
    BEFORE UPDATE ON public.user_ban_status
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

-- Trigger to update ad impression count
CREATE OR REPLACE FUNCTION public.increment_ad_impressions()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    UPDATE public.admin_ads
    SET impressions_count = impressions_count + 1
    WHERE id = NEW.ad_id;
    RETURN NEW;
END;
$$;

CREATE TRIGGER on_ad_impression_tracked
    AFTER INSERT ON public.ad_impression_tracking
    FOR EACH ROW
    EXECUTE FUNCTION public.increment_ad_impressions();

-- Trigger to update ad click count
CREATE OR REPLACE FUNCTION public.increment_ad_clicks()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    UPDATE public.admin_ads
    SET clicks_count = clicks_count + 1
    WHERE id = NEW.ad_id;
    RETURN NEW;
END;
$$;

CREATE TRIGGER on_ad_click_tracked
    AFTER INSERT ON public.ad_click_tracking
    FOR EACH ROW
    EXECUTE FUNCTION public.increment_ad_clicks();

-- 11. Mock Data
DO $$
DECLARE
    admin_user_id UUID;
    sample_ad_id UUID := gen_random_uuid();
    v_date DATE;
BEGIN
    -- Get or create admin user
    SELECT id INTO admin_user_id
    FROM public.profiles
    WHERE email = 'chatvybz@gmail.com'
    LIMIT 1;

    -- If admin doesn't exist yet, create sample data with placeholder
    IF admin_user_id IS NULL THEN
        RAISE NOTICE 'Admin user not found. Sample data will be created when admin registers.';
    ELSE
        -- Create sample message volume data (last 30 days)
        FOR i IN 0..29 LOOP
            v_date := CURRENT_DATE - i;
            
            INSERT INTO public.daily_message_volume (day, country_code, message_count)
            VALUES
                (v_date, 'US', floor(random() * 500 + 100)::INTEGER),
                (v_date, 'GB', floor(random() * 300 + 50)::INTEGER),
                (v_date, 'CA', floor(random() * 200 + 30)::INTEGER),
                (v_date, 'AU', floor(random() * 150 + 20)::INTEGER),
                (v_date, NULL, floor(random() * 1000 + 200)::INTEGER)
            ON CONFLICT (day, country_code) DO NOTHING;
        END LOOP;

        -- Create sample ad
        INSERT INTO public.admin_ads (
            id, ad_type, title, description, media_url, target_url,
            start_date, end_date, target_countries, is_active, created_by
        ) VALUES (
            sample_ad_id,
            'banner',
            'Welcome to ChatVybz Premium',
            'Upgrade to Premium for unlimited features and ad-free experience',
            'https://images.unsplash.com/photo-1557804506-669a67965ba0?w=800',
            'https://chatvybz.com/premium',
            CURRENT_TIMESTAMP - INTERVAL '7 days',
            CURRENT_TIMESTAMP + INTERVAL '30 days',
            ARRAY['US', 'GB', 'CA', 'AU'],
            true,
            admin_user_id
        );

        RAISE NOTICE 'Admin dashboard sample data created successfully';
    END IF;
END $$;