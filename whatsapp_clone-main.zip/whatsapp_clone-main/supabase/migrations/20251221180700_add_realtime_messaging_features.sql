-- Location: supabase/migrations/20251221180700_add_realtime_messaging_features.sql
-- Schema Analysis: chat_messages table exists, profiles table exists
-- Integration Type: extension
-- Dependencies: chat_messages, profiles

-- 1. Extend chat_messages table with message status tracking
ALTER TABLE public.chat_messages
ADD COLUMN status TEXT DEFAULT 'sent',
ADD COLUMN delivered_at TIMESTAMPTZ,
ADD COLUMN read_at TIMESTAMPTZ;

-- Add index for status queries
CREATE INDEX idx_chat_messages_status ON public.chat_messages(status);
CREATE INDEX idx_chat_messages_sender_status ON public.chat_messages(sender_id, status);

-- 2. Create typing_indicators table for real-time typing updates
CREATE TABLE public.typing_indicators (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
    conversation_id TEXT NOT NULL,
    is_typing BOOLEAN DEFAULT false,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Add indexes for typing indicators
CREATE INDEX idx_typing_indicators_conversation ON public.typing_indicators(conversation_id);
CREATE INDEX idx_typing_indicators_user ON public.typing_indicators(user_id);
CREATE UNIQUE INDEX idx_typing_indicators_user_conversation ON public.typing_indicators(user_id, conversation_id);

-- 3. Enable RLS on typing_indicators
ALTER TABLE public.typing_indicators ENABLE ROW LEVEL SECURITY;

-- 4. RLS Policies for typing_indicators
CREATE POLICY "users_manage_own_typing_indicators"
ON public.typing_indicators
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

CREATE POLICY "users_view_all_typing_indicators"
ON public.typing_indicators
FOR SELECT
TO authenticated
USING (true);

-- 5. Function to update message status
CREATE OR REPLACE FUNCTION public.update_message_status(
    message_uuid UUID,
    new_status TEXT
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    IF new_status = 'delivered' THEN
        UPDATE public.chat_messages
        SET status = new_status, delivered_at = CURRENT_TIMESTAMP
        WHERE id = message_uuid;
    ELSIF new_status = 'read' THEN
        UPDATE public.chat_messages
        SET status = new_status, read_at = CURRENT_TIMESTAMP, delivered_at = COALESCE(delivered_at, CURRENT_TIMESTAMP)
        WHERE id = message_uuid;
    ELSE
        UPDATE public.chat_messages
        SET status = new_status
        WHERE id = message_uuid;
    END IF;
END;
$$;

-- 6. Function to update typing indicator
CREATE OR REPLACE FUNCTION public.update_typing_indicator(
    conversation_id_param TEXT,
    is_typing_param BOOLEAN
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    INSERT INTO public.typing_indicators (user_id, conversation_id, is_typing, updated_at)
    VALUES (auth.uid(), conversation_id_param, is_typing_param, CURRENT_TIMESTAMP)
    ON CONFLICT (user_id, conversation_id)
    DO UPDATE SET is_typing = is_typing_param, updated_at = CURRENT_TIMESTAMP;
END;
$$;

-- 7. Trigger to auto-clean old typing indicators
CREATE OR REPLACE FUNCTION public.clean_old_typing_indicators()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
    DELETE FROM public.typing_indicators
    WHERE updated_at < CURRENT_TIMESTAMP - INTERVAL '10 seconds' AND is_typing = false;
    RETURN NEW;
END;
$$;

CREATE TRIGGER typing_indicators_cleanup
    AFTER INSERT OR UPDATE ON public.typing_indicators
    FOR EACH STATEMENT
    EXECUTE FUNCTION public.clean_old_typing_indicators();