-- Migration: Message Attachments and Forwarding Support
-- Description: Adds file attachment support and message forwarding metadata

-- Create message_attachments table for file sharing
CREATE TABLE public.message_attachments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    message_id UUID REFERENCES public.chat_messages(id) ON DELETE CASCADE,
    file_name TEXT NOT NULL,
    file_type TEXT NOT NULL,
    file_size BIGINT NOT NULL,
    file_url TEXT NOT NULL,
    thumbnail_url TEXT,
    mime_type TEXT,
    duration INTEGER,
    width INTEGER,
    height INTEGER,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Add forwarding metadata to chat_messages
ALTER TABLE public.chat_messages
ADD COLUMN IF NOT EXISTS forwarded_from_message_id UUID REFERENCES public.chat_messages(id) ON DELETE SET NULL,
ADD COLUMN IF NOT EXISTS forwarded_from_user_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
ADD COLUMN IF NOT EXISTS forwarded_at TIMESTAMPTZ,
ADD COLUMN IF NOT EXISTS is_forwarded BOOLEAN DEFAULT false;

-- Create indexes for performance
CREATE INDEX idx_message_attachments_message_id ON public.message_attachments(message_id);
CREATE INDEX idx_chat_messages_forwarded_from ON public.chat_messages(forwarded_from_message_id);
CREATE INDEX idx_chat_messages_is_forwarded ON public.chat_messages(is_forwarded);

-- Enable RLS
ALTER TABLE public.message_attachments ENABLE ROW LEVEL SECURITY;

-- RLS policies for message_attachments
CREATE POLICY "users_can_view_message_attachments"
ON public.message_attachments
FOR SELECT
TO authenticated
USING (
    EXISTS (
        SELECT 1 FROM public.chat_messages cm
        WHERE cm.id = message_id
        AND (cm.sender_id = auth.uid() OR cm.recipient_id = auth.uid())
    )
);

CREATE POLICY "users_can_create_message_attachments"
ON public.message_attachments
FOR INSERT
TO authenticated
WITH CHECK (
    EXISTS (
        SELECT 1 FROM public.chat_messages cm
        WHERE cm.id = message_id
        AND cm.sender_id = auth.uid()
    )
);

CREATE POLICY "users_can_delete_own_message_attachments"
ON public.message_attachments
FOR DELETE
TO authenticated
USING (
    EXISTS (
        SELECT 1 FROM public.chat_messages cm
        WHERE cm.id = message_id
        AND cm.sender_id = auth.uid()
    )
);

-- Create storage bucket for message attachments
INSERT INTO storage.buckets (id, name, public)
VALUES ('message-attachments', 'message-attachments', false)
ON CONFLICT (id) DO NOTHING;

-- Storage RLS policies
CREATE POLICY "users_can_upload_message_attachments"
ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (
    bucket_id = 'message-attachments'
    AND (storage.foldername(name))[1] = auth.uid()::text
);

CREATE POLICY "users_can_view_message_attachments"
ON storage.objects
FOR SELECT
TO authenticated
USING (
    bucket_id = 'message-attachments'
);

CREATE POLICY "users_can_delete_own_message_attachments"
ON storage.objects
FOR DELETE
TO authenticated
USING (
    bucket_id = 'message-attachments'
    AND (storage.foldername(name))[1] = auth.uid()::text
);

-- Function to get message with attachments
CREATE OR REPLACE FUNCTION public.get_message_with_attachments(message_uuid UUID)
RETURNS TABLE(
    message_id UUID,
    message_content TEXT,
    sender_id UUID,
    recipient_id UUID,
    created_at TIMESTAMPTZ,
    is_forwarded BOOLEAN,
    forwarded_from_user_name TEXT,
    attachment_count BIGINT,
    attachments JSONB
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    RETURN QUERY
    SELECT
        cm.id,
        cm.message,
        cm.sender_id,
        cm.recipient_id,
        cm.created_at,
        cm.is_forwarded,
        p.full_name::TEXT,
        COUNT(ma.id),
        COALESCE(
            jsonb_agg(
                jsonb_build_object(
                    'id', ma.id,
                    'fileName', ma.file_name,
                    'fileType', ma.file_type,
                    'fileSize', ma.file_size,
                    'fileUrl', ma.file_url,
                    'thumbnailUrl', ma.thumbnail_url,
                    'mimeType', ma.mime_type,
                    'duration', ma.duration,
                    'width', ma.width,
                    'height', ma.height
                )
            ) FILTER (WHERE ma.id IS NOT NULL),
            '[]'::jsonb
        )
    FROM public.chat_messages cm
    LEFT JOIN public.message_attachments ma ON cm.id = ma.message_id
    LEFT JOIN public.profiles p ON cm.forwarded_from_user_id = p.id
    WHERE cm.id = message_uuid
    GROUP BY cm.id, cm.message, cm.sender_id, cm.recipient_id, cm.created_at, cm.is_forwarded, p.full_name;
END;
$$;

-- Trigger to update message status when attachments are added
CREATE OR REPLACE FUNCTION public.update_message_on_attachment()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
    UPDATE public.chat_messages
    SET status = 'sent'
    WHERE id = NEW.message_id
    AND status = 'pending';
    
    RETURN NEW;
END;
$$;

CREATE TRIGGER trigger_update_message_on_attachment
    AFTER INSERT ON public.message_attachments
    FOR EACH ROW
    EXECUTE FUNCTION public.update_message_on_attachment();

-- Mock data for testing
DO $$
DECLARE
    test_user_id UUID;
    test_recipient_id UUID;
    test_message_id UUID;
BEGIN
    -- Get existing users
    SELECT id INTO test_user_id FROM public.profiles LIMIT 1;
    SELECT id INTO test_recipient_id FROM public.profiles WHERE id != test_user_id LIMIT 1;
    
    IF test_user_id IS NOT NULL AND test_recipient_id IS NOT NULL THEN
        -- Create a test message
        INSERT INTO public.chat_messages (
            id, sender_id, recipient_id, message, status, created_at
        ) VALUES (
            gen_random_uuid(),
            test_user_id,
            test_recipient_id,
            'Check out these files I am sharing with you!',
            'sent',
            NOW()
        ) RETURNING id INTO test_message_id;
        
        -- Create sample attachments
        INSERT INTO public.message_attachments (
            message_id, file_name, file_type, file_size, file_url, mime_type
        ) VALUES
            (test_message_id, 'project-proposal.pdf', 'document', 2048576, '/storage/message-attachments/sample.pdf', 'application/pdf'),
            (test_message_id, 'screenshot.png', 'image', 512000, '/storage/message-attachments/sample.png', 'image/png');
        
        RAISE NOTICE 'Mock message attachments created successfully';
    END IF;
END $$;