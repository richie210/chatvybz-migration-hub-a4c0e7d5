-- Location: supabase/migrations/20251224144500_advanced_call_search.sql
-- Purpose: Add full-text search capabilities for advanced call history search
-- Dependencies: calls, call_participants, meetings, meeting_recordings, profiles, saved_search_queries
-- CRITICAL: This migration requires meeting_recordings to have transcript and call_id columns
--          from migration 20251224142849_call_recording_ai_summaries.sql

-- Verify prerequisites: Check if required columns exist
DO $$ 
BEGIN
    -- Check if transcript column exists
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_schema = 'public' 
        AND table_name = 'meeting_recordings' 
        AND column_name = 'transcript'
    ) THEN
        RAISE EXCEPTION 'Migration prerequisite not met: meeting_recordings.transcript column does not exist. Run migration 20251224142849_call_recording_ai_summaries.sql first.';
    END IF;

    -- Check if call_id column exists
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_schema = 'public' 
        AND table_name = 'meeting_recordings' 
        AND column_name = 'call_id'
    ) THEN
        RAISE EXCEPTION 'Migration prerequisite not met: meeting_recordings.call_id column does not exist. Run migration 20251224142849_call_recording_ai_summaries.sql first.';
    END IF;
END $$;

-- 1. Add full-text search index on meeting_recordings.transcript
CREATE INDEX IF NOT EXISTS idx_meeting_recordings_transcript_search 
ON public.meeting_recordings 
USING gin(to_tsvector('english', COALESCE(transcript, '')));

-- 2. Add combined search index for faster queries
CREATE INDEX IF NOT EXISTS idx_calls_search_combo
ON public.calls(initiator_id, created_at DESC, call_status, call_type);

-- 3. Create comprehensive search function for call history
CREATE OR REPLACE FUNCTION public.search_call_history(
    p_user_id UUID,
    p_search_text TEXT DEFAULT NULL,
    p_participant_ids UUID[] DEFAULT NULL,
    p_min_duration INTEGER DEFAULT NULL,
    p_max_duration INTEGER DEFAULT NULL,
    p_start_date TIMESTAMPTZ DEFAULT NULL,
    p_end_date TIMESTAMPTZ DEFAULT NULL,
    p_call_types TEXT[] DEFAULT NULL,
    p_limit INTEGER DEFAULT 50,
    p_offset INTEGER DEFAULT 0
)
RETURNS TABLE(
    call_id UUID,
    call_type TEXT,
    call_status TEXT,
    duration INTEGER,
    started_at TIMESTAMPTZ,
    ended_at TIMESTAMPTZ,
    initiator_name TEXT,
    initiator_avatar TEXT,
    participant_count BIGINT,
    participants JSONB,
    has_recording BOOLEAN,
    recording_id UUID,
    transcript_snippet TEXT,
    relevance_score REAL
)
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
AS $$
BEGIN
    RETURN QUERY
    WITH user_calls AS (
        -- Get all calls where user is initiator or recipient
        SELECT DISTINCT c.id as call_id
        FROM public.calls c
        LEFT JOIN public.call_participants cp ON c.id = cp.call_id
        WHERE (c.initiator_id = p_user_id OR c.recipient_id = p_user_id OR cp.user_id = p_user_id)
          AND (p_start_date IS NULL OR c.created_at >= p_start_date)
          AND (p_end_date IS NULL OR c.created_at <= p_end_date)
          AND (p_call_types IS NULL OR c.call_type::TEXT = ANY(p_call_types))
          AND (p_min_duration IS NULL OR c.duration >= p_min_duration)
          AND (p_max_duration IS NULL OR c.duration <= p_max_duration)
    ),
    participant_filtered_calls AS (
        -- Filter by participant IDs if provided
        SELECT uc.call_id
        FROM user_calls uc
        WHERE p_participant_ids IS NULL
           OR EXISTS (
               SELECT 1 FROM public.call_participants cp2
               WHERE cp2.call_id = uc.call_id
                 AND cp2.user_id = ANY(p_participant_ids)
           )
    ),
    transcript_search AS (
        -- Search in transcripts if search text provided
        SELECT 
            mr.call_id,
            mr.id as recording_id,
            COALESCE(
                ts_rank(
                    to_tsvector('english', COALESCE(mr.transcript, '')),
                    plainto_tsquery('english', COALESCE(p_search_text, ''))
                ),
                0
            ) as rank,
            ts_headline(
                'english',
                COALESCE(mr.transcript, ''),
                plainto_tsquery('english', COALESCE(p_search_text, '')),
                'MaxWords=50, MinWords=20, MaxFragments=1'
            ) as snippet
        FROM public.meeting_recordings mr
        WHERE mr.call_id IS NOT NULL
          AND mr.transcript IS NOT NULL
          AND (p_search_text IS NULL 
               OR to_tsvector('english', mr.transcript) @@ plainto_tsquery('english', p_search_text))
    )
    SELECT 
        c.id,
        c.call_type::TEXT,
        c.call_status::TEXT,
        c.duration,
        c.started_at,
        c.ended_at,
        p.display_name as initiator_name,
        p.avatar_url as initiator_avatar,
        COUNT(DISTINCT cp.user_id) as participant_count,
        jsonb_agg(
            DISTINCT jsonb_build_object(
                'userId', cp.user_id,
                'displayName', cp_profile.display_name,
                'avatarUrl', cp_profile.avatar_url,
                'joinedAt', cp.joined_at,
                'leftAt', cp.left_at
            )
        ) FILTER (WHERE cp.user_id IS NOT NULL) as participants,
        EXISTS(SELECT 1 FROM public.meeting_recordings mr2 WHERE mr2.call_id = c.id) as has_recording,
        ts.recording_id,
        ts.snippet as transcript_snippet,
        COALESCE(ts.rank, 0)::REAL as relevance_score
    FROM public.calls c
    INNER JOIN participant_filtered_calls pfc ON c.id = pfc.call_id
    LEFT JOIN public.profiles p ON c.initiator_id = p.id
    LEFT JOIN public.call_participants cp ON c.id = cp.call_id
    LEFT JOIN public.profiles cp_profile ON cp.user_id = cp_profile.id
    LEFT JOIN transcript_search ts ON c.id = ts.call_id
    WHERE (p_search_text IS NULL OR ts.call_id IS NOT NULL OR p_search_text = '')
    GROUP BY 
        c.id, 
        c.call_type, 
        c.call_status, 
        c.duration, 
        c.started_at, 
        c.ended_at,
        p.display_name,
        p.avatar_url,
        ts.recording_id,
        ts.snippet,
        ts.rank
    ORDER BY 
        CASE WHEN p_search_text IS NOT NULL AND p_search_text != '' THEN COALESCE(ts.rank, 0) ELSE 0 END DESC,
        c.created_at DESC
    LIMIT p_limit
    OFFSET p_offset;
END;
$$;

-- 4. Add RLS policy for search function access
-- Users can only search their own call history (enforced in function logic)

-- 5. Create helper function to get search suggestions based on recent searches
CREATE OR REPLACE FUNCTION public.get_search_suggestions(
    p_user_id UUID,
    p_partial_text TEXT,
    p_limit INTEGER DEFAULT 10
)
RETURNS TABLE(
    suggestion TEXT,
    search_count BIGINT,
    last_used TIMESTAMPTZ
)
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
    SELECT 
        search_text as suggestion,
        COUNT(*) as search_count,
        MAX(last_used_at) as last_used
    FROM public.saved_search_queries
    WHERE user_id = p_user_id
      AND search_text ILIKE p_partial_text || '%'
    GROUP BY search_text
    ORDER BY MAX(last_used_at) DESC
    LIMIT p_limit;
$$;

-- 6. Update saved_search_queries to track usage
CREATE OR REPLACE FUNCTION public.update_search_query_usage()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
    NEW.last_used_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trigger_update_search_usage ON public.saved_search_queries;
CREATE TRIGGER trigger_update_search_usage
BEFORE UPDATE ON public.saved_search_queries
FOR EACH ROW
WHEN (OLD.last_used_at IS DISTINCT FROM NEW.last_used_at)
EXECUTE FUNCTION public.update_search_query_usage();

-- 7. Add index for faster participant name lookups
CREATE INDEX IF NOT EXISTS idx_profiles_display_name_search
ON public.profiles
USING gin(to_tsvector('english', display_name));