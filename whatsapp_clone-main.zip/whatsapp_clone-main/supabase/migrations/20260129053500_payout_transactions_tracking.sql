-- Payout Transactions Tracking Migration
-- Adds transaction-level tracking for Stripe payouts with detailed analytics

DO $$
BEGIN
    RAISE NOTICE 'Creating payout_transactions table for transaction-level analytics...';
END $$;

-- 1. Create payout_transactions table for detailed transaction tracking
CREATE TABLE IF NOT EXISTS public.payout_transactions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    payout_id UUID NOT NULL REFERENCES public.creator_payouts(id) ON DELETE CASCADE,
    transaction_type TEXT NOT NULL CHECK (transaction_type IN ('subscription', 'ad_revenue', 'donation', 'refund', 'adjustment')),
    source_id UUID,
    source_type TEXT,
    amount DECIMAL(10, 2) NOT NULL,
    currency TEXT DEFAULT 'USD',
    fee_amount DECIMAL(10, 2) DEFAULT 0,
    net_amount DECIMAL(10, 2) NOT NULL,
    description TEXT,
    metadata JSONB DEFAULT '{}'::jsonb,
    transaction_date TIMESTAMPTZ NOT NULL,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 2. Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_payout_transactions_payout_id ON public.payout_transactions(payout_id);
CREATE INDEX IF NOT EXISTS idx_payout_transactions_type ON public.payout_transactions(transaction_type);
CREATE INDEX IF NOT EXISTS idx_payout_transactions_date ON public.payout_transactions(transaction_date);
CREATE INDEX IF NOT EXISTS idx_payout_transactions_source ON public.payout_transactions(source_id, source_type);

-- 3. Create payout_notifications table for live notification system
CREATE TABLE IF NOT EXISTS public.payout_notifications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    payout_id UUID REFERENCES public.creator_payouts(id) ON DELETE CASCADE,
    notification_type TEXT NOT NULL CHECK (notification_type IN ('payout_created', 'payout_processing', 'payout_paid', 'payout_failed', 'payout_updated')),
    title TEXT NOT NULL,
    message TEXT NOT NULL,
    data JSONB DEFAULT '{}'::jsonb,
    read BOOLEAN DEFAULT false,
    read_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 4. Create indexes for notifications
CREATE INDEX IF NOT EXISTS idx_payout_notifications_user_id ON public.payout_notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_payout_notifications_read ON public.payout_notifications(read);
CREATE INDEX IF NOT EXISTS idx_payout_notifications_created_at ON public.payout_notifications(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_payout_notifications_payout_id ON public.payout_notifications(payout_id);

-- 5. Enable Row Level Security
ALTER TABLE public.payout_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payout_notifications ENABLE ROW LEVEL SECURITY;

-- 6. RLS Policies for payout_transactions
CREATE POLICY "creators_can_view_own_payout_transactions"
ON public.payout_transactions
FOR SELECT
TO authenticated
USING (
    EXISTS (
        SELECT 1 FROM public.creator_payouts
        WHERE creator_payouts.id = payout_transactions.payout_id
        AND creator_payouts.creator_id = auth.uid()
    )
);

-- 7. RLS Policies for payout_notifications
CREATE POLICY "users_can_view_own_notifications"
ON public.payout_notifications
FOR SELECT
TO authenticated
USING (user_id = auth.uid());

CREATE POLICY "users_can_update_own_notifications"
ON public.payout_notifications
FOR UPDATE
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

-- 8. Function to create notification on payout status change
CREATE OR REPLACE FUNCTION public.create_payout_notification()
RETURNS TRIGGER AS $func$
DECLARE
    notification_title TEXT;
    notification_message TEXT;
    notification_type TEXT;
BEGIN
    IF TG_OP = 'INSERT' THEN
        notification_type := 'payout_created';
        notification_title := 'New Payout Created';
        notification_message := 'A new payout of ' || NEW.amount || ' ' || NEW.currency || ' has been created.';
    ELSIF TG_OP = 'UPDATE' AND OLD.status != NEW.status THEN
        CASE NEW.status
            WHEN 'processing' THEN
                notification_type := 'payout_processing';
                notification_title := 'Payout Processing';
                notification_message := 'Your payout of ' || NEW.amount || ' ' || NEW.currency || ' is now being processed.';
            WHEN 'paid' THEN
                notification_type := 'payout_paid';
                notification_title := 'Payout Completed! 🎉';
                notification_message := 'Your payout of ' || NEW.amount || ' ' || NEW.currency || ' has been successfully transferred.';
            WHEN 'failed' THEN
                notification_type := 'payout_failed';
                notification_title := 'Payout Failed';
                notification_message := 'Your payout of ' || NEW.amount || ' ' || NEW.currency || ' has failed. Please check your account details.';
            ELSE
                notification_type := 'payout_updated';
                notification_title := 'Payout Updated';
                notification_message := 'Your payout status has been updated to ' || NEW.status || '.';
        END CASE;
    ELSE
        RETURN NEW;
    END IF;

    INSERT INTO public.payout_notifications (
        user_id,
        payout_id,
        notification_type,
        title,
        message,
        data
    ) VALUES (
        NEW.creator_id,
        NEW.id,
        notification_type,
        notification_title,
        notification_message,
        jsonb_build_object(
            'payout_id', NEW.id,
            'amount', NEW.amount,
            'currency', NEW.currency,
            'status', NEW.status,
            'stripe_payout_id', NEW.stripe_payout_id
        )
    );

    RETURN NEW;
END;
$func$ LANGUAGE plpgsql SECURITY DEFINER;

-- 9. Trigger for automatic notification creation
DROP TRIGGER IF EXISTS trigger_create_payout_notification ON public.creator_payouts;
CREATE TRIGGER trigger_create_payout_notification
AFTER INSERT OR UPDATE ON public.creator_payouts
FOR EACH ROW
EXECUTE FUNCTION public.create_payout_notification();

DO $$
BEGIN
    RAISE NOTICE 'Payout transactions tracking migration completed successfully';
    RAISE NOTICE 'Created tables: payout_transactions, payout_notifications';
    RAISE NOTICE 'Created trigger: trigger_create_payout_notification for automatic notifications';
END $$;