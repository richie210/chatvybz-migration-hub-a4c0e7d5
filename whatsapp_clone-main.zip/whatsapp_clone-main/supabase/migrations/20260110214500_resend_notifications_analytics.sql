-- Migration: Resend notification and analytics reporting system
-- Created: 2026-01-10
-- Purpose: Add tables for notification delivery logs, scheduled reports, and report delivery tracking

-- Notification delivery logs table
CREATE TABLE IF NOT EXISTS public.notification_delivery_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
    recipient_email TEXT NOT NULL,
    notification_type TEXT NOT NULL CHECK (notification_type IN ('message', 'mention', 'call')),
    delivery_status TEXT NOT NULL DEFAULT 'sent' CHECK (delivery_status IN ('sent', 'failed')),
    message_id TEXT,
    error_message TEXT,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Scheduled reports table
CREATE TABLE IF NOT EXISTS public.scheduled_reports (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
    report_type TEXT NOT NULL CHECK (report_type IN ('creator_revenue', 'call_metrics', 'subscriber_insights')),
    recipient_email TEXT NOT NULL,
    frequency TEXT NOT NULL CHECK (frequency IN ('daily', 'weekly', 'monthly')),
    schedule_time TIME NOT NULL,
    timezone TEXT NOT NULL DEFAULT 'UTC',
    channel_id UUID REFERENCES public.channels(id) ON DELETE CASCADE,
    is_active BOOLEAN DEFAULT true,
    last_sent_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Report delivery logs table
CREATE TABLE IF NOT EXISTS public.report_delivery_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
    report_type TEXT NOT NULL CHECK (report_type IN ('creator_revenue', 'call_metrics', 'subscriber_insights')),
    recipient_email TEXT NOT NULL,
    delivery_status TEXT NOT NULL DEFAULT 'sent' CHECK (delivery_status IN ('sent', 'failed')),
    message_id TEXT,
    error_message TEXT,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_notification_delivery_logs_user_id ON public.notification_delivery_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_notification_delivery_logs_created_at ON public.notification_delivery_logs(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_scheduled_reports_user_id ON public.scheduled_reports(user_id);
CREATE INDEX IF NOT EXISTS idx_scheduled_reports_is_active ON public.scheduled_reports(is_active);
CREATE INDEX IF NOT EXISTS idx_report_delivery_logs_user_id ON public.report_delivery_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_report_delivery_logs_created_at ON public.report_delivery_logs(created_at DESC);

-- Enable RLS
ALTER TABLE public.notification_delivery_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.scheduled_reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.report_delivery_logs ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "users_manage_own_notification_delivery_logs"
ON public.notification_delivery_logs
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

CREATE POLICY "users_manage_own_scheduled_reports"
ON public.scheduled_reports
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

CREATE POLICY "users_manage_own_report_delivery_logs"
ON public.report_delivery_logs
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

-- Update notification_preferences table to add email_notifications column if not exists
DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.columns 
        WHERE table_schema = 'public' 
        AND table_name = 'notification_preferences' 
        AND column_name = 'email_notifications'
    ) THEN
        ALTER TABLE public.notification_preferences 
        ADD COLUMN email_notifications BOOLEAN DEFAULT false;
    END IF;
END $$;