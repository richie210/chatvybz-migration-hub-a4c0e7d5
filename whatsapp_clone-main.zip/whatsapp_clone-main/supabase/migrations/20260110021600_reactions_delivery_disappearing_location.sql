-- Location: supabase/migrations/20260110021600_reactions_delivery_disappearing_location.sql
-- Schema Analysis: Existing message_reactions, chat_messages, message_auto_delete_settings tables
-- Integration Type: Extension - Adding reaction viewer tracking, message expiration, and location sharing
-- Dependencies: message_reactions, chat_messages, profiles

-- ============================================
-- 1. DISAPPEARING MESSAGES ENHANCEMENT
-- ============================================

-- Add expiration tracking to chat_messages
ALTER TABLE public.chat_messages
ADD COLUMN IF NOT EXISTS expires_at TIMESTAMPTZ,
ADD COLUMN IF NOT EXISTS auto_delete_enabled BOOLEAN DEFAULT false;

-- Create index for efficient expiration queries
CREATE INDEX IF NOT EXISTS idx_chat_messages_expires_at ON public.chat_messages(expires_at) WHERE expires_at IS NOT NULL;

-- Function to calculate expiration timestamp based on auto-delete settings
CREATE OR REPLACE FUNCTION public.calculate_message_expiration(
    p_conversation_id UUID,
    p_user_id UUID,
    p_created_at TIMESTAMPTZ
)
RETURNS TIMESTAMPTZ
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
AS $$
DECLARE
    v_settings RECORD;
    v_hours INTEGER;
BEGIN
    -- Get auto-delete settings for conversation
    SELECT * INTO v_settings
    FROM public.message_auto_delete_settings
    WHERE user_id = p_user_id
    AND conversation_id = p_conversation_id
    AND is_enabled = true;

    IF NOT FOUND THEN
        RETURN NULL;
    END IF;

    -- Calculate hours based on duration type
    CASE v_settings.duration_type
        WHEN '24h' THEN v_hours := 24;
        WHEN '7d' THEN v_hours := 168;
        WHEN '30d' THEN v_hours := 720;
        WHEN '90d' THEN v_hours := 2160;
        WHEN 'custom' THEN v_hours := COALESCE(v_settings.custom_duration_hours, 24);
        ELSE v_hours := 24;
    END CASE;

    RETURN p_created_at + (v_hours || ' hours')::INTERVAL;
END;
$$;

-- Trigger to set expiration on message insert
CREATE OR REPLACE FUNCTION public.set_message_expiration()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_expires_at TIMESTAMPTZ;
BEGIN
    -- Calculate expiration for sender
    v_expires_at := public.calculate_message_expiration(
        NEW.recipient_id,
        NEW.sender_id,
        NEW.created_at
    );

    IF v_expires_at IS NOT NULL THEN
        NEW.expires_at := v_expires_at;
        NEW.auto_delete_enabled := true;
    END IF;

    RETURN NEW;
END;
$$;

CREATE TRIGGER trigger_set_message_expiration
    BEFORE INSERT ON public.chat_messages
    FOR EACH ROW
    EXECUTE FUNCTION public.set_message_expiration();

-- Function to delete expired messages
CREATE OR REPLACE FUNCTION public.delete_expired_messages()
RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_deleted_count INTEGER;
BEGIN
    -- Delete messages that have expired
    WITH deleted AS (
        DELETE FROM public.chat_messages
        WHERE expires_at IS NOT NULL
        AND expires_at <= NOW()
        AND auto_delete_enabled = true
        RETURNING id
    )
    SELECT COUNT(*) INTO v_deleted_count FROM deleted;

    RETURN v_deleted_count;
END;
$$;

-- ============================================
-- 2. LIVE LOCATION SHARING
-- ============================================

-- Create location shares table
CREATE TABLE public.location_shares (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    conversation_id UUID NOT NULL,
    latitude DECIMAL(10, 8) NOT NULL,
    longitude DECIMAL(11, 8) NOT NULL,
    accuracy DECIMAL(10, 2),
    altitude DECIMAL(10, 2),
    heading DECIMAL(5, 2),
    speed DECIMAL(10, 2),
    is_live BOOLEAN DEFAULT true,
    duration_minutes INTEGER DEFAULT 60,
    expires_at TIMESTAMPTZ NOT NULL,
    last_updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for location queries
CREATE INDEX idx_location_shares_user_id ON public.location_shares(user_id);
CREATE INDEX idx_location_shares_conversation_id ON public.location_shares(conversation_id);
CREATE INDEX idx_location_shares_is_live ON public.location_shares(is_live) WHERE is_live = true;
CREATE INDEX idx_location_shares_expires_at ON public.location_shares(expires_at);

-- Enable RLS
ALTER TABLE public.location_shares ENABLE ROW LEVEL SECURITY;

-- RLS Policy: Users can view location shares in their conversations
CREATE POLICY "users_view_conversation_locations"
ON public.location_shares
FOR SELECT
TO authenticated
USING (
    user_id = auth.uid() OR
    conversation_id IN (
        SELECT recipient_id FROM public.chat_messages WHERE sender_id = auth.uid()
        UNION
        SELECT sender_id FROM public.chat_messages WHERE recipient_id = auth.uid()
    )
);

-- RLS Policy: Users can manage their own location shares
CREATE POLICY "users_manage_own_locations"
ON public.location_shares
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

-- Function to update location coordinates
CREATE OR REPLACE FUNCTION public.update_location_coordinates(
    p_location_id UUID,
    p_latitude DECIMAL,
    p_longitude DECIMAL,
    p_accuracy DECIMAL DEFAULT NULL,
    p_altitude DECIMAL DEFAULT NULL,
    p_heading DECIMAL DEFAULT NULL,
    p_speed DECIMAL DEFAULT NULL
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_result JSONB;
BEGIN
    -- Update location coordinates
    UPDATE public.location_shares
    SET
        latitude = p_latitude,
        longitude = p_longitude,
        accuracy = COALESCE(p_accuracy, accuracy),
        altitude = COALESCE(p_altitude, altitude),
        heading = COALESCE(p_heading, heading),
        speed = COALESCE(p_speed, speed),
        last_updated_at = NOW()
    WHERE id = p_location_id
    AND user_id = auth.uid()
    AND is_live = true
    AND expires_at > NOW();

    IF NOT FOUND THEN
        RETURN jsonb_build_object(
            'success', false,
            'error', 'Location share not found or expired'
        );
    END IF;

    RETURN jsonb_build_object(
        'success', true,
        'updated_at', NOW()
    );
END;
$$;

-- Function to stop live location sharing
CREATE OR REPLACE FUNCTION public.stop_location_sharing(
    p_location_id UUID
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    UPDATE public.location_shares
    SET
        is_live = false,
        expires_at = NOW()
    WHERE id = p_location_id
    AND user_id = auth.uid();

    IF NOT FOUND THEN
        RETURN jsonb_build_object(
            'success', false,
            'error', 'Location share not found'
        );
    END IF;

    RETURN jsonb_build_object(
        'success', true,
        'stopped_at', NOW()
    );
END;
$$;

-- Function to cleanup expired location shares
CREATE OR REPLACE FUNCTION public.cleanup_expired_locations()
RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_deleted_count INTEGER;
BEGIN
    WITH deleted AS (
        DELETE FROM public.location_shares
        WHERE expires_at <= NOW()
        RETURNING id
    )
    SELECT COUNT(*) INTO v_deleted_count FROM deleted;

    RETURN v_deleted_count;
END;
$$;

-- ============================================
-- 3. MESSAGE DELIVERY FAILURE TRACKING
-- ============================================

-- Add delivery failure tracking to chat_messages
ALTER TABLE public.chat_messages
ADD COLUMN IF NOT EXISTS delivery_attempts INTEGER DEFAULT 0,
ADD COLUMN IF NOT EXISTS last_delivery_attempt TIMESTAMPTZ,
ADD COLUMN IF NOT EXISTS delivery_failure_reason TEXT,
ADD COLUMN IF NOT EXISTS suggested_resend_time TIMESTAMPTZ;

-- Create index for failed messages
CREATE INDEX IF NOT EXISTS idx_chat_messages_delivery_failures ON public.chat_messages(status, delivery_attempts) WHERE status = 'failed';

-- Function to record delivery failure
CREATE OR REPLACE FUNCTION public.record_delivery_failure(
    p_message_id UUID,
    p_failure_reason TEXT
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_attempts INTEGER;
BEGIN
    UPDATE public.chat_messages
    SET
        delivery_attempts = delivery_attempts + 1,
        last_delivery_attempt = NOW(),
        delivery_failure_reason = p_failure_reason,
        status = 'failed'
    WHERE id = p_message_id
    RETURNING delivery_attempts INTO v_attempts;

    RETURN jsonb_build_object(
        'success', true,
        'attempts', v_attempts,
        'recorded_at', NOW()
    );
END;
$$;

-- ============================================
-- COMMENTS AND DOCUMENTATION
-- ============================================

COMMENT ON TABLE public.location_shares IS 'Real-time location sharing for conversations with expiration tracking';
COMMENT ON COLUMN public.chat_messages.expires_at IS 'Timestamp when message should be auto-deleted';
COMMENT ON COLUMN public.chat_messages.delivery_attempts IS 'Number of delivery attempts for failed messages';
COMMENT ON FUNCTION public.calculate_message_expiration IS 'Calculates message expiration based on auto-delete settings';
COMMENT ON FUNCTION public.update_location_coordinates IS 'Updates live location coordinates for active location shares';
COMMENT ON FUNCTION public.delete_expired_messages IS 'Deletes messages that have passed their expiration time';
COMMENT ON FUNCTION public.cleanup_expired_locations IS 'Removes expired location shares from the database';