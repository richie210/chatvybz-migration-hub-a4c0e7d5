-- Location: supabase/migrations/20260110031000_fix_qr_auth_anon_insert.sql
-- Purpose: Fix RLS policy to allow anonymous users to generate QR tokens for login
-- Issue: Users cannot generate QR tokens because they're not authenticated yet during login

-- Drop the existing restrictive INSERT policy that only allows authenticated users
DROP POLICY IF EXISTS "anyone_can_create_qr_tokens" ON public.qr_auth_tokens;

-- Create new INSERT policy that allows both authenticated AND anonymous users
CREATE POLICY "anon_and_auth_can_create_qr_tokens"
ON public.qr_auth_tokens
FOR INSERT
TO anon, authenticated
WITH CHECK (true);

-- Drop and recreate SELECT policy to allow anonymous users to check tokens
DROP POLICY IF EXISTS "users_can_view_own_qr_tokens" ON public.qr_auth_tokens;

CREATE POLICY "anon_and_auth_can_view_qr_tokens"
ON public.qr_auth_tokens
FOR SELECT
TO anon, authenticated
USING (true);

-- Drop and recreate UPDATE policy to allow anonymous users to verify tokens
DROP POLICY IF EXISTS "users_can_update_own_qr_tokens" ON public.qr_auth_tokens;

CREATE POLICY "anon_and_auth_can_update_qr_tokens"
ON public.qr_auth_tokens
FOR UPDATE
TO anon, authenticated
USING (true)
WITH CHECK (true);

-- Add comment explaining the security model
COMMENT ON TABLE public.qr_auth_tokens IS 'QR authentication tokens - allows anonymous access for login flow. Security is enforced by token expiration (5 minutes) and one-time use pattern.';