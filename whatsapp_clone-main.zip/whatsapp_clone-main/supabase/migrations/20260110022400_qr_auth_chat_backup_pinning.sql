-- Location: supabase/migrations/20260110022400_qr_auth_chat_backup_pinning.sql
-- Schema Analysis: profiles table exists, chat_messages table exists
-- Integration Type: extension
-- Dependencies: profiles, chat_messages

-- 1. Create QR authentication tokens table
CREATE TABLE public.qr_auth_tokens (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    status TEXT NOT NULL DEFAULT 'pending', -- pending, verified, expired
    user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
    expires_at TIMESTAMPTZ NOT NULL,
    verified_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Add indexes for QR tokens
CREATE INDEX idx_qr_auth_tokens_status ON public.qr_auth_tokens(status);
CREATE INDEX idx_qr_auth_tokens_expires ON public.qr_auth_tokens(expires_at);
CREATE INDEX idx_qr_auth_tokens_user ON public.qr_auth_tokens(user_id);

-- 2. Create chat backups table
CREATE TABLE public.chat_backups (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    file_name TEXT NOT NULL,
    file_path TEXT NOT NULL,
    file_url TEXT,
    message_count INTEGER DEFAULT 0,
    file_size BIGINT DEFAULT 0,
    backup_type TEXT NOT NULL, -- full, restore, incremental
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Add indexes for chat backups
CREATE INDEX idx_chat_backups_user ON public.chat_backups(user_id);
CREATE INDEX idx_chat_backups_type ON public.chat_backups(backup_type);
CREATE INDEX idx_chat_backups_created ON public.chat_backups(created_at);

-- 3. Create pinned conversations table
CREATE TABLE public.pinned_conversations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    conversation_id TEXT NOT NULL,
    conversation_type TEXT DEFAULT 'direct', -- direct, group
    pinned_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    pin_order INTEGER DEFAULT 0,
    UNIQUE(user_id, conversation_id)
);

-- Add indexes for pinned conversations
CREATE INDEX idx_pinned_conversations_user ON public.pinned_conversations(user_id);
CREATE INDEX idx_pinned_conversations_order ON public.pinned_conversations(user_id, pin_order);
CREATE INDEX idx_pinned_conversations_type ON public.pinned_conversations(conversation_type);

-- 4. Enable RLS on all tables
ALTER TABLE public.qr_auth_tokens ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.chat_backups ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pinned_conversations ENABLE ROW LEVEL SECURITY;

-- 5. RLS Policies for qr_auth_tokens
CREATE POLICY "users_can_view_own_qr_tokens"
ON public.qr_auth_tokens
FOR SELECT
TO authenticated
USING (user_id = auth.uid() OR user_id IS NULL);

CREATE POLICY "anyone_can_create_qr_tokens"
ON public.qr_auth_tokens
FOR INSERT
TO authenticated
WITH CHECK (true);

CREATE POLICY "users_can_update_own_qr_tokens"
ON public.qr_auth_tokens
FOR UPDATE
TO authenticated
USING (user_id = auth.uid() OR user_id IS NULL)
WITH CHECK (user_id = auth.uid());

-- 6. RLS Policies for chat_backups
CREATE POLICY "users_manage_own_backups"
ON public.chat_backups
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

-- 7. RLS Policies for pinned_conversations
CREATE POLICY "users_manage_own_pins"
ON public.pinned_conversations
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

-- 8. Function to cleanup expired QR tokens
CREATE OR REPLACE FUNCTION public.cleanup_expired_qr_tokens()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    UPDATE public.qr_auth_tokens
    SET status = 'expired'
    WHERE status = 'pending'
    AND expires_at < NOW();
END;
$$;

-- 9. Function to get pinned conversations count
CREATE OR REPLACE FUNCTION public.get_pinned_count(p_user_id UUID)
RETURNS INTEGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    pin_count INTEGER;
BEGIN
    SELECT COUNT(*)
    INTO pin_count
    FROM public.pinned_conversations
    WHERE user_id = p_user_id;
    
    RETURN pin_count;
END;
$$;

-- 10. Create storage bucket for chat backups (if not exists)
INSERT INTO storage.buckets (id, name, public)
VALUES ('chat-backups', 'chat-backups', false)
ON CONFLICT (id) DO NOTHING;

-- 11. Storage policies for chat-backups bucket
CREATE POLICY "users_can_upload_own_backups"
ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (
    bucket_id = 'chat-backups' AND
    (storage.foldername(name))[1] = auth.uid()::text
);

CREATE POLICY "users_can_view_own_backups"
ON storage.objects
FOR SELECT
TO authenticated
USING (
    bucket_id = 'chat-backups' AND
    (storage.foldername(name))[1] = auth.uid()::text
);

CREATE POLICY "users_can_delete_own_backups"
ON storage.objects
FOR DELETE
TO authenticated
USING (
    bucket_id = 'chat-backups' AND
    (storage.foldername(name))[1] = auth.uid()::text
);