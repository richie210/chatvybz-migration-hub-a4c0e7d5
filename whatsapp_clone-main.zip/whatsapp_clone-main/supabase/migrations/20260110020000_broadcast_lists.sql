-- Broadcast Lists Migration
-- Enables sending messages to multiple contacts simultaneously with individual delivery tracking

-- 1. Create broadcast_lists table
CREATE TABLE public.broadcast_lists (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    description TEXT,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 2. Create broadcast_list_members table
CREATE TABLE public.broadcast_list_members (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    broadcast_list_id UUID NOT NULL REFERENCES public.broadcast_lists(id) ON DELETE CASCADE,
    contact_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    added_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(broadcast_list_id, contact_id)
);

-- 3. Create broadcast_messages table
CREATE TABLE public.broadcast_messages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    sender_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    broadcast_list_id UUID NOT NULL REFERENCES public.broadcast_lists(id) ON DELETE CASCADE,
    message_content TEXT NOT NULL,
    is_encrypted BOOLEAN DEFAULT false,
    nonce TEXT,
    sent_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 4. Create broadcast_delivery_tracking table
CREATE TABLE public.broadcast_delivery_tracking (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    broadcast_message_id UUID NOT NULL REFERENCES public.broadcast_messages(id) ON DELETE CASCADE,
    recipient_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    status TEXT DEFAULT 'sent' CHECK (status IN ('sent', 'delivered', 'read', 'failed')),
    delivered_at TIMESTAMPTZ,
    read_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(broadcast_message_id, recipient_id)
);

-- 5. Create indexes
CREATE INDEX idx_broadcast_lists_user_id ON public.broadcast_lists(user_id);
CREATE INDEX idx_broadcast_list_members_list_id ON public.broadcast_list_members(broadcast_list_id);
CREATE INDEX idx_broadcast_list_members_contact_id ON public.broadcast_list_members(contact_id);
CREATE INDEX idx_broadcast_messages_sender_id ON public.broadcast_messages(sender_id);
CREATE INDEX idx_broadcast_messages_list_id ON public.broadcast_messages(broadcast_list_id);
CREATE INDEX idx_broadcast_delivery_tracking_message_id ON public.broadcast_delivery_tracking(broadcast_message_id);
CREATE INDEX idx_broadcast_delivery_tracking_recipient_id ON public.broadcast_delivery_tracking(recipient_id);

-- 6. Enable RLS
ALTER TABLE public.broadcast_lists ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.broadcast_list_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.broadcast_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.broadcast_delivery_tracking ENABLE ROW LEVEL SECURITY;

-- 7. RLS Policies

-- Broadcast Lists Policies
CREATE POLICY "users_manage_own_broadcast_lists"
ON public.broadcast_lists
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

-- Broadcast List Members Policies
CREATE POLICY "users_manage_own_list_members"
ON public.broadcast_list_members
FOR ALL
TO authenticated
USING (
    EXISTS (
        SELECT 1 FROM public.broadcast_lists bl
        WHERE bl.id = broadcast_list_id AND bl.user_id = auth.uid()
    )
)
WITH CHECK (
    EXISTS (
        SELECT 1 FROM public.broadcast_lists bl
        WHERE bl.id = broadcast_list_id AND bl.user_id = auth.uid()
    )
);

-- Broadcast Messages Policies
CREATE POLICY "users_manage_own_broadcast_messages"
ON public.broadcast_messages
FOR ALL
TO authenticated
USING (sender_id = auth.uid())
WITH CHECK (sender_id = auth.uid());

-- Broadcast Delivery Tracking Policies
CREATE POLICY "senders_view_delivery_tracking"
ON public.broadcast_delivery_tracking
FOR SELECT
TO authenticated
USING (
    EXISTS (
        SELECT 1 FROM public.broadcast_messages bm
        WHERE bm.id = broadcast_message_id AND bm.sender_id = auth.uid()
    )
);

CREATE POLICY "recipients_view_own_delivery_status"
ON public.broadcast_delivery_tracking
FOR SELECT
TO authenticated
USING (recipient_id = auth.uid());

CREATE POLICY "recipients_update_delivery_status"
ON public.broadcast_delivery_tracking
FOR UPDATE
TO authenticated
USING (recipient_id = auth.uid())
WITH CHECK (recipient_id = auth.uid());

-- 8. Trigger for updated_at
CREATE OR REPLACE FUNCTION public.update_broadcast_list_updated_at()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;

CREATE TRIGGER broadcast_lists_updated_at
    BEFORE UPDATE ON public.broadcast_lists
    FOR EACH ROW
    EXECUTE FUNCTION public.update_broadcast_list_updated_at();

-- 9. Mock Data
DO $$
DECLARE
    existing_user_id UUID;
    contact_user_id UUID;
    broadcast_list_id UUID := gen_random_uuid();
    broadcast_message_id UUID := gen_random_uuid();
BEGIN
    -- Get existing users
    SELECT id INTO existing_user_id FROM public.profiles ORDER BY created_at LIMIT 1;
    SELECT id INTO contact_user_id FROM public.profiles WHERE id != existing_user_id ORDER BY created_at LIMIT 1;

    IF existing_user_id IS NOT NULL AND contact_user_id IS NOT NULL THEN
        -- Create sample broadcast list
        INSERT INTO public.broadcast_lists (id, user_id, name, description)
        VALUES (
            broadcast_list_id,
            existing_user_id,
            'Family Group',
            'Broadcast list for family members'
        );

        -- Add members to broadcast list
        INSERT INTO public.broadcast_list_members (broadcast_list_id, contact_id)
        VALUES (broadcast_list_id, contact_user_id);

        -- Create sample broadcast message
        INSERT INTO public.broadcast_messages (id, sender_id, broadcast_list_id, message_content)
        VALUES (
            broadcast_message_id,
            existing_user_id,
            broadcast_list_id,
            'Hello everyone! This is a test broadcast message.'
        );

        -- Create delivery tracking
        INSERT INTO public.broadcast_delivery_tracking (broadcast_message_id, recipient_id, status)
        VALUES (broadcast_message_id, contact_user_id, 'delivered');

        RAISE NOTICE 'Broadcast lists mock data created successfully';
    ELSE
        RAISE NOTICE 'No existing users found. Run auth migration first.';
    END IF;
END $$;