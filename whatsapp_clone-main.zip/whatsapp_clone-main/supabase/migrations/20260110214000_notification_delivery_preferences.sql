-- Add email report preferences to notification_preferences table
-- This enables scheduled analytics email reports for creator revenue, call metrics, and subscriber insights

ALTER TABLE public.notification_preferences
ADD COLUMN IF NOT EXISTS email_report_preferences JSONB DEFAULT '{}'::jsonb;

COMMENT ON COLUMN public.notification_preferences.email_report_preferences IS 'Scheduled email report settings: {"creator_revenue": {"enabled": true, "frequency": "weekly"}, "call_metrics": {...}, "subscriber_insights": {...}}';

ALTER TABLE public.notification_preferences
ADD COLUMN IF NOT EXISTS push_notification_enabled BOOLEAN DEFAULT true;

ALTER TABLE public.notification_preferences
ADD COLUMN IF NOT EXISTS email_notification_enabled BOOLEAN DEFAULT true;

ALTER TABLE public.notification_preferences
ADD COLUMN IF NOT EXISTS quiet_hours_start TIME DEFAULT NULL;

ALTER TABLE public.notification_preferences
ADD COLUMN IF NOT EXISTS quiet_hours_end TIME DEFAULT NULL;

ALTER TABLE public.notification_preferences
ADD COLUMN IF NOT EXISTS do_not_disturb BOOLEAN DEFAULT false;

COMMENT ON COLUMN public.notification_preferences.push_notification_enabled IS 'Enable/disable browser push notifications';
COMMENT ON COLUMN public.notification_preferences.email_notification_enabled IS 'Enable/disable email notifications';
COMMENT ON COLUMN public.notification_preferences.quiet_hours_start IS 'Start time for quiet hours (no notifications)';
COMMENT ON COLUMN public.notification_preferences.quiet_hours_end IS 'End time for quiet hours (no notifications)';
COMMENT ON COLUMN public.notification_preferences.do_not_disturb IS 'Enable do-not-disturb mode (blocks all notifications)';

-- Create index for faster lookups
CREATE INDEX IF NOT EXISTS idx_notification_preferences_user_id ON public.notification_preferences(user_id);