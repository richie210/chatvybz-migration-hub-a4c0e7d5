-- Content Moderation and Flagging System
-- Supports AI-powered content flagging using Anthropic Claude

-- Flagged Content Table
CREATE TABLE IF NOT EXISTS public.flagged_content (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  content_id TEXT NOT NULL,
  content_type TEXT NOT NULL CHECK (content_type IN ('message', 'channel_post', 'status', 'comment')),
  content TEXT NOT NULL,
  author_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  violation_type TEXT NOT NULL CHECK (violation_type IN ('spam', 'harassment', 'tos_violation', 'none')),
  ai_confidence DECIMAL(3,2) NOT NULL CHECK (ai_confidence >= 0 AND ai_confidence <= 1),
  severity TEXT NOT NULL CHECK (severity IN ('low', 'medium', 'high', 'critical')),
  ai_reasoning TEXT NOT NULL,
  recommended_action TEXT NOT NULL CHECK (recommended_action IN ('approve', 'review', 'remove', 'ban_user')),
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'removed', 'reviewed')),
  reviewed_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  reviewed_at TIMESTAMPTZ,
  admin_notes TEXT,
  action_taken TEXT,
  flagged_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_flagged_content_status ON public.flagged_content(status);
CREATE INDEX IF NOT EXISTS idx_flagged_content_author ON public.flagged_content(author_id);
CREATE INDEX IF NOT EXISTS idx_flagged_content_violation_type ON public.flagged_content(violation_type);
CREATE INDEX IF NOT EXISTS idx_flagged_content_severity ON public.flagged_content(severity);
CREATE INDEX IF NOT EXISTS idx_flagged_content_flagged_at ON public.flagged_content(flagged_at DESC);

-- RLS Policies
ALTER TABLE public.flagged_content ENABLE ROW LEVEL SECURITY;

-- Admin can view all flagged content
CREATE POLICY "Admins can view all flagged content"
  ON public.flagged_content
  FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE profiles.id = auth.uid()
      AND profiles.is_admin = true
    )
  );

-- Admin can update flagged content (review)
CREATE POLICY "Admins can update flagged content"
  ON public.flagged_content
  FOR UPDATE
  USING (
    EXISTS (
      SELECT 1 FROM public.profiles
      WHERE profiles.id = auth.uid()
      AND profiles.is_admin = true
    )
  );

-- System can insert flagged content
CREATE POLICY "System can insert flagged content"
  ON public.flagged_content
  FOR INSERT
  WITH CHECK (true);

-- Updated at trigger
CREATE OR REPLACE FUNCTION public.update_flagged_content_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_flagged_content_updated_at_trigger
  BEFORE UPDATE ON public.flagged_content
  FOR EACH ROW
  EXECUTE FUNCTION public.update_flagged_content_updated_at();

-- Success message
DO $$
BEGIN
  RAISE NOTICE 'Content moderation and flagging system created successfully';
END $$;
