-- Location: supabase/migrations/20251221191700_add_scheduling_mentions.sql
-- Schema Analysis: Existing chat_messages, profiles tables
-- Integration Type: Addition (new scheduling and mentions features)
-- Dependencies: chat_messages, profiles

-- ==========================================
-- 1. NEW TABLES FOR MESSAGE SCHEDULING
-- ==========================================

-- Scheduled messages table
CREATE TABLE public.scheduled_messages (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    sender_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    recipient_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
    message TEXT NOT NULL,
    scheduled_time TIMESTAMPTZ NOT NULL,
    timezone TEXT DEFAULT 'UTC',
    delivery_status TEXT DEFAULT 'pending',
    delivery_confirmation BOOLEAN DEFAULT false,
    recurring_pattern TEXT,
    next_occurrence TIMESTAMPTZ,
    is_encrypted BOOLEAN DEFAULT false,
    nonce TEXT,
    attachments JSONB DEFAULT '[]'::jsonb,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    delivered_at TIMESTAMPTZ,
    cancelled_at TIMESTAMPTZ,
    edit_history JSONB DEFAULT '[]'::jsonb,
    CONSTRAINT valid_scheduled_time CHECK (scheduled_time > CURRENT_TIMESTAMP)
);

-- Message mentions table for @mention tracking
CREATE TABLE public.message_mentions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    message_id UUID NOT NULL REFERENCES public.chat_messages(id) ON DELETE CASCADE,
    mentioned_user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    mentioner_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    is_read BOOLEAN DEFAULT false,
    notified_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(message_id, mentioned_user_id)
);

-- ==========================================
-- 2. INDEXES FOR PERFORMANCE
-- ==========================================

CREATE INDEX idx_scheduled_messages_sender ON public.scheduled_messages(sender_id);
CREATE INDEX idx_scheduled_messages_recipient ON public.scheduled_messages(recipient_id);
CREATE INDEX idx_scheduled_messages_scheduled_time ON public.scheduled_messages(scheduled_time);
CREATE INDEX idx_scheduled_messages_delivery_status ON public.scheduled_messages(delivery_status);
CREATE INDEX idx_message_mentions_message ON public.message_mentions(message_id);
CREATE INDEX idx_message_mentions_mentioned_user ON public.message_mentions(mentioned_user_id);
CREATE INDEX idx_message_mentions_is_read ON public.message_mentions(is_read) WHERE is_read = false;

-- ==========================================
-- 3. FUNCTIONS FOR MESSAGE SCHEDULING
-- ==========================================

-- Function to process scheduled messages
CREATE OR REPLACE FUNCTION public.process_scheduled_messages()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    -- Move due scheduled messages to chat_messages
    INSERT INTO public.chat_messages (
        sender_id,
        recipient_id,
        message,
        is_encrypted,
        nonce,
        created_at
    )
    SELECT
        sm.sender_id,
        sm.recipient_id,
        sm.message,
        sm.is_encrypted,
        sm.nonce,
        CURRENT_TIMESTAMP
    FROM public.scheduled_messages sm
    WHERE sm.scheduled_time <= CURRENT_TIMESTAMP
        AND sm.delivery_status = 'pending'
        AND sm.cancelled_at IS NULL;

    -- Update scheduled messages as delivered
    UPDATE public.scheduled_messages
    SET 
        delivery_status = 'delivered',
        delivered_at = CURRENT_TIMESTAMP,
        delivery_confirmation = true
    WHERE scheduled_time <= CURRENT_TIMESTAMP
        AND delivery_status = 'pending'
        AND cancelled_at IS NULL;

    -- Handle recurring messages
    UPDATE public.scheduled_messages
    SET 
        scheduled_time = next_occurrence,
        delivery_status = 'pending'
    WHERE next_occurrence IS NOT NULL
        AND next_occurrence <= CURRENT_TIMESTAMP
        AND delivery_status = 'delivered';
END;
$$;

-- Function to cancel scheduled message
CREATE OR REPLACE FUNCTION public.cancel_scheduled_message(message_uuid UUID)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    result jsonb;
BEGIN
    UPDATE public.scheduled_messages
    SET 
        delivery_status = 'cancelled',
        cancelled_at = CURRENT_TIMESTAMP
    WHERE id = message_uuid
        AND sender_id = auth.uid()
        AND delivery_status = 'pending'
    RETURNING jsonb_build_object(
        'success', true,
        'message', 'Scheduled message cancelled successfully'
    ) INTO result;

    IF result IS NULL THEN
        RETURN jsonb_build_object(
            'success', false,
            'message', 'Unable to cancel message'
        );
    END IF;

    RETURN result;
END;
$$;

-- Function to edit scheduled message
CREATE OR REPLACE FUNCTION public.edit_scheduled_message(
    message_uuid UUID,
    new_message TEXT,
    new_scheduled_time TIMESTAMPTZ
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    old_content TEXT;
    result jsonb;
BEGIN
    -- Get old message for history
    SELECT message INTO old_content
    FROM public.scheduled_messages
    WHERE id = message_uuid
        AND sender_id = auth.uid();

    -- Update message with history
    UPDATE public.scheduled_messages
    SET 
        message = new_message,
        scheduled_time = new_scheduled_time,
        updated_at = CURRENT_TIMESTAMP,
        edit_history = edit_history || jsonb_build_object(
            'edited_at', CURRENT_TIMESTAMP,
            'previous_message', old_content,
            'previous_time', scheduled_time
        )
    WHERE id = message_uuid
        AND sender_id = auth.uid()
        AND delivery_status = 'pending'
    RETURNING jsonb_build_object(
        'success', true,
        'message', 'Scheduled message updated successfully'
    ) INTO result;

    IF result IS NULL THEN
        RETURN jsonb_build_object(
            'success', false,
            'message', 'Unable to update message'
        );
    END IF;

    RETURN result;
END;
$$;

-- Function to notify mentioned users
CREATE OR REPLACE FUNCTION public.notify_mentioned_users()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    -- Update notified_at timestamp for new mentions
    UPDATE public.message_mentions
    SET notified_at = CURRENT_TIMESTAMP
    WHERE id = NEW.id;

    RETURN NEW;
END;
$$;

-- Function to extract mentions from message
CREATE OR REPLACE FUNCTION public.extract_mentions(message_text TEXT)
RETURNS UUID[]
LANGUAGE plpgsql
STABLE
AS $$
DECLARE
    mention_ids UUID[];
BEGIN
    -- Extract @mentions and return user IDs
    -- Pattern: @[username] or @[user.id]
    SELECT ARRAY_AGG(DISTINCT p.id)
    INTO mention_ids
    FROM public.profiles p
    WHERE message_text ~* ('@' || p.full_name)
        OR message_text ~* ('@' || p.email);

    RETURN COALESCE(mention_ids, ARRAY[]::UUID[]);
END;
$$;

-- ==========================================
-- 4. ENABLE RLS
-- ==========================================

ALTER TABLE public.scheduled_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.message_mentions ENABLE ROW LEVEL SECURITY;

-- ==========================================
-- 5. RLS POLICIES (Pattern 2: Simple User Ownership)
-- ==========================================

-- Scheduled messages policies
CREATE POLICY "users_manage_own_scheduled_messages"
ON public.scheduled_messages
FOR ALL
TO authenticated
USING (sender_id = auth.uid())
WITH CHECK (sender_id = auth.uid());

-- Message mentions policies - users can view mentions they're part of
CREATE POLICY "users_view_their_mentions"
ON public.message_mentions
FOR SELECT
TO authenticated
USING (mentioned_user_id = auth.uid() OR mentioner_id = auth.uid());

CREATE POLICY "users_create_mentions"
ON public.message_mentions
FOR INSERT
TO authenticated
WITH CHECK (mentioner_id = auth.uid());

CREATE POLICY "users_update_their_mentions"
ON public.message_mentions
FOR UPDATE
TO authenticated
USING (mentioned_user_id = auth.uid())
WITH CHECK (mentioned_user_id = auth.uid());

-- ==========================================
-- 6. TRIGGERS
-- ==========================================

CREATE TRIGGER trigger_notify_mentions
    AFTER INSERT ON public.message_mentions
    FOR EACH ROW
    EXECUTE FUNCTION public.notify_mentioned_users();

-- Trigger to update updated_at on scheduled_messages
CREATE TRIGGER trigger_scheduled_messages_updated_at
    BEFORE UPDATE ON public.scheduled_messages
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();