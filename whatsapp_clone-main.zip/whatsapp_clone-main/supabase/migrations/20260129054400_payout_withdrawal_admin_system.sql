-- Payout Withdrawal & Admin System Migration
-- Creates bank account management, withdrawal requests, and admin authentication

-- =====================================================
-- BANK ACCOUNTS TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS public.bank_accounts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  account_nickname TEXT NOT NULL,
  bank_name TEXT NOT NULL,
  account_type TEXT NOT NULL CHECK (account_type IN ('checking', 'savings')),
  routing_number TEXT NOT NULL,
  account_number_last4 TEXT NOT NULL,
  account_number_encrypted TEXT NOT NULL, -- Encrypted full account number
  is_primary BOOLEAN DEFAULT false,
  is_verified BOOLEAN DEFAULT false,
  verification_status TEXT DEFAULT 'pending' CHECK (verification_status IN ('pending', 'verified', 'failed')),
  verification_date TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_bank_accounts_user_id ON public.bank_accounts(user_id);
CREATE INDEX idx_bank_accounts_is_primary ON public.bank_accounts(user_id, is_primary) WHERE is_primary = true;

-- =====================================================
-- WITHDRAWAL REQUESTS TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS public.withdrawal_requests (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  bank_account_id UUID NOT NULL REFERENCES public.bank_accounts(id) ON DELETE RESTRICT,
  amount DECIMAL(10, 2) NOT NULL CHECK (amount > 0),
  currency TEXT DEFAULT 'USD',
  processing_fee DECIMAL(10, 2) DEFAULT 0,
  net_amount DECIMAL(10, 2) NOT NULL,
  status TEXT DEFAULT 'submitted' CHECK (status IN ('submitted', 'under_review', 'processing', 'completed', 'failed', 'cancelled')),
  withdrawal_type TEXT DEFAULT 'one_time' CHECK (withdrawal_type IN ('one_time', 'recurring')),
  schedule_frequency TEXT CHECK (schedule_frequency IN ('daily', 'weekly', 'monthly', 'custom')),
  schedule_date DATE,
  estimated_arrival_date DATE,
  actual_arrival_date DATE,
  failure_reason TEXT,
  notes TEXT,
  stripe_payout_id TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  completed_at TIMESTAMPTZ
);

CREATE INDEX idx_withdrawal_requests_user_id ON public.withdrawal_requests(user_id);
CREATE INDEX idx_withdrawal_requests_status ON public.withdrawal_requests(status);
CREATE INDEX idx_withdrawal_requests_created_at ON public.withdrawal_requests(created_at DESC);

-- =====================================================
-- WITHDRAWAL LIMITS TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS public.withdrawal_limits (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  daily_limit DECIMAL(10, 2) DEFAULT 1000.00,
  weekly_limit DECIMAL(10, 2) DEFAULT 5000.00,
  monthly_limit DECIMAL(10, 2) DEFAULT 20000.00,
  daily_used DECIMAL(10, 2) DEFAULT 0,
  weekly_used DECIMAL(10, 2) DEFAULT 0,
  monthly_used DECIMAL(10, 2) DEFAULT 0,
  last_daily_reset TIMESTAMPTZ DEFAULT NOW(),
  last_weekly_reset TIMESTAMPTZ DEFAULT NOW(),
  last_monthly_reset TIMESTAMPTZ DEFAULT NOW(),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id)
);

CREATE INDEX idx_withdrawal_limits_user_id ON public.withdrawal_limits(user_id);

-- =====================================================
-- ADMIN USERS CONFIGURATION
-- =====================================================
-- Update admin email in profiles table
DO $$
BEGIN
  -- Set is_admin flag for unityfmstream@gmail.com
  UPDATE public.profiles
  SET is_admin = true
  WHERE email = 'unityfmstream@gmail.com';
  
  -- If profile doesn't exist yet, it will be set when user registers
END $$;

-- =====================================================
-- FUNCTIONS
-- =====================================================

-- Function to calculate withdrawal fee
CREATE OR REPLACE FUNCTION public.calculate_withdrawal_fee(amount DECIMAL)
RETURNS DECIMAL AS $$
BEGIN
  -- Standard fee: 1% with minimum $1 and maximum $10
  RETURN LEAST(GREATEST(amount * 0.01, 1.00), 10.00);
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- Function to ensure only one primary bank account per user
CREATE OR REPLACE FUNCTION public.ensure_single_primary_bank_account()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.is_primary = true THEN
    -- Set all other accounts for this user to non-primary
    UPDATE public.bank_accounts
    SET is_primary = false
    WHERE user_id = NEW.user_id AND id != NEW.id;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_ensure_single_primary_bank_account
BEFORE INSERT OR UPDATE ON public.bank_accounts
FOR EACH ROW
EXECUTE FUNCTION public.ensure_single_primary_bank_account();

-- Function to update withdrawal limits usage
CREATE OR REPLACE FUNCTION public.update_withdrawal_limits()
RETURNS TRIGGER AS $$
DECLARE
  v_limits RECORD;
BEGIN
  IF NEW.status = 'completed' AND (OLD.status IS NULL OR OLD.status != 'completed') THEN
    -- Get or create limits record
    INSERT INTO public.withdrawal_limits (user_id)
    VALUES (NEW.user_id)
    ON CONFLICT (user_id) DO NOTHING;
    
    SELECT * INTO v_limits FROM public.withdrawal_limits WHERE user_id = NEW.user_id;
    
    -- Reset counters if needed
    IF v_limits.last_daily_reset < CURRENT_DATE THEN
      UPDATE public.withdrawal_limits
      SET daily_used = 0, last_daily_reset = NOW()
      WHERE user_id = NEW.user_id;
    END IF;
    
    IF v_limits.last_weekly_reset < DATE_TRUNC('week', CURRENT_DATE) THEN
      UPDATE public.withdrawal_limits
      SET weekly_used = 0, last_weekly_reset = NOW()
      WHERE user_id = NEW.user_id;
    END IF;
    
    IF v_limits.last_monthly_reset < DATE_TRUNC('month', CURRENT_DATE) THEN
      UPDATE public.withdrawal_limits
      SET monthly_used = 0, last_monthly_reset = NOW()
      WHERE user_id = NEW.user_id;
    END IF;
    
    -- Update usage
    UPDATE public.withdrawal_limits
    SET 
      daily_used = daily_used + NEW.amount,
      weekly_used = weekly_used + NEW.amount,
      monthly_used = monthly_used + NEW.amount,
      updated_at = NOW()
    WHERE user_id = NEW.user_id;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_withdrawal_limits
AFTER INSERT OR UPDATE ON public.withdrawal_requests
FOR EACH ROW
EXECUTE FUNCTION public.update_withdrawal_limits();

-- =====================================================
-- RLS POLICIES
-- =====================================================

-- Enable RLS
ALTER TABLE public.bank_accounts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.withdrawal_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.withdrawal_limits ENABLE ROW LEVEL SECURITY;

-- Bank Accounts Policies
CREATE POLICY "Users can view their own bank accounts"
ON public.bank_accounts FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own bank accounts"
ON public.bank_accounts FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own bank accounts"
ON public.bank_accounts FOR UPDATE
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own bank accounts"
ON public.bank_accounts FOR DELETE
USING (auth.uid() = user_id);

-- Withdrawal Requests Policies
CREATE POLICY "Users can view their own withdrawal requests"
ON public.withdrawal_requests FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own withdrawal requests"
ON public.withdrawal_requests FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own pending withdrawal requests"
ON public.withdrawal_requests FOR UPDATE
USING (auth.uid() = user_id AND status IN ('submitted', 'under_review'))
WITH CHECK (auth.uid() = user_id);

-- Withdrawal Limits Policies
CREATE POLICY "Users can view their own withdrawal limits"
ON public.withdrawal_limits FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own withdrawal limits"
ON public.withdrawal_limits FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own withdrawal limits"
ON public.withdrawal_limits FOR UPDATE
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

-- =====================================================
-- ADMIN POLICIES
-- =====================================================

-- Admin can view all withdrawal requests
CREATE POLICY "Admins can view all withdrawal requests"
ON public.withdrawal_requests FOR SELECT
USING (
  EXISTS (
    SELECT 1 FROM public.profiles
    WHERE profiles.id = auth.uid() AND profiles.is_admin = true
  )
);

-- Admin can update any withdrawal request
CREATE POLICY "Admins can update all withdrawal requests"
ON public.withdrawal_requests FOR UPDATE
USING (
  EXISTS (
    SELECT 1 FROM public.profiles
    WHERE profiles.id = auth.uid() AND profiles.is_admin = true
  )
);

-- =====================================================
-- INITIAL DATA
-- =====================================================

-- Create default withdrawal limits for existing users
INSERT INTO public.withdrawal_limits (user_id)
SELECT id FROM auth.users
ON CONFLICT (user_id) DO NOTHING;