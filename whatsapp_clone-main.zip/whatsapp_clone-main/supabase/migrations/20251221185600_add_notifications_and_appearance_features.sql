-- Location: supabase/migrations/20251221185600_add_notifications_and_appearance_features.sql
-- Schema Analysis: Building upon existing messaging, calls, and status tables
-- Integration Type: Extension - adding notification preferences and appearance settings
-- Dependencies: profiles, chat_messages, calls, status_updates, status_replies

-- 1. Create notification preferences table
CREATE TABLE public.notification_preferences (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
    message_notifications BOOLEAN DEFAULT true,
    call_notifications BOOLEAN DEFAULT true,
    status_notifications BOOLEAN DEFAULT true,
    reply_notifications BOOLEAN DEFAULT true,
    group_notifications BOOLEAN DEFAULT true,
    muted_conversations JSONB DEFAULT '[]'::jsonb,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 2. Create appearance settings table
CREATE TABLE public.appearance_settings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
    theme TEXT DEFAULT 'system',
    font_size TEXT DEFAULT 'medium',
    wallpaper_url TEXT,
    wallpaper_type TEXT DEFAULT 'default',
    language TEXT DEFAULT 'en',
    compact_mode BOOLEAN DEFAULT false,
    show_animations BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- 3. Create indexes
CREATE INDEX idx_notification_preferences_user_id ON public.notification_preferences(user_id);
CREATE INDEX idx_appearance_settings_user_id ON public.appearance_settings(user_id);

-- 4. Create update trigger function
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;

-- 5. Add triggers
CREATE TRIGGER update_notification_preferences_updated_at
    BEFORE UPDATE ON public.notification_preferences
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_appearance_settings_updated_at
    BEFORE UPDATE ON public.appearance_settings
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

-- 6. Enable RLS
ALTER TABLE public.notification_preferences ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.appearance_settings ENABLE ROW LEVEL SECURITY;

-- 7. Create RLS policies (Pattern 2: Simple User Ownership)
CREATE POLICY "users_manage_own_notification_preferences"
ON public.notification_preferences
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

CREATE POLICY "users_manage_own_appearance_settings"
ON public.appearance_settings
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

-- 8. Create storage bucket for wallpapers
INSERT INTO storage.buckets (id, name, public)
VALUES ('chat-wallpapers', 'chat-wallpapers', false)
ON CONFLICT (id) DO NOTHING;

-- 9. Create storage policies for wallpapers bucket
CREATE POLICY "users_can_upload_own_wallpapers"
ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (
    bucket_id = 'chat-wallpapers' 
    AND auth.uid()::text = (storage.foldername(name))[1]
);

CREATE POLICY "users_can_view_own_wallpapers"
ON storage.objects
FOR SELECT
TO authenticated
USING (
    bucket_id = 'chat-wallpapers' 
    AND auth.uid()::text = (storage.foldername(name))[1]
);

CREATE POLICY "users_can_update_own_wallpapers"
ON storage.objects
FOR UPDATE
TO authenticated
USING (
    bucket_id = 'chat-wallpapers' 
    AND auth.uid()::text = (storage.foldername(name))[1]
);

CREATE POLICY "users_can_delete_own_wallpapers"
ON storage.objects
FOR DELETE
TO authenticated
USING (
    bucket_id = 'chat-wallpapers' 
    AND auth.uid()::text = (storage.foldername(name))[1]
);