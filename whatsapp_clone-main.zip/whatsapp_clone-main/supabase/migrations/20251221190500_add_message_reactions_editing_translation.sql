-- Location: supabase/migrations/20251221190500_add_message_reactions_editing_translation.sql
-- Schema Analysis: Existing chat_messages table with basic messaging functionality
-- Integration Type: Extension - Adding reactions, editing, enhanced deletion, and translation features
-- Dependencies: chat_messages, profiles

-- 1. Add new columns to chat_messages table for additional features
ALTER TABLE public.chat_messages
ADD COLUMN IF NOT EXISTS is_edited BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS edited_at TIMESTAMPTZ,
ADD COLUMN IF NOT EXISTS edit_history JSONB DEFAULT '[]'::JSONB,
ADD COLUMN IF NOT EXISTS deleted_for TEXT[], -- Array of user IDs who deleted this message
ADD COLUMN IF NOT EXISTS deleted_by_sender BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS reactions JSONB DEFAULT '{}'::JSONB, -- { "👍": ["user_id1", "user_id2"], "❤️": ["user_id3"] }
ADD COLUMN IF NOT EXISTS original_language TEXT,
ADD COLUMN IF NOT EXISTS translations JSONB DEFAULT '{}'::JSONB; -- { "es": "Hola", "fr": "Bonjour" }

-- 2. Create message_reactions table for detailed reaction tracking
CREATE TABLE IF NOT EXISTS public.message_reactions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    message_id UUID NOT NULL REFERENCES public.chat_messages(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    emoji TEXT NOT NULL CHECK (emoji IN ('👍', '❤️', '😂', '😮', '😢', '🙏')),
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(message_id, user_id, emoji)
);

-- 3. Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_message_reactions_message_id ON public.message_reactions(message_id);
CREATE INDEX IF NOT EXISTS idx_message_reactions_user_id ON public.message_reactions(user_id);
CREATE INDEX IF NOT EXISTS idx_chat_messages_edited ON public.chat_messages(is_edited) WHERE is_edited = true;
CREATE INDEX IF NOT EXISTS idx_chat_messages_translations ON public.chat_messages USING gin(translations);

-- 4. Function to check if message can be edited (within time window)
CREATE OR REPLACE FUNCTION public.can_edit_message(message_uuid UUID, edit_window_minutes INTEGER DEFAULT 15)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
SELECT EXISTS (
    SELECT 1 FROM public.chat_messages cm
    WHERE cm.id = message_uuid
    AND cm.sender_id = auth.uid()
    AND cm.created_at > (NOW() - (edit_window_minutes || ' minutes')::INTERVAL)
    AND cm.deleted_by_sender = false
)
$$;

-- 5. Function to edit a message
CREATE OR REPLACE FUNCTION public.edit_message(
    message_uuid UUID,
    new_content TEXT
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    old_content TEXT;
    result JSONB;
BEGIN
    -- Check if user can edit this message
    IF NOT public.can_edit_message(message_uuid) THEN
        RETURN jsonb_build_object(
            'success', false,
            'error', 'Cannot edit this message. Time window expired or not authorized.'
        );
    END IF;

    -- Get old content and update message
    UPDATE public.chat_messages
    SET 
        message = new_content,
        is_edited = true,
        edited_at = NOW(),
        edit_history = edit_history || jsonb_build_object(
            'content', message,
            'edited_at', NOW()
        )
    WHERE id = message_uuid
    RETURNING message INTO old_content;

    RETURN jsonb_build_object(
        'success', true,
        'message', 'Message edited successfully'
    );
END;
$$;

-- 6. Function to delete message with visibility controls
CREATE OR REPLACE FUNCTION public.delete_message_with_visibility(
    message_uuid UUID,
    delete_for_everyone BOOLEAN DEFAULT false
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    msg_sender_id UUID;
    current_user_id UUID := auth.uid();
BEGIN
    -- Get message sender
    SELECT sender_id INTO msg_sender_id
    FROM public.chat_messages
    WHERE id = message_uuid;

    IF msg_sender_id IS NULL THEN
        RETURN jsonb_build_object(
            'success', false,
            'error', 'Message not found'
        );
    END IF;

    -- If sender wants to delete for everyone
    IF delete_for_everyone AND msg_sender_id = current_user_id THEN
        UPDATE public.chat_messages
        SET deleted_by_sender = true
        WHERE id = message_uuid;

        RETURN jsonb_build_object(
            'success', true,
            'message', 'Message deleted for everyone'
        );
    END IF;

    -- Delete for current user only (add to deleted_for array)
    UPDATE public.chat_messages
    SET deleted_for = COALESCE(deleted_for, ARRAY[]::TEXT[]) || ARRAY[current_user_id::TEXT]
    WHERE id = message_uuid;

    RETURN jsonb_build_object(
        'success', true,
        'message', 'Message deleted for you'
    );
END;
$$;

-- 7. Function to add/remove reaction
CREATE OR REPLACE FUNCTION public.toggle_reaction(
    message_uuid UUID,
    reaction_emoji TEXT
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    current_user_id UUID := auth.uid();
    existing_reaction UUID;
BEGIN
    -- Validate emoji
    IF reaction_emoji NOT IN ('👍', '❤️', '😂', '😮', '😢', '🙏') THEN
        RETURN jsonb_build_object(
            'success', false,
            'error', 'Invalid reaction emoji'
        );
    END IF;

    -- Check if reaction already exists
    SELECT id INTO existing_reaction
    FROM public.message_reactions
    WHERE message_id = message_uuid
    AND user_id = current_user_id
    AND emoji = reaction_emoji;

    IF existing_reaction IS NOT NULL THEN
        -- Remove reaction
        DELETE FROM public.message_reactions WHERE id = existing_reaction;
        RETURN jsonb_build_object(
            'success', true,
            'action', 'removed',
            'emoji', reaction_emoji
        );
    ELSE
        -- Add reaction
        INSERT INTO public.message_reactions (message_id, user_id, emoji)
        VALUES (message_uuid, current_user_id, reaction_emoji);
        
        RETURN jsonb_build_object(
            'success', true,
            'action', 'added',
            'emoji', reaction_emoji
        );
    END IF;
END;
$$;

-- 8. Function to cache translation
CREATE OR REPLACE FUNCTION public.cache_translation(
    message_uuid UUID,
    target_language TEXT,
    translated_text TEXT
)
RETURNS JSONB
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    UPDATE public.chat_messages
    SET translations = COALESCE(translations, '{}'::JSONB) || 
        jsonb_build_object(target_language, translated_text)
    WHERE id = message_uuid;

    RETURN jsonb_build_object(
        'success', true,
        'message', 'Translation cached successfully'
    );
END;
$$;

-- 9. Enable RLS for message_reactions
ALTER TABLE public.message_reactions ENABLE ROW LEVEL SECURITY;

-- 10. RLS Policies for message_reactions (Pattern 4: Public Read, Private Write)
CREATE POLICY "public_can_view_reactions"
ON public.message_reactions
FOR SELECT
TO public
USING (true);

CREATE POLICY "users_can_manage_own_reactions"
ON public.message_reactions
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

-- 11. Update existing RLS policies to handle deleted messages
DROP POLICY IF EXISTS "Users can view public messages" ON public.chat_messages;

CREATE POLICY "users_can_view_non_deleted_messages"
ON public.chat_messages
FOR SELECT
TO public
USING (
    (is_private = false OR sender_id = auth.uid() OR recipient_id = auth.uid())
    AND deleted_by_sender = false
    AND (deleted_for IS NULL OR NOT (auth.uid()::TEXT = ANY(deleted_for)))
);

-- 12. Trigger to update reactions JSONB when message_reactions changes
CREATE OR REPLACE FUNCTION public.update_message_reactions_summary()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
DECLARE
    reactions_summary JSONB;
BEGIN
    -- Rebuild reactions summary for the message
    SELECT jsonb_object_agg(emoji, user_ids)
    INTO reactions_summary
    FROM (
        SELECT emoji, jsonb_agg(user_id) as user_ids
        FROM public.message_reactions
        WHERE message_id = COALESCE(NEW.message_id, OLD.message_id)
        GROUP BY emoji
    ) sub;

    -- Update chat_messages with new reactions summary
    UPDATE public.chat_messages
    SET reactions = COALESCE(reactions_summary, '{}'::JSONB)
    WHERE id = COALESCE(NEW.message_id, OLD.message_id);

    RETURN COALESCE(NEW, OLD);
END;
$$;

CREATE TRIGGER trigger_update_message_reactions_summary
AFTER INSERT OR UPDATE OR DELETE ON public.message_reactions
FOR EACH ROW
EXECUTE FUNCTION public.update_message_reactions_summary();

-- 13. Create function to get message reactions with user details
CREATE OR REPLACE FUNCTION public.get_message_reactions(message_uuid UUID)
RETURNS TABLE(
    emoji TEXT,
    users JSONB
)
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
SELECT 
    mr.emoji,
    jsonb_agg(
        jsonb_build_object(
            'id', p.id,
            'full_name', p.full_name,
            'avatar_url', p.avatar_url
        )
    ) as users
FROM public.message_reactions mr
JOIN public.profiles p ON mr.user_id = p.id
WHERE mr.message_id = message_uuid
GROUP BY mr.emoji;
$$;