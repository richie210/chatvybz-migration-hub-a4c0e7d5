-- Location: supabase/migrations/20251224142849_call_recording_ai_summaries.sql
-- Schema Analysis: Extends existing meeting_recordings table, references meetings, calls, profiles
-- Integration Type: Extension + Addition
-- Dependencies: meetings, calls, profiles, meeting_recordings

-- 1. Create ENUM for recording types
CREATE TYPE public.recording_type AS ENUM ('call', 'meeting', 'conference');
CREATE TYPE public.share_permission AS ENUM ('view', 'download', 'full_access');

-- 2. Extend meeting_recordings table with new columns
ALTER TABLE public.meeting_recordings
ADD COLUMN IF NOT EXISTS recording_type public.recording_type DEFAULT 'meeting'::public.recording_type,
ADD COLUMN IF NOT EXISTS call_id UUID REFERENCES public.calls(id) ON DELETE CASCADE,
ADD COLUMN IF NOT EXISTS transcript TEXT,
ADD COLUMN IF NOT EXISTS ai_summary TEXT,
ADD COLUMN IF NOT EXISTS action_items JSONB DEFAULT '[]'::jsonb,
ADD COLUMN IF NOT EXISTS key_points JSONB DEFAULT '[]'::jsonb,
ADD COLUMN IF NOT EXISTS is_processing BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS processing_error TEXT,
ADD COLUMN IF NOT EXISTS processed_at TIMESTAMPTZ,
ADD COLUMN IF NOT EXISTS uploaded_by UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
ADD COLUMN IF NOT EXISTS is_public BOOLEAN DEFAULT false;

-- 3. Create recording_shares table for sharing functionality
CREATE TABLE public.recording_shares (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    recording_id UUID REFERENCES public.meeting_recordings(id) ON DELETE CASCADE,
    shared_with_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
    shared_by_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    permission public.share_permission DEFAULT 'view'::public.share_permission,
    expires_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT unique_recording_share UNIQUE(recording_id, shared_with_id)
);

-- 4. Create indexes for new columns and relationships
CREATE INDEX IF NOT EXISTS idx_meeting_recordings_call_id ON public.meeting_recordings(call_id);
CREATE INDEX IF NOT EXISTS idx_meeting_recordings_recording_type ON public.meeting_recordings(recording_type);
CREATE INDEX IF NOT EXISTS idx_meeting_recordings_uploaded_by ON public.meeting_recordings(uploaded_by);
CREATE INDEX IF NOT EXISTS idx_meeting_recordings_is_public ON public.meeting_recordings(is_public);
CREATE INDEX IF NOT EXISTS idx_recording_shares_recording_id ON public.recording_shares(recording_id);
CREATE INDEX IF NOT EXISTS idx_recording_shares_shared_with_id ON public.recording_shares(shared_with_id);

-- 5. Enable RLS on new table
ALTER TABLE public.recording_shares ENABLE ROW LEVEL SECURITY;

-- 6. Helper function to check recording ownership with NULL-safe checks and explicit type casting
CREATE OR REPLACE FUNCTION public.owns_recording(recording_uuid UUID)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
SELECT EXISTS (
    SELECT 1 FROM public.meeting_recordings mr
    WHERE mr.id = recording_uuid
    AND (
        mr.uploaded_by = (auth.uid())::uuid
        OR (mr.meeting_id IS NOT NULL AND EXISTS (
            SELECT 1 FROM public.meetings m
            WHERE m.id = mr.meeting_id AND m.host_id = (auth.uid())::uuid
        ))
        OR (mr.call_id IS NOT NULL AND EXISTS (
            SELECT 1 FROM public.calls c
            WHERE c.id = mr.call_id AND (c.initiator_id = (auth.uid())::uuid OR c.recipient_id = (auth.uid())::uuid)
        ))
    )
)
$$;

-- 7. Helper function to check recording access with NULL-safe checks and explicit type casting
CREATE OR REPLACE FUNCTION public.can_access_recording(recording_uuid UUID)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
SELECT EXISTS (
    SELECT 1 FROM public.meeting_recordings mr
    WHERE mr.id = recording_uuid
    AND (
        mr.is_public = true
        OR mr.uploaded_by = (auth.uid())::uuid
        OR (mr.meeting_id IS NOT NULL AND EXISTS (
            SELECT 1 FROM public.meetings m
            WHERE m.id = mr.meeting_id AND m.host_id = (auth.uid())::uuid
        ))
        OR (mr.meeting_id IS NOT NULL AND EXISTS (
            SELECT 1 FROM public.meeting_participants mp
            WHERE mp.meeting_id = mr.meeting_id AND mp.user_id = (auth.uid())::uuid
        ))
        OR (mr.call_id IS NOT NULL AND EXISTS (
            SELECT 1 FROM public.calls c
            WHERE c.id = mr.call_id AND (c.initiator_id = (auth.uid())::uuid OR c.recipient_id = (auth.uid())::uuid)
        ))
        OR EXISTS (
            SELECT 1 FROM public.recording_shares rs
            WHERE rs.recording_id = recording_uuid 
            AND rs.shared_with_id = (auth.uid())::uuid
            AND (rs.expires_at IS NULL OR rs.expires_at > now())
        )
    )
)
$$;

-- 8. Update RLS policies for meeting_recordings with NULL-safe checks and explicit type casting
DROP POLICY IF EXISTS "Hosts can create recordings" ON public.meeting_recordings;
DROP POLICY IF EXISTS "Users can view recordings" ON public.meeting_recordings;

CREATE POLICY "users_can_create_recordings"
ON public.meeting_recordings
FOR INSERT
TO authenticated
WITH CHECK (
    uploaded_by = (auth.uid())::uuid
    OR (meeting_id IS NOT NULL AND EXISTS (
        SELECT 1 FROM public.meetings m
        WHERE m.id = meeting_id AND m.host_id = (auth.uid())::uuid
    ))
    OR (call_id IS NOT NULL AND EXISTS (
        SELECT 1 FROM public.calls c
        WHERE c.id = call_id AND (c.initiator_id = (auth.uid())::uuid OR c.recipient_id = (auth.uid())::uuid)
    ))
);

CREATE POLICY "users_can_view_recordings"
ON public.meeting_recordings
FOR SELECT
TO authenticated
USING (public.can_access_recording(id));

CREATE POLICY "owners_can_update_recordings"
ON public.meeting_recordings
FOR UPDATE
TO authenticated
USING (public.owns_recording(id))
WITH CHECK (public.owns_recording(id));

CREATE POLICY "owners_can_delete_recordings"
ON public.meeting_recordings
FOR DELETE
TO authenticated
USING (public.owns_recording(id));

-- 9. RLS policies for recording_shares with NULL-safe checks and explicit type casting
CREATE POLICY "users_can_view_shares"
ON public.recording_shares
FOR SELECT
TO authenticated
USING (
    shared_with_id = (auth.uid())::uuid
    OR shared_by_id = (auth.uid())::uuid
    OR EXISTS (
        SELECT 1 FROM public.meeting_recordings mr
        WHERE mr.id = recording_id AND public.owns_recording(mr.id)
    )
);

CREATE POLICY "owners_can_create_shares"
ON public.recording_shares
FOR INSERT
TO authenticated
WITH CHECK (
    shared_by_id = (auth.uid())::uuid
    AND EXISTS (
        SELECT 1 FROM public.meeting_recordings mr
        WHERE mr.id = recording_id AND public.owns_recording(mr.id)
    )
);

CREATE POLICY "owners_can_delete_shares"
ON public.recording_shares
FOR DELETE
TO authenticated
USING (
    shared_by_id = (auth.uid())::uuid
    OR EXISTS (
        SELECT 1 FROM public.meeting_recordings mr
        WHERE mr.id = recording_id AND public.owns_recording(mr.id)
    )
);

-- 10. Function to clean up expired shares
CREATE OR REPLACE FUNCTION public.cleanup_expired_shares()
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    DELETE FROM public.recording_shares
    WHERE expires_at IS NOT NULL AND expires_at < now();
END;
$$;