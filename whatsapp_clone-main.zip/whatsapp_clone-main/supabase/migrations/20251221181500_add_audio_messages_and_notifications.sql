-- Migration: Add audio messages and push notification support
-- Description: Extends chat_messages for audio, creates storage bucket, and adds push notification tokens

-- ============================================================================
-- SCHEMA: Add audio support to chat_messages (MOVED TO TOP)
-- ============================================================================

-- Add audio-related columns to chat_messages FIRST
ALTER TABLE chat_messages
ADD COLUMN IF NOT EXISTS audio_url TEXT,
ADD COLUMN IF NOT EXISTS audio_duration INTEGER, -- duration in seconds
ADD COLUMN IF NOT EXISTS audio_waveform JSONB; -- waveform data for visualization

-- Create index for audio messages
CREATE INDEX IF NOT EXISTS idx_chat_messages_audio 
ON chat_messages(audio_url) 
WHERE audio_url IS NOT NULL;

-- ============================================================================
-- STORAGE: Audio Messages Bucket (NOW REFERENCES EXISTING COLUMNS)
-- ============================================================================

-- Create private bucket for audio messages
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'audio-messages',
  'audio-messages',
  false,
  10485760, -- 10MB limit
  ARRAY['audio/webm', 'audio/wav', 'audio/mp3', 'audio/ogg', 'audio/mpeg']
)
ON CONFLICT (id) DO NOTHING;

-- RLS policies for audio-messages bucket
CREATE POLICY "Users can upload their own audio messages"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'audio-messages' AND
  auth.uid()::text = (storage.foldername(name))[1]
);

CREATE POLICY "Users can view audio messages they sent or received"
ON storage.objects FOR SELECT
TO authenticated
USING (
  bucket_id = 'audio-messages' AND
  (
    auth.uid()::text = (storage.foldername(name))[1] OR
    EXISTS (
      SELECT 1 FROM chat_messages cm
      WHERE cm.audio_url = CONCAT('audio-messages/', name)
      AND (cm.sender_id = auth.uid() OR cm.recipient_id = auth.uid())
    )
  )
);

CREATE POLICY "Users can delete their own audio messages"
ON storage.objects FOR DELETE
TO authenticated
USING (
  bucket_id = 'audio-messages' AND
  auth.uid()::text = (storage.foldername(name))[1]
);

-- ============================================================================
-- SCHEMA: Push notification tokens
-- ============================================================================

-- Create table for push notification subscriptions
CREATE TABLE IF NOT EXISTS push_subscriptions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  endpoint TEXT NOT NULL,
  keys JSONB NOT NULL, -- stores p256dh and auth keys
  user_agent TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, endpoint)
);

-- Enable RLS
ALTER TABLE push_subscriptions ENABLE ROW LEVEL SECURITY;

-- RLS policies for push_subscriptions
CREATE POLICY "Users can manage their own push subscriptions"
ON push_subscriptions FOR ALL
TO authenticated
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

-- Create index for efficient lookups
CREATE INDEX IF NOT EXISTS idx_push_subscriptions_user_id 
ON push_subscriptions(user_id);

-- ============================================================================
-- FUNCTIONS: Push notification trigger
-- ============================================================================

-- Function to notify about new messages (for push notifications)
CREATE OR REPLACE FUNCTION notify_new_message()
RETURNS TRIGGER AS $$
BEGIN
  -- Emit real-time event for push notification handling
  PERFORM pg_notify(
    'new_message_notification',
    json_build_object(
      'recipient_id', NEW.recipient_id,
      'sender_id', NEW.sender_id,
      'message_id', NEW.id,
      'message', CASE 
        WHEN NEW.audio_url IS NOT NULL THEN '🎤 Audio message'
        WHEN NEW.is_encrypted THEN '🔒 Encrypted message'
        ELSE LEFT(NEW.message, 50)
      END,
      'created_at', NEW.created_at
    )::text
  );
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger for new messages
DROP TRIGGER IF EXISTS trigger_notify_new_message ON chat_messages;
CREATE TRIGGER trigger_notify_new_message
AFTER INSERT ON chat_messages
FOR EACH ROW
EXECUTE FUNCTION notify_new_message();

-- ============================================================================
-- MOCK DATA: Test audio message (optional)
-- ============================================================================

DO $$
DECLARE
  test_sender_id UUID;
  test_recipient_id UUID;
BEGIN
  -- Get existing user IDs for testing
  SELECT id INTO test_sender_id FROM profiles LIMIT 1;
  SELECT id INTO test_recipient_id FROM profiles OFFSET 1 LIMIT 1;
  
  -- Only insert if we have users
  IF test_sender_id IS NOT NULL AND test_recipient_id IS NOT NULL THEN
    INSERT INTO chat_messages (
      sender_id,
      recipient_id,
      sender_name,
      message,
      audio_url,
      audio_duration,
      audio_waveform,
      status
    ) VALUES (
      test_sender_id,
      test_recipient_id,
      (SELECT full_name FROM profiles WHERE id = test_sender_id),
      'Audio message',
      NULL, -- Will be populated when actual audio is uploaded
      45, -- 45 seconds
      '{"peaks": [0.1, 0.3, 0.5, 0.7, 0.9, 0.7, 0.5, 0.3, 0.1]}'::jsonb,
      'sent'
    )
    ON CONFLICT DO NOTHING;
    
    RAISE NOTICE 'Test audio message created successfully';
  ELSE
    RAISE NOTICE 'Skipping test data - no users found';
  END IF;
END $$;

-- ============================================================================
-- COMMENTS
-- ============================================================================

COMMENT ON TABLE push_subscriptions IS 'Stores browser push notification subscriptions for users';
COMMENT ON COLUMN chat_messages.audio_url IS 'Storage path for audio message files';
COMMENT ON COLUMN chat_messages.audio_duration IS 'Duration of audio message in seconds';
COMMENT ON COLUMN chat_messages.audio_waveform IS 'JSON array of waveform peaks for visualization';