-- Location: supabase/migrations/20251224151145_chat_translation_settings.sql
-- Schema Analysis: Extending appearance_settings table for translation features
-- Integration Type: Extension
-- Dependencies: appearance_settings, profiles

-- Add translation-specific columns to appearance_settings table
ALTER TABLE public.appearance_settings
ADD COLUMN IF NOT EXISTS auto_translate_enabled BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS translation_preference TEXT DEFAULT 'ask_before',
ADD COLUMN IF NOT EXISTS do_not_translate_languages TEXT[] DEFAULT '{}',
ADD COLUMN IF NOT EXISTS preferred_translation_language TEXT DEFAULT 'en',
ADD COLUMN IF NOT EXISTS translate_entire_chats BOOLEAN DEFAULT false;

-- Add comment for documentation
COMMENT ON COLUMN public.appearance_settings.auto_translate_enabled IS 'Enable/disable automatic message translation';
COMMENT ON COLUMN public.appearance_settings.translation_preference IS 'Translation preference: auto_all, ask_before, or never';
COMMENT ON COLUMN public.appearance_settings.do_not_translate_languages IS 'Languages that should not trigger translation prompt';
COMMENT ON COLUMN public.appearance_settings.preferred_translation_language IS 'User preferred language for translations';
COMMENT ON COLUMN public.appearance_settings.translate_entire_chats IS 'Whether to translate all messages in conversations';

-- Create index for translation queries
CREATE INDEX IF NOT EXISTS idx_appearance_settings_auto_translate 
ON public.appearance_settings(user_id, auto_translate_enabled) 
WHERE auto_translate_enabled = true;

-- Update RLS policies (already exist from previous migration, no changes needed)
-- Pattern 2: Simple User Ownership already covers these new columns