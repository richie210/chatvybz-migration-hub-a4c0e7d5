-- Migration: Add calls and status/stories features
-- Created: 2025-12-21 18:29:30

-- ==============================================
-- 1. CREATE CUSTOM TYPES
-- ==============================================

-- Call status enum
DO $$ BEGIN
  CREATE TYPE call_status AS ENUM ('ringing', 'ongoing', 'ended', 'missed', 'declined');
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

-- Call type enum
DO $$ BEGIN
  CREATE TYPE call_type AS ENUM ('voice', 'video', 'conference');
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

-- ==============================================
-- 2. CREATE CALLS TABLES
-- ==============================================

-- Calls table
CREATE TABLE IF NOT EXISTS calls (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  initiator_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  recipient_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  call_type call_type NOT NULL DEFAULT 'voice',
  call_status call_status NOT NULL DEFAULT 'ringing',
  started_at TIMESTAMPTZ,
  ended_at TIMESTAMPTZ,
  duration INTEGER DEFAULT 0, -- duration in seconds
  is_muted BOOLEAN DEFAULT false,
  is_speaker_on BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Call participants table (for conference calls)
CREATE TABLE IF NOT EXISTS call_participants (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  call_id UUID NOT NULL REFERENCES calls(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  joined_at TIMESTAMPTZ DEFAULT NOW(),
  left_at TIMESTAMPTZ,
  is_muted BOOLEAN DEFAULT false,
  is_video_on BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ==============================================
-- 3. CREATE STATUS/STORIES TABLES
-- ==============================================

-- Status updates table
CREATE TABLE IF NOT EXISTS status_updates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  media_url TEXT NOT NULL,
  media_type TEXT NOT NULL, -- 'image' or 'video'
  caption TEXT,
  background_color TEXT,
  expires_at TIMESTAMPTZ NOT NULL DEFAULT (NOW() + INTERVAL '24 hours'),
  view_count INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Status views tracking
CREATE TABLE IF NOT EXISTS status_views (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  status_id UUID NOT NULL REFERENCES status_updates(id) ON DELETE CASCADE,
  viewer_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  viewed_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(status_id, viewer_id)
);

-- Status replies table
CREATE TABLE IF NOT EXISTS status_replies (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  status_id UUID NOT NULL REFERENCES status_updates(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  reply_text TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Status sharing permissions (contact-specific sharing)
CREATE TABLE IF NOT EXISTS status_sharing (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  status_id UUID NOT NULL REFERENCES status_updates(id) ON DELETE CASCADE,
  shared_with_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(status_id, shared_with_id)
);

-- ==============================================
-- 4. CREATE INDEXES
-- ==============================================

-- Calls indexes
CREATE INDEX IF NOT EXISTS idx_calls_initiator ON calls(initiator_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_calls_recipient ON calls(recipient_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_calls_status ON calls(call_status);
CREATE INDEX IF NOT EXISTS idx_call_participants_call ON call_participants(call_id);
CREATE INDEX IF NOT EXISTS idx_call_participants_user ON call_participants(user_id);

-- Status indexes
CREATE INDEX IF NOT EXISTS idx_status_user ON status_updates(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_status_expires ON status_updates(expires_at);
CREATE INDEX IF NOT EXISTS idx_status_views_status ON status_views(status_id);
CREATE INDEX IF NOT EXISTS idx_status_views_viewer ON status_views(viewer_id);
CREATE INDEX IF NOT EXISTS idx_status_replies_status ON status_replies(status_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_status_sharing_status ON status_sharing(status_id);

-- ==============================================
-- 5. CREATE FUNCTIONS
-- ==============================================

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Function to increment status view count
CREATE OR REPLACE FUNCTION increment_status_view_count()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE status_updates
  SET view_count = view_count + 1
  WHERE id = NEW.status_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Function to calculate call duration
CREATE OR REPLACE FUNCTION calculate_call_duration()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.ended_at IS NOT NULL AND NEW.started_at IS NOT NULL THEN
    NEW.duration = EXTRACT(EPOCH FROM (NEW.ended_at - NEW.started_at))::INTEGER;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Function to clean up expired statuses
CREATE OR REPLACE FUNCTION delete_expired_statuses()
RETURNS void AS $$
BEGIN
  DELETE FROM status_updates
  WHERE expires_at < NOW();
END;
$$ LANGUAGE plpgsql;

-- ==============================================
-- 6. CREATE TRIGGERS
-- ==============================================

-- Trigger for status view count
DROP TRIGGER IF EXISTS trigger_increment_status_view ON status_views;
CREATE TRIGGER trigger_increment_status_view
  AFTER INSERT ON status_views
  FOR EACH ROW
  EXECUTE FUNCTION increment_status_view_count();

-- Trigger for call duration calculation
DROP TRIGGER IF EXISTS trigger_calculate_call_duration ON calls;
CREATE TRIGGER trigger_calculate_call_duration
  BEFORE UPDATE ON calls
  FOR EACH ROW
  WHEN (NEW.ended_at IS DISTINCT FROM OLD.ended_at)
  EXECUTE FUNCTION calculate_call_duration();

-- Trigger for updated_at on calls
DROP TRIGGER IF EXISTS update_calls_updated_at ON calls;
CREATE TRIGGER update_calls_updated_at
  BEFORE UPDATE ON calls
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at();

-- Trigger for updated_at on status_updates
DROP TRIGGER IF EXISTS update_status_updated_at ON status_updates;
CREATE TRIGGER update_status_updated_at
  BEFORE UPDATE ON status_updates
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at();

-- ==============================================
-- 7. CREATE STORAGE BUCKETS
-- ==============================================

-- Status media bucket (private - users control who sees)
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'status-media',
  'status-media',
  false,
  10485760, -- 10MB limit
  ARRAY['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'video/mp4', 'video/quicktime']
)
ON CONFLICT (id) DO NOTHING;

-- Call recordings bucket (private)
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'call-recordings',
  'call-recordings',
  false,
  104857600, -- 100MB limit
  ARRAY['audio/webm', 'audio/mp4', 'video/webm', 'video/mp4']
)
ON CONFLICT (id) DO NOTHING;

-- ==============================================
-- 8. ENABLE ROW LEVEL SECURITY
-- ==============================================

ALTER TABLE calls ENABLE ROW LEVEL SECURITY;
ALTER TABLE call_participants ENABLE ROW LEVEL SECURITY;
ALTER TABLE status_updates ENABLE ROW LEVEL SECURITY;
ALTER TABLE status_views ENABLE ROW LEVEL SECURITY;
ALTER TABLE status_replies ENABLE ROW LEVEL SECURITY;
ALTER TABLE status_sharing ENABLE ROW LEVEL SECURITY;

-- ==============================================
-- 9. CREATE RLS POLICIES - CALLS
-- ==============================================

-- Users can view their own calls (as initiator or recipient)
CREATE POLICY "Users can view own calls"
  ON calls FOR SELECT
  USING (
    auth.uid() = initiator_id 
    OR auth.uid() = recipient_id
    OR auth.uid() IN (
      SELECT user_id FROM call_participants WHERE call_id = calls.id
    )
  );

-- Users can create calls
CREATE POLICY "Users can create calls"
  ON calls FOR INSERT
  WITH CHECK (auth.uid() = initiator_id);

-- Users can update their own calls
CREATE POLICY "Users can update own calls"
  ON calls FOR UPDATE
  USING (auth.uid() = initiator_id OR auth.uid() = recipient_id);

-- Call participants policies
CREATE POLICY "Users can view call participants"
  ON call_participants FOR SELECT
  USING (
    auth.uid() IN (
      SELECT initiator_id FROM calls WHERE id = call_participants.call_id
      UNION
      SELECT recipient_id FROM calls WHERE id = call_participants.call_id
      UNION
      SELECT user_id FROM call_participants WHERE call_id = call_participants.call_id
    )
  );

CREATE POLICY "Users can join calls as participants"
  ON call_participants FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own participation"
  ON call_participants FOR UPDATE
  USING (auth.uid() = user_id);

-- ==============================================
-- 10. CREATE RLS POLICIES - STATUS
-- ==============================================

-- Users can view their own status updates
CREATE POLICY "Users can view own status"
  ON status_updates FOR SELECT
  USING (auth.uid() = user_id);

-- Users can view all non-expired status updates (simplified - no contacts table needed)
-- If status_sharing exists for a status, only those users can see it
-- Otherwise, all authenticated users can see it
CREATE POLICY "Users can view public status"
  ON status_updates FOR SELECT
  USING (
    expires_at > NOW()
    AND auth.uid() != user_id
    AND (
      -- Either no specific sharing restrictions
      NOT EXISTS (SELECT 1 FROM status_sharing WHERE status_id = status_updates.id)
      -- OR user is in the sharing list
      OR EXISTS (
        SELECT 1 FROM status_sharing 
        WHERE status_id = status_updates.id 
        AND shared_with_id = auth.uid()
      )
    )
  );

-- Users can create their own status
CREATE POLICY "Users can create status"
  ON status_updates FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- Users can update their own status
CREATE POLICY "Users can update own status"
  ON status_updates FOR UPDATE
  USING (auth.uid() = user_id);

-- Users can delete their own status
CREATE POLICY "Users can delete own status"
  ON status_updates FOR DELETE
  USING (auth.uid() = user_id);

-- Status views policies
CREATE POLICY "Users can view status views for their own status"
  ON status_views FOR SELECT
  USING (
    status_id IN (SELECT id FROM status_updates WHERE user_id = auth.uid())
  );

CREATE POLICY "Users can record their views"
  ON status_views FOR INSERT
  WITH CHECK (auth.uid() = viewer_id);

-- Status replies policies
CREATE POLICY "Users can view replies to their status"
  ON status_replies FOR SELECT
  USING (
    status_id IN (SELECT id FROM status_updates WHERE user_id = auth.uid())
    OR auth.uid() = user_id
  );

CREATE POLICY "Users can create replies"
  ON status_replies FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- Status sharing policies
CREATE POLICY "Users can manage sharing for own status"
  ON status_sharing FOR ALL
  USING (
    status_id IN (SELECT id FROM status_updates WHERE user_id = auth.uid())
  );

-- ==============================================
-- 11. STORAGE RLS POLICIES
-- ==============================================

-- Status media policies
CREATE POLICY "Users can upload status media"
  ON storage.objects FOR INSERT
  WITH CHECK (
    bucket_id = 'status-media'
    AND auth.uid()::text = (storage.foldername(name))[1]
  );

-- Simplified policy - users can view status media if they can see the status update
CREATE POLICY "Users can view accessible status media"
  ON storage.objects FOR SELECT
  USING (
    bucket_id = 'status-media'
    AND (
      -- User owns the media
      auth.uid()::text = (storage.foldername(name))[1]
      OR 
      -- Or user can access via status_updates table (no contacts table needed)
      (storage.foldername(name))[1]::uuid IN (
        SELECT user_id FROM status_updates
        WHERE expires_at > NOW()
        AND (
          -- Either no sharing restrictions
          NOT EXISTS (SELECT 1 FROM status_sharing WHERE status_id = status_updates.id)
          -- OR user is in sharing list
          OR EXISTS (
            SELECT 1 FROM status_sharing 
            WHERE status_id = status_updates.id 
            AND shared_with_id = auth.uid()
          )
        )
      )
    )
  );

CREATE POLICY "Users can delete own status media"
  ON storage.objects FOR DELETE
  USING (
    bucket_id = 'status-media'
    AND auth.uid()::text = (storage.foldername(name))[1]
  );

-- Call recordings policies
CREATE POLICY "Users can upload call recordings"
  ON storage.objects FOR INSERT
  WITH CHECK (
    bucket_id = 'call-recordings'
    AND auth.uid()::text = (storage.foldername(name))[1]
  );

CREATE POLICY "Users can access recordings from their calls"
  ON storage.objects FOR SELECT
  USING (
    bucket_id = 'call-recordings'
    AND (storage.foldername(name))[1] IN (
      SELECT initiator_id::text FROM calls WHERE initiator_id = auth.uid() OR recipient_id = auth.uid()
    )
  );

-- ==============================================
-- 12. MOCK DATA
-- ==============================================

-- Insert mock calls
DO $$
DECLARE
  user1_id UUID;
  user2_id UUID;
  user3_id UUID;
  call1_id UUID;
  call2_id UUID;
BEGIN
  -- Get existing user IDs
  SELECT id INTO user1_id FROM profiles LIMIT 1;
  SELECT id INTO user2_id FROM profiles OFFSET 1 LIMIT 1;
  SELECT id INTO user3_id FROM profiles OFFSET 2 LIMIT 1;

  -- Skip if no users exist
  IF user1_id IS NULL OR user2_id IS NULL THEN
    RAISE NOTICE 'Skipping mock calls - insufficient users';
    RETURN;
  END IF;

  -- Insert completed voice call
  INSERT INTO calls (id, initiator_id, recipient_id, call_type, call_status, started_at, ended_at, duration, created_at)
  VALUES (
    gen_random_uuid(),
    user1_id,
    user2_id,
    'voice',
    'ended',
    NOW() - INTERVAL '2 hours',
    NOW() - INTERVAL '2 hours' + INTERVAL '15 minutes',
    900, -- 15 minutes
    NOW() - INTERVAL '2 hours'
  );

  -- Insert missed video call
  INSERT INTO calls (id, initiator_id, recipient_id, call_type, call_status, created_at)
  VALUES (
    gen_random_uuid(),
    user2_id,
    user1_id,
    'video',
    'missed',
    NOW() - INTERVAL '1 hour'
  );

  -- Insert ongoing conference call
  IF user3_id IS NOT NULL THEN
    call1_id := gen_random_uuid();
    INSERT INTO calls (id, initiator_id, call_type, call_status, started_at, created_at)
    VALUES (
      call1_id,
      user1_id,
      'conference',
      'ongoing',
      NOW() - INTERVAL '10 minutes',
      NOW() - INTERVAL '10 minutes'
    );

    -- Add participants to conference
    INSERT INTO call_participants (call_id, user_id, is_muted, is_video_on)
    VALUES
      (call1_id, user1_id, false, true),
      (call1_id, user2_id, false, true),
      (call1_id, user3_id, true, false);
  END IF;

  -- Insert status updates
  INSERT INTO status_updates (user_id, media_url, media_type, caption, view_count, created_at)
  VALUES
    (
      user1_id,
      'https://images.unsplash.com/photo-1506905925346-21bda4d32df4',
      'image',
      'Beautiful mountain view! 🏔️',
      15,
      NOW() - INTERVAL '3 hours'
    ),
    (
      user2_id,
      'https://images.unsplash.com/photo-1469474968028-56623f02e42e',
      'image',
      'Nature walk today 🌲',
      8,
      NOW() - INTERVAL '5 hours'
    );

  -- Insert status views
  INSERT INTO status_views (status_id, viewer_id, viewed_at)
  SELECT 
    s.id,
    CASE WHEN s.user_id = user1_id THEN user2_id ELSE user1_id END,
    NOW() - INTERVAL '2 hours'
  FROM status_updates s
  WHERE s.user_id IN (user1_id, user2_id)
  LIMIT 2;

  RAISE NOTICE 'Mock data for calls and status created successfully';
END $$;