-- Enhanced Appwrite Session Tracking Migration
-- Creates session_history table for comprehensive session tracking with device info and location data

CREATE TABLE IF NOT EXISTS public.session_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  session_id TEXT NOT NULL UNIQUE,
  user_id TEXT NOT NULL,
  device_info JSONB DEFAULT '{}'::jsonb,
  location_info JSONB DEFAULT '{}'::jsonb,
  ip_address TEXT,
  trust_status TEXT DEFAULT 'unknown' CHECK (trust_status IN ('trusted', 'suspicious', 'revoked', 'unknown')),
  risk_score INTEGER DEFAULT 0 CHECK (risk_score >= 0 AND risk_score <= 100),
  last_active TIMESTAMPTZ DEFAULT now(),
  revoked_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_session_history_user_id ON public.session_history(user_id);
CREATE INDEX IF NOT EXISTS idx_session_history_session_id ON public.session_history(session_id);
CREATE INDEX IF NOT EXISTS idx_session_history_created_at ON public.session_history(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_session_history_trust_status ON public.session_history(trust_status);

-- Enable RLS
ALTER TABLE public.session_history ENABLE ROW LEVEL SECURITY;

-- RLS Policies
-- Users can view their own session history
CREATE POLICY "Users can view own session history"
  ON public.session_history
  FOR SELECT
  USING (true);

-- Users can insert their own session records
CREATE POLICY "Users can insert own session records"
  ON public.session_history
  FOR INSERT
  WITH CHECK (true);

-- Users can update their own session records
CREATE POLICY "Users can update own session records"
  ON public.session_history
  FOR UPDATE
  USING (true);

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION public.update_session_history_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger to automatically update updated_at
DROP TRIGGER IF EXISTS update_session_history_updated_at_trigger ON public.session_history;
CREATE TRIGGER update_session_history_updated_at_trigger
  BEFORE UPDATE ON public.session_history
  FOR EACH ROW
  EXECUTE FUNCTION public.update_session_history_updated_at();

-- Add comments for documentation
COMMENT ON TABLE public.session_history IS 'Tracks Appwrite session information with device fingerprinting and location data';
COMMENT ON COLUMN public.session_history.session_id IS 'Appwrite session ID';
COMMENT ON COLUMN public.session_history.user_id IS 'Appwrite user ID';
COMMENT ON COLUMN public.session_history.device_info IS 'Device fingerprint data (browser, OS, device type)';
COMMENT ON COLUMN public.session_history.location_info IS 'Geolocation data (city, country, coordinates, ISP)';
COMMENT ON COLUMN public.session_history.trust_status IS 'Session trust level (trusted, suspicious, revoked, unknown)';
COMMENT ON COLUMN public.session_history.risk_score IS 'Security risk score (0-100)';
COMMENT ON COLUMN public.session_history.last_active IS 'Last activity timestamp for the session';