-- Location: supabase/migrations/20251221192400_add_autodelete_search_features.sql
-- Schema Analysis: Existing chat_messages table with E2EE support, profiles table with country_code
-- Integration Type: Addition - Adding auto-delete settings, search functionality, and chat archiving
-- Dependencies: chat_messages, profiles

-- ============================================
-- 1. MESSAGE AUTO-DELETE SETTINGS
-- ============================================

-- Create enum for auto-delete duration options
CREATE TYPE public.auto_delete_duration AS ENUM ('24h', '7d', '30d', '90d', 'custom');

-- Message auto-delete settings table (per conversation/chat)
CREATE TABLE public.message_auto_delete_settings (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    conversation_id UUID NOT NULL,
    is_enabled BOOLEAN DEFAULT false,
    duration_type public.auto_delete_duration DEFAULT '24h'::public.auto_delete_duration,
    custom_duration_hours INTEGER,
    apply_to_media BOOLEAN DEFAULT true,
    apply_to_documents BOOLEAN DEFAULT true,
    apply_to_text BOOLEAN DEFAULT true,
    is_encrypted BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for auto-delete settings
CREATE INDEX idx_auto_delete_settings_user_id ON public.message_auto_delete_settings(user_id);
CREATE INDEX idx_auto_delete_settings_conversation_id ON public.message_auto_delete_settings(conversation_id);
CREATE INDEX idx_auto_delete_settings_enabled ON public.message_auto_delete_settings(is_enabled);

-- Enable RLS
ALTER TABLE public.message_auto_delete_settings ENABLE ROW LEVEL SECURITY;

-- RLS Policy: Users manage their own auto-delete settings
CREATE POLICY "users_manage_own_auto_delete_settings"
ON public.message_auto_delete_settings
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

-- ============================================
-- 2. FULL-TEXT SEARCH FUNCTIONALITY
-- ============================================

-- Search index table for messages
CREATE TABLE public.message_search_index (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    message_id UUID NOT NULL REFERENCES public.chat_messages(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    conversation_id UUID NOT NULL,
    search_vector tsvector,
    message_preview TEXT,
    message_type TEXT DEFAULT 'text',
    has_media BOOLEAN DEFAULT false,
    sender_name TEXT,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Create GIN index for full-text search
CREATE INDEX idx_message_search_vector ON public.message_search_index USING GIN(search_vector);
CREATE INDEX idx_message_search_user_id ON public.message_search_index(user_id);
CREATE INDEX idx_message_search_conversation_id ON public.message_search_index(conversation_id);
CREATE INDEX idx_message_search_created_at ON public.message_search_index(created_at DESC);

-- Enable RLS
ALTER TABLE public.message_search_index ENABLE ROW LEVEL SECURITY;

-- RLS Policy: Users can only search their own messages
CREATE POLICY "users_search_own_messages"
ON public.message_search_index
FOR SELECT
TO authenticated
USING (user_id = auth.uid());

-- ============================================
-- 3. CHAT ARCHIVING FUNCTIONALITY
-- ============================================

-- Archived chats table
CREATE TABLE public.archived_chats (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    conversation_id UUID NOT NULL,
    conversation_name TEXT NOT NULL,
    conversation_type TEXT DEFAULT 'private',
    last_message_preview TEXT,
    message_count INTEGER DEFAULT 0,
    archived_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    category TEXT,
    tags TEXT[],
    is_pinned BOOLEAN DEFAULT false,
    custom_folder TEXT,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for archived chats
CREATE INDEX idx_archived_chats_user_id ON public.archived_chats(user_id);
CREATE INDEX idx_archived_chats_conversation_id ON public.archived_chats(conversation_id);
CREATE INDEX idx_archived_chats_archived_at ON public.archived_chats(archived_at DESC);
CREATE INDEX idx_archived_chats_category ON public.archived_chats(category);
CREATE INDEX idx_archived_chats_pinned ON public.archived_chats(is_pinned);

-- Enable RLS
ALTER TABLE public.archived_chats ENABLE ROW LEVEL SECURITY;

-- RLS Policy: Users manage their own archived chats
CREATE POLICY "users_manage_own_archived_chats"
ON public.archived_chats
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

-- ============================================
-- 4. SAVED SEARCH QUERIES
-- ============================================

-- Saved search queries table
CREATE TABLE public.saved_search_queries (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    query_name TEXT NOT NULL,
    search_text TEXT,
    filters JSONB DEFAULT '{}'::jsonb,
    is_notification_enabled BOOLEAN DEFAULT false,
    last_used_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for saved searches
CREATE INDEX idx_saved_searches_user_id ON public.saved_search_queries(user_id);
CREATE INDEX idx_saved_searches_last_used ON public.saved_search_queries(last_used_at DESC);

-- Enable RLS
ALTER TABLE public.saved_search_queries ENABLE ROW LEVEL SECURITY;

-- RLS Policy: Users manage their own saved searches
CREATE POLICY "users_manage_own_saved_searches"
ON public.saved_search_queries
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

-- ============================================
-- 5. FUNCTIONS
-- ============================================

-- Function to calculate delete timestamp based on duration
CREATE OR REPLACE FUNCTION public.calculate_delete_timestamp(
    duration_type public.auto_delete_duration,
    custom_hours INTEGER DEFAULT NULL
)
RETURNS TIMESTAMPTZ
LANGUAGE plpgsql
STABLE
AS $$
BEGIN
    CASE duration_type
        WHEN '24h' THEN
            RETURN NOW() + INTERVAL '24 hours';
        WHEN '7d' THEN
            RETURN NOW() + INTERVAL '7 days';
        WHEN '30d' THEN
            RETURN NOW() + INTERVAL '30 days';
        WHEN '90d' THEN
            RETURN NOW() + INTERVAL '90 days';
        WHEN 'custom' THEN
            IF custom_hours IS NOT NULL THEN
                RETURN NOW() + (custom_hours || ' hours')::INTERVAL;
            ELSE
                RETURN NOW() + INTERVAL '24 hours';
            END IF;
        ELSE
            RETURN NOW() + INTERVAL '24 hours';
    END CASE;
END;
$$;

-- Function to process auto-delete messages
CREATE OR REPLACE FUNCTION public.process_auto_delete_messages()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    -- Delete messages that have exceeded their auto-delete duration
    DELETE FROM public.chat_messages cm
    WHERE EXISTS (
        SELECT 1 FROM public.message_auto_delete_settings mads
        WHERE mads.conversation_id = cm.recipient_id
        AND mads.is_enabled = true
        AND cm.created_at <= (
            NOW() - 
            CASE mads.duration_type
                WHEN '24h' THEN INTERVAL '24 hours'
                WHEN '7d' THEN INTERVAL '7 days'
                WHEN '30d' THEN INTERVAL '30 days'
                WHEN '90d' THEN INTERVAL '90 days'
                WHEN 'custom' THEN (COALESCE(mads.custom_duration_hours, 24) || ' hours')::INTERVAL
            END
        )
    );
END;
$$;

-- Function to update search index when message is created/updated
CREATE OR REPLACE FUNCTION public.update_message_search_index()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    -- Insert or update search index
    INSERT INTO public.message_search_index (
        message_id,
        user_id,
        conversation_id,
        search_vector,
        message_preview,
        message_type,
        has_media,
        sender_name,
        created_at
    )
    VALUES (
        NEW.id,
        NEW.sender_id,
        COALESCE(NEW.recipient_id, NEW.sender_id),
        to_tsvector('english', COALESCE(NEW.message, '')),
        LEFT(NEW.message, 200),
        CASE 
            WHEN NEW.audio_url IS NOT NULL THEN 'audio'
            WHEN NEW.meeting_id IS NOT NULL THEN 'meeting'
            ELSE 'text'
        END,
        (NEW.audio_url IS NOT NULL),
        NEW.sender_name,
        NEW.created_at
    )
    ON CONFLICT (message_id) 
    DO UPDATE SET
        search_vector = to_tsvector('english', COALESCE(NEW.message, '')),
        message_preview = LEFT(NEW.message, 200),
        updated_at = CURRENT_TIMESTAMP;
    
    RETURN NEW;
END;
$$;

-- Trigger to automatically update search index
CREATE TRIGGER trigger_update_message_search_index
AFTER INSERT OR UPDATE ON public.chat_messages
FOR EACH ROW
EXECUTE FUNCTION public.update_message_search_index();

-- Function to search messages with filters
CREATE OR REPLACE FUNCTION public.search_messages(
    search_query TEXT,
    filter_conversation_id UUID DEFAULT NULL,
    filter_message_type TEXT DEFAULT NULL,
    filter_date_from TIMESTAMPTZ DEFAULT NULL,
    filter_date_to TIMESTAMPTZ DEFAULT NULL,
    result_limit INTEGER DEFAULT 50
)
RETURNS TABLE(
    message_id UUID,
    conversation_id UUID,
    message_preview TEXT,
    message_type TEXT,
    sender_name TEXT,
    created_at TIMESTAMPTZ,
    rank REAL
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    RETURN QUERY
    SELECT 
        msi.message_id,
        msi.conversation_id,
        msi.message_preview,
        msi.message_type,
        msi.sender_name,
        msi.created_at,
        ts_rank(msi.search_vector, to_tsquery('english', search_query)) AS rank
    FROM public.message_search_index msi
    WHERE msi.user_id = auth.uid()
        AND msi.search_vector @@ to_tsquery('english', search_query)
        AND (filter_conversation_id IS NULL OR msi.conversation_id = filter_conversation_id)
        AND (filter_message_type IS NULL OR msi.message_type = filter_message_type)
        AND (filter_date_from IS NULL OR msi.created_at >= filter_date_from)
        AND (filter_date_to IS NULL OR msi.created_at <= filter_date_to)
    ORDER BY rank DESC, msi.created_at DESC
    LIMIT result_limit;
END;
$$;

-- Trigger to update timestamps
CREATE OR REPLACE FUNCTION public.update_updated_at_timestamp()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;

CREATE TRIGGER trigger_auto_delete_settings_updated_at
BEFORE UPDATE ON public.message_auto_delete_settings
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_timestamp();

CREATE TRIGGER trigger_archived_chats_updated_at
BEFORE UPDATE ON public.archived_chats
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_timestamp();

CREATE TRIGGER trigger_saved_searches_updated_at
BEFORE UPDATE ON public.saved_search_queries
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_timestamp();