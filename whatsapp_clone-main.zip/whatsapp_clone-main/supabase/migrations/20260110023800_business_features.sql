-- Business Profiles Table
CREATE TABLE IF NOT EXISTS business_profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  business_name TEXT NOT NULL,
  business_description TEXT,
  business_category TEXT,
  business_email TEXT,
  business_phone TEXT,
  business_address TEXT,
  business_website TEXT,
  logo_url TEXT,
  banner_url TEXT,
  operating_hours JSONB DEFAULT '{}',
  is_verified BOOLEAN DEFAULT false,
  verification_badge TEXT,
  storefront_customization JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id)
);

-- Product Catalog Table
CREATE TABLE IF NOT EXISTS products (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_profile_id UUID NOT NULL REFERENCES business_profiles(id) ON DELETE CASCADE,
  product_name TEXT NOT NULL,
  product_description TEXT,
  product_category TEXT,
  price DECIMAL(10, 2) NOT NULL,
  currency TEXT DEFAULT 'USD',
  stock_quantity INTEGER DEFAULT 0,
  is_available BOOLEAN DEFAULT true,
  product_images JSONB DEFAULT '[]',
  product_variants JSONB DEFAULT '[]',
  sku TEXT,
  weight DECIMAL(10, 2),
  dimensions JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Payment Methods Table
CREATE TABLE IF NOT EXISTS payment_methods (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_profile_id UUID NOT NULL REFERENCES business_profiles(id) ON DELETE CASCADE,
  method_type TEXT NOT NULL, -- 'credit_card', 'digital_wallet', 'bank_transfer'
  provider TEXT NOT NULL, -- 'stripe', 'paypal', etc.
  is_active BOOLEAN DEFAULT true,
  configuration JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Payment Transactions Table
CREATE TABLE IF NOT EXISTS payment_transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_profile_id UUID NOT NULL REFERENCES business_profiles(id) ON DELETE CASCADE,
  customer_id UUID REFERENCES profiles(id) ON DELETE SET NULL,
  product_id UUID REFERENCES products(id) ON DELETE SET NULL,
  transaction_type TEXT NOT NULL, -- 'purchase', 'refund'
  amount DECIMAL(10, 2) NOT NULL,
  currency TEXT DEFAULT 'USD',
  status TEXT DEFAULT 'pending', -- 'pending', 'completed', 'failed', 'refunded'
  payment_method TEXT,
  payment_provider TEXT,
  transaction_reference TEXT,
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Business Analytics Table
CREATE TABLE IF NOT EXISTS business_analytics (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_profile_id UUID NOT NULL REFERENCES business_profiles(id) ON DELETE CASCADE,
  date DATE NOT NULL,
  total_sales DECIMAL(10, 2) DEFAULT 0,
  total_orders INTEGER DEFAULT 0,
  total_customers INTEGER DEFAULT 0,
  top_products JSONB DEFAULT '[]',
  customer_engagement JSONB DEFAULT '{}',
  revenue_by_category JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(business_profile_id, date)
);

-- Customer Interactions Table
CREATE TABLE IF NOT EXISTS customer_interactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  business_profile_id UUID NOT NULL REFERENCES business_profiles(id) ON DELETE CASCADE,
  customer_id UUID REFERENCES profiles(id) ON DELETE CASCADE,
  interaction_type TEXT NOT NULL, -- 'inquiry', 'order', 'support'
  message_id UUID,
  notes TEXT,
  status TEXT DEFAULT 'open', -- 'open', 'in_progress', 'resolved'
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_business_profiles_user_id ON business_profiles(user_id);
CREATE INDEX IF NOT EXISTS idx_products_business_profile_id ON products(business_profile_id);
CREATE INDEX IF NOT EXISTS idx_products_category ON products(product_category);
CREATE INDEX IF NOT EXISTS idx_payment_transactions_business_profile_id ON payment_transactions(business_profile_id);
CREATE INDEX IF NOT EXISTS idx_payment_transactions_customer_id ON payment_transactions(customer_id);
CREATE INDEX IF NOT EXISTS idx_payment_transactions_status ON payment_transactions(status);
CREATE INDEX IF NOT EXISTS idx_business_analytics_business_profile_id ON business_analytics(business_profile_id);
CREATE INDEX IF NOT EXISTS idx_business_analytics_date ON business_analytics(date);
CREATE INDEX IF NOT EXISTS idx_customer_interactions_business_profile_id ON customer_interactions(business_profile_id);
CREATE INDEX IF NOT EXISTS idx_customer_interactions_customer_id ON customer_interactions(customer_id);

-- RLS Policies
ALTER TABLE business_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE products ENABLE ROW LEVEL SECURITY;
ALTER TABLE payment_methods ENABLE ROW LEVEL SECURITY;
ALTER TABLE payment_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE business_analytics ENABLE ROW LEVEL SECURITY;
ALTER TABLE customer_interactions ENABLE ROW LEVEL SECURITY;

-- Business Profiles Policies
CREATE POLICY "Users can view all business profiles" ON business_profiles FOR SELECT USING (true);
CREATE POLICY "Users can create their own business profile" ON business_profiles FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update their own business profile" ON business_profiles FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete their own business profile" ON business_profiles FOR DELETE USING (auth.uid() = user_id);

-- Products Policies
CREATE POLICY "Anyone can view available products" ON products FOR SELECT USING (is_available = true);
CREATE POLICY "Business owners can manage their products" ON products FOR ALL USING (
  business_profile_id IN (SELECT id FROM business_profiles WHERE user_id = auth.uid())
);

-- Payment Methods Policies
CREATE POLICY "Business owners can manage their payment methods" ON payment_methods FOR ALL USING (
  business_profile_id IN (SELECT id FROM business_profiles WHERE user_id = auth.uid())
);

-- Payment Transactions Policies
CREATE POLICY "Business owners can view their transactions" ON payment_transactions FOR SELECT USING (
  business_profile_id IN (SELECT id FROM business_profiles WHERE user_id = auth.uid())
  OR customer_id = auth.uid()
);
CREATE POLICY "Authenticated users can create transactions" ON payment_transactions FOR INSERT WITH CHECK (auth.uid() IS NOT NULL);

-- Business Analytics Policies
CREATE POLICY "Business owners can view their analytics" ON business_analytics FOR SELECT USING (
  business_profile_id IN (SELECT id FROM business_profiles WHERE user_id = auth.uid())
);

-- Customer Interactions Policies
CREATE POLICY "Business owners and customers can view interactions" ON customer_interactions FOR SELECT USING (
  business_profile_id IN (SELECT id FROM business_profiles WHERE user_id = auth.uid())
  OR customer_id = auth.uid()
);
CREATE POLICY "Business owners can manage interactions" ON customer_interactions FOR ALL USING (
  business_profile_id IN (SELECT id FROM business_profiles WHERE user_id = auth.uid())
);

-- Update timestamp function
CREATE OR REPLACE FUNCTION update_business_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Triggers for updated_at
CREATE TRIGGER update_business_profiles_updated_at BEFORE UPDATE ON business_profiles
  FOR EACH ROW EXECUTE FUNCTION update_business_updated_at();

CREATE TRIGGER update_products_updated_at BEFORE UPDATE ON products
  FOR EACH ROW EXECUTE FUNCTION update_business_updated_at();

CREATE TRIGGER update_payment_methods_updated_at BEFORE UPDATE ON payment_methods
  FOR EACH ROW EXECUTE FUNCTION update_business_updated_at();

CREATE TRIGGER update_payment_transactions_updated_at BEFORE UPDATE ON payment_transactions
  FOR EACH ROW EXECUTE FUNCTION update_business_updated_at();

CREATE TRIGGER update_customer_interactions_updated_at BEFORE UPDATE ON customer_interactions
  FOR EACH ROW EXECUTE FUNCTION update_business_updated_at();
