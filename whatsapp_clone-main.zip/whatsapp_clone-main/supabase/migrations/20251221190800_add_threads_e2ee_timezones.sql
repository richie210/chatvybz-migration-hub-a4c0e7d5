-- Location: supabase/migrations/20251221190800_add_threads_e2ee_timezones.sql
-- Schema Analysis: Extending existing messaging system with reply threads, comprehensive E2EE, and timezone support
-- Integration Type: Enhancement (PARTIAL_EXISTS)
-- Dependencies: chat_messages, calls, status_updates, profiles

-- =====================================================
-- 1. ADD REPLY THREAD SUPPORT TO CHAT_MESSAGES
-- =====================================================

-- Add thread columns to existing chat_messages table
ALTER TABLE public.chat_messages
ADD COLUMN IF NOT EXISTS parent_message_id UUID REFERENCES public.chat_messages(id) ON DELETE CASCADE,
ADD COLUMN IF NOT EXISTS thread_id UUID,
ADD COLUMN IF NOT EXISTS reply_count INTEGER DEFAULT 0,
ADD COLUMN IF NOT EXISTS is_thread_root BOOLEAN DEFAULT false;

-- Create indexes for thread queries
CREATE INDEX IF NOT EXISTS idx_chat_messages_parent_id ON public.chat_messages(parent_message_id);
CREATE INDEX IF NOT EXISTS idx_chat_messages_thread_id ON public.chat_messages(thread_id);
CREATE INDEX IF NOT EXISTS idx_chat_messages_is_thread_root ON public.chat_messages(is_thread_root) WHERE is_thread_root = true;

-- Function to auto-increment reply count on thread root
CREATE OR REPLACE FUNCTION public.increment_reply_count()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  IF NEW.parent_message_id IS NOT NULL THEN
    UPDATE public.chat_messages
    SET reply_count = reply_count + 1
    WHERE id = NEW.parent_message_id OR id = NEW.thread_id;
  END IF;
  RETURN NEW;
END;
$$;

-- Trigger to update reply count
DROP TRIGGER IF EXISTS trigger_increment_reply_count ON public.chat_messages;
CREATE TRIGGER trigger_increment_reply_count
  AFTER INSERT ON public.chat_messages
  FOR EACH ROW
  WHEN (NEW.parent_message_id IS NOT NULL)
  EXECUTE FUNCTION public.increment_reply_count();

-- Function to set thread_id automatically
CREATE OR REPLACE FUNCTION public.set_thread_id()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  IF NEW.parent_message_id IS NOT NULL THEN
    -- Get the root message's thread_id or use parent_id as thread_id
    SELECT COALESCE(thread_id, id) INTO NEW.thread_id
    FROM public.chat_messages
    WHERE id = NEW.parent_message_id;
    
    -- Mark parent as thread root if not already
    UPDATE public.chat_messages
    SET is_thread_root = true
    WHERE id = NEW.parent_message_id AND is_thread_root = false;
  END IF;
  RETURN NEW;
END;
$$;

-- Trigger to auto-set thread_id before insert
DROP TRIGGER IF EXISTS trigger_set_thread_id ON public.chat_messages;
CREATE TRIGGER trigger_set_thread_id
  BEFORE INSERT ON public.chat_messages
  FOR EACH ROW
  EXECUTE FUNCTION public.set_thread_id();

-- =====================================================
-- 2. EXTEND E2EE TO CALLS
-- =====================================================

-- Add encryption columns to calls table
ALTER TABLE public.calls
ADD COLUMN IF NOT EXISTS is_encrypted BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS nonce TEXT,
ADD COLUMN IF NOT EXISTS encrypted_metadata JSONB;

-- Create index for encrypted calls
CREATE INDEX IF NOT EXISTS idx_calls_is_encrypted ON public.calls(is_encrypted) WHERE is_encrypted = true;

-- =====================================================
-- 3. EXTEND E2EE TO STATUS UPDATES
-- =====================================================

-- Add encryption columns to status_updates table
ALTER TABLE public.status_updates
ADD COLUMN IF NOT EXISTS is_encrypted BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS nonce TEXT,
ADD COLUMN IF NOT EXISTS encrypted_caption TEXT,
ADD COLUMN IF NOT EXISTS encrypted_media_url TEXT;

-- Create index for encrypted status
CREATE INDEX IF NOT EXISTS idx_status_is_encrypted ON public.status_updates(is_encrypted) WHERE is_encrypted = true;

-- =====================================================
-- 4. ADD COUNTRY CODE AND TIMEZONE TO PROFILES
-- =====================================================

-- Add country code column to profiles
ALTER TABLE public.profiles
ADD COLUMN IF NOT EXISTS country_code TEXT DEFAULT 'US',
ADD COLUMN IF NOT EXISTS timezone_offset INTEGER DEFAULT 0;

-- Create index for country code lookups
CREATE INDEX IF NOT EXISTS idx_profiles_country_code ON public.profiles(country_code);

-- =====================================================
-- 5. UPDATE RLS POLICIES
-- =====================================================

-- No changes needed to existing RLS policies as new columns follow same ownership patterns

-- =====================================================
-- 6. UTILITY FUNCTIONS FOR THREADS
-- =====================================================

-- Function to get thread messages
CREATE OR REPLACE FUNCTION public.get_thread_messages(thread_root_id UUID)
RETURNS TABLE (
  id UUID,
  message TEXT,
  sender_id UUID,
  parent_message_id UUID,
  created_at TIMESTAMPTZ,
  is_encrypted BOOLEAN,
  nonce TEXT,
  sender_name TEXT,
  sender_avatar TEXT
)
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
  SELECT 
    cm.id,
    cm.message,
    cm.sender_id,
    cm.parent_message_id,
    cm.created_at,
    cm.is_encrypted,
    cm.nonce,
    p.full_name,
    p.avatar_url
  FROM public.chat_messages cm
  JOIN public.profiles p ON cm.sender_id = p.id
  WHERE cm.thread_id = thread_root_id OR cm.id = thread_root_id
  ORDER BY cm.created_at ASC;
$$;

-- Function to get thread count for a message
CREATE OR REPLACE FUNCTION public.get_thread_count(message_id UUID)
RETURNS INTEGER
LANGUAGE sql
STABLE
SECURITY DEFINER
AS $$
  SELECT COUNT(*)::INTEGER
  FROM public.chat_messages
  WHERE thread_id = message_id;
$$;

-- =====================================================
-- 7. TIMEZONE UTILITY FUNCTIONS
-- =====================================================

-- Function to convert UTC timestamp to user timezone
CREATE OR REPLACE FUNCTION public.to_user_timezone(
  utc_time TIMESTAMPTZ,
  user_id_param UUID
)
RETURNS TIMESTAMPTZ
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
AS $$
DECLARE
  user_timezone TEXT;
BEGIN
  SELECT timezone INTO user_timezone
  FROM public.profiles
  WHERE id = user_id_param;
  
  IF user_timezone IS NULL THEN
    user_timezone := 'UTC';
  END IF;
  
  RETURN utc_time AT TIME ZONE user_timezone;
END;
$$;

-- Function to get user's current local time
CREATE OR REPLACE FUNCTION public.get_user_local_time(user_id_param UUID)
RETURNS TIMESTAMPTZ
LANGUAGE plpgsql
STABLE
SECURITY DEFINER
AS $$
DECLARE
  user_timezone TEXT;
BEGIN
  SELECT timezone INTO user_timezone
  FROM public.profiles
  WHERE id = user_id_param;
  
  IF user_timezone IS NULL THEN
    user_timezone := 'UTC';
  END IF;
  
  RETURN NOW() AT TIME ZONE user_timezone;
END;
$$;

-- =====================================================
-- 8. COMMENTS
-- =====================================================

COMMENT ON COLUMN public.chat_messages.parent_message_id IS 'ID of the message this is replying to';
COMMENT ON COLUMN public.chat_messages.thread_id IS 'ID of the root message in this thread';
COMMENT ON COLUMN public.chat_messages.reply_count IS 'Number of replies in this thread';
COMMENT ON COLUMN public.chat_messages.is_thread_root IS 'True if this message has replies';

COMMENT ON COLUMN public.calls.is_encrypted IS 'Whether call metadata is E2EE encrypted';
COMMENT ON COLUMN public.calls.nonce IS 'Encryption nonce for call metadata';
COMMENT ON COLUMN public.calls.encrypted_metadata IS 'Encrypted call metadata (e.g., notes, recordings)';

COMMENT ON COLUMN public.status_updates.is_encrypted IS 'Whether status content is E2EE encrypted';
COMMENT ON COLUMN public.status_updates.nonce IS 'Encryption nonce for status';
COMMENT ON COLUMN public.status_updates.encrypted_caption IS 'Encrypted status caption';
COMMENT ON COLUMN public.status_updates.encrypted_media_url IS 'Encrypted media URL';

COMMENT ON COLUMN public.profiles.country_code IS 'User country code (ISO 3166-1 alpha-2)';
COMMENT ON COLUMN public.profiles.timezone_offset IS 'Timezone offset in minutes from UTC';

COMMENT ON FUNCTION public.get_thread_messages(UUID) IS 'Retrieves all messages in a thread';
COMMENT ON FUNCTION public.get_thread_count(UUID) IS 'Returns the number of replies in a thread';
COMMENT ON FUNCTION public.to_user_timezone(TIMESTAMPTZ, UUID) IS 'Converts UTC time to user timezone';
COMMENT ON FUNCTION public.get_user_local_time(UUID) IS 'Returns current time in user timezone';