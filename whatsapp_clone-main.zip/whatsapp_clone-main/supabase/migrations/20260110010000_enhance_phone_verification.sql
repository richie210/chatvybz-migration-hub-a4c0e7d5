-- Enhanced Phone Number Registration System
-- Adds proper indexing for E.164 phone numbers and improves verification tracking

-- Add index on profiles.phone for fast lookups (E.164 format)
CREATE INDEX IF NOT EXISTS idx_profiles_phone ON public.profiles(phone) WHERE phone IS NOT NULL;

-- Add index on profiles.country_code for regional queries
CREATE INDEX IF NOT EXISTS idx_profiles_country_code ON public.profiles(country_code) WHERE country_code IS NOT NULL;

-- Add composite index for phone + country_code
CREATE INDEX IF NOT EXISTS idx_profiles_phone_country ON public.profiles(phone, country_code) WHERE phone IS NOT NULL;

-- Add index on user_contacts for contact discovery
CREATE INDEX IF NOT EXISTS idx_user_contacts_phone ON public.user_contacts(contact_phone, contact_country_code);
CREATE INDEX IF NOT EXISTS idx_user_contacts_platform_user ON public.user_contacts(platform_user_id) WHERE platform_user_id IS NOT NULL;

-- Add index on phone_verification_attempts for rate limiting
CREATE INDEX IF NOT EXISTS idx_phone_verification_phone ON public.phone_verification_attempts(phone_number, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_phone_verification_expires ON public.phone_verification_attempts(expires_at) WHERE is_verified = false;

-- Add index on phone_auth_rate_limits for fast rate limit checks
CREATE INDEX IF NOT EXISTS idx_phone_rate_limits_phone ON public.phone_auth_rate_limits(phone_number, last_request_at DESC);
CREATE INDEX IF NOT EXISTS idx_phone_rate_limits_blocked ON public.phone_auth_rate_limits(blocked_until) WHERE blocked_until IS NOT NULL;

-- Update phone_verification_attempts table to support Twilio Verify
ALTER TABLE public.phone_verification_attempts
ADD COLUMN IF NOT EXISTS verification_sid TEXT,
ADD COLUMN IF NOT EXISTS channel TEXT DEFAULT 'sms' CHECK (channel IN ('sms', 'call')),
ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'canceled', 'max_attempts_reached'));

COMMENT ON COLUMN public.phone_verification_attempts.verification_sid IS 'Twilio Verify SID for tracking verification status';
COMMENT ON COLUMN public.phone_verification_attempts.channel IS 'Verification channel: sms or call';
COMMENT ON COLUMN public.phone_verification_attempts.status IS 'Twilio Verify status';

-- Function to clean up expired verification attempts
CREATE OR REPLACE FUNCTION cleanup_expired_verifications()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Delete expired and unverified attempts older than 24 hours
  DELETE FROM public.phone_verification_attempts
  WHERE is_verified = false
    AND expires_at < NOW() - INTERVAL '24 hours';
    
  -- Reset rate limits older than 1 hour
  DELETE FROM public.phone_auth_rate_limits
  WHERE last_request_at < NOW() - INTERVAL '1 hour'
    AND (blocked_until IS NULL OR blocked_until < NOW());
END;
$$;

COMMENT ON FUNCTION cleanup_expired_verifications IS 'Cleans up expired verification attempts and rate limits';

-- Create a scheduled job to run cleanup (requires pg_cron extension)
-- Note: This requires pg_cron extension to be enabled in Supabase
-- Uncomment if pg_cron is available:
-- SELECT cron.schedule(
--   'cleanup-expired-verifications',
--   '0 * * * *', -- Run every hour
--   $$SELECT cleanup_expired_verifications();$$
-- );

-- Function to get phone verification statistics
CREATE OR REPLACE FUNCTION get_phone_verification_stats(p_phone_number TEXT)
RETURNS TABLE (
  total_attempts INTEGER,
  successful_verifications INTEGER,
  failed_attempts INTEGER,
  last_attempt_at TIMESTAMPTZ,
  is_rate_limited BOOLEAN
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN QUERY
  SELECT
    COUNT(*)::INTEGER AS total_attempts,
    COUNT(*) FILTER (WHERE is_verified = true)::INTEGER AS successful_verifications,
    COUNT(*) FILTER (WHERE is_verified = false AND expires_at < NOW())::INTEGER AS failed_attempts,
    MAX(created_at) AS last_attempt_at,
    EXISTS(
      SELECT 1 FROM public.phone_auth_rate_limits
      WHERE phone_number = p_phone_number
        AND (blocked_until IS NOT NULL AND blocked_until > NOW())
    ) AS is_rate_limited
  FROM public.phone_verification_attempts
  WHERE phone_number = p_phone_number
    AND created_at > NOW() - INTERVAL '7 days';
END;
$$;

COMMENT ON FUNCTION get_phone_verification_stats IS 'Returns verification statistics for a phone number';

-- Grant necessary permissions
GRANT EXECUTE ON FUNCTION cleanup_expired_verifications TO authenticated;
GRANT EXECUTE ON FUNCTION get_phone_verification_stats TO authenticated;

-- Add helpful comments
COMMENT ON INDEX idx_profiles_phone IS 'Fast lookup for phone numbers in E.164 format';
COMMENT ON INDEX idx_user_contacts_phone IS 'Optimizes contact discovery matching';
COMMENT ON INDEX idx_phone_verification_phone IS 'Optimizes rate limiting checks';
