-- Location: supabase/migrations/20260110032000_fix_qr_rls_final.sql
-- Purpose: Final fix for QR authentication RLS - allow anonymous users to generate tokens
-- Issue: Previous migrations didn't properly grant anonymous access

-- Step 1: Drop ALL existing policies on qr_auth_tokens to start fresh
DROP POLICY IF EXISTS "users_can_view_own_qr_tokens" ON public.qr_auth_tokens;
DROP POLICY IF EXISTS "anyone_can_create_qr_tokens" ON public.qr_auth_tokens;
DROP POLICY IF EXISTS "users_can_update_own_qr_tokens" ON public.qr_auth_tokens;
DROP POLICY IF EXISTS "anon_and_auth_can_create_qr_tokens" ON public.qr_auth_tokens;
DROP POLICY IF EXISTS "anon_and_auth_can_view_qr_tokens" ON public.qr_auth_tokens;
DROP POLICY IF EXISTS "anon_and_auth_can_update_qr_tokens" ON public.qr_auth_tokens;

-- Step 2: Create new policies with explicit anonymous and authenticated access

-- Allow anonymous and authenticated users to INSERT tokens (for QR generation during login)
CREATE POLICY "qr_tokens_insert_policy"
ON public.qr_auth_tokens
FOR INSERT
TO anon, authenticated
WITH CHECK (true);

-- Allow anonymous and authenticated users to SELECT tokens (for status checking)
CREATE POLICY "qr_tokens_select_policy"
ON public.qr_auth_tokens
FOR SELECT
TO anon, authenticated
USING (true);

-- Allow anonymous and authenticated users to UPDATE tokens (for verification)
CREATE POLICY "qr_tokens_update_policy"
ON public.qr_auth_tokens
FOR UPDATE
TO anon, authenticated
USING (true)
WITH CHECK (true);

-- Allow authenticated users to DELETE expired tokens
CREATE POLICY "qr_tokens_delete_policy"
ON public.qr_auth_tokens
FOR DELETE
TO authenticated
USING (status = 'expired' OR expires_at < NOW());

-- Step 3: Add helpful comment
COMMENT ON TABLE public.qr_auth_tokens IS 'QR authentication tokens - Security model: Anonymous access allowed for login flow. Protection via 5-minute expiration and one-time use. Tokens auto-expire and cannot be reused.';

-- Step 4: Verify RLS is enabled
ALTER TABLE public.qr_auth_tokens ENABLE ROW LEVEL SECURITY;