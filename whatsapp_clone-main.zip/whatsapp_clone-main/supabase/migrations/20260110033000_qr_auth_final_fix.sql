-- Location: supabase/migrations/20260110033000_qr_auth_final_fix.sql
-- Purpose: Comprehensive fix for QR authentication RLS policy violation
-- Issue: Anonymous users cannot INSERT into qr_auth_tokens table during login flow
-- Solution: Grant explicit permissions to anon role with proper RLS policies

-- Step 1: Ensure RLS is enabled
ALTER TABLE public.qr_auth_tokens ENABLE ROW LEVEL SECURITY;

-- Step 2: Drop ALL existing policies to avoid conflicts
DO $$ 
BEGIN
    -- Drop policies if they exist
    DROP POLICY IF EXISTS "users_can_view_own_qr_tokens" ON public.qr_auth_tokens;
    DROP POLICY IF EXISTS "anyone_can_create_qr_tokens" ON public.qr_auth_tokens;
    DROP POLICY IF EXISTS "users_can_update_own_qr_tokens" ON public.qr_auth_tokens;
    DROP POLICY IF EXISTS "anon_and_auth_can_create_qr_tokens" ON public.qr_auth_tokens;
    DROP POLICY IF EXISTS "anon_and_auth_can_view_qr_tokens" ON public.qr_auth_tokens;
    DROP POLICY IF EXISTS "anon_and_auth_can_update_qr_tokens" ON public.qr_auth_tokens;
    DROP POLICY IF EXISTS "qr_tokens_insert_policy" ON public.qr_auth_tokens;
    DROP POLICY IF EXISTS "qr_tokens_select_policy" ON public.qr_auth_tokens;
    DROP POLICY IF EXISTS "qr_tokens_update_policy" ON public.qr_auth_tokens;
    DROP POLICY IF EXISTS "qr_tokens_delete_policy" ON public.qr_auth_tokens;
    
    RAISE NOTICE 'Dropped all existing QR auth policies';
END $$;

-- Step 3: Create comprehensive policies for anonymous and authenticated users

-- Policy 1: Allow INSERT for anonymous and authenticated users (QR generation)
CREATE POLICY "allow_qr_token_insert"
ON public.qr_auth_tokens
FOR INSERT
TO anon, authenticated
WITH CHECK (true);

-- Policy 2: Allow SELECT for anonymous and authenticated users (status checking)
CREATE POLICY "allow_qr_token_select"
ON public.qr_auth_tokens
FOR SELECT
TO anon, authenticated
USING (true);

-- Policy 3: Allow UPDATE for anonymous and authenticated users (verification)
CREATE POLICY "allow_qr_token_update"
ON public.qr_auth_tokens
FOR UPDATE
TO anon, authenticated
USING (true)
WITH CHECK (true);

-- Policy 4: Allow DELETE for authenticated users (cleanup)
CREATE POLICY "allow_qr_token_delete"
ON public.qr_auth_tokens
FOR DELETE
TO authenticated
USING (status = 'expired' OR expires_at < NOW());

-- Step 4: Grant explicit table permissions to anon and authenticated roles
GRANT SELECT, INSERT, UPDATE ON public.qr_auth_tokens TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.qr_auth_tokens TO authenticated;

-- Step 5: Update table comment with security model explanation
COMMENT ON TABLE public.qr_auth_tokens IS 'QR authentication tokens - Security model: Anonymous access allowed for login flow. Protection via 5-minute expiration and one-time use. Tokens auto-expire and cannot be reused.';

-- Step 6: Verify policies are created
DO $$ 
DECLARE
    policy_count INTEGER;
BEGIN
    SELECT COUNT(*) INTO policy_count
    FROM pg_policies
    WHERE tablename = 'qr_auth_tokens';
    
    RAISE NOTICE 'Total QR auth policies created: %', policy_count;
END $$;