-- Location: supabase/migrations/20251224141645_profile_setup_contact_discovery.sql
-- Schema Analysis: profiles table exists with avatar_url, full_name, phone, country_code
-- Integration Type: extension - adding bio, display_name columns and contact discovery tables
-- Dependencies: profiles, phone_verification_attempts

-- 1. Add missing profile fields
ALTER TABLE public.profiles
ADD COLUMN IF NOT EXISTS display_name TEXT,
ADD COLUMN IF NOT EXISTS bio TEXT,
ADD COLUMN IF NOT EXISTS profile_setup_completed BOOLEAN DEFAULT false;

-- Create indexes for new columns
CREATE INDEX IF NOT EXISTS idx_profiles_display_name ON public.profiles(display_name);

-- 2. Create contact discovery tables
CREATE TABLE IF NOT EXISTS public.user_contacts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
    contact_phone TEXT NOT NULL,
    contact_name TEXT,
    contact_country_code TEXT NOT NULL DEFAULT '+1',
    is_platform_user BOOLEAN DEFAULT false,
    platform_user_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
    sync_status TEXT DEFAULT 'pending',
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS public.contact_sync_status (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
    last_sync_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    total_contacts INTEGER DEFAULT 0,
    platform_users_found INTEGER DEFAULT 0,
    sync_enabled BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(user_id)
);

-- 3. Create indexes for contact tables
CREATE INDEX IF NOT EXISTS idx_user_contacts_user_id ON public.user_contacts(user_id);
CREATE INDEX IF NOT EXISTS idx_user_contacts_phone ON public.user_contacts(contact_phone, contact_country_code);
CREATE INDEX IF NOT EXISTS idx_user_contacts_platform_user ON public.user_contacts(platform_user_id);
CREATE INDEX IF NOT EXISTS idx_contact_sync_user_id ON public.contact_sync_status(user_id);

-- 4. Enable RLS
ALTER TABLE public.user_contacts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.contact_sync_status ENABLE ROW LEVEL SECURITY;

-- 5. RLS Policies - Pattern 2: Simple User Ownership
CREATE POLICY "users_manage_own_contacts"
ON public.user_contacts
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

CREATE POLICY "users_manage_own_sync_status"
ON public.contact_sync_status
FOR ALL
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

-- 6. Function to match contacts with platform users
CREATE OR REPLACE FUNCTION public.match_contacts_with_platform_users(p_user_id UUID)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    -- Update user_contacts with matching platform users
    UPDATE public.user_contacts uc
    SET 
        is_platform_user = true,
        platform_user_id = p.id,
        sync_status = 'matched',
        updated_at = CURRENT_TIMESTAMP
    FROM public.profiles p
    WHERE uc.user_id = p_user_id
        AND uc.contact_phone = p.phone
        AND uc.contact_country_code = p.country_code
        AND p.id != p_user_id; -- Don't match self

    -- Update sync status
    UPDATE public.contact_sync_status
    SET
        platform_users_found = (
            SELECT COUNT(*) 
            FROM public.user_contacts 
            WHERE user_id = p_user_id AND is_platform_user = true
        ),
        last_sync_at = CURRENT_TIMESTAMP,
        updated_at = CURRENT_TIMESTAMP
    WHERE user_id = p_user_id;
END;
$$;

-- 7. Create storage bucket for profile photos (private)
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
    'profile-photos',
    'profile-photos',
    false,  -- PRIVATE
    5242880, -- 5MB
    ARRAY['image/jpeg', 'image/png', 'image/webp']
)
ON CONFLICT (id) DO NOTHING;

-- 8. Storage RLS policies
CREATE POLICY "users_manage_own_profile_photos" ON storage.objects
FOR ALL TO authenticated
USING (bucket_id = 'profile-photos' AND owner = auth.uid())
WITH CHECK (bucket_id = 'profile-photos' AND owner = auth.uid());

-- 9. Trigger to update updated_at timestamp
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_user_contacts_updated_at
    BEFORE UPDATE ON public.user_contacts
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_contact_sync_updated_at
    BEFORE UPDATE ON public.contact_sync_status
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();