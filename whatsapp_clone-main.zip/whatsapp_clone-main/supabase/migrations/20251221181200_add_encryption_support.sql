-- Add encryption support to chat_messages table
ALTER TABLE chat_messages 
ADD COLUMN IF NOT EXISTS is_encrypted BOOLEAN DEFAULT false,
ADD COLUMN IF NOT EXISTS nonce TEXT;

-- Add public_key column to profiles table for end-to-end encryption
ALTER TABLE profiles 
ADD COLUMN IF NOT EXISTS public_key TEXT;

-- Create index for faster public key lookups
CREATE INDEX IF NOT EXISTS idx_profiles_public_key ON profiles(public_key);

-- Add comment to explain encryption fields
COMMENT ON COLUMN chat_messages.is_encrypted IS 'Indicates if message content is encrypted using public-key cryptography';
COMMENT ON COLUMN chat_messages.nonce IS 'Nonce used for message encryption (required for decryption)';
COMMENT ON COLUMN profiles.public_key IS 'User public key for end-to-end encryption (base64 encoded)';