-- Migration: Phone Number Authentication with SMS OTP
-- Creates tables for phone authentication, OTP verification, and rate limiting

-- ============================================================================
-- 1. PHONE VERIFICATION TABLE
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.phone_verification_attempts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    phone_number TEXT NOT NULL,
    country_code TEXT NOT NULL,
    otp_code TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    expires_at TIMESTAMPTZ NOT NULL DEFAULT (now() + interval '10 minutes'),
    verified_at TIMESTAMPTZ,
    attempts_count INTEGER NOT NULL DEFAULT 0,
    is_verified BOOLEAN NOT NULL DEFAULT false,
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
    CONSTRAINT phone_verification_attempts_attempts_count_check CHECK (attempts_count <= 5)
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_phone_verification_phone ON public.phone_verification_attempts(phone_number);
CREATE INDEX IF NOT EXISTS idx_phone_verification_expires ON public.phone_verification_attempts(expires_at);
CREATE INDEX IF NOT EXISTS idx_phone_verification_user ON public.phone_verification_attempts(user_id);

-- ============================================================================
-- 2. RATE LIMITING TABLE
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.phone_auth_rate_limits (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    phone_number TEXT NOT NULL,
    country_code TEXT NOT NULL,
    request_count INTEGER NOT NULL DEFAULT 1,
    first_request_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_request_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    blocked_until TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE(phone_number, country_code)
);

-- Index for rate limiting lookups
CREATE INDEX IF NOT EXISTS idx_phone_rate_limit_lookup ON public.phone_auth_rate_limits(phone_number, country_code);
CREATE INDEX IF NOT EXISTS idx_phone_rate_limit_blocked ON public.phone_auth_rate_limits(blocked_until);

-- ============================================================================
-- 3. RLS POLICIES
-- ============================================================================

-- Enable RLS
ALTER TABLE public.phone_verification_attempts ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.phone_auth_rate_limits ENABLE ROW LEVEL SECURITY;

-- Phone verification attempts: Users can only see their own verification attempts
CREATE POLICY "Users can view own phone verification attempts"
    ON public.phone_verification_attempts
    FOR SELECT
    TO authenticated
    USING (auth.uid() = user_id);

-- Phone verification attempts: Allow insertion for authenticated users
CREATE POLICY "Users can create phone verification attempts"
    ON public.phone_verification_attempts
    FOR INSERT
    TO authenticated
    WITH CHECK (true);

-- Phone verification attempts: Users can update their own attempts
CREATE POLICY "Users can update own phone verification attempts"
    ON public.phone_verification_attempts
    FOR UPDATE
    TO authenticated
    USING (auth.uid() = user_id);

-- Rate limits: Users can view their own rate limit status
CREATE POLICY "Users can view own rate limit status"
    ON public.phone_auth_rate_limits
    FOR SELECT
    TO authenticated
    USING (true);

-- Rate limits: Allow system to insert/update rate limits
CREATE POLICY "System can manage rate limits"
    ON public.phone_auth_rate_limits
    FOR ALL
    TO authenticated
    USING (true)
    WITH CHECK (true);

-- ============================================================================
-- 4. FUNCTIONS FOR PHONE AUTHENTICATION
-- ============================================================================

-- Function to check rate limit
CREATE OR REPLACE FUNCTION public.check_phone_rate_limit(
    p_phone_number TEXT,
    p_country_code TEXT
)
RETURNS JSONB AS $$
DECLARE
    v_rate_limit RECORD;
    v_is_blocked BOOLEAN;
    v_requests_remaining INTEGER;
BEGIN
    -- Get or create rate limit record
    SELECT * INTO v_rate_limit
    FROM public.phone_auth_rate_limits
    WHERE phone_number = p_phone_number
    AND country_code = p_country_code;
    
    -- If no record exists, return allowed
    IF v_rate_limit IS NULL THEN
        RETURN jsonb_build_object(
            'allowed', true,
            'requests_remaining', 5,
            'reset_at', NULL
        );
    END IF;
    
    -- Check if blocked
    IF v_rate_limit.blocked_until IS NOT NULL AND v_rate_limit.blocked_until > now() THEN
        RETURN jsonb_build_object(
            'allowed', false,
            'requests_remaining', 0,
            'reset_at', v_rate_limit.blocked_until,
            'message', 'Too many requests. Please try again later.'
        );
    END IF;
    
    -- Check if rate limit window has expired (1 hour)
    IF v_rate_limit.first_request_at < (now() - interval '1 hour') THEN
        -- Reset rate limit
        UPDATE public.phone_auth_rate_limits
        SET request_count = 1,
            first_request_at = now(),
            last_request_at = now(),
            blocked_until = NULL,
            updated_at = now()
        WHERE id = v_rate_limit.id;
        
        RETURN jsonb_build_object(
            'allowed', true,
            'requests_remaining', 4,
            'reset_at', NULL
        );
    END IF;
    
    -- Check if exceeded limit (5 requests per hour)
    IF v_rate_limit.request_count >= 5 THEN
        -- Block for 1 hour
        UPDATE public.phone_auth_rate_limits
        SET blocked_until = now() + interval '1 hour',
            updated_at = now()
        WHERE id = v_rate_limit.id;
        
        RETURN jsonb_build_object(
            'allowed', false,
            'requests_remaining', 0,
            'reset_at', now() + interval '1 hour',
            'message', 'Rate limit exceeded. Blocked for 1 hour.'
        );
    END IF;
    
    -- Increment request count
    UPDATE public.phone_auth_rate_limits
    SET request_count = request_count + 1,
        last_request_at = now(),
        updated_at = now()
    WHERE id = v_rate_limit.id;
    
    v_requests_remaining := 5 - (v_rate_limit.request_count + 1);
    
    RETURN jsonb_build_object(
        'allowed', true,
        'requests_remaining', v_requests_remaining,
        'reset_at', NULL
    );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to create OTP verification attempt
CREATE OR REPLACE FUNCTION public.create_phone_otp_attempt(
    p_phone_number TEXT,
    p_country_code TEXT,
    p_otp_code TEXT
)
RETURNS UUID AS $$
DECLARE
    v_attempt_id UUID;
BEGIN
    -- Insert new verification attempt
    INSERT INTO public.phone_verification_attempts (
        phone_number,
        country_code,
        otp_code,
        expires_at
    ) VALUES (
        p_phone_number,
        p_country_code,
        p_otp_code,
        now() + interval '10 minutes'
    )
    RETURNING id INTO v_attempt_id;
    
    -- Create or update rate limit record
    INSERT INTO public.phone_auth_rate_limits (
        phone_number,
        country_code,
        request_count,
        first_request_at,
        last_request_at
    ) VALUES (
        p_phone_number,
        p_country_code,
        1,
        now(),
        now()
    )
    ON CONFLICT (phone_number, country_code)
    DO UPDATE SET
        request_count = CASE
            WHEN public.phone_auth_rate_limits.first_request_at < (now() - interval '1 hour')
            THEN 1
            ELSE public.phone_auth_rate_limits.request_count + 1
        END,
        first_request_at = CASE
            WHEN public.phone_auth_rate_limits.first_request_at < (now() - interval '1 hour')
            THEN now()
            ELSE public.phone_auth_rate_limits.first_request_at
        END,
        last_request_at = now(),
        updated_at = now();
    
    RETURN v_attempt_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to verify OTP code
CREATE OR REPLACE FUNCTION public.verify_phone_otp(
    p_phone_number TEXT,
    p_country_code TEXT,
    p_otp_code TEXT
)
RETURNS JSONB AS $$
DECLARE
    v_attempt RECORD;
BEGIN
    -- Find most recent unverified attempt
    SELECT * INTO v_attempt
    FROM public.phone_verification_attempts
    WHERE phone_number = p_phone_number
    AND country_code = p_country_code
    AND is_verified = false
    AND expires_at > now()
    ORDER BY created_at DESC
    LIMIT 1;
    
    -- Check if attempt exists
    IF v_attempt IS NULL THEN
        RETURN jsonb_build_object(
            'success', false,
            'message', 'No valid verification attempt found. Please request a new OTP.'
        );
    END IF;
    
    -- Check if too many attempts
    IF v_attempt.attempts_count >= 5 THEN
        RETURN jsonb_build_object(
            'success', false,
            'message', 'Too many verification attempts. Please request a new OTP.'
        );
    END IF;
    
    -- Increment attempt count
    UPDATE public.phone_verification_attempts
    SET attempts_count = attempts_count + 1
    WHERE id = v_attempt.id;
    
    -- Verify OTP code
    IF v_attempt.otp_code = p_otp_code THEN
        -- Mark as verified
        UPDATE public.phone_verification_attempts
        SET is_verified = true,
            verified_at = now()
        WHERE id = v_attempt.id;
        
        RETURN jsonb_build_object(
            'success', true,
            'message', 'Phone number verified successfully',
            'attempt_id', v_attempt.id
        );
    ELSE
        RETURN jsonb_build_object(
            'success', false,
            'message', 'Invalid OTP code. Please try again.',
            'attempts_remaining', 5 - (v_attempt.attempts_count + 1)
        );
    END IF;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to clean up expired verification attempts (called by cron job)
CREATE OR REPLACE FUNCTION public.cleanup_expired_phone_verifications()
RETURNS void AS $$
BEGIN
    DELETE FROM public.phone_verification_attempts
    WHERE expires_at < now()
    AND is_verified = false;
    
    -- Also clean up old verified attempts (older than 30 days)
    DELETE FROM public.phone_verification_attempts
    WHERE created_at < (now() - interval '30 days');
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ============================================================================
-- 5. TRIGGER TO UPDATE PROFILES ON PHONE VERIFICATION
-- ============================================================================

-- Function to update profile with phone number after verification
CREATE OR REPLACE FUNCTION public.update_profile_on_phone_verification()
RETURNS TRIGGER AS $$
BEGIN
    -- Only update if verified
    IF NEW.is_verified = true AND OLD.is_verified = false THEN
        -- Update user profile with phone number
        UPDATE public.profiles
        SET phone = NEW.phone_number,
            country_code = NEW.country_code,
            updated_at = now()
        WHERE id = NEW.user_id;
    END IF;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger
DROP TRIGGER IF EXISTS trigger_update_profile_on_phone_verification ON public.phone_verification_attempts;
CREATE TRIGGER trigger_update_profile_on_phone_verification
    AFTER UPDATE ON public.phone_verification_attempts
    FOR EACH ROW
    WHEN (NEW.is_verified = true AND OLD.is_verified = false)
    EXECUTE FUNCTION public.update_profile_on_phone_verification();

-- ============================================================================
-- 6. GRANT PERMISSIONS
-- ============================================================================

GRANT SELECT, INSERT, UPDATE ON public.phone_verification_attempts TO authenticated;
GRANT SELECT, INSERT, UPDATE ON public.phone_auth_rate_limits TO authenticated;
GRANT EXECUTE ON FUNCTION public.check_phone_rate_limit TO authenticated;
GRANT EXECUTE ON FUNCTION public.create_phone_otp_attempt TO authenticated;
GRANT EXECUTE ON FUNCTION public.verify_phone_otp TO authenticated;