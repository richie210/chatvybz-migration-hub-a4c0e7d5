-- Location: supabase/migrations/20260110030000_fix_qr_auth_anon_access.sql
-- Purpose: Fix RLS policy to allow anonymous users to generate QR tokens for login
-- Issue: Users cannot generate QR tokens because they're not authenticated yet

-- Drop the existing restrictive INSERT policy
DROP POLICY IF EXISTS "anyone_can_create_qr_tokens" ON public.qr_auth_tokens;

-- Create new policy that allows both authenticated AND anonymous users to create QR tokens
CREATE POLICY "anon_and_auth_can_create_qr_tokens"
ON public.qr_auth_tokens
FOR INSERT
TO anon, authenticated
WITH CHECK (true);

-- Update SELECT policy to allow anonymous users to check their own tokens
DROP POLICY IF EXISTS "users_can_view_own_qr_tokens" ON public.qr_auth_tokens;

CREATE POLICY "anon_and_auth_can_view_qr_tokens"
ON public.qr_auth_tokens
FOR SELECT
TO anon, authenticated
USING (true);

-- Update UPDATE policy to allow anonymous users to verify tokens
DROP POLICY IF EXISTS "users_can_update_own_qr_tokens" ON public.qr_auth_tokens;

CREATE POLICY "anon_and_auth_can_update_qr_tokens"
ON public.qr_auth_tokens
FOR UPDATE
TO anon, authenticated
USING (true)
WITH CHECK (true);

-- Add comment explaining the security model
COMMENT ON TABLE public.qr_auth_tokens IS 'QR authentication tokens - allows anonymous access for login flow. Security is enforced by token expiration and one-time use pattern.';