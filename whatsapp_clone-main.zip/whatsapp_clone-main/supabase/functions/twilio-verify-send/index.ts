import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.39.3';

declare const Deno: {
  env: {
    get(key: string): string | undefined;
  };
};

const TWILIO_ACCOUNT_SID = Deno.env.get('TWILIO_ACCOUNT_SID');
const TWILIO_AUTH_TOKEN = Deno.env.get('TWILIO_AUTH_TOKEN');
const TWILIO_VERIFY_SERVICE_SID = Deno.env.get('TWILIO_VERIFY_SERVICE_SID');
const SUPABASE_URL = Deno.env.get('SUPABASE_URL');
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface VerifySendRequest {
  phoneNumber: string;
  channel?: 'sms' | 'call';
}

serve(async (req) => {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    // Validate Twilio credentials
    if (!TWILIO_ACCOUNT_SID || !TWILIO_AUTH_TOKEN || !TWILIO_VERIFY_SERVICE_SID) {
      throw new Error('Twilio Verify credentials not configured');
    }

    const { phoneNumber, channel = 'sms' }: VerifySendRequest = await req.json();

    if (!phoneNumber) {
      return new Response(
        JSON.stringify({ error: 'Phone number is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Validate E.164 format
    const e164Regex = /^\+[1-9]\d{1,14}$/;
    if (!e164Regex.test(phoneNumber)) {
      return new Response(
        JSON.stringify({ error: 'Phone number must be in E.164 format (e.g., +596696972158)' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Initialize Supabase client for rate limiting
    const supabase = createClient(SUPABASE_URL!, SUPABASE_SERVICE_ROLE_KEY!);

    // Extract country code
    const countryCodeMatch = phoneNumber.match(/^\+(\d{1,3})/);
    const countryCode = countryCodeMatch ? `+${countryCodeMatch[1]}` : '+1';

    // Check rate limit
    const { data: rateLimitData, error: rateLimitError } = await supabase.rpc(
      'check_phone_rate_limit',
      {
        p_phone_number: phoneNumber,
        p_country_code: countryCode,
      }
    );

    if (rateLimitError) {
      console.error('Rate limit check error:', rateLimitError);
      throw new Error('Failed to check rate limit');
    }

    if (!rateLimitData?.allowed) {
      return new Response(
        JSON.stringify({
          error: rateLimitData?.message || 'Rate limit exceeded',
          resetAt: rateLimitData?.reset_at,
        }),
        { status: 429, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Send verification via Twilio Verify API
    const twilioUrl = `https://verify.twilio.com/v2/Services/${TWILIO_VERIFY_SERVICE_SID}/Verifications`;
    const twilioAuth = btoa(`${TWILIO_ACCOUNT_SID}:${TWILIO_AUTH_TOKEN}`);

    const twilioResponse = await fetch(twilioUrl, {
      method: 'POST',
      headers: {
        'Authorization': `Basic ${twilioAuth}`,
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: new URLSearchParams({
        To: phoneNumber,
        Channel: channel,
      }),
    });

    if (!twilioResponse.ok) {
      const twilioError = await twilioResponse.text();
      console.error('Twilio Verify API error:', twilioError);
      throw new Error('Failed to send verification code. Please check the phone number.');
    }

    const twilioData = await twilioResponse.json();

    return new Response(
      JSON.stringify({
        success: true,
        status: twilioData.status, // 'pending'
        channel: twilioData.channel,
        to: twilioData.to,
        valid: twilioData.valid,
        message: `Verification code sent via ${channel}`,
      }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Twilio Verify send error:', error);
    return new Response(
      JSON.stringify({
        error: error.message || 'Failed to send verification code',
      }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
