import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.39.3';

declare const Deno: {
  env: {
    get(key: string): string | undefined;
  };
};

const SUPABASE_URL = Deno.env.get('SUPABASE_URL');
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface VerifyOTPRequest {
  phoneNumber: string;
  countryCode: string;
  otpCode: string;
}

/**
 * Verify OTP against stored hash using Web Crypto API
 */
async function verifyOTP(otp: string, storedHash: string): Promise<boolean> {
  try {
    const encoder = new TextEncoder();
    const data = encoder.encode(otp);
    
    // Decode stored hash
    const combined = Uint8Array.from(atob(storedHash), c => c.charCodeAt(0));
    const salt = combined.slice(0, 16);
    const hash = combined.slice(16);
    
    // Import key for PBKDF2
    const keyMaterial = await crypto.subtle.importKey(
      'raw',
      data,
      { name: 'PBKDF2' },
      false,
      ['deriveBits']
    );
    
    // Derive bits using same parameters
    const derivedBits = await crypto.subtle.deriveBits(
      {
        name: 'PBKDF2',
        salt: salt,
        iterations: 100000,
        hash: 'SHA-256'
      },
      keyMaterial,
      256
    );
    
    const derivedHash = new Uint8Array(derivedBits);
    
    // Compare hashes
    if (derivedHash.length !== hash.length) return false;
    
    let match = true;
    for (let i = 0; i < derivedHash.length; i++) {
      if (derivedHash[i] !== hash[i]) {
        match = false;
        break;
      }
    }
    
    return match;
  } catch (error) {
    console.error('OTP verification error:', error);
    return false;
  }
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    // Parse request body
    const { phoneNumber, countryCode, otpCode }: VerifyOTPRequest = await req.json();

    if (!phoneNumber || !countryCode || !otpCode) {
      return new Response(
        JSON.stringify({ error: 'Phone number, country code, and OTP code are required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Format phone number to E.164
    const cleanPhone = phoneNumber.replace(/\D/g, '');
    const cleanCode = countryCode.replace(/\D/g, '');
    const e164Phone = `+${cleanCode}${cleanPhone}`;

    // Initialize Supabase client
    const supabase = createClient(SUPABASE_URL!, SUPABASE_SERVICE_ROLE_KEY!);

    // Get the most recent unverified OTP attempt for this phone number
    const { data: otpAttempt, error: fetchError } = await supabase
      .from('phone_verification_attempts')
      .select('*')
      .eq('phone_number', e164Phone)
      .eq('country_code', `+${cleanCode}`)
      .eq('is_verified', false)
      .gt('expires_at', new Date().toISOString())
      .order('created_at', { ascending: false })
      .limit(1)
      .single();

    if (fetchError || !otpAttempt) {
      return new Response(
        JSON.stringify({ error: 'No valid OTP found. Please request a new code.' }),
        { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Check if max attempts exceeded
    if (otpAttempt.attempts_count >= otpAttempt.max_attempts) {
      return new Response(
        JSON.stringify({ error: 'Maximum verification attempts exceeded. Please request a new code.' }),
        { status: 429, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Increment attempts count
    await supabase
      .from('phone_verification_attempts')
      .update({ attempts_count: otpAttempt.attempts_count + 1 })
      .eq('id', otpAttempt.id);

    // Verify OTP using Web Crypto API
    const isValid = await verifyOTP(otpCode, otpAttempt.otp_hash);

    if (!isValid) {
      const remainingAttempts = otpAttempt.max_attempts - (otpAttempt.attempts_count + 1);
      return new Response(
        JSON.stringify({
          error: 'Invalid verification code',
          remainingAttempts: Math.max(0, remainingAttempts),
        }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Mark OTP as verified (single-use enforcement)
    await supabase
      .from('phone_verification_attempts')
      .update({
        is_verified: true,
        verified_at: new Date().toISOString(),
      })
      .eq('id', otpAttempt.id);

    // Check if user exists with this phone number
    const { data: existingUser, error: userError } = await supabase
      .from('profiles')
      .select('id, phone, country_code')
      .eq('phone', e164Phone)
      .eq('country_code', `+${cleanCode}`)
      .single();

    const userExists = !userError && existingUser !== null;

    // Return success response
    return new Response(
      JSON.stringify({
        success: true,
        message: 'Phone number verified successfully',
        phoneNumber: e164Phone,
        countryCode: `+${cleanCode}`,
        userExists: userExists,
        userId: userExists ? existingUser.id : null,
      }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('OTP verification error:', error);
    return new Response(
      JSON.stringify({ error: error.message || 'Internal server error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});