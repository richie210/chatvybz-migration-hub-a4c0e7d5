import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import Stripe from 'https://esm.sh/stripe@14.21.0';

declare const Deno: any;

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req?.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY') || '', {
      apiVersion: '2023-10-16',
    })

    const supabaseClient = createClient(
      Deno?.env?.get('SUPABASE_URL') ?? '',
      Deno?.env?.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    if (req?.method === 'POST') {
      const signature = req?.headers?.get('stripe-signature')
      const body = await req?.text()

      if (!signature) {
        return new Response(
          JSON.stringify({ error: 'No signature provided' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        )
      }

      let event
      try {
        event = stripe?.webhooks?.constructEvent(
          body,
          signature,
          Deno?.env?.get('STRIPE_WEBHOOK_SECRET') || ''
        )
      } catch (err) {
        console.error('Webhook signature verification failed:', err?.message)
        return new Response(
          JSON.stringify({ error: 'Invalid signature' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        )
      }

      // Log webhook event
      await supabaseClient?.from('stripe_webhook_events')?.insert({
          stripe_event_id: event?.id,
          event_type: event?.type,
          payload: event?.data?.object
        })

      // Handle different event types
      switch (event?.type) {
        // Subscription events
        case 'customer.subscription.created': case'customer.subscription.updated':
          await handleSubscriptionUpdate(event?.data?.object, supabaseClient)
          break

        case 'customer.subscription.deleted':
          await handleSubscriptionDeleted(event?.data?.object, supabaseClient)
          break

        case 'invoice.payment_succeeded':
          await handlePaymentSucceeded(event?.data?.object, supabaseClient)
          break

        case 'invoice.payment_failed':
          await handlePaymentFailed(event?.data?.object, supabaseClient)
          break

        // Payout events (NEW)
        case 'payout.paid':
          await handlePayoutPaid(event?.data?.object, supabaseClient, stripe)
          break

        case 'payout.failed':
          await handlePayoutFailed(event?.data?.object, supabaseClient, stripe)
          break

        case 'payout.updated':
          await handlePayoutUpdated(event?.data?.object, supabaseClient, stripe)
          break

        case 'payout.created':
          await handlePayoutCreated(event?.data?.object, supabaseClient, stripe)
          break

        default:
          console.log(`Unhandled event type: ${event?.type}`)
      }

      // Mark event as processed
      await supabaseClient?.from('stripe_webhook_events')?.update({ processed: true, processed_at: new Date()?.toISOString() })?.eq('stripe_event_id', event?.id)

      return new Response(
        JSON.stringify({ received: true }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    return new Response(
      JSON.stringify({ error: 'Method not allowed' }),
      { status: 405, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )

  } catch (error) {
    console.error('Webhook error:', error)
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})

// Existing subscription handlers
async function handleSubscriptionUpdate(subscription, supabaseClient) {
  const { error } = await supabaseClient?.from('channel_subscriptions')?.update({
      status: subscription?.status,
      current_period_start: new Date(subscription.current_period_start * 1000)?.toISOString(),
      current_period_end: new Date(subscription.current_period_end * 1000)?.toISOString(),
      cancel_at_period_end: subscription?.cancel_at_period_end,
      updated_at: new Date()?.toISOString()
    })?.eq('stripe_subscription_id', subscription?.id)

  if (error) {
    console.error('Error updating subscription:', error)
  }
}

async function handleSubscriptionDeleted(subscription, supabaseClient) {
  const { error } = await supabaseClient?.from('channel_subscriptions')?.update({
      status: 'canceled',
      canceled_at: new Date()?.toISOString(),
      updated_at: new Date()?.toISOString()
    })?.eq('stripe_subscription_id', subscription?.id)

  if (error) {
    console.error('Error canceling subscription:', error)
  }
}

async function handlePaymentSucceeded(invoice, supabaseClient) {
  if (!invoice?.subscription) return

  const { error } = await supabaseClient?.from('channel_subscriptions')?.update({
      status: 'active',
      updated_at: new Date()?.toISOString()
    })?.eq('stripe_subscription_id', invoice?.subscription)

  if (error) {
    console.error('Error updating subscription after payment:', error)
  }
}

async function handlePaymentFailed(invoice, supabaseClient) {
  if (!invoice?.subscription) return

  const { error } = await supabaseClient?.from('channel_subscriptions')?.update({
      status: 'past_due',
      updated_at: new Date()?.toISOString()
    })?.eq('stripe_subscription_id', invoice?.subscription)

  if (error) {
    console.error('Error updating subscription after failed payment:', error)
  }
}

// NEW: Payout event handlers
async function handlePayoutPaid(payout, supabaseClient, stripe) {
  try {
    console.log('Processing payout.paid event:', payout?.id)

    // Update payout status in database
    const { data: updatedPayout, error: updateError } = await supabaseClient
      ?.from('creator_payouts')
      ?.update({
        status: 'paid',
        paid_at: new Date(payout?.arrival_date * 1000)?.toISOString(),
        updated_at: new Date()?.toISOString()
      })
      ?.eq('stripe_payout_id', payout?.id)
      ?.select('id, creator_id, channel_id, amount')
      ?.single()

    if (updateError) {
      console.error('Error updating payout:', updateError)
      return
    }

    if (updatedPayout) {
      // Fetch balance transactions for this payout to create transaction-level records
      await createPayoutTransactions(payout, updatedPayout, stripe, supabaseClient)
    }

  } catch (error) {
    console.error('Error handling payout.paid:', error)
  }
}

async function handlePayoutFailed(payout, supabaseClient, stripe) {
  try {
    console.log('Processing payout.failed event:', payout?.id)

    const { error } = await supabaseClient
      ?.from('creator_payouts')
      ?.update({
        status: 'failed',
        updated_at: new Date()?.toISOString()
      })
      ?.eq('stripe_payout_id', payout?.id)

    if (error) {
      console.error('Error updating failed payout:', error)
    }
  } catch (error) {
    console.error('Error handling payout.failed:', error)
  }
}

async function handlePayoutUpdated(payout, supabaseClient, stripe) {
  try {
    console.log('Processing payout.updated event:', payout?.id)

    let status = 'pending'
    if (payout?.status === 'in_transit') {
      status = 'processing'
    } else if (payout?.status === 'paid') {
      status = 'paid'
    } else if (payout?.status === 'failed' || payout?.status === 'canceled') {
      status = 'failed'
    }

    const updateData: any = {
      status: status,
      updated_at: new Date()?.toISOString()
    }

    if (payout?.arrival_date && status === 'paid') {
      updateData.paid_at = new Date(payout?.arrival_date * 1000)?.toISOString()
    }

    const { error } = await supabaseClient
      ?.from('creator_payouts')
      ?.update(updateData)
      ?.eq('stripe_payout_id', payout?.id)

    if (error) {
      console.error('Error updating payout:', error)
    }
  } catch (error) {
    console.error('Error handling payout.updated:', error)
  }
}

async function handlePayoutCreated(payout, supabaseClient, stripe) {
  try {
    console.log('Processing payout.created event:', payout?.id)

    // Check if payout already exists
    const { data: existing } = await supabaseClient
      ?.from('creator_payouts')
      ?.select('id')
      ?.eq('stripe_payout_id', payout?.id)
      ?.single()

    if (existing) {
      console.log('Payout already exists, skipping creation')
      return
    }

    // Update status to processing if it was just created
    const { error } = await supabaseClient
      ?.from('creator_payouts')
      ?.update({
        status: 'processing',
        updated_at: new Date()?.toISOString()
      })
      ?.eq('stripe_payout_id', payout?.id)

    if (error) {
      console.error('Error updating created payout:', error)
    }
  } catch (error) {
    console.error('Error handling payout.created:', error)
  }
}

// Create detailed transaction records from Stripe balance transactions
async function createPayoutTransactions(payout, dbPayout, stripe, supabaseClient) {
  try {
    // Fetch balance transactions for this payout
    const balanceTransactions = await stripe.balanceTransactions.list({
      payout: payout?.id,
      limit: 100
    })

    if (!balanceTransactions?.data || balanceTransactions?.data?.length === 0) {
      console.log('No balance transactions found for payout:', payout?.id)
      return
    }

    // Map balance transactions to our payout_transactions table
    const transactions = balanceTransactions?.data?.map((txn) => {
      let transactionType = 'adjustment'
      
      // Determine transaction type based on Stripe type
      if (txn?.type === 'charge' || txn?.type === 'payment') {
        transactionType = 'subscription'
      } else if (txn?.type === 'refund') {
        transactionType = 'refund'
      } else if (txn?.description?.toLowerCase()?.includes('ad')) {
        transactionType = 'ad_revenue'
      } else if (txn?.description?.toLowerCase()?.includes('tip') || txn?.description?.toLowerCase()?.includes('donation')) {
        transactionType = 'donation'
      }

      const amount = txn?.amount / 100 // Convert from cents
      const feeAmount = txn?.fee / 100
      const netAmount = txn?.net / 100

      return {
        payout_id: dbPayout?.id,
        transaction_type: transactionType,
        source_id: txn?.source,
        source_type: txn?.type,
        amount: amount,
        currency: txn?.currency?.toUpperCase(),
        fee_amount: feeAmount,
        net_amount: netAmount,
        description: txn?.description || `${txn?.type} transaction`,
        metadata: {
          stripe_transaction_id: txn?.id,
          stripe_source: txn?.source,
          stripe_type: txn?.type,
          available_on: txn?.available_on
        },
        transaction_date: new Date(txn?.created * 1000)?.toISOString()
      }
    })

    // Insert transactions in batches
    const { error: insertError } = await supabaseClient
      ?.from('payout_transactions')
      ?.insert(transactions)

    if (insertError) {
      console.error('Error inserting payout transactions:', insertError)
    } else {
      console.log(`Created ${transactions?.length} transaction records for payout ${payout?.id}`)
    }
  } catch (error) {
    console.error('Error creating payout transactions:', error)
  }
}