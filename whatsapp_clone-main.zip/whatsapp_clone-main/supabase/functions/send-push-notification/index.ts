import { serve } from "https://deno.land/std@0.192.0/http/server.ts";
/// <reference lib="deno.ns" />

// Declare Deno namespace for type safety
declare const Deno: {
  env: {
    get(key: string): string | undefined;
  };
};

serve(async (req) => {
  // ✅ CORS preflight
  if (req.method === "OPTIONS") {
    return new Response("ok", {
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "POST, OPTIONS",
        "Access-Control-Allow-Headers": "*"
      }
    });
  }

  try {
    const { notificationType, recipientEmail, recipientName, data } = await req.json();

    if (!notificationType || !recipientEmail || !data) {
      return new Response(JSON.stringify({
        error: "Missing required fields: notificationType, recipientEmail, data"
      }), {
        status: 400,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*"
        }
      });
    }

    const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY");
    if (!RESEND_API_KEY) {
      return new Response(JSON.stringify({
        error: "Resend API key not configured"
      }), {
        status: 500,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*"
        }
      });
    }

    // Generate email content based on notification type
    let subject = "";
    let htmlContent = "";

    if (notificationType === "message") {
      subject = `New Message from ${data.senderName || 'Someone'}`;
      htmlContent = generateMessageNotificationEmail(recipientName, data);
    } else if (notificationType === "mention") {
      subject = `${data.mentionerName || 'Someone'} mentioned you`;
      htmlContent = generateMentionNotificationEmail(recipientName, data);
    } else if (notificationType === "call") {
      subject = `${data.callType || 'Call'} from ${data.callerName || 'Someone'}`;
      htmlContent = generateCallNotificationEmail(recipientName, data);
    } else {
      return new Response(JSON.stringify({
        error: "Invalid notification type. Must be: message, mention, or call"
      }), {
        status: 400,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*"
        }
      });
    }

    // Send email via Resend API
    const resendResponse = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${RESEND_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        from: "onboarding@resend.dev",
        to: recipientEmail,
        subject: subject,
        html: htmlContent
      })
    });

    const resendData = await resendResponse.json();

    if (!resendResponse.ok) {
      return new Response(JSON.stringify({
        error: "Failed to send notification",
        details: resendData
      }), {
        status: resendResponse.status,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*"
        }
      });
    }

    return new Response(JSON.stringify({
      success: true,
      message: "Push notification sent successfully",
      emailId: resendData.id
    }), {
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*"
      }
    });
  } catch (error) {
    return new Response(JSON.stringify({
      error: error.message
    }), {
      status: 500,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*"
      }
    });
  }
});

function generateMessageNotificationEmail(name: string, data: any): string {
  return `
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; background: #f3f4f6; margin: 0; padding: 20px; }
        .container { max-width: 500px; margin: 0 auto; background: white; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
        .header { background: linear-gradient(135deg, #14b8a6 0%, #0d9488 100%); color: white; padding: 24px; text-align: center; }
        .content { padding: 30px; }
        .message-box { background: #f9fafb; border-left: 4px solid #14b8a6; padding: 16px; margin: 20px 0; border-radius: 4px; }
        .sender { font-weight: bold; color: #0d9488; margin-bottom: 8px; }
        .message-text { color: #374151; line-height: 1.5; }
        .cta-button { display: inline-block; background: #14b8a6; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin-top: 20px; font-weight: 600; }
        .footer { text-align: center; padding: 20px; color: #6b7280; font-size: 12px; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h2>💬 New Message</h2>
        </div>
        <div class="content">
          <p>Hi ${name || 'there'},</p>
          <p>You have a new message:</p>
          <div class="message-box">
            <div class="sender">${data.senderName || 'Someone'}</div>
            <div class="message-text">${data.messagePreview || 'New message received'}</div>
          </div>
          <a href="${data.chatUrl || '#'}" class="cta-button">View Message</a>
        </div>
        <div class="footer">
          <p>ChatVybz - Stay Connected</p>
        </div>
      </div>
    </body>
    </html>
  `;
}

function generateMentionNotificationEmail(name: string, data: any): string {
  return `
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; background: #f3f4f6; margin: 0; padding: 20px; }
        .container { max-width: 500px; margin: 0 auto; background: white; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
        .header { background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); color: white; padding: 24px; text-align: center; }
        .content { padding: 30px; }
        .mention-box { background: #fef3c7; border-left: 4px solid #f59e0b; padding: 16px; margin: 20px 0; border-radius: 4px; }
        .mentioner { font-weight: bold; color: #d97706; margin-bottom: 8px; }
        .mention-text { color: #374151; line-height: 1.5; }
        .cta-button { display: inline-block; background: #f59e0b; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin-top: 20px; font-weight: 600; }
        .footer { text-align: center; padding: 20px; color: #6b7280; font-size: 12px; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h2>@ You were mentioned</h2>
        </div>
        <div class="content">
          <p>Hi ${name || 'there'},</p>
          <p>Someone mentioned you in a conversation:</p>
          <div class="mention-box">
            <div class="mentioner">${data.mentionerName || 'Someone'} mentioned you</div>
            <div class="mention-text">${data.messagePreview || 'Check out the mention'}</div>
          </div>
          <a href="${data.messageUrl || '#'}" class="cta-button">View Mention</a>
        </div>
        <div class="footer">
          <p>ChatVybz - Stay Connected</p>
        </div>
      </div>
    </body>
    </html>
  `;
}

function generateCallNotificationEmail(name: string, data: any): string {
  return `
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; background: #f3f4f6; margin: 0; padding: 20px; }
        .container { max-width: 500px; margin: 0 auto; background: white; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
        .header { background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%); color: white; padding: 24px; text-align: center; }
        .content { padding: 30px; }
        .call-box { background: #eff6ff; border-left: 4px solid #3b82f6; padding: 16px; margin: 20px 0; border-radius: 4px; }
        .caller { font-weight: bold; color: #2563eb; margin-bottom: 8px; font-size: 18px; }
        .call-type { color: #6b7280; font-size: 14px; }
        .cta-button { display: inline-block; background: #3b82f6; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; margin-top: 20px; font-weight: 600; }
        .footer { text-align: center; padding: 20px; color: #6b7280; font-size: 12px; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h2>📞 ${data.callStatus === 'missed' ? 'Missed Call' : 'Incoming Call'}</h2>
        </div>
        <div class="content">
          <p>Hi ${name || 'there'},</p>
          <p>${data.callStatus === 'missed' ? 'You missed a call from:' : 'You have an incoming call from:'}</p>
          <div class="call-box">
            <div class="caller">${data.callerName || 'Unknown'}</div>
            <div class="call-type">${data.callType || 'Voice'} Call</div>
          </div>
          <a href="${data.callUrl || '#'}" class="cta-button">${data.callStatus === 'missed' ? 'Call Back' : 'Join Call'}</a>
        </div>
        <div class="footer">
          <p>ChatVybz - Stay Connected</p>
        </div>
      </div>
    </body>
    </html>
  `;
}