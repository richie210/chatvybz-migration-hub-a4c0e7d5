/// <reference lib="deno.ns" />

import { serve } from "https://deno.land/std@0.192.0/http/server.ts";

// Declare Deno global for type safety (already available in Deno runtime)
declare const Deno: {
  env: {
    get(key: string): string | undefined;
  };
};

serve(async (req) => {
  // ✅ CORS preflight
  if (req?.method === "OPTIONS") {
    return new Response("ok", {
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "POST, OPTIONS",
        "Access-Control-Allow-Headers": "*"
      }
    });
  }

  try {
    const { to, subject, notificationType, data } = await req?.json();

    if (!to || !subject || !notificationType) {
      throw new Error("Missing required fields: to, subject, notificationType");
    }

    const RESEND_API_KEY = Deno?.env?.get("RESEND_API_KEY");
    if (!RESEND_API_KEY) {
      throw new Error("RESEND_API_KEY not configured");
    }

    // Build email HTML based on notification type
    let htmlContent = "";
    
    if (notificationType === "message") {
      htmlContent = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #0d9488;">New Message</h2>
          <p>You have a new message from <strong>${data?.senderName || 'Unknown'}</strong></p>
          <div style="background: #f3f4f6; padding: 15px; border-radius: 8px; margin: 20px 0;">
            <p style="margin: 0;">${data?.message || ''}</p>
          </div>
          <p style="color: #6b7280; font-size: 14px;">Sent at ${new Date(data?.timestamp || Date.now())?.toLocaleString()}</p>
        </div>
      `;
    } else if (notificationType === "mention") {
      htmlContent = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #0d9488;">You were mentioned</h2>
          <p><strong>${data?.mentionedBy || 'Someone'}</strong> mentioned you in ${data?.location || 'a conversation'}</p>
          <div style="background: #f3f4f6; padding: 15px; border-radius: 8px; margin: 20px 0;">
            <p style="margin: 0;">${data?.message || ''}</p>
          </div>
          <p style="color: #6b7280; font-size: 14px;">Mentioned at ${new Date(data?.timestamp || Date.now())?.toLocaleString()}</p>
        </div>
      `;
    } else if (notificationType === "call") {
      htmlContent = `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #0d9488;">${data?.callStatus === 'missed' ? 'Missed Call' : 'Call Notification'}</h2>
          <p><strong>${data?.callerName || 'Unknown'}</strong> ${data?.callStatus === 'missed' ? 'tried to call you' : 'called you'}</p>
          <div style="background: #f3f4f6; padding: 15px; border-radius: 8px; margin: 20px 0;">
            <p style="margin: 0;"><strong>Call Type:</strong> ${data?.callType || 'voice'}</p>
            <p style="margin: 5px 0 0 0;"><strong>Duration:</strong> ${data?.duration || 'N/A'}</p>
          </div>
          <p style="color: #6b7280; font-size: 14px;">${new Date(data?.timestamp || Date.now())?.toLocaleString()}</p>
        </div>
      `;
    }

    // Send email via Resend API
    const resendResponse = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${RESEND_API_KEY}`
      },
      body: JSON.stringify({
        from: "onboarding@resend.dev",
        to: [to],
        subject: subject,
        html: htmlContent
      })
    });

    const resendData = await resendResponse?.json();

    if (!resendResponse?.ok) {
      throw new Error(resendData?.message || "Failed to send email");
    }

    return new Response(JSON.stringify({
      success: true,
      messageId: resendData?.id,
      notificationType
    }), {
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*"
      }
    });
  } catch (error) {
    return new Response(JSON.stringify({
      error: error.message
    }), {
      status: 500,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*"
      }
    });
  }
});