import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.39.3';

declare const Deno: {
  env: {
    get(key: string): string | undefined;
  };
};

const TWILIO_ACCOUNT_SID = Deno.env.get('TWILIO_ACCOUNT_SID');
const TWILIO_AUTH_TOKEN = Deno.env.get('TWILIO_AUTH_TOKEN');
const TWILIO_PHONE_NUMBER = Deno.env.get('TWILIO_PHONE_NUMBER');
const SUPABASE_URL = Deno.env.get('SUPABASE_URL');
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface SendVoiceOTPRequest {
  phoneNumber: string;
  countryCode: string;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    console.log('📞 Voice OTP request received');
    console.log('🔧 Checking Twilio credentials...');
    console.log('TWILIO_ACCOUNT_SID:', TWILIO_ACCOUNT_SID ? `${TWILIO_ACCOUNT_SID.substring(0, 10)}...` : 'MISSING');
    console.log('TWILIO_AUTH_TOKEN:', TWILIO_AUTH_TOKEN ? 'SET' : 'MISSING');
    console.log('TWILIO_PHONE_NUMBER:', TWILIO_PHONE_NUMBER || 'MISSING');

    if (!TWILIO_ACCOUNT_SID || !TWILIO_AUTH_TOKEN || !TWILIO_PHONE_NUMBER) {
      console.error('❌ Twilio credentials missing');
      return new Response(
        JSON.stringify({
          success: false,
          error: 'Voice call service not configured',
          hint: 'Twilio credentials are not configured in Supabase Edge Function secrets. Please add TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, and TWILIO_PHONE_NUMBER',
          code: 'SERVICE_UNAVAILABLE'
        }),
        { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
      console.error('❌ Supabase credentials missing');
      return new Response(
        JSON.stringify({
          success: false,
          error: 'Database service not configured',
          hint: 'Please contact support',
          code: 'SERVICE_UNAVAILABLE'
        }),
        { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const { phoneNumber, countryCode }: SendVoiceOTPRequest = await req.json();
    console.log('📥 Request data:', { phoneNumber, countryCode });

    if (!phoneNumber || !countryCode) {
      return new Response(
        JSON.stringify({ 
          success: false,
          error: 'Phone number and country code are required',
          code: 'INVALID_INPUT'
        }),
        { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Clean and format phone number to E.164
    const cleanPhone = phoneNumber.replace(/\D/g, '');
    const cleanCode = countryCode.replace(/[^0-9+]/g, '').replace(/^\+/, '');
    const e164Phone = `+${cleanCode}${cleanPhone}`;
    
    console.log('📱 Formatted phone:', {
      original: `${countryCode} ${phoneNumber}`,
      cleaned: e164Phone,
      from: TWILIO_PHONE_NUMBER
    });

    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    // Check rate limit
    const fifteenMinutesAgo = new Date(Date.now() - 15 * 60 * 1000).toISOString();
    const { data: recentAttempts, error: rateLimitError } = await supabase
      .from('phone_verification_attempts')
      .select('id')
      .eq('phone_number', e164Phone)
      .gte('created_at', fifteenMinutesAgo);

    if (rateLimitError) {
      console.error('Rate limit check error:', rateLimitError);
    }

    if (recentAttempts && recentAttempts.length >= 5) {
      console.warn('⚠️ Rate limit exceeded for', e164Phone);
      return new Response(
        JSON.stringify({
          success: false,
          error: 'Too many verification attempts',
          hint: 'Please wait 15 minutes before trying again',
          code: 'RATE_LIMIT_EXCEEDED'
        }),
        { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Generate 6-digit OTP
    const otpCode = Math.floor(100000 + Math.random() * 900000).toString();
    console.log(`🔢 Generated OTP for ${e164Phone}`);

    // Store OTP in database
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000).toISOString();
    const { data: otpData, error: otpError } = await supabase
      .from('phone_verification_attempts')
      .insert({
        phone_number: e164Phone,
        country_code: `+${cleanCode}`,
        otp_code: otpCode,
        expires_at: expiresAt,
        attempts_count: 0,
        is_verified: false,
        delivery_method: 'voice'
      })
      .select()
      .single();

    if (otpError) {
      console.error('❌ Database error:', otpError);
      return new Response(
        JSON.stringify({
          success: false,
          error: 'Failed to generate verification code',
          hint: 'Please try again',
          code: 'DATABASE_ERROR'
        }),
        { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`✅ OTP stored in database (ID: ${otpData.id})`);

    // Format OTP for voice (add pauses between digits)
    const voiceOTP = otpCode.split('').join(', ');

    // Create TwiML for voice call
    const twiml = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Pause length="1"/>
  <Say voice="alice" language="en-US">Hello! This is ChatVybz phone verification.</Say>
  <Pause length="1"/>
  <Say voice="alice" language="en-US">Your verification code is:</Say>
  <Pause length="1"/>
  <Say voice="alice" language="en-US">${voiceOTP}</Say>
  <Pause length="2"/>
  <Say voice="alice" language="en-US">I repeat, your verification code is:</Say>
  <Pause length="1"/>
  <Say voice="alice" language="en-US">${voiceOTP}</Say>
  <Pause length="1"/>
  <Say voice="alice" language="en-US">Thank you for using ChatVybz. Goodbye.</Say>
</Response>`;

    // Make voice call via Twilio
    const twilioUrl = `https://api.twilio.com/2010-04-01/Accounts/${TWILIO_ACCOUNT_SID}/Calls.json`;
    const twilioAuth = btoa(`${TWILIO_ACCOUNT_SID}:${TWILIO_AUTH_TOKEN}`);

    console.log(`📤 Initiating voice call via Twilio...`);
    console.log(`From: ${TWILIO_PHONE_NUMBER}`);
    console.log(`To: ${e164Phone}`);

    const twilioParams = new URLSearchParams({
      To: e164Phone,
      From: TWILIO_PHONE_NUMBER,
      Twiml: twiml
    });

    const twilioResponse = await fetch(twilioUrl, {
      method: 'POST',
      headers: {
        'Authorization': `Basic ${twilioAuth}`,
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: twilioParams,
    });

    const responseText = await twilioResponse.text();
    console.log('Twilio response status:', twilioResponse.status);
    console.log('Twilio response:', responseText);

    if (!twilioResponse.ok) {
      console.error('❌ Twilio error:', responseText);

      let errorMessage = 'Failed to initiate voice call';
      let errorHint = 'Please check your phone number and try again';
      let errorCode = 'TWILIO_ERROR';

      try {
        const errorData = JSON.parse(responseText);
        console.error('Twilio error details:', errorData);

        if (errorData.code === 21211) {
          errorMessage = 'Invalid phone number';
          errorHint = 'Please check your phone number format';
          errorCode = 'INVALID_PHONE_NUMBER';
        } else if (errorData.code === 21408 || errorData.code === 21612) {
          errorMessage = 'Cannot call this number';
          errorHint = 'Your region may not support voice calls. Please try QR Code authentication';
          errorCode = 'UNSUPPORTED_REGION';
        } else if (errorData.message) {
          errorMessage = errorData.message;
          errorHint = 'Twilio error: ' + errorData.message;
        }
      } catch (e) {
        console.error('Failed to parse Twilio error:', e);
      }

      await supabase
        .from('phone_verification_attempts')
        .delete()
        .eq('id', otpData.id);

      return new Response(
        JSON.stringify({
          success: false,
          error: errorMessage,
          hint: errorHint,
          code: errorCode
        }),
        { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const twilioData = JSON.parse(responseText);
    console.log(`✅ Voice call initiated successfully (SID: ${twilioData.sid})`);

    return new Response(
      JSON.stringify({
        success: true,
        attemptId: otpData.id,
        expiresAt: expiresAt,
        phoneNumber: e164Phone,
        deliveryMethod: 'voice',
        callSid: twilioData.sid,
        message: 'Voice call initiated with verification code'
      }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('❌ Voice OTP error:', error);
    return new Response(
      JSON.stringify({
        success: false,
        error: error.message || 'Failed to send voice verification',
        hint: 'Internal server error. Please try again or contact support',
        code: 'INTERNAL_ERROR'
      }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});