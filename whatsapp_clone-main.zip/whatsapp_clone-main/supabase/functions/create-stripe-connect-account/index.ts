import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import Stripe from 'https://esm.sh/stripe@14.21.0';

declare const Deno: {
  env: {
    get(key: string): string | undefined;
  };
};

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req?.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY') || '', {
      apiVersion: '2023-10-16',
    })

    const supabaseClient = createClient(
      Deno?.env?.get('SUPABASE_URL') ?? '',
      Deno?.env?.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    if (req?.method === 'POST') {
      const { userId } = await req?.json()

      if (!userId) {
        return new Response(
          JSON.stringify({ error: 'User ID is required' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        )
      }

      // Get user profile
      const { data: profile, error: profileError } = await supabaseClient?.from('profiles')?.select('email, full_name')?.eq('id', userId)?.single()

      if (profileError) {
        return new Response(
          JSON.stringify({ error: 'User not found' }),
          { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        )
      }

      // Create Stripe Connect account
      const account = await stripe?.accounts?.create({
        type: 'express',
        email: profile?.email,
        capabilities: {
          card_payments: { requested: true },
          transfers: { requested: true },
        },
        business_type: 'individual',
        metadata: {
          supabase_user_id: userId
        }
      })

      // Create account link for onboarding
      const accountLink = await stripe?.accountLinks?.create({
        account: account?.id,
        refresh_url: `${Deno?.env?.get('APP_URL')}/channel-monetization-dashboard`,
        return_url: `${Deno?.env?.get('APP_URL')}/channel-monetization-dashboard?setup=complete`,
        type: 'account_onboarding',
      })

      // Save to database
      const { error: updateError } = await supabaseClient?.from('profiles')?.update({
          stripe_connect_account_id: account?.id,
          stripe_connect_onboarded: false
        })?.eq('id', userId)

      if (updateError) {
        console.error('Database error:', updateError)
      }

      return new Response(
        JSON.stringify({
          accountId: account.id,
          url: accountLink.url
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    return new Response(
      JSON.stringify({ error: 'Method not allowed' }),
      { status: 405, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )

  } catch (error) {
    console.error('Error:', error)
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})