import { serve } from "https://deno.land/std@0.192.0/http/server.ts";

serve(async (req) => {
  // ✅ CORS preflight
  if (req.method === "OPTIONS") {
    return new Response("ok", {
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "POST, OPTIONS",
        "Access-Control-Allow-Headers": "*"
      }
    });
  }

  try {
    const { reportType, recipientEmail, recipientName, data } = await req.json();

    if (!reportType || !recipientEmail || !data) {
      return new Response(JSON.stringify({
        error: "Missing required fields: reportType, recipientEmail, data"
      }), {
        status: 400,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*"
        }
      });
    }

    // ... Add this line to declare Deno if not available ... //
    const Deno = (globalThis as any).Deno;
    const RESEND_API_KEY = Deno.env.get("RESEND_API_KEY");
    if (!RESEND_API_KEY) {
      return new Response(JSON.stringify({
        error: "Resend API key not configured"
      }), {
        status: 500,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*"
        }
      });
    }

    // Generate email content based on report type
    let subject = "";
    let htmlContent = "";

    if (reportType === "creator_revenue") {
      subject = `Creator Revenue Report - ${new Date().toLocaleDateString()}`;
      htmlContent = generateCreatorRevenueEmail(recipientName, data);
    } else if (reportType === "call_metrics") {
      subject = `Call Analytics Report - ${new Date().toLocaleDateString()}`;
      htmlContent = generateCallMetricsEmail(recipientName, data);
    } else if (reportType === "subscriber_insights") {
      subject = `Subscriber Insights Report - ${new Date().toLocaleDateString()}`;
      htmlContent = generateSubscriberInsightsEmail(recipientName, data);
    } else {
      return new Response(JSON.stringify({
        error: "Invalid report type. Must be: creator_revenue, call_metrics, or subscriber_insights"
      }), {
        status: 400,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*"
        }
      });
    }

    // Send email via Resend API
    const resendResponse = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${RESEND_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        from: "onboarding@resend.dev",
        to: recipientEmail,
        subject: subject,
        html: htmlContent
      })
    });

    const resendData = await resendResponse.json();

    if (!resendResponse.ok) {
      return new Response(JSON.stringify({
        error: "Failed to send email",
        details: resendData
      }), {
        status: resendResponse.status,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*"
        }
      });
    }

    return new Response(JSON.stringify({
      success: true,
      message: "Analytics report sent successfully",
      emailId: resendData.id
    }), {
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*"
      }
    });
  } catch (error) {
    return new Response(JSON.stringify({
      error: error.message
    }), {
      status: 500,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*"
      }
    });
  }
});

function generateCreatorRevenueEmail(name: string, data: any): string {
  return `
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 8px 8px 0 0; }
        .content { background: #f9fafb; padding: 30px; border-radius: 0 0 8px 8px; }
        .metric-card { background: white; padding: 20px; margin: 15px 0; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .metric-title { font-size: 14px; color: #6b7280; text-transform: uppercase; margin-bottom: 8px; }
        .metric-value { font-size: 32px; font-weight: bold; color: #1f2937; }
        .metric-change { font-size: 14px; color: #10b981; margin-top: 8px; }
        .footer { text-align: center; margin-top: 30px; color: #6b7280; font-size: 12px; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>💰 Creator Revenue Report</h1>
          <p>Your earnings summary for ${new Date().toLocaleDateString()}</p>
        </div>
        <div class="content">
          <p>Hi ${name || 'Creator'},</p>
          <p>Here's your revenue performance summary:</p>
          
          <div class="metric-card">
            <div class="metric-title">Total Revenue</div>
            <div class="metric-value">$${(data.totalRevenue || 0).toFixed(2)}</div>
            <div class="metric-change">+${(data.revenueGrowth || 0).toFixed(1)}% from last period</div>
          </div>
          
          <div class="metric-card">
            <div class="metric-title">Subscription Revenue</div>
            <div class="metric-value">$${(data.subscriptionRevenue || 0).toFixed(2)}</div>
          </div>
          
          <div class="metric-card">
            <div class="metric-title">Ad Revenue</div>
            <div class="metric-value">$${(data.adRevenue || 0).toFixed(2)}</div>
          </div>
          
          <div class="metric-card">
            <div class="metric-title">Active Subscribers</div>
            <div class="metric-value">${data.activeSubscribers || 0}</div>
          </div>
          
          <p style="margin-top: 30px;">Keep up the great work! 🚀</p>
        </div>
        <div class="footer">
          <p>This is an automated report from ChatVybz Analytics</p>
        </div>
      </div>
    </body>
    </html>
  `;
}

function generateCallMetricsEmail(name: string, data: any): string {
  return `
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%); color: white; padding: 30px; text-align: center; border-radius: 8px 8px 0 0; }
        .content { background: #f9fafb; padding: 30px; border-radius: 0 0 8px 8px; }
        .metric-card { background: white; padding: 20px; margin: 15px 0; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .metric-title { font-size: 14px; color: #6b7280; text-transform: uppercase; margin-bottom: 8px; }
        .metric-value { font-size: 32px; font-weight: bold; color: #1f2937; }
        .metric-subtitle { font-size: 14px; color: #6b7280; margin-top: 8px; }
        .footer { text-align: center; margin-top: 30px; color: #6b7280; font-size: 12px; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>📞 Call Analytics Report</h1>
          <p>Your call performance metrics for ${new Date().toLocaleDateString()}</p>
        </div>
        <div class="content">
          <p>Hi ${name || 'User'},</p>
          <p>Here's your call activity summary:</p>
          
          <div class="metric-card">
            <div class="metric-title">Total Calls</div>
            <div class="metric-value">${data.totalCalls || 0}</div>
            <div class="metric-subtitle">${data.completedCalls || 0} completed, ${data.missedCalls || 0} missed</div>
          </div>
          
          <div class="metric-card">
            <div class="metric-title">Average Duration</div>
            <div class="metric-value">${Math.floor((data.avgDuration || 0) / 60)}m ${Math.floor((data.avgDuration || 0) % 60)}s</div>
          </div>
          
          <div class="metric-card">
            <div class="metric-title">Answer Rate</div>
            <div class="metric-value">${(data.answerRate || 0)}%</div>
          </div>
          
          <div class="metric-card">
            <div class="metric-title">Call Types</div>
            <div class="metric-subtitle">
              Voice: ${data.voiceCalls || 0} | Video: ${data.videoCalls || 0} | Conference: ${data.conferenceCalls || 0}
            </div>
          </div>
          
          <p style="margin-top: 30px;">Stay connected! 📱</p>
        </div>
        <div class="footer">
          <p>This is an automated report from ChatVybz Analytics</p>
        </div>
      </div>
    </body>
    </html>
  `;
}

function generateSubscriberInsightsEmail(name: string, data: any): string {
  return `
    <!DOCTYPE html>
    <html>
    <head>
      <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: white; padding: 30px; text-align: center; border-radius: 8px 8px 0 0; }
        .content { background: #f9fafb; padding: 30px; border-radius: 0 0 8px 8px; }
        .metric-card { background: white; padding: 20px; margin: 15px 0; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .metric-title { font-size: 14px; color: #6b7280; text-transform: uppercase; margin-bottom: 8px; }
        .metric-value { font-size: 32px; font-weight: bold; color: #1f2937; }
        .metric-change { font-size: 14px; color: #10b981; margin-top: 8px; }
        .footer { text-align: center; margin-top: 30px; color: #6b7280; font-size: 12px; }
      </style>
    </head>
    <body>
      <div class="container">
        <div class="header">
          <h1>👥 Subscriber Insights Report</h1>
          <p>Your audience growth metrics for ${new Date().toLocaleDateString()}</p>
        </div>
        <div class="content">
          <p>Hi ${name || 'Creator'},</p>
          <p>Here's your subscriber performance summary:</p>
          
          <div class="metric-card">
            <div class="metric-title">Total Subscribers</div>
            <div class="metric-value">${data.totalSubscribers || 0}</div>
            <div class="metric-change">+${data.newSubscribers || 0} new this period</div>
          </div>
          
          <div class="metric-card">
            <div class="metric-title">Engagement Rate</div>
            <div class="metric-value">${(data.engagementRate || 0).toFixed(1)}%</div>
          </div>
          
          <div class="metric-card">
            <div class="metric-title">Message Views</div>
            <div class="metric-value">${data.totalViews || 0}</div>
          </div>
          
          <div class="metric-card">
            <div class="metric-title">Top Performing Content</div>
            <div class="metric-subtitle">${data.topContent || 'No data available'}</div>
          </div>
          
          <p style="margin-top: 30px;">Your audience is growing! 🌟</p>
        </div>
        <div class="footer">
          <p>This is an automated report from ChatVybz Analytics</p>
        </div>
      </div>
    </body>
    </html>
  `;
}