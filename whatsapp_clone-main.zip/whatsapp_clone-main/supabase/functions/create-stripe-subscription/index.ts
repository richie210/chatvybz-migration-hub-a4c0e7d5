import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import Stripe from 'https://esm.sh/stripe@14.21.0';

// Add this block - Declare Deno types for the environment
declare const Deno: {
  env: {
    get(key: string): string | undefined;
  };
};

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req?.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY') || '', {
      apiVersion: '2023-10-16',
    })

    const supabaseClient = createClient(
      Deno?.env?.get('SUPABASE_URL') ?? '',
      Deno?.env?.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    if (req?.method === 'POST') {
      const { customerId, priceId, channelId, tierId, userId } = await req?.json()

      if (!customerId || !priceId || !channelId || !tierId || !userId) {
        return new Response(
          JSON.stringify({ error: 'Missing required parameters' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        )
      }

      // Create Stripe subscription
      const subscription = await stripe?.subscriptions?.create({
        customer: customerId,
        items: [{ price: priceId }],
        payment_behavior: 'default_incomplete',
        payment_settings: { save_default_payment_method: 'on_subscription' },
        expand: ['latest_invoice.payment_intent'],
        metadata: {
          channel_id: channelId,
          tier_id: tierId,
          user_id: userId
        }
      })

      // Save subscription to database
      const { data, error } = await supabaseClient?.from('channel_subscriptions')?.insert({
          channel_id: channelId,
          user_id: userId,
          tier_id: tierId,
          status: subscription?.status === 'active' ? 'active' : 'incomplete',
          stripe_subscription_id: subscription?.id,
          stripe_customer_id: customerId,
          current_period_start: new Date(subscription.current_period_start * 1000)?.toISOString(),
          current_period_end: new Date(subscription.current_period_end * 1000)?.toISOString()
        })?.select()?.single()

      if (error) {
        console.error('Database error:', error)
        // Cancel the Stripe subscription if database insert fails
        await stripe?.subscriptions?.cancel(subscription?.id)
        return new Response(
          JSON.stringify({ error: 'Failed to save subscription' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        )
      }

      // Get client secret from payment intent
      const clientSecret = subscription?.latest_invoice?.payment_intent?.client_secret

      return new Response(
        JSON.stringify({
          subscriptionId: subscription.id,
          clientSecret: clientSecret,
          status: subscription.status,
          subscription: data
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    return new Response(
      JSON.stringify({ error: 'Method not allowed' }),
      { status: 405, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )

  } catch (error) {
    console.error('Error:', error)
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})