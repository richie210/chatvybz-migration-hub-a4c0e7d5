// Supabase Edge Function for fetching link previews
// This avoids CORS issues when fetching metadata from external URLs

import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight
  if (req?.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { url } = await req?.json();

    if (!url) {
      return new Response(
        JSON.stringify({ error: 'URL is required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Fetch the URL
    const response = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (compatible; LinkPreviewBot/1.0)'
      }
    });

    if (!response?.ok) {
      throw new Error(`Failed to fetch URL: ${response.status}`);
    }

    const html = await response?.text();

    // Extract Open Graph tags
    const ogTitle = html?.match(/<meta property="og:title" content="([^"]*)"/)?.[1];
    const ogDescription = html?.match(/<meta property="og:description" content="([^"]*)"/)?.[1];
    const ogImage = html?.match(/<meta property="og:image" content="([^"]*)"/)?.[1];
    const ogSiteName = html?.match(/<meta property="og:site_name" content="([^"]*)"/)?.[1];

    // Fallback to standard meta tags
    const title = ogTitle || html?.match(/<title>([^<]*)<\/title>/)?.[1] || '';
    const description = ogDescription || html?.match(/<meta name="description" content="([^"]*)"/)?.[1] || '';
    const image = ogImage || html?.match(/<meta name="image" content="([^"]*)"/)?.[1] || null;

    // Extract favicon
    let favicon = html?.match(/<link rel="icon" href="([^"]*)"/)?.[1] ||
                  html?.match(/<link rel="shortcut icon" href="([^"]*)"/)?.[1];
    
    // Make favicon absolute URL if relative
    if (favicon && !favicon?.startsWith('http')) {
      const urlObj = new URL(url);
      favicon = `${urlObj?.origin}${favicon?.startsWith('/') ? '' : '/'}${favicon}`;
    }

    // Make image absolute URL if relative
    let absoluteImage = image;
    if (image && !image?.startsWith('http')) {
      const urlObj = new URL(url);
      absoluteImage = `${urlObj?.origin}${image?.startsWith('/') ? '' : '/'}${image}`;
    }

    const previewData = {
      title: title?.trim(),
      description: description?.trim(),
      image: absoluteImage,
      siteName: ogSiteName || new URL(url)?.hostname?.replace('www.', ''),
      favicon: favicon
    };

    return new Response(
      JSON.stringify(previewData),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error fetching link preview:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
