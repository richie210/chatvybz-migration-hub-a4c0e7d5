import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import Stripe from 'https://esm.sh/stripe@14.21.0';

// Add this block - Declare Deno interface for type safety
declare const Deno: {
  env: {
    get(key: string): string | undefined;
  };
};

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req?.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY') || '', {
      apiVersion: '2023-10-16',
    })

    const supabaseClient = createClient(
      Deno?.env?.get('SUPABASE_URL') ?? '',
      Deno?.env?.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    if (req?.method === 'POST') {
      const { channelId, creatorId, amount } = await req?.json()

      if (!channelId || !creatorId || !amount) {
        return new Response(
          JSON.stringify({ error: 'Missing required parameters' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        )
      }

      // Minimum payout amount
      if (amount < 50) {
        return new Response(
          JSON.stringify({ error: 'Minimum payout amount is $50' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        )
      }

      // Get creator's Stripe Connect account
      const { data: profile, error: profileError } = await supabaseClient?.from('profiles')?.select('stripe_connect_account_id, stripe_connect_onboarded')?.eq('id', creatorId)?.single()

      if (profileError || !profile?.stripe_connect_account_id) {
        return new Response(
          JSON.stringify({ error: 'Stripe Connect account not found. Please complete onboarding first.' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        )
      }

      if (!profile?.stripe_connect_onboarded) {
        return new Response(
          JSON.stringify({ error: 'Please complete Stripe Connect onboarding first' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        )
      }

      // Calculate period (last 30 days)
      const periodEnd = new Date()
      const periodStart = new Date()
      periodStart?.setDate(periodStart?.getDate() - 30)

      // Get revenue breakdown
      const { data: revenueSplits, error: revenueError } = await supabaseClient?.from('channel_revenue_splits')?.select('*')?.eq('channel_id', channelId)?.gte('period_start', periodStart?.toISOString())

      if (revenueError) {
        console.error('Revenue error:', revenueError)
      }

      // Create payout record
      const { data: payout, error: payoutError } = await supabaseClient?.from('creator_payouts')?.insert({
          channel_id: channelId,
          creator_id: creatorId,
          amount: amount,
          currency: 'USD',
          status: 'pending',
          stripe_connect_account_id: profile?.stripe_connect_account_id,
          period_start: periodStart?.toISOString(),
          period_end: periodEnd?.toISOString(),
          revenue_breakdown: {
            subscription_revenue: revenueSplits?.filter(r => r?.revenue_type === 'subscription')?.reduce((sum, r) => sum + parseFloat(r?.creator_earnings), 0) || 0,
            ad_revenue: revenueSplits?.filter(r => r?.revenue_type === 'ad_revenue')?.reduce((sum, r) => sum + parseFloat(r?.creator_earnings), 0) || 0
          }
        })?.select()?.single()

      if (payoutError) {
        console.error('Payout error:', payoutError)
        return new Response(
          JSON.stringify({ error: 'Failed to create payout record' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        )
      }

      // Create Stripe transfer
      try {
        const transfer = await stripe?.transfers?.create({
          amount: Math.round(amount * 100), // Convert to cents
          currency: 'usd',
          destination: profile?.stripe_connect_account_id,
          metadata: {
            payout_id: payout?.id,
            channel_id: channelId,
            creator_id: creatorId
          }
        })

        // Update payout with Stripe transfer ID
        await supabaseClient?.from('creator_payouts')?.update({
            stripe_payout_id: transfer?.id,
            status: 'processing',
            updated_at: new Date()?.toISOString()
          })?.eq('id', payout?.id)

        return new Response(
          JSON.stringify({
            success: true,
            payout: payout,
            transfer: transfer
          }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        )
      } catch (stripeError) {
        // Update payout status to failed
        await supabaseClient?.from('creator_payouts')?.update({
            status: 'failed',
            updated_at: new Date()?.toISOString()
          })?.eq('id', payout?.id)

        return new Response(
          JSON.stringify({ error: `Stripe transfer failed: ${stripeError.message}` }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        )
      }
    }

    return new Response(
      JSON.stringify({ error: 'Method not allowed' }),
      { status: 405, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )

  } catch (error) {
    console.error('Error:', error)
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})