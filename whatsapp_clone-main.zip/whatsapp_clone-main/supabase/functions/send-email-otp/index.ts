import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.39.3';

declare const Deno: {
  env: {
    get(key: string): string | undefined;
  };
};

const RESEND_API_KEY = Deno.env.get('RESEND_API_KEY');
const SUPABASE_URL = Deno.env.get('SUPABASE_URL');
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface SendEmailOTPRequest {
  email: string;
  phoneNumber: string;
  countryCode: string;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    console.log('📧 Email OTP request received');

    if (!RESEND_API_KEY) {
      console.error('❌ Resend API key missing');
      return new Response(
        JSON.stringify({
          success: false,
          error: 'Email service not configured',
          hint: 'Resend API key is not configured. Please contact support',
          code: 'SERVICE_UNAVAILABLE'
        }),
        { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    if (!SUPABASE_URL || !SUPABASE_SERVICE_ROLE_KEY) {
      console.error('❌ Supabase credentials missing');
      return new Response(
        JSON.stringify({
          success: false,
          error: 'Database service not configured',
          hint: 'Please contact support',
          code: 'SERVICE_UNAVAILABLE'
        }),
        { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const { email, phoneNumber, countryCode }: SendEmailOTPRequest = await req.json();

    if (!email || !phoneNumber || !countryCode) {
      return new Response(
        JSON.stringify({ 
          success: false,
          error: 'Email, phone number, and country code are required',
          code: 'INVALID_INPUT'
        }),
        { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const cleanPhone = phoneNumber.replace(/\D/g, '');
    const cleanCode = countryCode.replace(/\D/g, '');
    const e164Phone = `+${cleanCode}${cleanPhone}`;
    console.log(`📧 Email to: ${email} for phone: ${e164Phone}`);

    const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY);

    // Check rate limit
    const fifteenMinutesAgo = new Date(Date.now() - 15 * 60 * 1000).toISOString();
    const { data: recentAttempts, error: rateLimitError } = await supabase
      .from('phone_verification_attempts')
      .select('id')
      .eq('phone_number', e164Phone)
      .gte('created_at', fifteenMinutesAgo);

    if (rateLimitError) {
      console.error('Rate limit check error:', rateLimitError);
    }

    if (recentAttempts && recentAttempts.length >= 5) {
      return new Response(
        JSON.stringify({
          success: false,
          error: 'Too many verification attempts',
          hint: 'Please wait 15 minutes before trying again',
          code: 'RATE_LIMIT_EXCEEDED'
        }),
        { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Generate 6-digit OTP
    const otpCode = Math.floor(100000 + Math.random() * 900000).toString();
    console.log(`🔢 Generated OTP for ${e164Phone}`);

    // Store OTP in database
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000).toISOString();
    const { data: otpData, error: otpError } = await supabase
      .from('phone_verification_attempts')
      .insert({
        phone_number: e164Phone,
        country_code: countryCode.startsWith('+') ? countryCode : `+${countryCode.replace(/\D/g, '')}`,
        otp_code: otpCode,
        expires_at: expiresAt,
        attempts_count: 0,
        is_verified: false,
        delivery_method: 'email'
      })
      .select()
      .single();

    if (otpError) {
      console.error('❌ Database error:', otpError);
      return new Response(
        JSON.stringify({
          success: false,
          error: 'Failed to generate verification code',
          hint: 'Please try again',
          code: 'DATABASE_ERROR'
        }),
        { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`✅ OTP stored in database (ID: ${otpData.id})`);

    // Send email via Resend
    const emailHtml = `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; text-align: center; border-radius: 10px 10px 0 0; }
            .content { background: #f9f9f9; padding: 30px; border-radius: 0 0 10px 10px; }
            .otp-code { font-size: 32px; font-weight: bold; color: #667eea; text-align: center; padding: 20px; background: white; border-radius: 8px; margin: 20px 0; letter-spacing: 8px; }
            .footer { text-align: center; margin-top: 20px; color: #666; font-size: 12px; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>ChatVybz Verification</h1>
            </div>
            <div class="content">
              <p>Hello,</p>
              <p>You requested a verification code for your phone number: <strong>${e164Phone}</strong></p>
              <p>Your verification code is:</p>
              <div class="otp-code">${otpCode}</div>
              <p><strong>This code will expire in 10 minutes.</strong></p>
              <p>If you didn't request this code, please ignore this email.</p>
              <p>For security reasons, never share this code with anyone.</p>
            </div>
            <div class="footer">
              <p>© 2026 ChatVybz. All rights reserved.</p>
            </div>
          </div>
        </body>
      </html>
    `;

    console.log(`📤 Sending email to ${email}...`);

    const resendResponse = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${RESEND_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        from: 'ChatVybz <onboarding@resend.dev>',
        to: [email],
        subject: `Your ChatVybz Verification Code: ${otpCode}`,
        html: emailHtml,
      }),
    });

    if (!resendResponse.ok) {
      const resendError = await resendResponse.text();
      console.error('❌ Resend error:', resendError);

      let errorMessage = 'Failed to send email';
      let errorHint = 'Please check your email address and try again';
      let errorCode = 'EMAIL_DELIVERY_FAILED';

      try {
        const errorData = JSON.parse(resendError);
        console.error('Resend error details:', errorData);
        if (errorData.message) {
          errorMessage = errorData.message;
        }
      } catch (e) {
        console.error('Failed to parse Resend error:', e);
      }

      // Delete the OTP record since delivery failed
      await supabase
        .from('phone_verification_attempts')
        .delete()
        .eq('id', otpData.id);

      return new Response(
        JSON.stringify({
          success: false,
          error: errorMessage,
          hint: errorHint,
          code: errorCode
        }),
        { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const resendData = await resendResponse.json();
    console.log(`✅ Email sent successfully (ID: ${resendData.id})`);

    return new Response(
      JSON.stringify({
        success: true,
        attemptId: otpData.id,
        expiresAt: expiresAt,
        phoneNumber: e164Phone,
        deliveryMethod: 'email',
        emailId: resendData.id,
        message: 'Verification code sent to your email'
      }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('❌ Email OTP error:', error);
    return new Response(
      JSON.stringify({
        success: false,
        error: error.message || 'Failed to send email verification',
        hint: 'Please contact support',
        code: 'INTERNAL_ERROR'
      }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});