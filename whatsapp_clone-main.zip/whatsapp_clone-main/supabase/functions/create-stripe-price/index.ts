import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import Stripe from 'https://esm.sh/stripe@14.21.0';

const Deno = globalThis.Deno;

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req?.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY') || '', {
      apiVersion: '2023-10-16',
    })

    const supabaseClient = createClient(
      Deno?.env?.get('SUPABASE_URL') ?? '',
      Deno?.env?.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    if (req?.method === 'POST') {
      const { channelId, tierData } = await req?.json()

      if (!channelId || !tierData) {
        return new Response(
          JSON.stringify({ error: 'Channel ID and tier data are required' }),
          { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        )
      }

      // Get channel details
      const { data: channel, error: channelError } = await supabaseClient?.from('channels')?.select('name, username')?.eq('id', channelId)?.single()

      if (channelError) {
        return new Response(
          JSON.stringify({ error: 'Channel not found' }),
          { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        )
      }

      // Create Stripe product
      const product = await stripe?.products?.create({
        name: `${channel?.name} - ${tierData?.name}`,
        description: `Premium subscription for ${channel?.name} channel`,
        metadata: {
          channel_id: channelId,
          channel_username: channel?.username || ''
        }
      })

      // Create Stripe price
      const price = await stripe?.prices?.create({
        product: product?.id,
        unit_amount: tierData?.amount,
        currency: tierData?.currency?.toLowerCase(),
        recurring: {
          interval: tierData?.interval
        },
        metadata: {
          channel_id: channelId
        }
      })

      return new Response(
        JSON.stringify({
          productId: product.id,
          priceId: price.id,
          amount: tierData.amount,
          currency: tierData.currency,
          interval: tierData.interval
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    return new Response(
      JSON.stringify({ error: 'Method not allowed' }),
      { status: 405, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )

  } catch (error) {
    console.error('Error:', error)
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})