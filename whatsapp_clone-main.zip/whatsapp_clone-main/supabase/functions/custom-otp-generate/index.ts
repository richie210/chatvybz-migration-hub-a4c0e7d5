import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.39.3';

declare const Deno: {
  env: {
    get(key: string): string | undefined;
  };
};

const SUPABASE_URL = Deno.env.get('SUPABASE_URL');
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface GenerateOTPRequest {
  phoneNumber: string;
  countryCode: string;
  ipAddress?: string;
  userAgent?: string;
}

interface RateLimitResult {
  allowed: boolean;
  requests_remaining: number;
  reset_at?: string;
  message?: string;
}

/**
 * Generate cryptographically secure 6-digit OTP using CSPRNG
 * Uses Web Crypto API for secure random generation
 */
function generateSecureOTP(): string {
  const array = new Uint32Array(1);
  crypto.getRandomValues(array);
  
  // Generate 6-digit code (100000 to 999999)
  const otp = (array[0] % 900000) + 100000;
  return otp.toString();
}

/**
 * Hash OTP using Web Crypto API (PBKDF2)
 * This replaces bcrypt to avoid Worker dependency issues
 */
async function hashOTP(otp: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(otp);
  
  // Generate a random salt
  const salt = crypto.getRandomValues(new Uint8Array(16));
  
  // Import key for PBKDF2
  const keyMaterial = await crypto.subtle.importKey(
    'raw',
    data,
    { name: 'PBKDF2' },
    false,
    ['deriveBits']
  );
  
  // Derive bits using PBKDF2
  const derivedBits = await crypto.subtle.deriveBits(
    {
      name: 'PBKDF2',
      salt: salt,
      iterations: 100000,
      hash: 'SHA-256'
    },
    keyMaterial,
    256
  );
  
  // Combine salt and hash for storage
  const hashArray = new Uint8Array(derivedBits);
  const combined = new Uint8Array(salt.length + hashArray.length);
  combined.set(salt);
  combined.set(hashArray, salt.length);
  
  // Convert to base64 for storage
  return btoa(String.fromCharCode(...combined));
}

/**
 * Verify OTP against stored hash
 */
async function verifyOTP(otp: string, storedHash: string): Promise<boolean> {
  try {
    const encoder = new TextEncoder();
    const data = encoder.encode(otp);
    
    // Decode stored hash
    const combined = Uint8Array.from(atob(storedHash), c => c.charCodeAt(0));
    const salt = combined.slice(0, 16);
    const hash = combined.slice(16);
    
    // Import key for PBKDF2
    const keyMaterial = await crypto.subtle.importKey(
      'raw',
      data,
      { name: 'PBKDF2' },
      false,
      ['deriveBits']
    );
    
    // Derive bits using same parameters
    const derivedBits = await crypto.subtle.deriveBits(
      {
        name: 'PBKDF2',
        salt: salt,
        iterations: 100000,
        hash: 'SHA-256'
      },
      keyMaterial,
      256
    );
    
    const derivedHash = new Uint8Array(derivedBits);
    
    // Compare hashes
    if (derivedHash.length !== hash.length) return false;
    
    let match = true;
    for (let i = 0; i < derivedHash.length; i++) {
      if (derivedHash[i] !== hash[i]) {
        match = false;
        break;
      }
    }
    
    return match;
  } catch (error) {
    console.error('OTP verification error:', error);
    return false;
  }
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    // Parse request body
    const { phoneNumber, countryCode, ipAddress, userAgent }: GenerateOTPRequest = await req.json();

    if (!phoneNumber || !countryCode) {
      return new Response(
        JSON.stringify({ error: 'Phone number and country code are required' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Format phone number to E.164
    const cleanPhone = phoneNumber.replace(/\D/g, '');
    const cleanCode = countryCode.replace(/\D/g, '');
    const e164Phone = `+${cleanCode}${cleanPhone}`;

    // Initialize Supabase client
    const supabase = createClient(SUPABASE_URL!, SUPABASE_SERVICE_ROLE_KEY!);

    // Check rate limit (max 3 OTP requests per hour)
    const { data: rateLimitData, error: rateLimitError } = await supabase.rpc(
      'check_otp_generation_rate_limit',
      {
        p_phone_number: e164Phone,
        p_country_code: `+${cleanCode}`,
      }
    );

    if (rateLimitError) {
      console.error('Rate limit check error:', rateLimitError);
      throw new Error('Failed to check rate limit');
    }

    const rateLimit = rateLimitData as unknown as RateLimitResult[];
    const rateLimitResult = rateLimit[0];

    if (!rateLimitResult.allowed) {
      return new Response(
        JSON.stringify({
          error: rateLimitResult.message || 'Rate limit exceeded',
          resetAt: rateLimitResult.reset_at,
          requestsRemaining: 0,
        }),
        { status: 429, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Generate secure 6-digit OTP using CSPRNG
    const otpCode = generateSecureOTP();
    console.log('Generated OTP (will be hashed):', otpCode);

    // Hash OTP with Web Crypto API (PBKDF2)
    const otpHash = await hashOTP(otpCode);

    // Calculate expiration time (5 minutes as per guide)
    const expiresAt = new Date(Date.now() + 5 * 60 * 1000).toISOString();

    // Store hashed OTP in database
    const { data: otpData, error: otpError } = await supabase
      .from('phone_verification_attempts')
      .insert({
        phone_number: e164Phone,
        country_code: `+${cleanCode}`,
        otp_code: otpCode, // Temporary: will be removed after hashing migration
        otp_hash: otpHash,
        expires_at: expiresAt,
        attempts_count: 0,
        max_attempts: 3,
        is_verified: false,
        delivery_method: 'whatsapp',
        delivery_status: 'pending',
        ip_address: ipAddress || null,
        user_agent: userAgent || null,
      })
      .select()
      .single();

    if (otpError) {
      console.error('OTP storage error:', otpError);
      throw new Error('Failed to generate OTP');
    }

    console.log('OTP stored with hash. Attempt ID:', otpData.id);

    // TODO: Integrate WhatsApp Business API for delivery
    // For now, return success with OTP for testing (remove in production)
    // In production, this would call WhatsApp Business API
    
    // Simulate WhatsApp delivery (replace with actual WhatsApp Business API call)
    const deliverySuccess = true; // Replace with actual API call result

    if (deliverySuccess) {
      // Update delivery status
      await supabase
        .from('phone_verification_attempts')
        .update({ delivery_status: 'sent' })
        .eq('id', otpData.id);
    }

    // Return success response
    return new Response(
      JSON.stringify({
        success: true,
        attemptId: otpData.id,
        message: 'OTP sent successfully to your phone via WhatsApp',
        expiresAt: expiresAt,
        requestsRemaining: rateLimitResult.requests_remaining - 1,
        // TESTING ONLY: Remove in production
        testOTP: otpCode, // For testing without WhatsApp integration
      }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('OTP generation error:', error);
    return new Response(
      JSON.stringify({ error: error.message || 'Internal server error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});